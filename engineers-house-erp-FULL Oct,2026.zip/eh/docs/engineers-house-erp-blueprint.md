# Engineers House ERP — Phase 1 Engineering Blueprint

**Slogan:** One Platform for Training, Projects, Engineering, and Industrial Solutions
**Document:** Foundation + CRM + Training/LMS + Finance-lite
**Status:** Blueprint for build — design frozen for Phase 1, roadmap for Phases 2–4
**Audience:** Founder, product owner, and the development team that will implement it

---

## 1. How to read this document

This is **not** a spec for all 13 modules at once. Specifying everything before shipping anything is how ERP projects die. This blueprint fully specifies the **Phase 1 core** — the modules that touch revenue and daily operations first — and sequences the rest into a roadmap (Section 8). Build Phase 1, get real users on it, then open the next envelope.

---

## 2. Architecture decisions (ADRs)

These are the load-bearing choices. Each can be revisited, but changing them mid-build is expensive — so they're settled here.

| # | Decision | Choice | Rationale |
|---|----------|--------|-----------|
| ADR-1 | Topology | **Modular monolith** (one FastAPI service, one Next.js app, one PostgreSQL DB) | At ~100 users, microservices multiply DevOps cost and slow every feature. Clean module boundaries inside one process scale comfortably past 1000 users. Extract a service later *only* when a measured bottleneck demands it. |
| ADR-2 | Tenancy | **Tenant-aware, single-tenant deployment** | Every core table carries `tenant_id` and every query is tenant-scoped, so going SaaS later is a deployment change, not a rewrite. But run one shared instance for Engineers House now — skip per-tenant DB isolation until a paying external customer justifies it. |
| ADR-3 | Phase 1 infrastructure | PostgreSQL + Redis + Docker Compose | Redis earns its place early (sessions, cache, rate-limit, Celery broker). **Deferred:** Elasticsearch, Qdrant, Kubernetes, microservices, Superset/Power BI — see Section 8. |
| ADR-4 | Auth | JWT (short access + rotating refresh) + RBAC + TOTP 2FA | OAuth2 social login is Phase 2. Start with email/password + 2FA, which covers an internal team. |
| ADR-5 | Backend layering | Repository + Service per module, DDD-lite | Routers stay thin; business rules live in services; data access in repositories. Enough discipline for maintainability without ceremony overhead. |
| ADR-6 | i18n | Arabic + English, RTL/LTR from day one | Retrofitting RTL is painful. Bake `dir` switching, `next-intl`, and UTF-8 everywhere into the foundation. |

---

## 3. Phase 1 technology stack

| Layer | Technology | Notes |
|-------|-----------|-------|
| Frontend | Next.js + TypeScript + Tailwind + shadcn/ui | React Query for server state, Zustand for client state, `next-intl` for AR/EN + RTL, dark/light theme. |
| Backend | Python + FastAPI | REST now; WebSocket reserved for live dashboards (Phase 2). |
| ORM / migrations | SQLAlchemy 2.x + Alembic | Migrations versioned from commit one. |
| Database | PostgreSQL | Single primary; add a read replica only if reporting load demands it. |
| Cache / queue | Redis | Cache, session/refresh-token store, rate limiting, Celery broker. |
| Background jobs | Celery + Redis | Email/notification dispatch, certificate generation, scheduled installment reminders. |
| Storage | S3-compatible (AWS S3 or Supabase Storage) | Course videos, datasheets, certificate PDFs. |
| Auth | python-jose / passlib (argon2), pyotp (2FA) | |
| Containerization | Docker + docker-compose (dev), single VM/container host (Phase 1 prod) | |
| CI | GitHub Actions | Lint + type-check + unit/integration tests on every PR. |

---

## 4. Software Requirements Specification (Phase 1)

### 4.1 Purpose & scope
A cloud-based ERP for an industrial automation training-and-services company. Phase 1 delivers identity/access control, customer relationship management, training/LMS operations, and the shared finance layer that connects quotations and enrollments to money.

### 4.2 Personas
- **Super Admin** — owns configuration, roles, tenant settings.
- **Operations Manager** — cross-module visibility, approvals.
- **Sales Agent** — owns leads, opportunities, quotations.
- **Training Coordinator** — courses, cohorts, enrollments, attendance, certificates.
- **Instructor** — own sessions, attendance marking, evaluations.
- **Accountant** — invoices, payments, installment plans, financial reports.
- **Student** — self-service portal: enrollments, attendance, payments, certificates.

### 4.3 Functional requirements

**Identity & Access (IAM)**
- IAM-FR-01 — Email/password authentication with argon2 hashing and account lockout after N failed attempts.
- IAM-FR-02 — Optional TOTP 2FA per user; enforced for Admin/Accountant roles.
- IAM-FR-03 — Short-lived access tokens (15 min) + rotating refresh tokens stored server-side in Redis; refresh reuse triggers session revocation.
- IAM-FR-04 — RBAC: users hold roles; roles hold permissions (`module:action`); permission checks enforced in service layer, not just UI.
- IAM-FR-05 — Append-only audit log on every create/update/delete of business entities (who, what, before/after, IP, timestamp).
- IAM-FR-06 — All data access is tenant-scoped; no query may return cross-tenant rows.

**CRM**
- CRM-FR-01 — Capture leads with source, owner, and status; convert a lead into an Account + Contact + Opportunity in one action.
- CRM-FR-02 — Manage Accounts (companies) and Contacts with ownership.
- CRM-FR-03 — Opportunity pipeline with configurable stages, value, probability, and expected close date.
- CRM-FR-04 — Quotations with line items, tax, validity date, and status (draft → sent → accepted/rejected); accepted quotation can generate an Invoice.
- CRM-FR-05 — Activities (call/meeting/task) linked to any account, contact, or opportunity, with due dates and reminders.
- CRM-FR-06 — Dashboard: conversion rate, pipeline value by stage, lead source breakdown.

**Training / LMS**
- LMS-FR-01 — Course catalog with category (PLC, SCADA, HMI, Instrumentation, AC Drive, Classic Control, Electrical Distribution, Mechanical Power, CMMS), price, duration, and delivery mode (onsite/online/hybrid).
- LMS-FR-02 — Cohorts (course offerings) with instructor, capacity, schedule, and status.
- LMS-FR-03 — Sessions (individual class meetings) under a cohort with date/time and mode.
- LMS-FR-04 — Student records and enrollments into cohorts with fee and discount.
- LMS-FR-05 — Attendance per session per student (present/absent/late), markable by instructor.
- LMS-FR-06 — Installment plans on enrollments; automatic reminders before due dates.
- LMS-FR-07 — Certificate generation with unique serial + public verification code; PDF stored in object storage.
- LMS-FR-08 — Instructor revenue-share percentage recorded per cohort for payout reporting.

**Finance-lite (shared)**
- FIN-FR-01 — Invoices generated from a source (quotation **or** enrollment), with line items, tax, total, and running balance.
- FIN-FR-02 — Payments recorded against invoices (method, reference, date); balance updates automatically.
- FIN-FR-03 — Installment schedule view with paid/overdue status.
- FIN-FR-04 — Basic financial dashboard: revenue, outstanding balance, payments by period.

### 4.4 Non-functional requirements
- NFR-01 — P95 API response < 2 s under 100 concurrent users; architecture must scale to 1000 without redesign.
- NFR-02 — Target availability 99.5%; daily automated backups + point-in-time recovery.
- NFR-03 — Encryption in transit (TLS) and at rest (DB + object storage).
- NFR-04 — Rate limiting (Redis-backed) on auth and write endpoints.
- NFR-05 — Full Arabic + English UI with correct RTL/LTR layout; all user-facing strings externalized.
- NFR-06 — Responsive across desktop, tablet, mobile web; dark/light themes.
- NFR-07 — GDPR-ready: per-subject data export and delete; audit of access to personal data.

### 4.5 Explicitly out of scope for Phase 1
Project Management, Technical Office, Inventory/Procurement, CMMS, Event Management, Marketing, Knowledge Base, AI Engineering Assistant, native mobile apps, full double-entry accounting (P&L/balance sheet), Elasticsearch search, microservices. All are scheduled in Section 8.

---

## 5. Entity-Relationship Diagram (Phase 1 core)

```mermaid
erDiagram
    TENANT ||--o{ USER : has
    TENANT ||--o{ ROLE : defines
    USER }o--o{ ROLE : "user_role"
    ROLE }o--o{ PERMISSION : "role_permission"
    USER ||--o{ AUDIT_LOG : generates

    TENANT ||--o{ ACCOUNT : owns
    ACCOUNT ||--o{ CONTACT : has
    ACCOUNT ||--o{ OPPORTUNITY : has
    USER ||--o{ OPPORTUNITY : owns
    OPPORTUNITY ||--o{ QUOTATION : produces
    QUOTATION ||--o{ QUOTATION_LINE : contains
    ACCOUNT ||--o{ ACTIVITY : "related_to"

    TENANT ||--o{ COURSE : offers
    COURSE ||--o{ COHORT : "scheduled_as"
    INSTRUCTOR ||--o{ COHORT : teaches
    COHORT ||--o{ SESSION : "made_of"
    STUDENT ||--o{ ENROLLMENT : has
    COHORT ||--o{ ENROLLMENT : receives
    ENROLLMENT ||--o{ ATTENDANCE : tracked_by
    SESSION ||--o{ ATTENDANCE : "recorded_in"
    ENROLLMENT ||--o| CERTIFICATE : earns

    INVOICE ||--o{ INVOICE_LINE : contains
    INVOICE ||--o{ PAYMENT : "settled_by"
    QUOTATION ||--o| INVOICE : "billed_as"
    ENROLLMENT ||--o| INVOICE : "billed_as"

    TENANT {
        uuid id PK
        string name
        string slug
        jsonb settings
    }
    USER {
        uuid id PK
        uuid tenant_id FK
        string email
        string hashed_password
        string full_name
        string phone
        bool is_2fa_enabled
        string status
    }
    ROLE {
        uuid id PK
        uuid tenant_id FK
        string name
        bool is_system
    }
    PERMISSION {
        uuid id PK
        string code
        string module
    }
    AUDIT_LOG {
        uuid id PK
        uuid tenant_id FK
        uuid user_id FK
        string action
        string entity_type
        uuid entity_id
        jsonb before
        jsonb after
        timestamp created_at
    }
    ACCOUNT {
        uuid id PK
        uuid tenant_id FK
        string name
        string type
        string industry
        uuid owner_id FK
    }
    CONTACT {
        uuid id PK
        uuid account_id FK
        string name
        string email
        string phone
        string position
    }
    OPPORTUNITY {
        uuid id PK
        uuid tenant_id FK
        uuid account_id FK
        string title
        string stage
        decimal value
        int probability
        date expected_close
        uuid owner_id FK
    }
    QUOTATION {
        uuid id PK
        uuid account_id FK
        uuid opportunity_id FK
        string number
        string status
        date valid_until
        decimal subtotal
        decimal tax
        decimal total
    }
    QUOTATION_LINE {
        uuid id PK
        uuid quotation_id FK
        string description
        decimal qty
        decimal unit_price
        decimal line_total
    }
    ACTIVITY {
        uuid id PK
        uuid tenant_id FK
        string type
        string subject
        timestamp due_at
        string status
        string related_type
        uuid related_id
        uuid owner_id FK
    }
    COURSE {
        uuid id PK
        uuid tenant_id FK
        string code
        string title
        string category
        int duration_hours
        decimal price
        string mode
    }
    INSTRUCTOR {
        uuid id PK
        uuid tenant_id FK
        uuid user_id FK
        string name
        string specialization
        decimal revenue_share_pct
    }
    COHORT {
        uuid id PK
        uuid course_id FK
        uuid instructor_id FK
        date start_date
        date end_date
        int capacity
        string location
        string status
    }
    SESSION {
        uuid id PK
        uuid cohort_id FK
        string title
        timestamp scheduled_at
        int duration_min
        string mode
    }
    STUDENT {
        uuid id PK
        uuid tenant_id FK
        string full_name
        string email
        string phone
    }
    ENROLLMENT {
        uuid id PK
        uuid student_id FK
        uuid cohort_id FK
        string status
        decimal total_fee
        decimal discount
        timestamp enrolled_at
    }
    ATTENDANCE {
        uuid id PK
        uuid session_id FK
        uuid enrollment_id FK
        string status
        timestamp marked_at
    }
    CERTIFICATE {
        uuid id PK
        uuid enrollment_id FK
        string serial
        string verification_code
        timestamp issued_at
    }
    INVOICE {
        uuid id PK
        uuid tenant_id FK
        string source_type
        uuid source_id
        string number
        string status
        decimal total
        decimal balance
    }
    INVOICE_LINE {
        uuid id PK
        uuid invoice_id FK
        string description
        decimal qty
        decimal unit_price
        decimal line_total
    }
    PAYMENT {
        uuid id PK
        uuid invoice_id FK
        decimal amount
        string method
        string reference
        timestamp paid_at
    }
```

---

## 6. Roles & permissions matrix (Phase 1)

Access levels: **F** = full (view/create/edit/delete) · **W** = create/edit · **R** = read-only · **O** = own records only · **A** = approve · **—** = no access.

| Module | Super Admin | Ops Manager | Sales Agent | Training Coord. | Instructor | Accountant | Student |
|--------|:-----------:|:-----------:|:-----------:|:---------------:|:----------:|:----------:|:-------:|
| IAM / Users & Roles | F | R | — | — | — | — | — |
| Audit log | F | R | — | — | — | R | — |
| CRM — Accounts/Contacts | F | F | O | — | — | R | — |
| CRM — Opportunities/Pipeline | F | F | O | — | — | R | — |
| CRM — Quotations | F | A | W (O) | — | — | R | — |
| Training — Courses | F | F | — | F | R | R | R |
| Training — Cohorts/Sessions | F | F | — | F | O | R | R (own) |
| Training — Students/Enrollments | F | F | — | F | R | R | O |
| Training — Attendance | F | R | — | W | W (own) | — | R (own) |
| Training — Certificates | F | A | — | W | — | R | R (own) |
| Finance — Invoices | F | R | R | R | — | F | R (own) |
| Finance — Payments | F | R | — | R | — | F | R (own) |
| Dashboards | F | F | O | training | own | finance | own |

> The permission catalog is `module:action` codes (e.g. `crm.quotation.approve`). Roles are data, not code — new roles can be composed without redeploying.

---

## 7. Repository / folder structure (monorepo)

```
engineers-house-erp/
├── apps/
│   ├── api/                         # FastAPI backend (modular monolith)
│   │   ├── app/
│   │   │   ├── main.py
│   │   │   ├── core/                # config, db session, security, middleware, i18n
│   │   │   │   ├── config.py
│   │   │   │   ├── database.py
│   │   │   │   ├── security.py      # JWT, hashing, 2FA
│   │   │   │   ├── rbac.py          # permission dependency
│   │   │   │   ├── tenancy.py       # tenant context + query scoping
│   │   │   │   └── audit.py
│   │   │   ├── modules/
│   │   │   │   ├── identity/        # users, roles, permissions, auth
│   │   │   │   │   ├── router.py
│   │   │   │   │   ├── schemas.py
│   │   │   │   │   ├── models.py
│   │   │   │   │   ├── service.py
│   │   │   │   │   └── repository.py
│   │   │   │   ├── crm/             # accounts, contacts, opportunities, quotations, activities
│   │   │   │   ├── training/        # courses, cohorts, sessions, students, enrollments, attendance, certificates
│   │   │   │   └── finance/         # invoices, payments
│   │   │   ├── workers/             # Celery tasks (notifications, certificates, reminders)
│   │   │   └── shared/              # common schemas, enums, exceptions, pagination
│   │   ├── alembic/                 # migrations
│   │   ├── tests/                   # unit + integration
│   │   ├── pyproject.toml
│   │   └── Dockerfile
│   │
│   └── web/                         # Next.js frontend
│       ├── src/
│       │   ├── app/                 # App Router (locale-segmented: /[locale]/...)
│       │   ├── components/          # shared UI (shadcn-based)
│       │   ├── features/            # crm/, training/, finance/, auth/  (mirrors API modules)
│       │   ├── lib/                 # api client, react-query, auth, rbac guards
│       │   ├── stores/              # Zustand
│       │   ├── i18n/                # ar/en message catalogs, RTL handling
│       │   └── styles/
│       ├── package.json
│       └── Dockerfile
│
├── packages/
│   └── shared-types/                # TypeScript types generated from API OpenAPI schema
│
├── infra/
│   ├── docker-compose.yml           # api, web, postgres, redis, worker
│   ├── docker-compose.prod.yml
│   └── env/                         # .env.example templates
│
├── .github/workflows/              # CI: lint, type-check, test
│   └── ci.yml
├── docs/                           # this blueprint, API docs, runbooks
└── README.md
```

---

## 8. Phased roadmap (beyond Phase 1)

| Phase | Theme | Modules | Infrastructure unlocked |
|-------|-------|---------|------------------------|
| **1 (now)** | Revenue core | IAM/RBAC, CRM, Training/LMS, Finance-lite | PostgreSQL, Redis, Docker Compose, CI |
| **2** | Service delivery + reach | Project Management, Technical Office (document management + version control), Event Management, WebSocket live dashboards, OAuth2/social login | S3 maturity, WebSocket layer |
| **3** | Operations depth | Inventory & Procurement, CMMS (assets, work orders, MTBF/MTTR), full Accounting (double-entry, P&L, balance sheet), HR & Payroll | Reporting replica, BI tool (Superset) |
| **4** | Intelligence + scale | AI Engineering Assistant (RAG over Knowledge Base), Knowledge Base + semantic search, Marketing automation, native mobile apps (React Native/Expo) | Elasticsearch, Qdrant vector DB, Celery scale-out, container orchestration *if* load justifies |

> Native mobile and the AI assistant are deliberately last: they are the highest-effort, highest-risk pieces, and both are far cheaper to build well once the data model and APIs they depend on are stable and battle-tested.

---

## 9. Recommended next deliverable

With this frozen, the natural next step is the **runnable Phase 1 scaffold**: monorepo + FastAPI/Postgres/Redis wired up + Alembic migrations for the IAM tables + working auth (register/login/2FA) + RBAC dependency + the first CRM slice (lead → opportunity → quotation). That turns this blueprint into something you can log into.
