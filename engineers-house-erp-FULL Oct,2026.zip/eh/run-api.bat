REM Engineers House ERP - API server
@echo off
chcp 65001 >nul
cd /d "%~dp0apps\api"
set "PATH=D:\Programs;%PATH%"
set "DATABASE_URL=sqlite:///D:/eh_erp_v2.db"
set "JWT_SECRET=engineers-house-secret-key-2026-secure-change-me"
set "AUTO_CREATE_TABLES=true"
if not exist ".venv" python -m venv .venv
call .venv\Scripts\activate.bat
echo Installing/updating Python packages, first run can take a few minutes...
pip install -q fastapi "uvicorn[standard]" "sqlalchemy>=2.0" "pydantic>=2" pydantic-settings pyjwt "passlib[argon2]" argon2-cffi pyotp email-validator httpx python-multipart celery
echo Seeding database, admin account and chart of accounts...
python -m app.seed
echo Starting API on http://127.0.0.1:8000 ...
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
