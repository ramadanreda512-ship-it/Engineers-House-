REM Engineers House ERP - API server in ONLINE (production) mode
@echo off
chcp 65001 >nul
cd /d "%~dp0apps\api"
set "PATH=D:\Programs;%PATH%"
set "DATABASE_URL=sqlite:///D:/eh_erp_v2.db"
set "AUTO_CREATE_TABLES=true"
set "ENVIRONMENT=production"

REM A strong secret is generated ONCE and kept outside the project folder.
if not exist "D:\eh_secret.txt" (
  echo Generating a new secret key D:\eh_secret.txt ...
  powershell -NoProfile -Command "$b=New-Object byte[] 48; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); [Convert]::ToBase64String($b) | Out-File -Encoding ascii -NoNewline D:\eh_secret.txt"
)
set /p JWT_SECRET=<D:\eh_secret.txt

if not exist ".venv" python -m venv .venv
call .venv\Scripts\activate.bat
pip install -q fastapi "uvicorn[standard]" "sqlalchemy>=2.0" "pydantic>=2" pydantic-settings pyjwt "passlib[argon2]" argon2-cffi pyotp email-validator httpx python-multipart celery
python -m app.seed
echo Starting API (production) on http://127.0.0.1:8000 ...
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
