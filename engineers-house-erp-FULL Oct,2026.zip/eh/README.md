# Engineers House ERP — Phase 1 Scaffold

> One Platform for Training, Projects, Engineering, and Industrial Solutions

A runnable Phase 1 backend for the Engineers House ERP: a **modular monolith** (FastAPI + PostgreSQL + Redis) implementing the foundation, authentication with 2FA, role-based access control, the CRM slice (**account → opportunity → quotation**), the **Training/LMS slice** (**course → cohort → session → enrollment → attendance → certificate**), and the **Projects/Construction slice** (**BOQ → variation orders → progress billing (IPC) → retention → subcontracts**). Built per the frozen blueprint (`docs/engineers-house-erp-blueprint.md`).

This is the foundation everything else hangs on — not the whole ERP. The remaining modules (Training/LMS, Finance, Project, CMMS, …) plug into this same structure as later phases.

---

## What's implemented

- **Identity & Access** — register, login, JWT access + refresh tokens, refresh rotation, `/me`, TOTP-based 2FA setup/verify, tenant-aware user model.
- **RBAC** — permission catalog, system roles (Sales Agent, Accountant), a `require_permission()` dependency enforced in the API; super admin bypass.
- **CRM** — accounts (leads/customers/suppliers), contacts, opportunities (pipeline), and quotations with auto-numbered references and server-computed subtotal/tax/total.
- **Training / LMS** — courses (with optional passing-score requirement), instructors, cohorts, sessions, students, enrollments (with waitlisting when a cohort is full, auto-promotion of the first waitlisted student on withdrawal, and auto-generated installment schedules), idempotent attendance marking, graded assessments, certificate issuance gated on completion **and** passing score, and a daily background scan that flags installments due soon and marks overdue ones.
- **Projects / Construction** — BOQ (Bill of Quantities) tracking with executed-vs-planned quantity guards, variation orders gated on approval, server-computed progress billing (Interim Payment Certificates) with retention withholding, retention release, and independent subcontractor payment tracking on the same percentage-of-completion logic.
- **Cross-cutting** — single-tenant deployment with `tenant_id` carried everywhere (SaaS-ready per ADR-2), tenant-scoped queries, health check, CORS, OpenAPI/Swagger docs.

All writes are tenant-scoped and permission-guarded. **177 passing tests** cover auth, RBAC denial, the lead-to-quotation flow, the full training lifecycle (waitlisting, auto-promotion, idempotent attendance, assessment-gated certificates, installment reminders), the full project billing lifecycle (BOQ guards, VO approval gating, IPC math, subcontract payments), the finance lifecycle (server-computed invoice totals, partial/full payments with status recomputation, overpayment rejection, cash-flow summary), the maintenance lifecycle (asset status transitions, work-order completion, PM schedule generation), inventory & procurement (unique SKUs, stock movements that cannot go negative, PO receiving that raises stock), HR (leave-day computation, balance-decrementing approval, server-computed payroll), the tendering lifecycle (multi-level BOQ roll-up, cost-estimate build-up, and won-tender conversion into an execution project), and the accounting lifecycle (double-entry journal posting with balance enforcement, group-account guarding, receipt/payment vouchers, and the trial balance, income statement, balance sheet and project cost reports derived from posted entries). The system also covers partners/shareholders (capital contributions, equity-percentage profit distribution, and partner statements, each posting to the ledger), project budget-vs-actual (planned cost by category against actuals pulled from cost-center postings, with projected margin), fixed assets with straight-line depreciation (each run posting a depreciation journal entry), an AI financial analyst (assembles a cross-module financial snapshot and, when an API key is configured, asks Claude for an Arabic CFO-style analysis), and governance (a maker/checker approval workflow plus annual budgets with a budget-vs-actual variance report). The system spans **18 modules and 270+ endpoints**.

The accounting module is a full double-entry general ledger: a hierarchical chart of accounts (seeded with an Egyptian-style starting chart), cost centers that tag entries by project, balanced journal entries, receipt (قبض) and payment (صرف) vouchers that post their own balanced entries, and the standard financial statements. Project cost reports roll posted lines up by cost center, mirroring the legacy program's project-costing view.

Every module supports **editing and deleting** its records, with engineering guard rules that protect data integrity: simple definitional records (customers, items, employees, assets, courses) can be edited and deleted, but deletion is blocked when the record is in use (a course with cohorts, a student with enrollments, an asset with work orders, an item with stock movements, an employee with payroll) — the system returns a clear message suggesting deactivation/retirement instead. Financial and contractual records use a cancel/retire pattern rather than hard deletion: a project's contract value locks once progress billings exist, and projects are cancelled (preserving history) rather than deleted. Historical records (payments, stock movements, certificates) are immutable.

---

## Run it (Docker — recommended)

```bash
cd infra
docker compose up --build
```

Then open:
- API docs (Swagger): http://localhost:8000/docs
- Health: http://localhost:8000/health

The API container seeds a default tenant, permissions, roles, and a super admin on startup.
**Default login:** `admin@engineershouse.com` / `ChangeMe!2026` — change these via environment variables before any real deployment.

## Run it (local, without Docker)

```bash
cd apps/api
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt

# SQLite for quick local dev (no Postgres needed)
export DATABASE_URL="sqlite:///./eh_erp.db"
export JWT_SECRET="a-long-random-secret-at-least-32-bytes"

python -m app.seed                       # create tables + seed
uvicorn app.main:app --reload            # http://localhost:8000/docs
```

## Run the tests

```bash
cd apps/api
source .venv/bin/activate
pytest -q          # uses in-memory SQLite, no external services needed
ruff check .       # lint
```

---

## Try the core flow (curl)

```bash
# 1) Log in as the seeded super admin (form-encoded for OAuth2)
TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@engineershouse.com&password=ChangeMe!2026" | python -c "import sys,json;print(json.load(sys.stdin)['access_token'])")

# 2) Create a lead (account)
ACC=$(curl -s -X POST http://localhost:8000/api/v1/crm/accounts \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"Delta Factory","type":"lead","industry":"Food & Beverage"}' \
  | python -c "import sys,json;print(json.load(sys.stdin)['id'])")

# 3) Create an opportunity, then a quotation with line items
curl -s -X POST http://localhost:8000/api/v1/crm/opportunities \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"account_id\":\"$ACC\",\"title\":\"PLC retrofit\",\"value\":50000,\"probability\":40}"

curl -s -X POST http://localhost:8000/api/v1/crm/quotations \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"account_id\":\"$ACC\",\"tax_rate\":0.15,\"lines\":[{\"description\":\"Siemens S7-1200 CPU\",\"qty\":2,\"unit_price\":1200}]}"
```

---

## API endpoints (Phase 1)

| Method | Path | Permission |
|--------|------|-----------|
| POST | `/api/v1/auth/register` | public |
| POST | `/api/v1/auth/login` | public (form) |
| POST | `/api/v1/auth/login/mfa` | public |
| POST | `/api/v1/auth/refresh` | public |
| GET | `/api/v1/auth/me` | authenticated |
| POST | `/api/v1/auth/2fa/setup` | authenticated |
| POST | `/api/v1/auth/2fa/verify` | authenticated |
| POST | `/api/v1/crm/accounts` | `crm.account.create` |
| GET | `/api/v1/crm/accounts` | `crm.account.view` |
| POST | `/api/v1/crm/accounts/{id}/contacts` | `crm.contact.create` |
| POST | `/api/v1/crm/opportunities` | `crm.opportunity.create` |
| POST | `/api/v1/crm/quotations` | `crm.quotation.create` |
| POST | `/api/v1/training/courses` | `training.course.create` |
| GET | `/api/v1/training/courses` | `training.course.view` |
| POST | `/api/v1/training/instructors` | `training.instructor.create` |
| POST | `/api/v1/training/cohorts` | `training.cohort.create` |
| POST | `/api/v1/training/cohorts/{id}/sessions` | `training.session.create` |
| POST | `/api/v1/training/students` | `training.student.create` |
| POST | `/api/v1/training/enrollments` | `training.enrollment.create` |
| GET | `/api/v1/training/enrollments/{id}` | `training.enrollment.create` |
| POST | `/api/v1/training/enrollments/{id}/complete` | `training.enrollment.edit` |
| POST | `/api/v1/training/enrollments/{id}/withdraw` | `training.enrollment.edit` |
| POST | `/api/v1/training/enrollments/{id}/assessments` | `training.assessment.record` |
| POST | `/api/v1/training/sessions/{id}/attendance` | `training.attendance.mark` |
| POST | `/api/v1/training/enrollments/{id}/certificate` | `training.certificate.issue` |
| POST | `/api/v1/projects` | `project.create` |
| GET | `/api/v1/projects` | `project.view` |
| POST | `/api/v1/projects/{id}/boq` | `project.boq.manage` |
| PATCH | `/api/v1/projects/{id}/boq/{item_id}/progress` | `project.boq.manage` |
| POST | `/api/v1/projects/{id}/variation-orders` | `project.variation.request` |
| POST | `/api/v1/projects/{id}/variation-orders/{vo_id}/approve` | `project.variation.approve` |
| POST | `/api/v1/projects/{id}/billings` | `project.billing.create` |
| POST | `/api/v1/projects/{id}/retention-releases` | `project.retention.release` |
| POST | `/api/v1/projects/subcontractors` | `project.subcontractor.create` |
| POST | `/api/v1/projects/{id}/subcontracts` | `project.subcontract.award` |
| POST | `/api/v1/projects/{id}/subcontracts/{sc_id}/payments` | `project.subcontract.payment` |

---

## Project layout

```
engineers-house-erp/
├── apps/api/
│   ├── app/
│   │   ├── core/        # config, db, security, deps, rbac
│   │   ├── shared/      # base model + GUID type, enums, pagination, exceptions
│   │   ├── modules/
│   │   │   ├── identity/  # models, schemas, repository, service, router
│   │   │   ├── crm/       # models, schemas, repository, service, router
│   │   │   ├── training/  # courses, cohorts, sessions, enrollments, attendance, certificates
│   │   │   └── projects/  # BOQ, variation orders, progress billing, retention, subcontracts
│   │   ├── workers/     # Celery app (background jobs)
│   │   ├── main.py      # FastAPI entrypoint
│   │   └── seed.py      # tenant + permissions + roles + superadmin
│   ├── alembic/         # production migrations (autogenerate-ready)
│   ├── tests/           # pytest suite
│   ├── requirements*.txt, pyproject.toml, Dockerfile
│   └── .env.example
├── infra/docker-compose.yml   # api + worker + postgres + redis
├── .github/workflows/ci.yml   # lint + tests on every PR
└── docs/                      # blueprint lives here
```

---

## Production notes

- **Migrations:** dev uses `AUTO_CREATE_TABLES=true` (auto `create_all`). For production set it to `false` and manage schema with Alembic:
  `alembic revision --autogenerate -m "init"` then `alembic upgrade head` (run against PostgreSQL so native UUID columns are generated).
- **Secrets:** override `JWT_SECRET`, `SUPERADMIN_PASSWORD`, and DB credentials. The JWT secret should be ≥ 32 random bytes.
- **Refresh rotation:** refresh tokens are JWTs today; production should add Redis-backed reuse detection (the `redis` dependency and config are already wired).
```
