REM Engineers House ERP - start in ONLINE mode (for sharing with the team)
@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   Engineers House ERP  -  ONLINE MODE
echo ============================================
echo Use this instead of START.bat when the team works from the internet.
echo Do NOT run START.bat and START-ONLINE.bat at the same time.
echo.
start "EH ERP - API (online)" cmd /k "%~dp0run-api-online.bat"
timeout /t 5 >nul
start "EH ERP - Web (online)" cmd /k "%~dp0run-web-online.bat"
echo.
echo When the Web window says "Ready":
echo   1) Test locally:  http://localhost:3000
echo   2) Then make sure the Tailscale Funnel is ON (see the guide).
echo.
pause
