REM Engineers House ERP - Web frontend
@echo off
chcp 65001 >nul
cd /d "%~dp0apps\web"
set "PATH=D:\Programs;%PATH%"
if not exist ".env.local" copy ".env.local.example" ".env.local" >nul
if not exist "node_modules" echo Installing web packages, first run can take a few minutes...
if not exist "node_modules" call npm install
echo Starting Web on http://localhost:3000 ...
call npm run dev
pause
