/** @type {import('next').NextConfig} */
// All browser requests to /api/* are forwarded to the FastAPI backend running
// on the same machine. This lets the whole ERP be served from ONE address,
// which is what an internet tunnel or a cloud server needs.
const API_INTERNAL = process.env.API_INTERNAL_URL || "http://127.0.0.1:8000";

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${API_INTERNAL}/api/:path*` }];
  },
};
export default nextConfig;
