"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { login, saveToken, ApiError } from "@/lib/api";
import { useLang } from "@/lib/i18n";
import LangToggle from "@/components/LangToggle";

export default function LoginPage() {
  const router = useRouter();
  const { t, dir } = useLang();
  const [email, setEmail] = useState("admin@engineershouse.com");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const tokens = await login(email, password);
      saveToken(tokens.access_token, tokens.refresh_token);
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : t("unexpectedError"));
    } finally {
      setLoading(false);
    }
  }

  const align = dir === "rtl" ? "right" : "left";

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--bg)",
        padding: "1rem",
        position: "relative",
      }}
    >
      <div style={{ position: "absolute", top: 16, insetInlineEnd: 16 }}>
        <LangToggle />
      </div>

      <form
        onSubmit={handleSubmit}
        style={{
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: 14,
          padding: "2rem",
          width: 360,
          maxWidth: "100%",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "1.5rem" }}>
          <img
            src="/logo.jpg"
            alt="Engineers House"
            width={72}
            height={72}
            style={{ borderRadius: 12, margin: "0 auto 12px", display: "block" }}
          />
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>
            {t("brand")}
          </h1>
          <p
            style={{
              fontSize: 13,
              color: "var(--text-muted)",
              margin: "8px 0 0",
            }}
          >
            {t("tagline")}
          </p>
        </div>

        <label style={{ fontSize: 13, color: "var(--text-muted)" }}>
          {t("email")}
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ ...inputStyle, textAlign: align }}
        />

        <label style={{ fontSize: 13, color: "var(--text-muted)" }}>
          {t("password")}
        </label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          placeholder={t("passwordPlaceholder")}
          style={{ ...inputStyle, textAlign: align }}
        />

        {error && (
          <div
            style={{
              background: "#fceaea",
              color: "#a32d2d",
              fontSize: 13,
              padding: "10px 12px",
              borderRadius: 8,
              margin: "4px 0 14px",
            }}
          >
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          style={{
            width: "100%",
            background: "var(--brand)",
            color: "#fff",
            border: "none",
            borderRadius: 8,
            padding: "11px",
            fontSize: 15,
            fontWeight: 500,
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? t("loggingIn") : t("login")}
        </button>

      </form>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  margin: "6px 0 14px",
  padding: "10px 12px",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 14,
  background: "var(--surface)",
};
