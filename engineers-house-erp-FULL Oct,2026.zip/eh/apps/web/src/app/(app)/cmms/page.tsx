"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Asset, WorkOrder, CmmsSummary, Page } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Metric, Loading, ErrorBox, fmt, RowActions, ConfirmDialog, EditDialog, Field, dialogInput } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function CmmsPage() {
  const { t, dir } = useLang();
  const [summary, setSummary] = useState<CmmsSummary | null>(null);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [assetForm, setAssetForm] = useState({ code: "", name: "", criticality: "medium", location: "" });
  const [woForm, setWoForm] = useState({ asset_id: "", title: "", wo_type: "corrective", priority: "medium" });
  const [savingAsset, setSavingAsset] = useState(false);
  const [savingWo, setSavingWo] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // edit/delete asset
  const [editAsset, setEditAsset] = useState<Asset | null>(null);
  const [editName, setEditName] = useState("");
  const [editLoc, setEditLoc] = useState("");
  const [editCrit, setEditCrit] = useState("medium");
  const [editStatus, setEditStatus] = useState("operational");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [deleteAssetId, setDeleteAssetId] = useState<string | null>(null);

  const assetStatus: Record<string, string> = {
    operational: t("statusOperational"),
    under_maintenance: t("statusUnderMaintenance"),
    out_of_service: t("statusRejected"),
    retired: t("statusRejected"),
  };
  const woStatus: Record<string, string> = {
    open: t("statusOpen"),
    in_progress: t("statusInProgress"),
    completed: t("statusCompleted"),
    cancelled: t("statusCancelled"),
  };
  const woStatusKind: Record<string, string> = {
    open: "lead", in_progress: "waitlisted", completed: "completed", cancelled: "withdrawn",
  };

  async function load() {
    setLoading(true);
    try {
      const [sum, ast, wos] = await Promise.all([
        api.get<CmmsSummary>("/api/v1/cmms/summary"),
        api.get<Page<Asset>>("/api/v1/cmms/assets?size=100"),
        api.get<Page<WorkOrder>>("/api/v1/cmms/work-orders?size=100"),
      ]);
      setSummary(sum);
      setAssets(ast.items);
      setWorkOrders(wos.items);
      if (ast.items.length && !woForm.asset_id) setWoForm((f) => ({ ...f, asset_id: ast.items[0].id }));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addAsset(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingAsset(true);
    try {
      await api.post("/api/v1/cmms/assets", {
        code: assetForm.code,
        name: assetForm.name,
        criticality: assetForm.criticality,
        location: assetForm.location || null,
      });
      setAssetForm({ code: "", name: "", criticality: "medium", location: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSavingAsset(false);
    }
  }

  async function addWo(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingWo(true);
    try {
      await api.post("/api/v1/cmms/work-orders", {
        asset_id: woForm.asset_id,
        title: woForm.title,
        wo_type: woForm.wo_type,
        priority: woForm.priority,
      });
      setWoForm((f) => ({ ...f, title: "" }));
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSavingWo(false);
    }
  }

  async function woAction(woId: string, action: "start" | "complete") {
    try {
      const body = action === "complete" ? { labor_cost: 0, parts_cost: 0, downtime_hours: 0 } : undefined;
      await api.post(`/api/v1/cmms/work-orders/${woId}/${action}`, body);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  function openEditAsset(a: Asset) {
    setEditAsset(a);
    setEditName(a.name);
    setEditLoc(a.location || "");
    setEditCrit(a.criticality);
    setEditStatus(a.status);
    setDialogError(null);
  }

  async function saveAsset() {
    if (!editAsset) return;
    setDialogError(null);
    try {
      await api.patch(`/api/v1/cmms/assets/${editAsset.id}`, {
        name: editName,
        location: editLoc || null,
        criticality: editCrit,
        status: editStatus,
      });
      setEditAsset(null);
      await load();
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteAsset() {
    if (!deleteAssetId) return;
    try {
      await api.del(`/api/v1/cmms/assets/${deleteAssetId}`);
      setDeleteAssetId(null);
      await load();
    } catch (e) {
      setDeleteAssetId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const assetName = (id: string) => assets.find((a) => a.id === id)?.name || "—";
  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("cmmsTitle")}</PageTitle>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && summary && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.5rem" }}>
            <Metric label={t("totalAssets")} value={fmt(summary.total_assets)} />
            <Metric label={t("operational")} value={fmt(summary.operational_assets)} />
            <Metric label={t("openWorkOrders")} value={fmt(summary.open_work_orders)} />
            <Metric label={t("maintenanceCost")} value={fmt(summary.total_maintenance_cost)} sub={t("egp")} />
          </div>

          {/* Add asset */}
          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newAsset")}</div>
              <form onSubmit={addAsset} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.5fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
                <div><label style={labelStyle}>{t("assetCode")}</label><input value={assetForm.code} onChange={(e) => setAssetForm({ ...assetForm, code: e.target.value })} required style={inputStyle} placeholder="PUMP-01" /></div>
                <div><label style={labelStyle}>{t("assetName")}</label><input value={assetForm.name} onChange={(e) => setAssetForm({ ...assetForm, name: e.target.value })} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("criticality")}</label>
                  <select value={assetForm.criticality} onChange={(e) => setAssetForm({ ...assetForm, criticality: e.target.value })} style={inputStyle}>
                    <option value="low">{t("critLow")}</option>
                    <option value="medium">{t("critMedium")}</option>
                    <option value="high">{t("critHigh")}</option>
                  </select>
                </div>
                <div><label style={labelStyle}>{t("location")}</label><input value={assetForm.location} onChange={(e) => setAssetForm({ ...assetForm, location: e.target.value })} style={inputStyle} /></div>
                <button type="submit" disabled={savingAsset} style={btnStyle}>{savingAsset ? "..." : t("add")}</button>
              </form>
            </Card>
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("assets")}</div>
              {assets.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noAssets")}</div> : (
                <Table
                  headers={[t("assetCode"), t("assetName"), t("location"), t("status"), ""]}
                  rows={assets.map((a) => [
                    <span key={a.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{a.code}</span>,
                    a.name,
                    <span key={a.id + "l"} style={{ color: "var(--text-muted)" }}>{a.location || "—"}</span>,
                    <Badge key={a.id + "s"} text={assetStatus[a.status] || a.status} kind={a.status === "operational" ? "completed" : "waitlisted"} />,
                    <RowActions key={a.id + "act"} editLabel={t("edit")} deleteLabel={t("delete")} onEdit={() => openEditAsset(a)} onDelete={() => setDeleteAssetId(a.id)} />,
                  ])}
                />
              )}
            </Card>
          </div>

          {/* Work orders */}
          {assets.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <Card>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newWorkOrder")}</div>
                <form onSubmit={addWo} style={{ display: "grid", gridTemplateColumns: "1.3fr 1.5fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
                  <div><label style={labelStyle}>{t("asset")}</label>
                    <select value={woForm.asset_id} onChange={(e) => setWoForm({ ...woForm, asset_id: e.target.value })} style={inputStyle}>
                      {assets.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </select>
                  </div>
                  <div><label style={labelStyle}>{t("title")}</label><input value={woForm.title} onChange={(e) => setWoForm({ ...woForm, title: e.target.value })} required style={inputStyle} /></div>
                  <div><label style={labelStyle}>{t("woType")}</label>
                    <select value={woForm.wo_type} onChange={(e) => setWoForm({ ...woForm, wo_type: e.target.value })} style={inputStyle}>
                      <option value="corrective">{t("woCorrective")}</option>
                      <option value="preventive">{t("woPreventive")}</option>
                    </select>
                  </div>
                  <div><label style={labelStyle}>{t("priority")}</label>
                    <select value={woForm.priority} onChange={(e) => setWoForm({ ...woForm, priority: e.target.value })} style={inputStyle}>
                      <option value="low">{t("critLow")}</option>
                      <option value="medium">{t("critMedium")}</option>
                      <option value="high">{t("critHigh")}</option>
                    </select>
                  </div>
                  <button type="submit" disabled={savingWo} style={btnStyle}>{savingWo ? "..." : t("add")}</button>
                </form>
                {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
              </Card>
            </div>
          )}

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("workOrders")}</div>
            {workOrders.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noWorkOrders")}</div> : (
              <Table
                headers={[t("invoiceNumber"), t("asset"), t("title"), t("status"), ""]}
                rows={workOrders.map((wo) => [
                  <span key={wo.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{wo.number}</span>,
                  assetName(wo.asset_id),
                  wo.title,
                  <Badge key={wo.id + "s"} text={woStatus[wo.status] || wo.status} kind={woStatusKind[wo.status] || "lead"} />,
                  <div key={wo.id + "a"} style={{ display: "flex", gap: 8 }}>
                    {wo.status === "open" && <button onClick={() => woAction(wo.id, "start")} style={linkBtn}>{t("start")}</button>}
                    {(wo.status === "open" || wo.status === "in_progress") && <button onClick={() => woAction(wo.id, "complete")} style={linkBtn}>{t("complete")}</button>}
                  </div>,
                ])}
              />
            )}
          </Card>
        </>
      )}

      <EditDialog
        open={!!editAsset}
        title={t("edit") + " — " + t("asset")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveAsset}
        onCancel={() => setEditAsset(null)}
        error={dialogError}
      >
        <Field label={t("assetName")}>
          <input value={editName} onChange={(e) => setEditName(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("location")}>
          <input value={editLoc} onChange={(e) => setEditLoc(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("criticality")}>
          <select value={editCrit} onChange={(e) => setEditCrit(e.target.value)} style={dialogInput}>
            <option value="low">{t("critLow")}</option>
            <option value="medium">{t("critMedium")}</option>
            <option value="high">{t("critHigh")}</option>
          </select>
        </Field>
        <Field label={t("status")}>
          <select value={editStatus} onChange={(e) => setEditStatus(e.target.value)} style={dialogInput}>
            <option value="operational">{t("statusOperational")}</option>
            <option value="under_maintenance">{t("statusUnderMaintenance")}</option>
            <option value="retired">{t("statusRejected")}</option>
          </select>
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!deleteAssetId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteAsset}
        onCancel={() => setDeleteAssetId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const linkBtn: React.CSSProperties = { background: "transparent", color: "var(--brand)", border: "none", fontSize: 13, fontWeight: 500, padding: 0 };
