"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import {
  GLAccount, CostCenter, JournalEntry, Voucher, Page,
  TrialBalance, TrialBalanceRow, IncomeStatement, BalanceSheet, ProjectCostReport,
} from "@/lib/types";
import { PageTitle, Card, Table, Badge, Loading, ErrorBox, fmt, RowActions, ConfirmDialog } from "@/components/ui";
import { useLang } from "@/lib/i18n";

type Tab = "accounts" | "journal" | "vouchers" | "reports";

export default function AccountingPage() {
  const { t } = useLang();
  const [tab, setTab] = useState<Tab>("accounts");

  return (
    <div>
      <PageTitle>{t("accountingTitle")}</PageTitle>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <TabBtn active={tab === "accounts"} onClick={() => setTab("accounts")} label={t("chartOfAccounts")} />
        <TabBtn active={tab === "journal"} onClick={() => setTab("journal")} label={t("journalEntries")} />
        <TabBtn active={tab === "vouchers"} onClick={() => setTab("vouchers")} label={t("vouchers")} />
        <TabBtn active={tab === "reports"} onClick={() => setTab("reports")} label={t("reports")} />
      </div>
      {tab === "accounts" && <AccountsTab />}
      {tab === "journal" && <JournalTab />}
      {tab === "vouchers" && <VouchersTab />}
      {tab === "reports" && <ReportsTab />}
    </div>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid var(--border)", background: active ? "var(--brand)" : "var(--surface)", color: active ? "#fff" : "var(--text)", fontSize: 14, fontWeight: 500 }}>
      {label}
    </button>
  );
}

// ---------------- Chart of Accounts + Cost Centers ----------------
function AccountsTab() {
  const { t, dir } = useLang();
  const [accounts, setAccounts] = useState<GLAccount[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deleteAccId, setDeleteAccId] = useState<string | null>(null);

  const [form, setForm] = useState({ code: "", name: "", account_type: "expense", is_group: false, opening_balance: "" });
  const [ccForm, setCcForm] = useState({ code: "", name: "" });
  const [formError, setFormError] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const typeLabel: Record<string, string> = {
    asset: t("typeAsset"), liability: t("typeLiability"), equity: t("typeEquity"),
    revenue: t("typeRevenue"), expense: t("typeExpense"),
  };

  async function load() {
    setLoading(true);
    try {
      const [accs, ccs] = await Promise.all([
        api.get<GLAccount[]>("/api/v1/accounting/accounts"),
        api.get<CostCenter[]>("/api/v1/accounting/cost-centers"),
      ]);
      setAccounts(accs);
      setCostCenters(ccs);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function addAccount(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    try {
      await api.post("/api/v1/accounting/accounts", {
        code: form.code, name: form.name, account_type: form.account_type,
        is_group: form.is_group, opening_balance: Number(form.opening_balance) || 0,
      });
      setForm({ code: "", name: "", account_type: "expense", is_group: false, opening_balance: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    }
  }

  async function addCostCenter(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/accounting/cost-centers", { code: ccForm.code, name: ccForm.name });
      setCcForm({ code: "", name: "" });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteAcc() {
    if (!deleteAccId) return;
    try {
      await api.del(`/api/v1/accounting/accounts/${deleteAccId}`);
      setDeleteAccId(null);
      await load();
    } catch (e) {
      setDeleteAccId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newAccount")}</div>
          <form onSubmit={addAccount} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.6fr 1fr 1fr auto auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("accountCode")}</label><input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("accountName")}</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("accountType")}</label>
              <select value={form.account_type} onChange={(e) => setForm({ ...form, account_type: e.target.value })} style={inputStyle}>
                <option value="asset">{t("typeAsset")}</option>
                <option value="liability">{t("typeLiability")}</option>
                <option value="equity">{t("typeEquity")}</option>
                <option value="revenue">{t("typeRevenue")}</option>
                <option value="expense">{t("typeExpense")}</option>
              </select>
            </div>
            <div><label style={labelStyle}>{t("openingBalance")}</label><input type="number" value={form.opening_balance} onChange={(e) => setForm({ ...form, opening_balance: e.target.value })} style={inputStyle} /></div>
            <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, paddingBottom: 8 }}>
              <input type="checkbox" checked={form.is_group} onChange={(e) => setForm({ ...form, is_group: e.target.checked })} />
              {t("groupAccount")}
            </label>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
          {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
        </Card>
      </div>

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("chartOfAccounts")}</div>
          {accounts.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noAccounts")}</div> : (
            <Table
              headers={[t("accountCode"), t("accountName"), t("accountType"), t("openingBalance"), ""]}
              rows={accounts.map((a) => [
                <span key={a.id} style={{ fontFamily: "monospace", fontSize: 12, fontWeight: a.is_group ? 700 : 400, paddingInlineStart: a.is_group ? 0 : 16 }}>{a.code}</span>,
                <span key={a.id + "n"} style={{ fontWeight: a.is_group ? 600 : 400 }}>{a.name}{a.is_group ? "" : ""}</span>,
                <Badge key={a.id + "t"} text={typeLabel[a.account_type] || a.account_type} kind={a.account_type === "revenue" ? "completed" : a.account_type === "expense" ? "withdrawn" : "lead"} />,
                a.opening_balance ? `${fmt(a.opening_balance)} ${t("egp")}` : "—",
                a.is_group ? <span key={a.id + "x"} /> : <RowActions key={a.id + "act"} deleteLabel={t("delete")} onDelete={() => setDeleteAccId(a.id)} />,
              ])}
            />
          )}
        </Card>
      </div>

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("costCenters")}</div>
        <form onSubmit={addCostCenter} style={{ display: "flex", gap: 10, alignItems: "end", marginBottom: 14 }}>
          <div style={{ width: 130 }}><label style={labelStyle}>{t("costCenterCode")}</label><input value={ccForm.code} onChange={(e) => setCcForm({ ...ccForm, code: e.target.value })} required style={inputStyle} /></div>
          <div style={{ flex: 1 }}><label style={labelStyle}>{t("costCenterName")}</label><input value={ccForm.name} onChange={(e) => setCcForm({ ...ccForm, name: e.target.value })} required style={inputStyle} /></div>
          <button type="submit" style={btnStyle}>+ {t("newCostCenter")}</button>
        </form>
        {costCenters.length > 0 && (
          <Table
            headers={[t("costCenterCode"), t("costCenterName"), t("status")]}
            rows={costCenters.map((cc) => [
              <span key={cc.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{cc.code}</span>,
              cc.name,
              <Badge key={cc.id + "s"} text={cc.is_active ? t("active") : t("inactive")} kind={cc.is_active ? "completed" : "withdrawn"} />,
            ])}
          />
        )}
      </Card>

      <ConfirmDialog
        open={!!deleteAccId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteAcc}
        onCancel={() => setDeleteAccId(null)}
      />
    </>
  );
}

// ---------------- Journal Entries ----------------
function JournalTab() {
  const { t, dir } = useLang();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [accounts, setAccounts] = useState<GLAccount[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [desc, setDesc] = useState("");
  const [lines, setLines] = useState([
    { account_id: "", cost_center_id: "", debit: "", credit: "" },
    { account_id: "", cost_center_id: "", debit: "", credit: "" },
  ]);
  const [formError, setFormError] = useState<string | null>(null);
  const [cancelId, setCancelId] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const postable = accounts.filter((a) => !a.is_group);
  const accName = (id: string) => { const a = accounts.find((x) => x.id === id); return a ? `${a.code} ${a.name}` : "—"; };

  async function load() {
    setLoading(true);
    try {
      const [ent, accs, ccs] = await Promise.all([
        api.get<Page<JournalEntry>>("/api/v1/accounting/journal-entries?size=100"),
        api.get<GLAccount[]>("/api/v1/accounting/accounts"),
        api.get<CostCenter[]>("/api/v1/accounting/cost-centers"),
      ]);
      setEntries(ent.items);
      setAccounts(accs);
      setCostCenters(ccs);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const totalDebit = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
  const totalCredit = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);
  const balanced = totalDebit === totalCredit && totalDebit > 0;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    try {
      await api.post("/api/v1/accounting/journal-entries", {
        description: desc || null,
        lines: lines.filter((l) => l.account_id && (Number(l.debit) || Number(l.credit))).map((l) => ({
          account_id: l.account_id,
          cost_center_id: l.cost_center_id || null,
          debit: Number(l.debit) || 0,
          credit: Number(l.credit) || 0,
        })),
      });
      setDesc("");
      setLines([{ account_id: "", cost_center_id: "", debit: "", credit: "" }, { account_id: "", cost_center_id: "", debit: "", credit: "" }]);
      setShowForm(false);
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmCancel() {
    if (!cancelId) return;
    try {
      await api.post(`/api/v1/accounting/journal-entries/${cancelId}/cancel`);
      setCancelId(null);
      await load();
    } catch (e) {
      setCancelId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: showForm ? 14 : 0 }}>
            <div style={{ fontWeight: 500 }}>{t("newJournalEntry")}</div>
            <button onClick={() => setShowForm(!showForm)} style={btnStyle}>{showForm ? "▲" : `+ ${t("newJournalEntry")}`}</button>
          </div>
          {showForm && (
            <form onSubmit={submit}>
              <div style={{ marginBottom: 12 }}>
                <label style={labelStyle}>{t("description")}</label>
                <input value={desc} onChange={(e) => setDesc(e.target.value)} style={inputStyle} />
              </div>
              <table style={{ width: "100%", fontSize: 13, marginBottom: 10 }}>
                <thead><tr style={{ color: "var(--text-muted)", fontSize: 12 }}>
                  <th style={th}>{t("account")}</th><th style={th}>{t("costCenter")}</th><th style={thR}>{t("debit")}</th><th style={thR}>{t("credit")}</th>
                </tr></thead>
                <tbody>
                  {lines.map((line, i) => (
                    <tr key={i}>
                      <td style={td}>
                        <select value={line.account_id} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, account_id: e.target.value } : l))} style={inputStyle}>
                          <option value="">{t("selectAccount")}</option>
                          {postable.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
                        </select>
                      </td>
                      <td style={td}>
                        <select value={line.cost_center_id} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, cost_center_id: e.target.value } : l))} style={inputStyle}>
                          <option value="">—</option>
                          {costCenters.map((cc) => <option key={cc.id} value={cc.id}>{cc.code} — {cc.name}</option>)}
                        </select>
                      </td>
                      <td style={td}><input type="number" value={line.debit} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, debit: e.target.value, credit: "" } : l))} style={{ ...inputStyle, textAlign: "end" }} /></td>
                      <td style={td}><input type="number" value={line.credit} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, credit: e.target.value, debit: "" } : l))} style={{ ...inputStyle, textAlign: "end" }} /></td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr style={{ fontWeight: 600, borderTop: "2px solid var(--border)" }}>
                    <td style={td} colSpan={2}>{balanced ? `✓ ${t("balanced")}` : t("notBalanced")}</td>
                    <td style={{ ...tdR, color: balanced ? "inherit" : "#c0392b" }}>{fmt(totalDebit)}</td>
                    <td style={{ ...tdR, color: balanced ? "inherit" : "#c0392b" }}>{fmt(totalCredit)}</td>
                  </tr>
                </tfoot>
              </table>
              <div style={{ display: "flex", gap: 10 }}>
                <button type="button" onClick={() => setLines((p) => [...p, { account_id: "", cost_center_id: "", debit: "", credit: "" }])} style={btnGrey}>+ {t("addLine")}</button>
                <button type="submit" disabled={!balanced} style={{ ...btnStyle, opacity: balanced ? 1 : 0.5 }}>{t("save")}</button>
              </div>
              {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
            </form>
          )}
        </Card>
      </div>

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("journalEntries")}</div>
        {entries.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noEntries")}</div> : (
          <Table
            headers={[t("entryNumber"), t("entryDate"), t("description"), t("totalDebit"), t("status"), ""]}
            rows={entries.map((en) => [
              <span key={en.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{en.number}</span>,
              en.entry_date,
              <span key={en.id + "d"}>{en.description || "—"}</span>,
              `${fmt(en.total_debit)} ${t("egp")}`,
              <Badge key={en.id + "s"} text={en.status === "posted" ? t("active") : t("statusCancelled")} kind={en.status === "posted" ? "completed" : "withdrawn"} />,
              en.status === "posted" ? <button key={en.id + "c"} onClick={() => setCancelId(en.id)} style={{ ...miniBtn, color: "#a32d2d" }}>{t("cancelEntry")}</button> : <span key={en.id + "x"} />,
            ])}
          />
        )}
      </Card>

      <ConfirmDialog
        open={!!cancelId}
        title={t("cancelEntry")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("cancelEntry")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmCancel}
        onCancel={() => setCancelId(null)}
      />
    </>
  );
}

// ---------------- Vouchers ----------------
function VouchersTab() {
  const { t, dir } = useLang();
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [accounts, setAccounts] = useState<GLAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ voucher_type: "receipt", amount: "", cash_account_id: "", counter_account_id: "", payee: "", description: "" });
  const [formError, setFormError] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const postable = accounts.filter((a) => !a.is_group);

  async function load() {
    setLoading(true);
    try {
      const [vs, accs] = await Promise.all([
        api.get<Page<Voucher>>("/api/v1/accounting/vouchers?size=100"),
        api.get<GLAccount[]>("/api/v1/accounting/accounts"),
      ]);
      setVouchers(vs.items);
      setAccounts(accs);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    try {
      await api.post("/api/v1/accounting/vouchers", {
        voucher_type: form.voucher_type, amount: Number(form.amount) || 0,
        cash_account_id: form.cash_account_id, counter_account_id: form.counter_account_id,
        payee: form.payee || null, description: form.description || null,
      });
      setForm({ voucher_type: "receipt", amount: "", cash_account_id: "", counter_account_id: "", payee: "", description: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newVoucher")}</div>
          <form onSubmit={submit} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1.4fr 1.4fr", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("voucherType")}</label>
              <select value={form.voucher_type} onChange={(e) => setForm({ ...form, voucher_type: e.target.value })} style={inputStyle}>
                <option value="receipt">{t("voucherReceipt")}</option>
                <option value="payment">{t("voucherPayment")}</option>
              </select>
            </div>
            <div><label style={labelStyle}>{t("amount")}</label><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("cashAccount")}</label>
              <select value={form.cash_account_id} onChange={(e) => setForm({ ...form, cash_account_id: e.target.value })} required style={inputStyle}>
                <option value="">{t("selectAccount")}</option>
                {postable.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
              </select>
            </div>
            <div><label style={labelStyle}>{t("counterAccount")}</label>
              <select value={form.counter_account_id} onChange={(e) => setForm({ ...form, counter_account_id: e.target.value })} required style={inputStyle}>
                <option value="">{t("selectAccount")}</option>
                {postable.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
              </select>
            </div>
            <div style={{ gridColumn: "1 / 3" }}><label style={labelStyle}>{t("payee")}</label><input value={form.payee} onChange={(e) => setForm({ ...form, payee: e.target.value })} style={inputStyle} /></div>
            <div style={{ gridColumn: "3 / 5", display: "flex", alignItems: "end" }}><button type="submit" style={{ ...btnStyle, width: "100%" }}>{t("add")}</button></div>
          </form>
          {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
        </Card>
      </div>

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("vouchers")}</div>
        {vouchers.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noVouchers")}</div> : (
          <Table
            headers={[t("entryNumber"), t("voucherType"), t("amount"), t("payee"), t("status")]}
            rows={vouchers.map((v) => [
              <span key={v.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{v.number}</span>,
              <Badge key={v.id + "t"} text={v.voucher_type === "receipt" ? t("voucherReceipt") : t("voucherPayment")} kind={v.voucher_type === "receipt" ? "completed" : "withdrawn"} />,
              `${fmt(v.amount)} ${t("egp")}`,
              v.payee || "—",
              <Badge key={v.id + "s"} text={v.status === "posted" ? t("active") : t("statusCancelled")} kind={v.status === "posted" ? "completed" : "withdrawn"} />,
            ])}
          />
        )}
      </Card>
    </>
  );
}

// ---------------- Reports ----------------
function ReportsTab() {
  const { t } = useLang();
  const [report, setReport] = useState<"trial" | "income" | "balance" | "project">("trial");

  return (
    <>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <TabBtn active={report === "trial"} onClick={() => setReport("trial")} label={t("trialBalance")} />
        <TabBtn active={report === "income"} onClick={() => setReport("income")} label={t("incomeStatement")} />
        <TabBtn active={report === "balance"} onClick={() => setReport("balance")} label={t("balanceSheet")} />
        <TabBtn active={report === "project"} onClick={() => setReport("project")} label={t("projectCosts")} />
      </div>
      {report === "trial" && <TrialBalanceReport />}
      {report === "income" && <IncomeReport />}
      {report === "balance" && <BalanceReport />}
      {report === "project" && <ProjectCostsReport />}
    </>
  );
}

function TrialBalanceReport() {
  const { t } = useLang();
  const [data, setData] = useState<TrialBalance | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get<TrialBalance>("/api/v1/accounting/reports/trial-balance").then(setData).finally(() => setLoading(false)); }, []);
  if (loading) return <Loading text={t("loadingData")} />;
  if (!data) return null;
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ fontWeight: 500 }}>{t("trialBalance")}</div>
        <Badge text={data.is_balanced ? t("balanced") : t("notBalancedShort")} kind={data.is_balanced ? "completed" : "withdrawn"} />
      </div>
      <Table
        headers={[t("accountCode"), t("accountName"), t("debit"), t("credit")]}
        rows={[
          ...data.rows.map((r) => [
            <span key={r.account_id} style={{ fontFamily: "monospace", fontSize: 12 }}>{r.account_code}</span>,
            r.account_name,
            r.debit ? fmt(r.debit) : "—",
            r.credit ? fmt(r.credit) : "—",
          ]),
          [<strong key="tot">—</strong>, <strong key="totl">{t("total")}</strong>, <strong key="d">{fmt(data.total_debit)}</strong>, <strong key="c">{fmt(data.total_credit)}</strong>],
        ]}
      />
    </Card>
  );
}

function IncomeReport() {
  const { t } = useLang();
  const [data, setData] = useState<IncomeStatement | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get<IncomeStatement>("/api/v1/accounting/reports/income-statement").then(setData).finally(() => setLoading(false)); }, []);
  if (loading) return <Loading text={t("loadingData")} />;
  if (!data) return null;
  return (
    <Card>
      <div style={{ fontWeight: 500, marginBottom: 14 }}>{t("incomeStatement")}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 16 }}>
        <Stat label={t("totalRevenue")} value={data.total_revenue} t={t} />
        <Stat label={t("totalExpense")} value={data.total_expense} t={t} />
        <Stat label={t("netProfit")} value={data.net_profit} t={t} highlight />
      </div>
      {data.revenue_lines.length > 0 && <ReportLines title={t("totalRevenue")} rows={data.revenue_lines} field="credit" t={t} />}
      {data.expense_lines.length > 0 && <ReportLines title={t("totalExpense")} rows={data.expense_lines} field="debit" t={t} />}
    </Card>
  );
}

function BalanceReport() {
  const { t } = useLang();
  const [data, setData] = useState<BalanceSheet | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get<BalanceSheet>("/api/v1/accounting/reports/balance-sheet").then(setData).finally(() => setLoading(false)); }, []);
  if (loading) return <Loading text={t("loadingData")} />;
  if (!data) return null;
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ fontWeight: 500 }}>{t("balanceSheet")}</div>
        <Badge text={data.is_balanced ? t("balanced") : t("notBalancedShort")} kind={data.is_balanced ? "completed" : "withdrawn"} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 16 }}>
        <Stat label={t("totalAssets")} value={data.total_assets} t={t} />
        <Stat label={t("totalLiabilities")} value={data.total_liabilities} t={t} />
        <Stat label={t("totalEquity")} value={data.total_equity} t={t} />
        <Stat label={t("retainedEarnings")} value={data.retained_earnings} t={t} highlight />
      </div>
      {data.asset_lines.length > 0 && <ReportLines title={t("totalAssets")} rows={data.asset_lines} field="debit" t={t} />}
      {data.liability_lines.length > 0 && <ReportLines title={t("totalLiabilities")} rows={data.liability_lines} field="credit" t={t} />}
      {data.equity_lines.length > 0 && <ReportLines title={t("totalEquity")} rows={data.equity_lines} field="credit" t={t} />}
    </Card>
  );
}

function ProjectCostsReport() {
  const { t } = useLang();
  const [data, setData] = useState<ProjectCostReport | null>(null);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [cc, setCc] = useState("");
  const [loading, setLoading] = useState(true);
  async function load(ccId: string) {
    setLoading(true);
    const url = ccId ? `/api/v1/accounting/reports/project-costs?cost_center_id=${ccId}` : "/api/v1/accounting/reports/project-costs";
    try { setData(await api.get<ProjectCostReport>(url)); } finally { setLoading(false); }
  }
  useEffect(() => {
    api.get<CostCenter[]>("/api/v1/accounting/cost-centers").then(setCostCenters);
    load("");
  }, []);
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, gap: 10 }}>
        <div style={{ fontWeight: 500 }}>{t("projectCosts")}</div>
        <select value={cc} onChange={(e) => { setCc(e.target.value); load(e.target.value); }} style={{ ...baseInput, maxWidth: 260 }}>
          <option value="">{t("selectProject")}</option>
          {costCenters.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
        </select>
      </div>
      {loading ? <Loading text={t("loadingData")} /> : data && (
        <Table
          headers={[t("costCenter"), t("account"), t("debit"), t("credit"), t("closingBalance")]}
          rows={[
            ...data.rows.map((r, i) => [
              <span key={i} style={{ fontSize: 13 }}>{r.cost_center_code} — {r.cost_center_name}</span>,
              <span key={i + "a"} style={{ fontSize: 13 }}><span style={{ fontFamily: "monospace" }}>{r.account_code}</span> {r.account_name}</span>,
              fmt(r.debit),
              fmt(r.credit),
              fmt(r.balance),
            ]),
            [<strong key="t">{t("total")}</strong>, "", <strong key="d">{fmt(data.total_debit)}</strong>, <strong key="c">{fmt(data.total_credit)}</strong>, <strong key="b">{fmt(data.total_balance)}</strong>],
          ]}
        />
      )}
    </Card>
  );
}

function ReportLines({ title, rows, field, t }: { title: string; rows: TrialBalanceRow[]; field: "debit" | "credit"; t: (k: string) => string }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 6 }}>{title}</div>
      <Table
        headers={[t("accountCode"), t("accountName"), t("amount")]}
        rows={rows.map((r) => [
          <span key={r.account_id} style={{ fontFamily: "monospace", fontSize: 12 }}>{r.account_code}</span>,
          r.account_name,
          fmt(r[field]),
        ])}
      />
    </div>
  );
}

function Stat({ label, value, t, highlight }: { label: string; value: number; t: (k: string) => string; highlight?: boolean }) {
  return (
    <div style={{ padding: 12, background: "var(--bg)", borderRadius: 8 }}>
      <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 600, color: highlight ? "var(--brand)" : "var(--text)" }}>{fmt(value)} {t("egp")}</div>
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500 };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 8px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
const th: React.CSSProperties = { textAlign: "start", padding: "4px 6px", fontWeight: 500 };
const thR: React.CSSProperties = { textAlign: "end", padding: "4px 6px", fontWeight: 500 };
const td: React.CSSProperties = { padding: "4px 6px", textAlign: "start" };
const tdR: React.CSSProperties = { padding: "4px 6px", textAlign: "end" };
