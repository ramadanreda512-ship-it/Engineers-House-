"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Category, CategoryCounts } from "@/lib/types";
import { PageTitle, Card, Loading, ErrorBox } from "@/components/ui";
import { useLang } from "@/lib/i18n";
import BackupPanel from "./BackupPanel";
import UsersPanel from "./UsersPanel";

type Kind = "course" | "project" | "customer";

const KINDS: { kind: Kind; labelKey: string; icon: string }[] = [
  { kind: "course", labelKey: "courseCategories", icon: "🎓" },
  { kind: "project", labelKey: "projectCategories", icon: "🏗️" },
  { kind: "customer", labelKey: "customerCategories", icon: "👥" },
];

export default function SettingsPage() {
  const { t, dir } = useLang();
  const [section, setSection] = useState<"categories" | "backup" | "users">("categories");
  const [kind, setKind] = useState<Kind>("course");
  const [items, setItems] = useState<Category[]>([]);
  const [counts, setCounts] = useState<CategoryCounts | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ code: "", name_ar: "", name_en: "" });
  const [edit, setEdit] = useState<Category | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [list, cnt] = await Promise.all([
        api.get<Category[]>(`/api/v1/settings/categories?kind=${kind}`),
        api.get<CategoryCounts>(`/api/v1/settings/categories/counts?kind=${kind}`),
      ]);
      setItems(list);
      setCounts(cnt);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }, [kind]);

  useEffect(() => { load(); }, [load]);

  async function addCategory(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/settings/categories", {
        kind, code: form.code, name_ar: form.name_ar, name_en: form.name_en || null,
      });
      setForm({ code: "", name_ar: "", name_en: "" });
      setShowAdd(false);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function toggleActive(c: Category) {
    try {
      await api.patch(`/api/v1/settings/categories/${c.id}`, { is_active: !c.is_active });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function remove(c: Category) {
    if (c.is_system) { setError(t("systemCatCannotDelete")); return; }
    try {
      await api.del(`/api/v1/settings/categories/${c.id}`);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  const activeKind = KINDS.find((k) => k.kind === kind)!;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
        <div>
          <PageTitle>⚙️ {t("settingsTitle")}</PageTitle>
          <div style={{ color: "var(--text-muted)", fontSize: 14, marginTop: -8, marginBottom: 8 }}>{t("settingsSubtitle")}</div>
        </div>
        {section === "categories" && (
          <button onClick={() => setShowAdd(!showAdd)} style={btnPrimary}>+ {t("addCategory")}</button>
        )}
      </div>

      {/* Section switcher */}
      <div style={{ display: "flex", gap: 8, margin: "0.5rem 0 1.25rem" }}>
        <button onClick={() => setSection("categories")} style={section === "categories" ? sectionActive : sectionInactive}>
          🗂 {t("categoryType")}
        </button>
        <button onClick={() => setSection("backup")} style={section === "backup" ? sectionActive : sectionInactive}>
          💾 {t("backupTab")}
        </button>
        <button onClick={() => setSection("users")} style={section === "users" ? sectionActive : sectionInactive}>
          👤 {t("usersTab")}
        </button>
      </div>

      {section === "backup" && <BackupPanel />}

      {section === "users" && <UsersPanel />}

      {section === "categories" && (<>
      {error && <ErrorBox message={error} />}

      {/* Type selector — the tab tiles from the design */}
      <div style={{ marginBottom: "1.25rem", marginTop: "1rem" }}>
        <Card>
          <div style={{ fontWeight: 600, marginBottom: 14, textAlign: dir === "rtl" ? "right" : "left" }}>{t("categoryType")}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
            {KINDS.map((k) => (
              <button
                key={k.kind}
                onClick={() => { setKind(k.kind); setShowAdd(false); }}
                style={kind === k.kind ? tileActive : tile}
              >
                <span style={{ fontSize: 18 }}>{k.icon}</span>
                <span>{t(k.labelKey)}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* Add form */}
      {showAdd && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <form onSubmit={addCategory} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.3fr 1.3fr auto", gap: 10, alignItems: "end" }}>
              <div><label style={lbl}>{t("catCode")}</label><input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} required style={input} placeholder="e.g. PLC" /></div>
              <div><label style={lbl}>{t("catNameAr")}</label><input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} required style={input} /></div>
              <div><label style={lbl}>{t("catNameEn")}</label><input value={form.name_en} onChange={(e) => setForm({ ...form, name_en: e.target.value })} style={input} /></div>
              <button type="submit" style={btnPrimary}>{t("saveCategory")}</button>
            </form>
          </Card>
        </div>
      )}

      {/* Category list */}
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4, flexWrap: "wrap", gap: 8 }}>
          <div style={{ fontWeight: 600, fontSize: 16 }}>{activeKind.icon} {t(activeKind.labelKey)}</div>
          {counts && (
            <div style={{ fontSize: 13, color: "var(--text-muted)" }}>
              {counts.total} {t("catCountLine")} · {counts.active} {t("catActiveWord")} · {counts.system} {t("catSystemWord")}
            </div>
          )}
        </div>

        {loading ? (
          <Loading text={t("loadingData")} />
        ) : items.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: 14, padding: "1rem 0" }}>{t("noCategories")}</div>
        ) : (
          <div style={{ marginTop: 12 }}>
            {items.map((c) => (
              <div key={c.id} style={row}>
                {/* left: actions */}
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  {!c.is_system && (
                    <button onClick={() => remove(c)} title="delete" style={{ ...iconBtn, color: "#c0392b" }}>🗑</button>
                  )}
                  <button onClick={() => setEdit(c)} title="edit" style={iconBtn}>✏️</button>
                  <Toggle on={c.is_active} onClick={() => toggleActive(c)} />
                  {c.is_system && (
                    <span style={sysBadge}>{t("catSystem")}</span>
                  )}
                </div>

                {/* right: name + code */}
                <div style={{ textAlign: dir === "rtl" ? "right" : "left", display: "flex", alignItems: "center", gap: 12 }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14.5 }}>{c.name_ar}</div>
                    {c.name_en && <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>{c.name_en}</div>}
                  </div>
                  <span style={codeBadge}>{c.code}</span>
                  <span style={{ width: 8, height: 8, borderRadius: 99, background: c.is_active ? "#16a34a" : "#cbd5e1", display: "inline-block" }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {edit && (
        <EditDialog category={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />
      )}
      </>)}
    </div>
  );
}

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ width: 40, height: 22, borderRadius: 99, border: "none", cursor: "pointer", background: on ? "var(--brand)" : "#cbd5e1", position: "relative", transition: "background .2s" }}>
      <span style={{ position: "absolute", top: 2, insetInlineStart: on ? 20 : 2, width: 18, height: 18, borderRadius: 99, background: "#fff", transition: "inset-inline-start .2s" }} />
    </button>
  );
}

function EditDialog({ category, onClose, onDone }: { category: Category; onClose: () => void; onDone: () => void }) {
  const { t } = useLang();
  const [nameAr, setNameAr] = useState(category.name_ar);
  const [nameEn, setNameEn] = useState(category.name_en || "");
  const [code, setCode] = useState(category.code);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.patch(`/api/v1/settings/categories/${category.id}`, {
        code, name_ar: nameAr, name_en: nameEn || null,
      });
      onDone();
    } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 }}>
      <div style={{ background: "var(--surface)", borderRadius: 14, padding: 24, width: "100%", maxWidth: 440 }}>
        <h3 style={{ marginTop: 0 }}>{t("editCategory")}</h3>
        {err && <ErrorBox message={err} />}
        <form onSubmit={submit}>
          <label style={lbl}>{t("catCode")}</label>
          <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} disabled={category.is_system} required style={{ ...input, opacity: category.is_system ? 0.6 : 1 }} />
          <label style={{ ...lbl, marginTop: 10 }}>{t("catNameAr")}</label>
          <input value={nameAr} onChange={(e) => setNameAr(e.target.value)} required style={input} />
          <label style={{ ...lbl, marginTop: 10 }}>{t("catNameEn")}</label>
          <input value={nameEn} onChange={(e) => setNameEn(e.target.value)} style={input} />
          <div style={{ display: "flex", gap: 10, marginTop: 18, justifyContent: "flex-end" }}>
            <button type="button" onClick={onClose} style={btnGrey}>{t("cancel")}</button>
            <button type="submit" style={btnPrimary}>{t("saveCategory")}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* styles */
const input: React.CSSProperties = { width: "100%", padding: "9px 11px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const lbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const btnPrimary: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "10px 18px", fontSize: 14, cursor: "pointer" };
const tile: React.CSSProperties = { display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: "16px 14px", background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 14, fontWeight: 500, cursor: "pointer", color: "var(--text)" };
const sectionActive: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 10, padding: "9px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer" };
const sectionInactive: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 10, padding: "9px 20px", fontSize: 14, fontWeight: 500, cursor: "pointer" };
const tileActive: React.CSSProperties = { ...tile, background: "var(--surface)", border: "2px solid var(--brand)", color: "var(--brand)", fontWeight: 700 };
const row: React.CSSProperties = { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 8px", borderBottom: "1px solid var(--border)" };
const iconBtn: React.CSSProperties = { background: "transparent", border: "none", cursor: "pointer", fontSize: 15, padding: 4 };
const codeBadge: React.CSSProperties = { fontSize: 12, fontFamily: "monospace", fontWeight: 700, padding: "3px 10px", background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 8 };
const sysBadge: React.CSSProperties = { fontSize: 11, padding: "2px 10px", background: "#dbeafe", color: "#1e40af", borderRadius: 99, fontWeight: 600 };
