"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, ErrorBox } from "@/components/ui";
import { useLang } from "@/lib/i18n";

interface BackupStats {
  total_rows: number;
  highlights: Record<string, number>;
}

export default function BackupPanel() {
  const { t } = useLang();
  const [stats, setStats] = useState<BackupStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  async function loadStats() {
    try {
      const s = await api.get<BackupStats>("/api/v1/backup/stats");
      setStats(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }
  useEffect(() => { loadStats(); }, []);

  async function doExport() {
    setError(null); setMsg(null); setExporting(true);
    try {
      const data = await api.get<{ filename: string; content: string }>("/api/v1/backup/export");
      const blob = new Blob([data.content], { type: "application/json;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
      setMsg(t("backupDone"));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setExporting(false);
    }
  }

  async function doRestore() {
    if (!pendingFile) return;
    setError(null); setMsg(null); setRestoring(true);
    try {
      const content = await pendingFile.text();
      const res = await api.post<{ restored_rows: number }>("/api/v1/backup/restore", { content });
      setMsg(`${t("restoreDone")} ${res.restored_rows} ${t("restoreRowsWord")}`);
      setPendingFile(null);
      await loadStats();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setRestoring(false);
    }
  }

  const hl = stats?.highlights || {};
  const highlightRows: [string, number | undefined][] = [
    [t("backupCustomers"), hl.customers],
    [t("backupStudents"), hl.students],
    [t("backupCourses"), hl.courses],
    [t("backupProjects"), hl.projects],
    [t("backupInvoices"), hl.invoices],
    [t("backupJournal"), hl.journal_entries],
  ];

  return (
    <div>
      {error && <ErrorBox message={error} />}
      {msg && (
        <div style={{ background: "#dcfce7", color: "#166534", padding: "12px 16px", borderRadius: 10, marginBottom: 16, fontSize: 14, fontWeight: 500 }}>
          ✓ {msg}
        </div>
      )}

      {/* Stats */}
      {stats && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, flexWrap: "wrap", gap: 8 }}>
              <div style={{ fontWeight: 600, fontSize: 16 }}>💾 {t("backupTitle")}</div>
              <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{t("backupTotalRows")}: <b style={{ color: "var(--text)" }}>{stats.total_rows.toLocaleString()}</b></div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: 10 }}>
              {highlightRows.map(([label, val]) => (
                <div key={label} style={{ padding: "10px 12px", background: "var(--bg)", borderRadius: 8, textAlign: "center" }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: "var(--brand)" }}>{val ?? 0}</div>
                  <div style={{ fontSize: 11.5, color: "var(--text-muted)" }}>{label}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* Export */}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>⬇ {t("backupNow")}</div>
          <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 14 }}>{t("backupSubtitle")}</div>
          <button onClick={doExport} disabled={exporting} style={{ ...btnPrimary, opacity: exporting ? 0.6 : 1 }}>
            {exporting ? t("backupExporting") : `⬇ ${t("backupNow")}`}
          </button>
        </Card>
      </div>

      {/* Restore */}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>⬆ {t("restoreNow")}</div>
          <div style={{ background: "#fef3c7", color: "#92400e", padding: "10px 14px", borderRadius: 8, fontSize: 13, marginBottom: 14 }}>
            ⚠️ {t("restoreWarning")}
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <input
              type="file"
              accept=".json,application/json"
              onChange={(e) => { setPendingFile(e.target.files?.[0] || null); setMsg(null); }}
              style={{ fontSize: 13 }}
            />
            {pendingFile && (
              <button onClick={doRestore} disabled={restoring} style={{ ...btnDanger, opacity: restoring ? 0.6 : 1 }}>
                {restoring ? t("backupRestoring") : t("restoreConfirm")}
              </button>
            )}
          </div>
        </Card>
      </div>

      <div style={{ fontSize: 12.5, color: "var(--text-muted)", padding: "0 4px" }}>
        💡 {t("backupTip")}
      </div>
    </div>
  );
}

const btnPrimary: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "11px 22px", fontSize: 14, fontWeight: 600, cursor: "pointer" };
const btnDanger: React.CSSProperties = { background: "#c0392b", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", fontSize: 13, fontWeight: 600, cursor: "pointer" };
