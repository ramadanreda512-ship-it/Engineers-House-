"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { RoleSummary, TeamUser } from "@/lib/types";
import { Card, ErrorBox, Loading } from "@/components/ui";
import { useLang } from "@/lib/i18n";

// The three main access levels, shown first with a plain-language description.
const MAIN_ROLES = ["المدير", "المشرف", "المستخدم"];

export default function UsersPanel() {
  const { t } = useLang();
  const [users, setUsers] = useState<TeamUser[]>([]);
  const [roles, setRoles] = useState<RoleSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ full_name: "", email: "", password: "", role_id: "", phone: "" });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [u, r] = await Promise.all([
        api.get<TeamUser[]>("/api/v1/auth/users"),
        api.get<RoleSummary[]>("/api/v1/auth/roles"),
      ]);
      setUsers(u);
      setRoles(r);
      if (!form.role_id) {
        const supervisor = r.find((x) => x.name === "المشرف");
        setForm((f) => ({ ...f, role_id: supervisor?.id || r[0]?.id || "" }));
      }
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { load(); }, [load]);

  async function addUser(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setMsg(null);
    try {
      await api.post("/api/v1/auth/users", {
        email: form.email,
        full_name: form.full_name,
        password: form.password,
        role_id: form.role_id,
        phone: form.phone || null,
      });
      setForm({ full_name: "", email: "", password: "", role_id: form.role_id, phone: "" });
      setShowAdd(false);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function toggleStatus(u: TeamUser) {
    try {
      await api.patch(`/api/v1/auth/users/${u.id}`, {
        status: u.status === "active" ? "suspended" : "active",
      });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function changeRole(u: TeamUser, roleId: string) {
    try {
      await api.patch(`/api/v1/auth/users/${u.id}`, { role_id: roleId });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function resetPassword(u: TeamUser) {
    const pw = prompt(t("newPasswordPrompt"));
    if (!pw || pw.length < 8) return;
    try {
      await api.post(`/api/v1/auth/users/${u.id}/reset-password`, { new_password: pw });
      setMsg(`${t("passwordChanged")} — ${u.full_name}`);
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function removeUser(u: TeamUser) {
    if (!confirm(t("confirmDeleteUser"))) return;
    try {
      await api.del(`/api/v1/auth/users/${u.id}`);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  const roleDesc: Record<string, string> = {
    "المدير": t("roleManagerDesc"),
    "المشرف": t("roleSupervisorDesc"),
    "المستخدم": t("roleOperatorDesc"),
  };
  const mainRoles = MAIN_ROLES.map((n) => roles.find((r) => r.name === n)).filter(Boolean) as RoleSummary[];

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      {error && <ErrorBox message={error} />}
      {msg && (
        <div style={{ background: "#dcfce7", color: "#166534", padding: "11px 15px", borderRadius: 10, marginBottom: 14, fontSize: 14 }}>✓ {msg}</div>
      )}

      {/* Access levels explained */}
      {mainRoles.length > 0 && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <div style={{ fontWeight: 600, marginBottom: 12 }}>🔐 {t("rolesOverview")}</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: 12 }}>
              {mainRoles.map((r, i) => (
                <div key={r.id} style={{ padding: "13px 15px", background: "var(--bg)", borderRadius: 10, borderInlineStart: `4px solid ${["#c0392b", "#e67e22", "#16a34a"][i]}` }}>
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>{r.name}</div>
                  <div style={{ fontSize: 12.5, color: "var(--text-muted)", lineHeight: 1.6 }}>{roleDesc[r.name]}</div>
                  <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 6 }}>{r.permission_count} {t("permissionsCount")}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* Add user */}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: showAdd ? 14 : 0, flexWrap: "wrap", gap: 8 }}>
            <div>
              <div style={{ fontWeight: 600 }}>{t("usersTitle")}</div>
              <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>{t("usersSubtitle")}</div>
            </div>
            <button onClick={() => setShowAdd(!showAdd)} style={btnPrimary}>+ {t("addUser")}</button>
          </div>
          {showAdd && (
            <form onSubmit={addUser} style={{ display: "grid", gridTemplateColumns: "1.2fr 1.4fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
              <div><label style={lbl}>{t("userFullName")}</label><input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required style={input} /></div>
              <div><label style={lbl}>{t("userEmail")}</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required style={input} /></div>
              <div><label style={lbl}>{t("userPassword")}</label><input type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required minLength={8} style={input} /></div>
              <div><label style={lbl}>{t("userRole")}</label>
                <select value={form.role_id} onChange={(e) => setForm({ ...form, role_id: e.target.value })} style={input}>
                  {mainRoles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                  {roles.filter((r) => !MAIN_ROLES.includes(r.name)).map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </div>
              <button type="submit" style={btnPrimary}>{t("save")}</button>
            </form>
          )}
        </Card>
      </div>

      {/* Users list */}
      <Card>
        {users.map((u) => (
          <div key={u.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 6px", borderBottom: "1px solid var(--border)", gap: 12, flexWrap: "wrap" }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
              {!u.is_superadmin && (
                <>
                  <button onClick={() => toggleStatus(u)} style={{ ...miniBtn, color: u.status === "active" ? "#a32d2d" : "#16a34a" }}>
                    {u.status === "active" ? t("suspendUser") : t("activateUser")}
                  </button>
                  <button onClick={() => resetPassword(u)} style={miniBtn}>{t("resetPassword")}</button>
                  <button onClick={() => removeUser(u)} style={{ ...miniBtn, color: "#c0392b" }} title={t("deleteUser")}>🗑</button>
                </>
              )}
            </div>
            <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              {!u.is_superadmin ? (
                <select
                  value={u.roles[0]?.id || ""}
                  onChange={(e) => changeRole(u, e.target.value)}
                  style={{ ...input, width: "auto", fontSize: 12.5, padding: "5px 9px" }}
                >
                  {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              ) : (
                <span style={{ fontSize: 11.5, padding: "3px 10px", background: "#fee2e2", color: "#991b1b", borderRadius: 99, fontWeight: 600 }}>{t("mainManagerBadge")}</span>
              )}
              <span style={{ fontSize: 11.5, padding: "3px 10px", borderRadius: 99, fontWeight: 600, background: u.status === "active" ? "#dcfce7" : "#f1f5f9", color: u.status === "active" ? "#166534" : "#64748b" }}>
                {u.status === "active" ? t("statusActiveUser") : t("statusSuspended")}
              </span>
              <div style={{ textAlign: "end" }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>{u.full_name}</div>
                <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>{u.email}</div>
              </div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

const input: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13.5, background: "var(--surface)" };
const lbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const btnPrimary: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", fontSize: 13.5, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "4px 11px", fontSize: 12, cursor: "pointer", color: "var(--text)" };
