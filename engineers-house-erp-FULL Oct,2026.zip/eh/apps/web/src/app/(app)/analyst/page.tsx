"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { AnalystResponse, FinancialSnapshot } from "@/lib/types";
import { PageTitle, Card, Metric, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function AnalystPage() {
  const { t, dir } = useLang();
  const [snapshot, setSnapshot] = useState<FinancialSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [question, setQuestion] = useState("");
  const [asking, setAsking] = useState(false);
  const [answer, setAnswer] = useState<AnalystResponse | null>(null);

  async function loadSnapshot() {
    setLoading(true);
    try {
      setSnapshot(await api.get<FinancialSnapshot>("/api/v1/analyst/snapshot"));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { loadSnapshot(); /* eslint-disable-next-line */ }, []);

  async function ask(q?: string) {
    const query = q || question;
    if (!query.trim()) return;
    setAsking(true);
    setError(null);
    try {
      const resp = await api.post<AnalystResponse>("/api/v1/analyst/ask", { question: query });
      setAnswer(resp);
      setSnapshot(resp.snapshot);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setAsking(false);
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      <PageTitle>{t("analystTitle")}</PageTitle>
      <p style={{ color: "var(--text-muted)", fontSize: 14, marginTop: -8, marginBottom: 20 }}>{t("analystIntro")}</p>
      {error && <ErrorBox message={error} />}

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ display: "flex", gap: 10, alignItems: "stretch" }}>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder={t("askQuestion")}
              rows={2}
              style={{ ...baseInput, flex: 1, resize: "vertical", textAlign: dir === "rtl" ? "right" : "left" }}
            />
            <button onClick={() => ask()} disabled={asking} style={{ ...btnStyle, opacity: asking ? 0.6 : 1, minWidth: 90 }}>
              {asking ? t("analyzing") : t("ask")}
            </button>
          </div>
          <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: 12, color: "var(--text-muted)", alignSelf: "center" }}>{t("suggestedQuestions")}:</span>
            {[t("q1"), t("q2"), t("q3")].map((q, i) => (
              <button key={i} onClick={() => { setQuestion(q); ask(q); }} style={chip}>{q}</button>
            ))}
          </div>
        </Card>
      </div>

      {answer && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            {!answer.ai_enabled && (
              <div style={{ background: "#fef9e7", border: "1px solid #f6e3a1", borderRadius: 8, padding: "10px 14px", fontSize: 13, marginBottom: 14, color: "#8a6d1a" }}>
                {t("aiDisabled")}
              </div>
            )}
            <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.8, fontSize: 14, textAlign: dir === "rtl" ? "right" : "left" }}>
              {answer.answer}
            </div>
          </Card>
        </div>
      )}

      {snapshot && (
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 14 }}>{t("financialSnapshot")}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12 }}>
            <Metric label={t("totalRevenue")} value={`${fmt(snapshot.total_revenue)}`} sub={t("egp")} />
            <Metric label={t("totalExpense")} value={`${fmt(snapshot.total_expense)}`} sub={t("egp")} />
            <Metric label={t("netProfit")} value={`${fmt(snapshot.net_profit)}`} sub={t("egp")} />
            <Metric label={t("cashPosition")} value={`${fmt(snapshot.cash_position)}`} sub={t("egp")} />
            <Metric label={t("receivables")} value={`${fmt(snapshot.receivables)}`} sub={t("egp")} />
            <Metric label={t("payables")} value={`${fmt(snapshot.payables)}`} sub={t("egp")} />
            <Metric label={t("totalAssets")} value={`${fmt(snapshot.total_assets)}`} sub={t("egp")} />
            <Metric label={t("totalEquity")} value={`${fmt(snapshot.total_equity)}`} sub={t("egp")} />
            <Metric label={t("activeProjects")} value={String(snapshot.active_projects)} sub={`${fmt(snapshot.total_contract_value)} ${t("egp")}`} />
            <Metric label={t("partnersCount")} value={String(snapshot.partners_count)} sub={`${fmt(snapshot.partners_capital)} ${t("egp")}`} />
            <Metric label={t("bookValue")} value={`${fmt(snapshot.fixed_assets_book_value)}`} sub={t("egp")} />
            <Metric label={t("pipelineValue")} value={`${fmt(snapshot.tender_pipeline_value)}`} sub={`${snapshot.open_tenders} ${t("openTenders") || ""}`} />
          </div>
        </Card>
      )}
    </div>
  );
}

const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500 };
const chip: React.CSSProperties = { background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 16, padding: "5px 12px", fontSize: 12, cursor: "pointer" };
