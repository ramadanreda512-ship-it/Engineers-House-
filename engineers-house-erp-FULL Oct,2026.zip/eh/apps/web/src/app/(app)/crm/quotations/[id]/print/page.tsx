"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { QuotationPrintData } from "@/lib/types";
import { Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

/**
 * A4-sized printable quotation. The screen version shows a toolbar; the print
 * version hides the app shell entirely via a print stylesheet, so pressing
 * Print (or Save as PDF in the browser dialog) produces a clean document.
 */
export default function QuotationPrintPage() {
  const { t } = useLang();
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const [data, setData] = useState<QuotationPrintData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setData(await api.get<QuotationPrintData>(`/api/v1/crm/quotations/${id}/print`));
      } catch (e) {
        setError(e instanceof Error ? e.message : "Error");
      }
    })();
  }, [id]);

  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loading text={t("loadingData")} />;

  const q = data.quotation;
  const cur = q.currency || "EGP";
  const hasDiscount = q.line_discount_total > 0 || q.discount_amount > 0;

  return (
    <>
      {/* Print rules: hide the whole app, show only the document. */}
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #quote-doc, #quote-doc * { visibility: visible !important; }
          #quote-doc {
            position: absolute !important;
            inset-inline-start: 0; top: 0; width: 100%;
            margin: 0 !important; padding: 12mm !important;
            box-shadow: none !important; border: none !important;
          }
          .no-print { display: none !important; }
          @page { size: A4; margin: 0; }
        }
      `}</style>

      <div className="no-print" style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <button onClick={() => window.print()} style={btnPrimary}>{t("printBtn")}</button>
        <button onClick={() => router.back()} style={btnGrey}>{t("backBtn")}</button>
      </div>

      <div
        id="quote-doc"
        dir="rtl"
        style={{
          background: "#fff", color: "#111", maxWidth: 820, margin: "0 auto",
          padding: "28px 32px", borderRadius: 8, border: "1px solid #e5e7eb",
          fontFamily: "'Segoe UI', Tahoma, Arial, sans-serif", lineHeight: 1.6,
        }}
      >
        {/* Header: company vs document */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "3px solid #1e3a8a", paddingBottom: 14, marginBottom: 18 }}>
          <div style={{ textAlign: "left" }}>
            <div style={{ fontSize: 26, fontWeight: 800, color: "#1e3a8a", letterSpacing: 1 }}>{t("quotationDoc")}</div>
            <div style={{ fontSize: 13, fontFamily: "monospace", marginTop: 4 }}>{q.number}</div>
            <div style={{ fontSize: 12, color: "#555" }}>
              {t("quotDate")}: {new Date().toLocaleDateString("en-GB")}
            </div>
            {q.valid_until && (
              <div style={{ fontSize: 12, color: "#555" }}>{t("validUntil")}: {q.valid_until}</div>
            )}
          </div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>إنجينيرز هاوس</div>
            <div style={{ fontSize: 12.5, color: "#444" }}>Engineers House for Industrial Solutions</div>
            <div style={{ fontSize: 11.5, color: "#666", marginTop: 5 }}>
              الحلول الصناعية · الأتمتة · التدريب الهندسي
            </div>
          </div>
        </div>

        {/* Customer block */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 18 }}>
          <div style={{ background: "#f8fafc", padding: "12px 14px", borderRadius: 6 }}>
            <div style={{ fontSize: 11, color: "#64748b", marginBottom: 4 }}>{t("toCustomer")}</div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>{data.account_name}</div>
            {data.contact_name && (
              <div style={{ fontSize: 12.5, color: "#444" }}>{t("attn")}: {data.contact_name}</div>
            )}
            {data.account_address && <div style={{ fontSize: 12, color: "#555" }}>{data.account_address}</div>}
            {data.account_phone && <div style={{ fontSize: 12, color: "#555" }}>{data.account_phone}</div>}
            {data.account_tax_number && (
              <div style={{ fontSize: 12, color: "#555" }}>{t("taxNumberLabel")}: {data.account_tax_number}</div>
            )}
          </div>
          <div style={{ padding: "12px 14px" }}>
            {q.title && (
              <>
                <div style={{ fontSize: 11, color: "#64748b" }}>{t("quotTitle")}</div>
                <div style={{ fontWeight: 600, marginBottom: 8 }}>{q.title}</div>
              </>
            )}
            {q.delivery_period && (
              <div style={{ fontSize: 12.5 }}><b>{t("deliveryPeriod")}:</b> {q.delivery_period}</div>
            )}
            {q.payment_terms && (
              <div style={{ fontSize: 12.5 }}><b>{t("paymentTermsField")}:</b> {q.payment_terms}</div>
            )}
          </div>
        </div>

        {/* Line items */}
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, marginBottom: 16 }}>
          <thead>
            <tr style={{ background: "#1e3a8a", color: "#fff" }}>
              <th style={{ ...th, width: 34 }}>{t("itemNo")}</th>
              <th style={th}>{t("lineDesc")}</th>
              <th style={{ ...th, width: 70 }}>{t("svcUnit")}</th>
              <th style={{ ...th, width: 60 }}>{t("lineQty")}</th>
              <th style={{ ...th, width: 100 }}>{t("lineUnitPrice")}</th>
              {hasDiscount && <th style={{ ...th, width: 60 }}>{t("lineDiscount")}</th>}
              <th style={{ ...th, width: 110 }}>{t("lineTotal")}</th>
            </tr>
          </thead>
          <tbody>
            {q.lines.map((ln, i) => (
              <tr key={ln.id} style={{ background: i % 2 ? "#f8fafc" : "#fff" }}>
                <td style={{ ...td, textAlign: "center" }}>{i + 1}</td>
                <td style={td}>{ln.description}</td>
                <td style={{ ...td, textAlign: "center" }}>{ln.unit || "—"}</td>
                <td style={{ ...td, textAlign: "center" }}>{ln.qty}</td>
                <td style={{ ...td, textAlign: "center" }}>{fmt(ln.unit_price)}</td>
                {hasDiscount && (
                  <td style={{ ...td, textAlign: "center", color: ln.discount_pct ? "#b91c1c" : "#999" }}>
                    {ln.discount_pct ? `${ln.discount_pct}%` : "—"}
                  </td>
                )}
                <td style={{ ...td, textAlign: "center", fontWeight: 600 }}>{fmt(ln.line_total)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div style={{ display: "flex", justifyContent: "flex-start", marginBottom: 18 }}>
          <table style={{ fontSize: 13.5, minWidth: 300, borderCollapse: "collapse" }}>
            <tbody>
              {hasDiscount && (
                <>
                  <tr>
                    <td style={totLbl}>{t("quotGross")}</td>
                    <td style={totVal}>{fmt(q.gross_total)}</td>
                  </tr>
                  {q.line_discount_total > 0 && (
                    <tr>
                      <td style={totLbl}>{t("quotLineDisc")}</td>
                      <td style={{ ...totVal, color: "#b91c1c" }}>− {fmt(q.line_discount_total)}</td>
                    </tr>
                  )}
                  {q.discount_amount > 0 && (
                    <tr>
                      <td style={totLbl}>{t("headerDiscount")}</td>
                      <td style={{ ...totVal, color: "#b91c1c" }}>− {fmt(q.discount_amount)}</td>
                    </tr>
                  )}
                </>
              )}
              <tr>
                <td style={totLbl}>{t("quotSubtotal")}</td>
                <td style={totVal}>{fmt(q.subtotal)}</td>
              </tr>
              <tr>
                <td style={totLbl}>{t("quotTax")} ({Math.round((q.tax_rate || 0) * 100)}%)</td>
                <td style={totVal}>{fmt(q.tax)}</td>
              </tr>
              <tr style={{ background: "#1e3a8a", color: "#fff" }}>
                <td style={{ ...totLbl, color: "#fff", fontWeight: 800, fontSize: 15 }}>{t("quotGrand")}</td>
                <td style={{ ...totVal, color: "#fff", fontWeight: 800, fontSize: 15 }}>{fmt(q.total)} {cur}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Terms */}
        {(q.terms || q.notes) && (
          <div style={{ borderTop: "1px solid #e5e7eb", paddingTop: 12, marginBottom: 18 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{t("quotTerms")}</div>
            {q.terms && <div style={{ fontSize: 12, color: "#444", whiteSpace: "pre-wrap" }}>{q.terms}</div>}
            {q.notes && <div style={{ fontSize: 12, color: "#444", whiteSpace: "pre-wrap" }}>{q.notes}</div>}
          </div>
        )}

        {/* Footer / signature */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderTop: "2px solid #1e3a8a", paddingTop: 14, marginTop: 10 }}>
          <div style={{ textAlign: "center", fontSize: 12 }}>
            <div style={{ borderBottom: "1px solid #999", width: 170, height: 42 }} />
            <div style={{ marginTop: 4, color: "#555" }}>{t("signature")}</div>
          </div>
          <div style={{ fontSize: 12, color: "#555", textAlign: "end" }}>
            {q.prepared_by && <div>{t("preparedBy")}: <b>{q.prepared_by}</b></div>}
            <div style={{ marginTop: 6, fontStyle: "italic" }}>{t("thanksNote")}</div>
          </div>
        </div>
      </div>
    </>
  );
}

const th: React.CSSProperties = { padding: "9px 8px", fontSize: 12, fontWeight: 700, border: "1px solid #1e3a8a" };
const td: React.CSSProperties = { padding: "8px", border: "1px solid #e5e7eb" };
const totLbl: React.CSSProperties = { padding: "7px 14px", border: "1px solid #e5e7eb", color: "#334155" };
const totVal: React.CSSProperties = { padding: "7px 14px", border: "1px solid #e5e7eb", textAlign: "center", fontWeight: 600, minWidth: 130 };
const btnPrimary: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 22px", fontSize: 14, fontWeight: 600, cursor: "pointer" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "10px 22px", fontSize: 14, cursor: "pointer" };
