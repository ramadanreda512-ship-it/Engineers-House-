"use client";

import { useEffect, useState, useCallback } from "react";
import { api } from "@/lib/api";
import { Account, CrmContact, CrmActivity, CrmSummaryData, Page, PipelineData, PipelineCard, Account360Data, Quotation, CrmProduct } from "@/lib/types";
import { useRouter } from "next/navigation";
import { CatalogueTab, FollowUpsTab, LossAnalysisTab } from "./SalesTools";
import { PageTitle, Card, Metric, Table, Badge, Loading, ErrorBox, fmt, RowActions, ConfirmDialog } from "@/components/ui";
import { useLang } from "@/lib/i18n";
import ImportExport from "@/components/ImportExport";

const CLASSIFICATIONS = [
  "lead", "prospect", "client", "supplier", "partner", "contractor",
  "consultant", "factory", "government", "training_client",
  "maintenance_client", "automation_client",
];

export default function CrmPage() {
  const { t } = useLang();
  const [mainTab, setMainTab] = useState<"customers" | "pipeline" | "quotations" | "catalogue" | "followups" | "loss">("customers");
  const [selected, setSelected] = useState<Account | null>(null);
  if (selected) return <CustomerDetail account={selected} onBack={() => setSelected(null)} />;
  return (
    <div>
      <PageTitle>{t("crmTitle")}</PageTitle>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem" }}>
        <TabBtn active={mainTab === "customers"} onClick={() => setMainTab("customers")} label={t("customersTab")} />
        <TabBtn active={mainTab === "pipeline"} onClick={() => setMainTab("pipeline")} label={t("pipelineTab")} />
        <TabBtn active={mainTab === "quotations"} onClick={() => setMainTab("quotations")} label={t("quotationsTab")} />
        <TabBtn active={mainTab === "followups"} onClick={() => setMainTab("followups")} label={t("followUpsTab")} />
        <TabBtn active={mainTab === "loss"} onClick={() => setMainTab("loss")} label={t("lossTab")} />
        <TabBtn active={mainTab === "catalogue"} onClick={() => setMainTab("catalogue")} label={t("catalogueTab")} />
      </div>
      {mainTab === "customers" && <CustomerList onOpen={setSelected} />}
      {mainTab === "pipeline" && <PipelineBoard />}
      {mainTab === "quotations" && <QuotationsTab />}
      {mainTab === "followups" && <FollowUpsTab />}
      {mainTab === "loss" && <LossAnalysisTab />}
      {mainTab === "catalogue" && <CatalogueTab />}
    </div>
  );
}

function clsLabel(t: (k: string) => string, c: string | null): string {
  if (!c) return "—";
  const map: Record<string, string> = {
    lead: t("clsLead"), prospect: t("clsProspect"), client: t("clsClient"),
    supplier: t("clsSupplier"), partner: t("clsPartner"), contractor: t("clsContractor"),
    consultant: t("clsConsultant"), factory: t("clsFactory"), government: t("clsGovernment"),
    training_client: t("clsTraining"), maintenance_client: t("clsMaintenance"),
    automation_client: t("clsAutomation"),
  };
  return map[c] || c;
}

function CustomerList({ onOpen }: { onOpen: (a: Account) => void }) {
  const { t, dir } = useLang();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [summary, setSummary] = useState<CrmSummaryData | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [typeF, setTypeF] = useState("");
  const [clsF, setClsF] = useState("");
  const [sort, setSort] = useState("newest");
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const size = 20;
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), size: String(size), sort });
      if (search) params.set("search", search);
      if (typeF) params.set("type", typeF);
      if (clsF) params.set("classification", clsF);
      const [list, sm] = await Promise.all([
        api.get<Page<Account>>(`/api/v1/crm/accounts?${params}`),
        api.get<CrmSummaryData>("/api/v1/crm/summary"),
      ]);
      setAccounts(list.items);
      setTotal(list.total);
      setSummary(sm);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }, [page, search, typeF, clsF, sort]);

  useEffect(() => { load(); }, [load]);

  async function confirmDelete() {
    if (!deleteId) return;
    try {
      await api.del(`/api/v1/crm/accounts/${deleteId}`);
      setDeleteId(null);
      await load();
    } catch (e) {
      setDeleteId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function exportCsv() {
    try {
      const data = await api.get<{ filename: string; content: string }>("/api/v1/crm/accounts-export");
      const blob = new Blob([data.content], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const healthBadge = (h: string | null) => {
    if (!h) return null;
    const kind = h === "good" ? "completed" : h === "at_risk" ? "lead" : "withdrawn";
    const label = h === "good" ? t("healthGood") : h === "at_risk" ? t("healthAtRisk") : t("healthCritical");
    return <Badge text={label} kind={kind} />;
  };

  const totalPages = Math.max(1, Math.ceil(total / size));

  return (
    <div>
      {error && <ErrorBox message={error} />}

      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
          <Metric label={t("totalCustomers")} value={String(summary.total_accounts)} />
          <Metric label={t("openPipeline")} value={`${fmt(summary.open_pipeline_value)} ${t("egp")}`} />
          <Metric label={t("wonValue")} value={`${fmt(summary.won_value)} ${t("egp")}`} />
          <Metric label={t("quotationsTotal")} value={`${fmt(summary.quotation_total)} ${t("egp")}`} />
        </div>
      )}

      <div style={{ marginBottom: "1rem" }}>
        <Card>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder={t("searchCustomers")}
              style={{ ...inputStyle, flex: 1, minWidth: 200 }}
            />
            <select value={typeF} onChange={(e) => { setTypeF(e.target.value); setPage(1); }} style={{ ...inputStyle, width: "auto" }}>
              <option value="">{t("allTypes")}</option>
              <option value="lead">{t("typeLead")}</option>
              <option value="customer">{t("typeCustomer")}</option>
              <option value="supplier">{t("typeSupplier")}</option>
            </select>
            <select value={clsF} onChange={(e) => { setClsF(e.target.value); setPage(1); }} style={{ ...inputStyle, width: "auto" }}>
              <option value="">{t("allClassifications")}</option>
              {CLASSIFICATIONS.map((c) => <option key={c} value={c}>{clsLabel(t, c)}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ ...inputStyle, width: "auto" }}>
              <option value="newest">{t("sortNewest")}</option>
              <option value="name">{t("sortName")}</option>
              <option value="score">{t("sortScore")}</option>
            </select>
            <button onClick={exportCsv} style={btnGrey}>⬇ {t("exportCsv")}</button>
            <ImportExport exportPath="/api/v1/crm/accounts-export" importPath="/api/v1/crm/accounts-import" onImported={load} />
            <button onClick={() => setShowForm(!showForm)} style={btnStyle}>+ {t("newCustomer")}</button>
          </div>
          {showForm && <NewCustomerForm onDone={() => { setShowForm(false); load(); }} onError={setError} />}
        </Card>
      </div>

      <Card>
        {loading ? <Loading text={t("loadingData")} /> : accounts.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: 14, padding: 8 }}>{t("noCustomers")}</div>
        ) : (
          <>
            <Table
              headers={[t("customerCode"), t("customerName"), t("classification"), t("cityField"), t("customerScore"), t("customerHealth"), ""]}
              rows={accounts.map((a) => [
                <span key={a.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{a.code || "—"}</span>,
                <button key={a.id + "n"} onClick={() => onOpen(a)} style={linkBtn}>{a.name}</button>,
                <Badge key={a.id + "c"} text={clsLabel(t, a.classification)} kind="lead" />,
                a.city || "—",
                a.score ? `${a.score}` : "—",
                healthBadge(a.health) || "—",
                <RowActions key={a.id + "act"} deleteLabel={t("delete")} onDelete={() => setDeleteId(a.id)} />,
              ])}
            />
            {totalPages > 1 && (
              <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 14, alignItems: "center" }}>
                <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} style={pageBtn}>‹</button>
                <span style={{ fontSize: 13, color: "var(--text-muted)" }}>{page} / {totalPages}</span>
                <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} style={pageBtn}>›</button>
              </div>
            )}
          </>
        )}
      </Card>

      <ConfirmDialog
        open={!!deleteId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function NewCustomerForm({ onDone, onError }: { onDone: () => void; onError: (e: string) => void }) {
  const { t, dir } = useLang();
  const [f, setF] = useState({
    name: "", name_en: "", company_name: "", type: "lead", classification: "lead",
    industry: "", city: "", phone: "", email: "", tax_number: "",
    credit_limit: "", payment_terms_days: "", sales_engineer: "", score: "",
  });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/crm/accounts", {
        name: f.name, name_en: f.name_en || null, company_name: f.company_name || null,
        type: f.type, classification: f.classification || null, industry: f.industry || null,
        city: f.city || null, phone: f.phone || null, email: f.email || null,
        tax_number: f.tax_number || null,
        credit_limit: Number(f.credit_limit) || 0,
        payment_terms_days: Number(f.payment_terms_days) || 0,
        sales_engineer: f.sales_engineer || null, score: Number(f.score) || 0,
      });
      onDone();
    } catch (e) {
      onError(e instanceof Error ? e.message : "Error");
    }
  }

  const fld = (label: string, key: keyof typeof f, type = "text") => (
    <div>
      <label style={labelStyle}>{label}</label>
      <input type={type} value={f[key]} onChange={(e) => setF({ ...f, [key]: e.target.value })} style={inputStyle} required={key === "name"} />
    </div>
  );

  return (
    <form onSubmit={submit} style={{ marginTop: 16, borderTop: "1px solid var(--border)", paddingTop: 16 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12 }}>
        {fld(t("customerName"), "name")}
        {fld(t("nameEn"), "name_en")}
        {fld(t("companyName"), "company_name")}
        <div>
          <label style={labelStyle}>{t("customerType")}</label>
          <select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} style={inputStyle}>
            <option value="lead">{t("typeLead")}</option>
            <option value="customer">{t("typeCustomer")}</option>
            <option value="supplier">{t("typeSupplier")}</option>
          </select>
        </div>
        <div>
          <label style={labelStyle}>{t("classification")}</label>
          <select value={f.classification} onChange={(e) => setF({ ...f, classification: e.target.value })} style={inputStyle}>
            {CLASSIFICATIONS.map((c) => <option key={c} value={c}>{clsLabel(t, c)}</option>)}
          </select>
        </div>
        {fld(t("industry"), "industry")}
        {fld(t("cityField"), "city")}
        {fld(t("phoneField"), "phone")}
        {fld(t("emailField"), "email")}
        {fld(t("taxNumber"), "tax_number")}
        {fld(t("creditLimit"), "credit_limit", "number")}
        {fld(t("paymentTerms"), "payment_terms_days", "number")}
        {fld(t("salesEngineer"), "sales_engineer")}
        {fld(t("customerScore"), "score", "number")}
      </div>
      <div style={{ marginTop: 14 }}>
        <button type="submit" style={btnStyle}>{t("add")}</button>
      </div>
    </form>
  );
}

function CustomerDetail({ account, onBack }: { account: Account; onBack: () => void }) {
  const { t } = useLang();
  const [tab, setTab] = useState<"profile" | "contacts" | "timeline" | "view360">("profile");

  return (
    <div>
      <button onClick={onBack} style={{ ...btnGrey, marginBottom: 16 }}>← {t("backToList")}</button>
      <PageTitle>{account.name} {account.code ? `(${account.code})` : ""}</PageTitle>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <TabBtn active={tab === "profile"} onClick={() => setTab("profile")} label={t("profile")} />
        <TabBtn active={tab === "contacts"} onClick={() => setTab("contacts")} label={t("contacts")} />
        <TabBtn active={tab === "timeline"} onClick={() => setTab("timeline")} label={t("timeline")} />
        <TabBtn active={tab === "view360"} onClick={() => setTab("view360")} label={t("view360")} />
      </div>
      {tab === "profile" && <ProfileTab account={account} />}
      {tab === "contacts" && <ContactsTab accountId={account.id} />}
      {tab === "timeline" && <TimelineTab accountId={account.id} />}
      {tab === "view360" && <View360Tab accountId={account.id} />}
    </div>
  );
}

function ProfileTab({ account }: { account: Account }) {
  const { t } = useLang();
  const rows: [string, string | number | null][] = [
    [t("customerCode"), account.code], [t("nameEn"), account.name_en],
    [t("companyName"), account.company_name], [t("classification"), clsLabel(t, account.classification)],
    [t("industry"), account.industry], [t("activityField"), account.activity],
    [t("country"), account.country], [t("governorate"), account.governorate],
    [t("cityField"), account.city], [t("addressField"), account.address],
    [t("phoneField"), account.phone], [t("emailField"), account.email],
    [t("whatsapp"), account.whatsapp], [t("website"), account.website],
    [t("taxNumber"), account.tax_number], [t("commercialReg"), account.commercial_reg],
    [t("creditLimit"), account.credit_limit ? `${fmt(account.credit_limit)} ${account.currency}` : null],
    [t("paymentTerms"), account.payment_terms_days || null],
    [t("salesEngineer"), account.sales_engineer], [t("customerScore"), account.score || null],
    [t("source"), account.source],
  ];
  return (
    <Card>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14 }}>
        {rows.map(([label, val], i) => (
          <div key={i} style={{ borderBottom: "1px solid var(--border)", paddingBottom: 8 }}>
            <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{label}</div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{val ?? "—"}</div>
          </div>
        ))}
      </div>
      {account.notes && (
        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{t("notes")}</div>
          <div style={{ fontSize: 14 }}>{account.notes}</div>
        </div>
      )}
    </Card>
  );
}

function ContactsTab({ accountId }: { accountId: string }) {
  const { t, dir } = useLang();
  const [contacts, setContacts] = useState<CrmContact[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [f, setF] = useState({ name: "", position: "", department: "", phone: "", email: "", whatsapp: "", is_decision_maker: false, is_primary: false });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const load = useCallback(async () => {
    try { setContacts(await api.get<CrmContact[]>(`/api/v1/crm/accounts/${accountId}/contacts`)); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }, [accountId]);
  useEffect(() => { load(); }, [load]);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/crm/accounts/${accountId}/contacts`, {
        name: f.name, position: f.position || null, department: f.department || null,
        phone: f.phone || null, email: f.email || null, whatsapp: f.whatsapp || null,
        is_decision_maker: f.is_decision_maker, is_primary: f.is_primary,
      });
      setF({ name: "", position: "", department: "", phone: "", email: "", whatsapp: "", is_decision_maker: false, is_primary: false });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("addContact")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("contactName")}</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("position")}</label><input value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("department")}</label><input value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("phoneField")}</label><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("emailField")}</label><input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} style={inputStyle} /></div>
            <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, paddingBottom: 8 }}>
              <input type="checkbox" checked={f.is_decision_maker} onChange={(e) => setF({ ...f, is_decision_maker: e.target.checked })} />
              {t("decisionMaker")}
            </label>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
        </Card>
      </div>
      <Card>
        {contacts.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noContacts")}</div> : (
          <Table
            headers={[t("contactName"), t("position"), t("department"), t("phoneField"), t("emailField"), ""]}
            rows={contacts.map((c) => [
              <span key={c.id} style={{ fontWeight: 500 }}>{c.name}</span>,
              c.position || "—", c.department || "—", c.phone || "—", c.email || "—",
              c.is_decision_maker ? <Badge key={c.id + "d"} text={t("decisionMaker")} kind="completed" /> : <span key={c.id + "x"} />,
            ])}
          />
        )}
      </Card>
    </>
  );
}

function TimelineTab({ accountId }: { accountId: string }) {
  const { t, dir } = useLang();
  const [activities, setActivities] = useState<CrmActivity[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [f, setF] = useState({ activity_type: "call", subject: "", body: "", due_date: "" });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const typeLabel: Record<string, string> = {
    call: t("actCall"), meeting: t("actMeeting"), site_visit: t("actSiteVisit"),
    task: t("actTask"), note: t("actNote"), email: t("actEmail"),
  };
  const typeIcon: Record<string, string> = {
    call: "📞", meeting: "🤝", site_visit: "📍", task: "✅", note: "📝", email: "✉️",
  };

  const load = useCallback(async () => {
    try { setActivities(await api.get<CrmActivity[]>(`/api/v1/crm/accounts/${accountId}/activities`)); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }, [accountId]);
  useEffect(() => { load(); }, [load]);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/crm/accounts/${accountId}/activities`, {
        activity_type: f.activity_type, subject: f.subject, body: f.body || null,
        due_date: f.due_date || null,
      });
      setF({ activity_type: "call", subject: "", body: "", due_date: "" });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function toggleDone(a: CrmActivity) {
    try { await api.patch(`/api/v1/crm/activities/${a.id}`, { is_done: !a.is_done }); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("logActivity")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "1fr 2fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("activityType")}</label>
              <select value={f.activity_type} onChange={(e) => setF({ ...f, activity_type: e.target.value })} style={inputStyle}>
                {Object.keys(typeLabel).map((k) => <option key={k} value={k}>{typeLabel[k]}</option>)}
              </select>
            </div>
            <div><label style={labelStyle}>{t("subject")}</label><input value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("dueDate")}</label><input type="date" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} style={inputStyle} /></div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
        </Card>
      </div>
      <Card>
        {activities.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noActivities")}</div> : (
          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
            {activities.map((a, i) => (
              <div key={a.id} style={{ display: "flex", gap: 12, padding: "12px 0", borderBottom: i < activities.length - 1 ? "1px solid var(--border)" : "none" }}>
                <div style={{ fontSize: 20 }}>{typeIcon[a.activity_type] || "•"}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontWeight: 500, textDecoration: a.is_done ? "line-through" : "none", opacity: a.is_done ? 0.6 : 1 }}>{a.subject}</span>
                    <span style={{ fontSize: 12, color: "var(--text-muted)" }}>{new Date(a.activity_date).toLocaleDateString()}</span>
                  </div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>
                    <Badge text={typeLabel[a.activity_type] || a.activity_type} kind="lead" />
                    {a.due_date && <span style={{ marginInlineStart: 8 }}>{t("dueDate")}: {a.due_date}</span>}
                  </div>
                  {a.body && <div style={{ fontSize: 13, marginTop: 4 }}>{a.body}</div>}
                </div>
                {a.activity_type === "task" && (
                  <button onClick={() => toggleDone(a)} style={{ ...miniBtn, color: a.is_done ? "var(--text-muted)" : "#1a7d3c" }}>
                    {a.is_done ? "↺" : t("markDone")}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid var(--border)", background: active ? "var(--brand)" : "var(--surface)", color: active ? "#fff" : "var(--text)", fontSize: 14, fontWeight: 500 }}>
      {label}
    </button>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500 };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
const linkBtn: React.CSSProperties = { background: "none", border: "none", color: "var(--brand)", fontWeight: 600, fontSize: 14, cursor: "pointer", padding: 0, textAlign: "start" };
const pageBtn: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 6, padding: "4px 12px", fontSize: 14, cursor: "pointer" };

function PipelineBoard() {
  const { t, dir } = useLang();
  const [pipe, setPipe] = useState<PipelineData | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [losingId, setLosingId] = useState<string | null>(null);
  const [lossReason, setLossReason] = useState("");
  const [competitor, setCompetitor] = useState("");
  const [f, setF] = useState({ account_id: "", title: "", value: "", probability: "50", expected_close: "" });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const OPEN_STAGES = ["new", "qualified", "proposal", "negotiation"];
  const stageLabel: Record<string, string> = {
    new: t("stgNew"), qualified: t("stgQualified"), proposal: t("stgProposal"),
    negotiation: t("stgNegotiation"), won: t("stgWon"), lost: t("stgLost"),
  };
  const nextStage: Record<string, string> = {
    new: "qualified", qualified: "proposal", proposal: "negotiation",
  };

  async function load() {
    setLoading(true);
    try {
      const [p, accs] = await Promise.all([
        api.get<PipelineData>("/api/v1/crm/pipeline"),
        api.get<Page<Account>>("/api/v1/crm/accounts?size=100"),
      ]);
      setPipe(p);
      setAccounts(accs.items);
      if (accs.items.length && !f.account_id) setF((x) => ({ ...x, account_id: accs.items[0].id }));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function addOpp(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/crm/opportunities", {
        account_id: f.account_id, title: f.title,
        value: Number(f.value) || 0, probability: Number(f.probability) || 0,
        expected_close: f.expected_close || null,
      });
      setF({ ...f, title: "", value: "", probability: "50", expected_close: "" });
      setShowForm(false);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function move(card: PipelineCard, stage: string, extra: Record<string, unknown> = {}) {
    try {
      await api.patch(`/api/v1/crm/opportunities/${card.id}`, { stage, ...extra });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function confirmLost() {
    if (!losingId) return;
    try {
      await api.patch(`/api/v1/crm/opportunities/${losingId}`, {
        stage: "lost", loss_reason: lossReason || null, competitor: competitor || null,
      });
      setLosingId(null); setLossReason(""); setCompetitor("");
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (loading) return <Loading text={t("loadingData")} />;
  if (!pipe) return error ? <ErrorBox message={error} /> : null;

  const cols = pipe.stages.filter((s) => OPEN_STAGES.includes(s.stage));
  const wonCol = pipe.stages.find((s) => s.stage === "won");
  const lostCol = pipe.stages.find((s) => s.stage === "lost");
  const findStage = (c: PipelineCard) => pipe.stages.find((s) => s.items.some((i) => i.id === c.id))?.stage || "new";

  return (
    <div>
      {error && <ErrorBox message={error} />}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
        <Metric label={t("openPipelineTotal")} value={`${fmt(pipe.open_total)} ${t("egp")}`} />
        <Metric label={t("weightedForecast")} value={`${fmt(pipe.weighted_forecast)} ${t("egp")}`} />
        <Metric label={t("wonTotal")} value={`${fmt(pipe.won_total)} ${t("egp")}`} />
        <Metric label={t("lostTotal")} value={`${fmt(pipe.lost_total)} ${t("egp")}`} />
      </div>

      <div style={{ marginBottom: "1rem" }}>
        <button onClick={() => setShowForm(!showForm)} style={btnStyle}>+ {t("newOpportunity")}</button>
        {showForm && (
          <div style={{ marginTop: 12 }}>
            <Card>
              <form onSubmit={addOpp} style={{ display: "grid", gridTemplateColumns: "1.4fr 1.6fr 1fr 0.8fr 1fr auto", gap: 10, alignItems: "end" }}>
                <div><label style={labelStyle}>{t("customerName")}</label>
                  <select value={f.account_id} onChange={(e) => setF({ ...f, account_id: e.target.value })} required style={inputStyle}>
                    {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                </div>
                <div><label style={labelStyle}>{t("oppTitle")}</label><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("oppValue")}</label><input type="number" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("probability")}</label><input type="number" min="0" max="100" value={f.probability} onChange={(e) => setF({ ...f, probability: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("expectedClose")}</label><input type="date" value={f.expected_close} onChange={(e) => setF({ ...f, expected_close: e.target.value })} style={inputStyle} /></div>
                <button type="submit" style={btnStyle}>{t("add")}</button>
              </form>
            </Card>
          </div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, alignItems: "start", overflowX: "auto" }}>
        {cols.map((col) => (
          <div key={col.stage} style={{ background: "var(--bg)", borderRadius: 10, padding: 10, minWidth: 200 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, alignItems: "center" }}>
              <span style={{ fontWeight: 600, fontSize: 14 }}>{stageLabel[col.stage]}</span>
              <span style={{ fontSize: 12, color: "var(--text-muted)" }}>{col.count} · {fmt(col.total_value)}</span>
            </div>
            {col.items.length === 0 ? (
              <div style={{ fontSize: 12, color: "var(--text-muted)", padding: 6 }}>{t("noOpportunities")}</div>
            ) : col.items.map((c) => (
              <div key={c.id} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: 10, marginBottom: 8 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{c.title}</div>
                <div style={{ fontSize: 12, color: "var(--text-muted)", margin: "3px 0" }}>{c.account_name}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "var(--brand)" }}>{fmt(c.value)} {t("egp")} · {c.probability}%</div>
                {c.expected_close && <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{c.expected_close}</div>}
                <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                  {nextStage[col.stage] && (
                    <button onClick={() => move(c, nextStage[col.stage])} style={miniBtn}>{t("advanceStage")} ←</button>
                  )}
                  <button onClick={() => move(c, "won")} style={{ ...miniBtn, color: "#1a7d3c" }}>{t("markWon")}</button>
                  <button onClick={() => setLosingId(c.id)} style={{ ...miniBtn, color: "#a32d2d" }}>{t("markLost")}</button>
                </div>
                {losingId === c.id && (
                  <div style={{ marginTop: 8, borderTop: "1px solid var(--border)", paddingTop: 8, display: "flex", flexDirection: "column", gap: 6 }}>
                    <input placeholder={t("lossReason")} value={lossReason} onChange={(e) => setLossReason(e.target.value)} style={inputStyle} />
                    <input placeholder={t("competitorField")} value={competitor} onChange={(e) => setCompetitor(e.target.value)} style={inputStyle} />
                    <button onClick={confirmLost} style={{ ...miniBtn, color: "#a32d2d", alignSelf: "flex-start" }}>{t("confirmLost")}</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 16 }}>
        {[wonCol, lostCol].map((col) => col && (
          <Card key={col.stage}>
            <div style={{ fontWeight: 600, marginBottom: 8, color: col.stage === "won" ? "#1a7d3c" : "#a32d2d" }}>
              {stageLabel[col.stage]} ({col.count}) — {fmt(col.total_value)} {t("egp")}
            </div>
            {col.items.slice(0, 5).map((c) => (
              <div key={c.id} style={{ fontSize: 13, padding: "4px 0", borderBottom: "1px solid var(--border)" }}>
                {c.title} — {c.account_name} — {fmt(c.value)}
                {c.loss_reason && <span style={{ color: "var(--text-muted)" }}> · {t("lossReason")}: {c.loss_reason}</span>}
              </div>
            ))}
          </Card>
        ))}
      </div>
    </div>
  );
}

function View360Tab({ accountId }: { accountId: string }) {
  const { t } = useLang();
  const [data, setData] = useState<Account360Data | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<Account360Data>(`/api/v1/crm/accounts/${accountId}/summary360`)
      .then(setData)
      .catch((e) => setError(e instanceof Error ? e.message : "Error"))
      .finally(() => setLoading(false));
  }, [accountId]);

  if (loading) return <Loading text={t("loadingData")} />;
  if (error) return <ErrorBox message={error} />;
  if (!data) return null;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
      <Metric label={t("projects360")} value={String(data.projects_count)} sub={`${fmt(data.projects_value)} ${t("egp")}`} />
      <Metric label={t("invoices360")} value={String(data.invoices_count)} sub={`${fmt(data.invoices_total)} ${t("egp")}`} />
      <Metric label={t("paid360")} value={`${fmt(data.invoices_paid)} ${t("egp")}`} />
      <Metric label={t("balance360")} value={`${fmt(data.invoices_balance)} ${t("egp")}`} />
      <Metric label={t("quotes360")} value={String(data.quotations_count)} sub={`${fmt(data.quotations_total)} ${t("egp")}`} />
      <Metric label={t("opps360")} value={String(data.open_opportunities)} sub={`${fmt(data.open_opportunities_value)} ${t("egp")}`} />
      <Metric label={t("won360")} value={`${fmt(data.won_value)} ${t("egp")}`} />
      <Metric label={t("students360")} value={String(data.students_count)} sub={`${fmt(data.training_fees)} ${t("egp")}`} />
      <Metric label={t("activities360")} value={String(data.activities_count)} />
    </div>
  );
}


function QuotationsTab() {
  const { t, dir } = useLang();
  const router = useRouter();
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [products, setProducts] = useState<CrmProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [f, setF] = useState({
    account_id: "", title: "", valid_until: "", tax_rate: "14", discount_amount: "",
    payment_terms: "", delivery_period: "", terms: "", prepared_by: "",
  });
  const [lines, setLines] = useState([{ product_id: "", description: "", unit: "", qty: "1", unit_price: "", discount_pct: "0" }]);
  const qInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)", textAlign: dir === "rtl" ? "right" : "left" };

  const stLabel: Record<string, string> = {
    draft: t("qsDraft"), sent: t("qsSent"), accepted: t("qsAccepted"), rejected: t("qsRejected"),
  };
  const stKind: Record<string, string> = { draft: "lead", sent: "lead", accepted: "completed", rejected: "withdrawn" };

  async function load() {
    setLoading(true);
    try {
      const [qs, accs, prods] = await Promise.all([
        api.get<Page<Quotation>>("/api/v1/crm/quotations?size=100"),
        api.get<Page<Account>>("/api/v1/crm/accounts?size=100"),
        api.get<CrmProduct[]>("/api/v1/crm/products?active_only=true"),
      ]);
      setQuotations(qs.items);
      setAccounts(accs.items);
      setProducts(prods);
      if (accs.items.length && !f.account_id) setF((x) => ({ ...x, account_id: accs.items[0].id }));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const accName = (id: string) => accounts.find((a) => a.id === id)?.name || "—";

  // Live totals mirror the server formula exactly, so what the user sees
  // while typing is what gets saved.
  const gross = lines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.unit_price) || 0), 0);
  const lineDisc = lines.reduce((s, l) => {
    const raw = (Number(l.qty) || 0) * (Number(l.unit_price) || 0);
    return s + raw * ((Number(l.discount_pct) || 0) / 100);
  }, 0);
  const headerDisc = Math.min(Number(f.discount_amount) || 0, gross - lineDisc);
  const subtotal = gross - lineDisc - headerDisc;
  const taxAmt = subtotal * ((Number(f.tax_rate) || 0) / 100);

  function pickProduct(i: number, productId: string) {
    const p = products.find((x) => x.id === productId);
    setLines(lines.map((x, j) => j === i ? (p
      ? { ...x, product_id: p.id, description: p.name, unit: p.unit, unit_price: String(p.unit_price) }
      : { ...x, product_id: "" }) : x));
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/crm/quotations", {
        account_id: f.account_id,
        title: f.title || null,
        valid_until: f.valid_until || null,
        tax_rate: (Number(f.tax_rate) || 0) / 100,
        discount_amount: Number(f.discount_amount) || 0,
        payment_terms: f.payment_terms || null,
        delivery_period: f.delivery_period || null,
        terms: f.terms || null,
        prepared_by: f.prepared_by || null,
        lines: lines
          .filter((l) => l.description && Number(l.qty) > 0)
          .map((l) => ({
            product_id: l.product_id || null,
            description: l.description,
            unit: l.unit || null,
            qty: Number(l.qty),
            unit_price: Number(l.unit_price) || 0,
            discount_pct: Number(l.discount_pct) || 0,
          })),
      });
      setLines([{ product_id: "", description: "", unit: "", qty: "1", unit_price: "", discount_pct: "0" }]);
      setF({ ...f, title: "", valid_until: "", discount_amount: "" });
      setShowForm(false);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function setStatus(q: Quotation, status: string) {
    try { await api.patch(`/api/v1/crm/quotations/${q.id}/status/${status}`, {}); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      {error && <ErrorBox message={error} />}

      <div style={{ marginBottom: "1rem" }}>
        <button onClick={() => setShowForm(!showForm)} style={btnStyle}>+ {t("newQuotation")}</button>
      </div>

      {showForm && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <form onSubmit={save}>
              <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1.6fr 1fr 0.7fr", gap: 10, marginBottom: 12 }}>
                <div><label style={labelStyle}>{t("customerName")}</label>
                  <select value={f.account_id} onChange={(e) => setF({ ...f, account_id: e.target.value })} required style={qInput}>
                    {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                </div>
                <div><label style={labelStyle}>{t("quotTitle")}</label><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} style={qInput} /></div>
                <div><label style={labelStyle}>{t("validUntil")}</label><input type="date" value={f.valid_until} onChange={(e) => setF({ ...f, valid_until: e.target.value })} style={qInput} /></div>
                <div><label style={labelStyle}>{t("taxRatePct")}</label><input type="number" min="0" max="100" value={f.tax_rate} onChange={(e) => setF({ ...f, tax_rate: e.target.value })} style={qInput} /></div>
              </div>

              {lines.map((l, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "1.3fr 1.8fr 0.6fr 0.9fr 0.7fr 1fr auto", gap: 8, marginBottom: 8, alignItems: "center" }}>
                  <select value={l.product_id} onChange={(e) => pickProduct(i, e.target.value)} style={qInput}>
                    <option value="">{t("pickFromCatalogue")}</option>
                    {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <input placeholder={t("lineDesc")} value={l.description} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, description: e.target.value } : x))} required style={qInput} />
                  <input type="number" placeholder={t("lineQty")} min="0.01" step="0.01" value={l.qty} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, qty: e.target.value } : x))} style={qInput} />
                  <input type="number" placeholder={t("lineUnitPrice")} min="0" value={l.unit_price} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, unit_price: e.target.value } : x))} style={qInput} />
                  <input type="number" placeholder="%" min="0" max="100" value={l.discount_pct} onChange={(e) => setLines(lines.map((x, j) => j === i ? { ...x, discount_pct: e.target.value } : x))} style={qInput} />
                  <div style={{ fontSize: 13, fontWeight: 600 }}>
                    {fmt((Number(l.qty) || 0) * (Number(l.unit_price) || 0) * (1 - (Number(l.discount_pct) || 0) / 100))}
                  </div>
                  {lines.length > 1 && <button type="button" onClick={() => setLines(lines.filter((_, j) => j !== i))} style={qMini}>✕</button>}
                </div>
              ))}
              <button type="button" onClick={() => setLines([...lines, { product_id: "", description: "", unit: "", qty: "1", unit_price: "", discount_pct: "0" }])} style={qGrey}>{t("addLine")}</button>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 10, marginTop: 14 }}>
                <div><label style={labelStyle}>{t("headerDiscount")}</label><input type="number" min="0" value={f.discount_amount} onChange={(e) => setF({ ...f, discount_amount: e.target.value })} style={qInput} /></div>
                <div><label style={labelStyle}>{t("paymentTermsField")}</label><input value={f.payment_terms} onChange={(e) => setF({ ...f, payment_terms: e.target.value })} style={qInput} placeholder="50% مقدم" /></div>
                <div><label style={labelStyle}>{t("deliveryPeriod")}</label><input value={f.delivery_period} onChange={(e) => setF({ ...f, delivery_period: e.target.value })} style={qInput} placeholder="٤ أسابيع" /></div>
                <div><label style={labelStyle}>{t("preparedBy")}</label><input value={f.prepared_by} onChange={(e) => setF({ ...f, prepared_by: e.target.value })} style={qInput} /></div>
              </div>
              <div style={{ marginTop: 10 }}>
                <label style={labelStyle}>{t("quotTerms")}</label>
                <textarea value={f.terms} onChange={(e) => setF({ ...f, terms: e.target.value })} rows={2} style={{ ...qInput, resize: "vertical" }} />
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16, borderTop: "1px solid var(--border)", paddingTop: 12, flexWrap: "wrap", gap: 10 }}>
                <div style={{ fontSize: 13.5 }}>
                  {t("quotGross")}: <strong>{fmt(gross)}</strong>
                  {(lineDisc > 0 || headerDisc > 0) && <> &nbsp;|&nbsp; <span style={{ color: "#c0392b" }}>− {fmt(lineDisc + headerDisc)}</span></>}
                  &nbsp;|&nbsp; {t("quotTax")}: <strong>{fmt(taxAmt)}</strong>
                  &nbsp;|&nbsp; {t("quotGrand")}: <strong style={{ color: "var(--brand)" }}>{fmt(subtotal + taxAmt)} {t("egp")}</strong>
                </div>
                <button type="submit" style={btnStyle}>{t("saveQuotation")}</button>
              </div>
            </form>
          </Card>
        </div>
      )}

      <Card>
        {quotations.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noQuotations")}</div>
        ) : (
          <Table
            headers={[t("quotNumber"), t("customerName"), t("quotStatus"), t("quotSubtotal"), t("quotTax"), t("quotGrand"), ""]}
            rows={quotations.map((q) => [
              <span key={q.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{q.number}</span>,
              accName(q.account_id),
              <Badge key={q.id + "s"} text={stLabel[q.status] || q.status} kind={stKind[q.status]} />,
              fmt(q.subtotal),
              fmt(q.tax),
              <strong key={q.id + "t"}>{fmt(q.total)} {t("egp")}</strong>,
              <span key={q.id + "a"} style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button onClick={() => router.push(`/crm/quotations/${q.id}/print`)} style={qMiniBlue}>{t("printQuotation")}</button>
                {q.status === "draft" && <button onClick={() => setStatus(q, "sent")} style={qMiniBlue}>{t("markSent")}</button>}
                {q.status === "sent" && <>
                  <button onClick={() => setStatus(q, "accepted")} style={{ ...qMini, color: "#1a7d3c" }}>{t("markAccepted")}</button>
                  <button onClick={() => setStatus(q, "rejected")} style={qMini}>{t("markRejected")}</button>
                </>}
              </span>,
            ])}
          />
        )}
      </Card>
    </div>
  );
}

const qMini: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "#a32d2d" };
const qMiniBlue: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "var(--brand)" };
const qGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "7px 14px", fontSize: 13 };
