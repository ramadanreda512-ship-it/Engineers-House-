"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { CrmProduct, FollowUpBoardData, FollowUpItem, LossAnalysisData } from "@/lib/types";
import { Card, Metric, Table, Badge, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

const UNITS = ["piece", "hour", "day", "session", "trainee", "meter", "lump_sum", "month"];

/* ==================== 1) Sales catalogue ==================== */
export function CatalogueTab() {
  const { t } = useLang();
  const [items, setItems] = useState<CrmProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [f, setF] = useState({ code: "", name: "", category: "", unit: "piece", unit_price: "", unit_cost: "" });
  const [edit, setEdit] = useState<CrmProduct | null>(null);

  const unitLabel: Record<string, string> = {
    piece: t("unitPiece"), hour: t("unitHour"), day: t("unitDay"), session: t("unitSession"),
    trainee: t("unitTrainee"), meter: t("unitMeter"), lump_sum: t("unitLumpSum"), month: t("unitMonth"),
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setItems(await api.get<CrmProduct[]>("/api/v1/crm/products"));
      setError(null);
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/crm/products", {
        code: f.code.toUpperCase(), name: f.name, category: f.category || null,
        unit: f.unit, unit_price: Number(f.unit_price) || 0, unit_cost: Number(f.unit_cost) || 0,
      });
      setF({ code: "", name: "", category: "", unit: "piece", unit_price: "", unit_cost: "" });
      setShowAdd(false);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function toggle(p: CrmProduct) {
    try { await api.patch(`/api/v1/crm/products/${p.id}`, { is_active: !p.is_active }); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function remove(p: CrmProduct) {
    if (!confirm(`${t("confirmDelete")} ${p.name}?`)) return;
    try { await api.del(`/api/v1/crm/products/${p.id}`); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  const margin = (p: CrmProduct) =>
    p.unit_price > 0 ? Math.round(((p.unit_price - p.unit_cost) / p.unit_price) * 100) : 0;

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1rem" }}>
        <button onClick={() => setShowAdd(!showAdd)} style={btn}>+ {t("addService")}</button>
      </div>

      {showAdd && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <form onSubmit={save} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.8fr 1fr 0.9fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
              <div><label style={lbl}>{t("svcCode")}</label><input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} required style={inp} /></div>
              <div><label style={lbl}>{t("svcName")}</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required style={inp} /></div>
              <div><label style={lbl}>{t("svcCategory")}</label><input value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} style={inp} /></div>
              <div><label style={lbl}>{t("svcUnit")}</label>
                <select value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} style={inp}>
                  {UNITS.map((u) => <option key={u} value={u}>{unitLabel[u]}</option>)}
                </select>
              </div>
              <div><label style={lbl}>{t("svcPrice")}</label><input type="number" min="0" value={f.unit_price} onChange={(e) => setF({ ...f, unit_price: e.target.value })} required style={inp} /></div>
              <div><label style={lbl}>{t("svcCost")}</label><input type="number" min="0" value={f.unit_cost} onChange={(e) => setF({ ...f, unit_cost: e.target.value })} style={inp} /></div>
              <button type="submit" style={btn}>{t("save")}</button>
            </form>
          </Card>
        </div>
      )}

      <Card>
        {items.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noServices")}</div>
        ) : (
          <Table
            headers={[t("svcCode"), t("svcName"), t("svcCategory"), t("svcUnit"), t("svcPrice"), t("svcCost"), t("svcMargin"), ""]}
            rows={items.map((p) => [
              <span key={p.id} style={{ fontFamily: "monospace", fontSize: 12, opacity: p.is_active ? 1 : 0.5 }}>{p.code}</span>,
              <span key={p.id + "n"} style={{ fontWeight: 500, opacity: p.is_active ? 1 : 0.5 }}>{p.name}</span>,
              p.category || "—",
              unitLabel[p.unit] || p.unit,
              `${fmt(p.unit_price)} ${t("egp")}`,
              p.unit_cost > 0 ? `${fmt(p.unit_cost)}` : "—",
              p.unit_cost > 0 ? <Badge key={p.id + "m"} text={`${margin(p)}%`} kind={margin(p) >= 30 ? "completed" : "waitlisted"} /> : "—",
              <span key={p.id + "a"} style={{ display: "flex", gap: 6 }}>
                <button onClick={() => setEdit(p)} style={mini}>✏️</button>
                <button onClick={() => toggle(p)} style={mini}>{p.is_active ? "🚫" : "✓"}</button>
                <button onClick={() => remove(p)} style={{ ...mini, color: "#c0392b" }}>🗑</button>
              </span>,
            ])}
          />
        )}
      </Card>

      {edit && <EditProduct product={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load(); }} />}
    </div>
  );
}

function EditProduct({ product, onClose, onDone }: { product: CrmProduct; onClose: () => void; onDone: () => void }) {
  const { t } = useLang();
  const [name, setName] = useState(product.name);
  const [price, setPrice] = useState(String(product.unit_price));
  const [cost, setCost] = useState(String(product.unit_cost));
  const [err, setErr] = useState<string | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.patch(`/api/v1/crm/products/${product.id}`, {
        name, unit_price: Number(price) || 0, unit_cost: Number(cost) || 0,
      });
      onDone();
    } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }
  return (
    <div style={overlay}>
      <div style={modal}>
        <h3 style={{ marginTop: 0 }}>{product.code}</h3>
        {err && <ErrorBox message={err} />}
        <form onSubmit={submit}>
          <label style={lbl}>{t("svcName")}</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required style={inp} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <div><label style={lbl}>{t("svcPrice")}</label><input type="number" value={price} onChange={(e) => setPrice(e.target.value)} style={inp} /></div>
            <div><label style={lbl}>{t("svcCost")}</label><input type="number" value={cost} onChange={(e) => setCost(e.target.value)} style={inp} /></div>
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 18, justifyContent: "flex-end" }}>
            <button type="button" onClick={onClose} style={btnGrey}>{t("cancel")}</button>
            <button type="submit" style={btn}>{t("save")}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ==================== 2) Follow-up centre ==================== */
export function FollowUpsTab() {
  const { t } = useLang();
  const [board, setBoard] = useState<FollowUpBoardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setBoard(await api.get<FollowUpBoardData>("/api/v1/crm/follow-ups"));
      setError(null);
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  async function markDone(item: FollowUpItem) {
    try { await api.patch(`/api/v1/crm/activities/${item.id}`, { is_done: true }); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (loading) return <Loading text={t("loadingData")} />;
  if (!board) return null;

  const row = (item: FollowUpItem, color: string, showDone = true) => (
    <div key={item.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 4px", borderBottom: "1px solid var(--border)", gap: 10, flexWrap: "wrap" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        {showDone && <button onClick={() => markDone(item)} style={{ ...mini, color: "#16a34a" }}>✓</button>}
        {item.account_phone && (
          <a href={`tel:${item.account_phone}`} style={{ ...mini, textDecoration: "none", display: "inline-block", color: "var(--brand)" }}>{t("callNow")}</a>
        )}
        {item.account_whatsapp && (
          <a href={`https://wa.me/${item.account_whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer" style={{ ...mini, textDecoration: "none", display: "inline-block", color: "#25D366" }}>واتساب</a>
        )}
      </div>
      <div style={{ textAlign: "end", flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{item.subject}</div>
        <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>
          {item.account_name}
          {item.days_overdue > 0 && <span style={{ color, fontWeight: 600 }}> · {item.days_overdue} {t("daysAgo")}</span>}
          {item.value > 0 && <span> · {fmt(item.value)} {t("egp")}</span>}
        </div>
      </div>
    </div>
  );

  return (
    <div>
      {error && <ErrorBox message={error} />}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
        <div style={{ padding: "14px 16px", background: "var(--surface)", border: `1px solid ${board.due_today_count > 0 ? "#c0392b" : "var(--border)"}`, borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{t("dueTodayCrm")}</div>
          <div style={{ fontSize: 26, fontWeight: 800, color: board.due_today_count > 0 ? "#c0392b" : "var(--text)" }}>{board.due_today_count}</div>
        </div>
        <Metric label={t("overdueCrm")} value={String(board.overdue_count)} />
        <Metric label={t("staleOpps")} value={String(board.stale_count)} />
      </div>

      {board.due_today_count === 0 && board.overdue_count === 0 && board.stale_count === 0 ? (
        <Card><div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noFollowUps")}</div></Card>
      ) : (
        <div style={{ display: "grid", gap: 14 }}>
          {board.due_today.length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 8, color: "#c0392b" }}>🔔 {t("dueTodayCrm")}</div>
              {board.due_today.map((i) => row(i, "#c0392b"))}
            </Card>
          )}
          {board.overdue.length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 8, color: "#e67e22" }}>⏰ {t("overdueCrm")}</div>
              {board.overdue.map((i) => row(i, "#e67e22"))}
            </Card>
          )}
          {board.stale_opportunities.length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 2 }}>💤 {t("staleOpps")}</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 8 }}>{t("staleHint")}</div>
              {board.stale_opportunities.map((i) => row(i, "#64748b", false))}
            </Card>
          )}
          {board.upcoming.length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 8, color: "var(--text-muted)" }}>📅 {t("upcomingCrm")}</div>
              {board.upcoming.map((i) => row(i, "var(--text-muted)"))}
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

/* ==================== 3) Loss analysis ==================== */
export function LossAnalysisTab() {
  const { t } = useLang();
  const [data, setData] = useState<LossAnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try { setData(await api.get<LossAnalysisData>("/api/v1/crm/reports/loss-analysis")); }
      catch (e) { setError(e instanceof Error ? e.message : "Error"); }
      finally { setLoading(false); }
    })();
  }, []);

  if (loading) return <Loading text={t("loadingData")} />;
  if (error) return <ErrorBox message={error} />;
  if (!data) return null;

  const maxReason = Math.max(1, ...data.by_reason.map((r) => r.count));
  const maxComp = Math.max(1, ...data.by_competitor.map((c) => c.count));

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
        <Metric label={t("winRate")} value={`${data.win_rate_pct}%`} />
        <Metric label={t("wonDeals")} value={String(data.won_count)} sub={`${fmt(data.won_value)} ${t("egp")}`} />
        <Metric label={t("lostDeals")} value={String(data.lost_count)} sub={`${fmt(data.lost_value)} ${t("egp")}`} />
        <Metric label={t("avgWon")} value={`${fmt(data.avg_won_value)} ${t("egp")}`} />
      </div>

      {data.lost_count === 0 ? (
        <Card><div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noLossData")}</div></Card>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 14 }}>
          <Card>
            <div style={{ fontWeight: 600, marginBottom: 14 }}>❓ {t("whyWeLose")}</div>
            {data.by_reason.map((r) => (
              <div key={r.reason} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                  <span style={{ color: "var(--text-muted)" }}>{fmt(r.value)} {t("egp")} · <b style={{ color: "#c0392b" }}>{r.pct}%</b></span>
                  <span style={{ fontWeight: 500 }}>{r.reason}</span>
                </div>
                <div style={{ height: 8, background: "var(--bg)", borderRadius: 99 }}>
                  <div style={{ height: "100%", width: `${(r.count / maxReason) * 100}%`, borderRadius: 99, background: "linear-gradient(90deg,#c0392b88,#c0392b)" }} />
                </div>
              </div>
            ))}
          </Card>

          <Card>
            <div style={{ fontWeight: 600, marginBottom: 14 }}>🥊 {t("whoBeatsUs")}</div>
            {data.by_competitor.length === 0 ? (
              <div style={{ fontSize: 13, color: "var(--text-muted)" }}>—</div>
            ) : data.by_competitor.map((c) => (
              <div key={c.competitor} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                  <span style={{ color: "var(--text-muted)" }}>{c.count} {t("timesLost")} · {fmt(c.value)} {t("egp")}</span>
                  <span style={{ fontWeight: 500 }}>{c.competitor}</span>
                </div>
                <div style={{ height: 8, background: "var(--bg)", borderRadius: 99 }}>
                  <div style={{ height: "100%", width: `${(c.count / maxComp) * 100}%`, borderRadius: 99, background: "linear-gradient(90deg,#e67e2288,#e67e22)" }} />
                </div>
              </div>
            ))}
          </Card>
        </div>
      )}
    </div>
  );
}

/* styles */
const inp: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const lbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const btn: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", fontSize: 13.5, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 18px", fontSize: 13.5, cursor: "pointer" };
const mini: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "var(--text)" };
const overlay: React.CSSProperties = { position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 };
const modal: React.CSSProperties = { background: "var(--surface)", borderRadius: 14, padding: 24, width: "100%", maxWidth: 430 };
