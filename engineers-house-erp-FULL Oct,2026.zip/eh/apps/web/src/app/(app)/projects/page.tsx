"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { Project, Page, ProjectsSummaryData } from "@/lib/types";
import { PageTitle, Card, Metric, Table, Loading, ErrorBox, fmt, RowActions, ConfirmDialog, EditDialog, Field, dialogInput } from "@/components/ui";
import { useLang } from "@/lib/i18n";
import ImportExport from "@/components/ImportExport";

export default function ProjectsPage() {
  const { t, dir } = useLang();
  const [projects, setProjects] = useState<Project[]>([]);
  const [summary, setSummary] = useState<ProjectsSummaryData | null>(null);
  const [search, setSearch] = useState("");
  const [statusF, setStatusF] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  const [retention, setRetention] = useState("10");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // edit / cancel project
  const [editProj, setEditProj] = useState<Project | null>(null);
  const [eName, setEName] = useState("");
  const [eValue, setEValue] = useState("");
  const [eRetention, setERetention] = useState("");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [cancelProjId, setCancelProjId] = useState<string | null>(null);

  const statusLabel: Record<string, string> = {
    planned: t("statusPlanned"),
    active: t("statusActive"),
    on_hold: t("statusOnHold"),
    completed: t("statusCompleted"),
    cancelled: t("statusCancelled"),
  };

  async function load() {
    try {
      const params = new URLSearchParams({ size: "100" });
      if (search) params.set("search", search);
      if (statusF) params.set("status", statusF);
      const [res, sm] = await Promise.all([
        api.get<Page<Project>>(`/api/v1/projects?${params}`),
        api.get<ProjectsSummaryData>("/api/v1/projects/summary"),
      ]);
      setProjects(res.items);
      setSummary(sm);
    } catch (e) {
      setError(e instanceof Error ? e.message : t("loadProjectsError"));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, statusF]);

  async function addProject(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await api.post("/api/v1/projects", {
        code,
        name,
        contract_value: Number(value) || 0,
        retention_pct: Number(retention) || 0,
      });
      setCode("");
      setName("");
      setValue("");
      setRetention("10");
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : t("addProjectError"));
    } finally {
      setSaving(false);
    }
  }

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  function openEditProj(p: Project) {
    setEditProj(p);
    setEName(p.name);
    setEValue(String(p.contract_value));
    setERetention(String(p.retention_pct ?? ""));
    setDialogError(null);
  }

  async function saveProj() {
    if (!editProj) return;
    setDialogError(null);
    try {
      const body: Record<string, unknown> = {
        name: eName,
        contract_value: Number(eValue) || 0,
      };
      if (eRetention !== "") body.retention_pct = Number(eRetention);
      await api.patch(`/api/v1/projects/${editProj.id}`, body);
      setEditProj(null);
      await load();
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmCancelProj() {
    if (!cancelProjId) return;
    try {
      await api.post(`/api/v1/projects/${cancelProjId}/cancel`);
      setCancelProjId(null);
      await load();
    } catch (e) {
      setCancelProjId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  return (
    <div>
      <PageTitle>{t("projectsTitle")}</PageTitle>

      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
          <Metric label={t("totalProjectsK")} value={String(summary.total_projects)} />
          <Metric label={t("totalContractsK")} value={`${fmt(summary.total_contract_value)} ${t("egp")}`} />
          <Metric label={t("invoicedK")} value={`${fmt(summary.total_invoiced)} ${t("egp")}`} />
          <Metric label={t("receivedK")} value={`${fmt(summary.total_received)} ${t("egp")}`} />
          <Metric label={t("actualCostK")} value={`${fmt(summary.total_actual_cost)} ${t("egp")}`} />
        </div>
      )}

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("addProject")}</div>
          <form
            onSubmit={addProject}
            style={{
              display: "grid",
              gridTemplateColumns: "0.8fr 1.4fr 1fr 0.7fr auto",
              gap: 10,
              alignItems: "end",
            }}
          >
            <div>
              <label style={labelStyle}>{t("code")}</label>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
                style={inputStyle}
                placeholder="PRJ-2026-001"
              />
            </div>
            <div>
              <label style={labelStyle}>{t("projectName")}</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                style={inputStyle}
                placeholder={t("projectNamePlaceholder")}
              />
            </div>
            <div>
              <label style={labelStyle}>{t("contractValue")}</label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                required
                style={inputStyle}
                placeholder="500000"
              />
            </div>
            <div>
              <label style={labelStyle}>{t("retention")}</label>
              <input
                type="number"
                value={retention}
                onChange={(e) => setRetention(e.target.value)}
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={saving} style={btnStyle}>
              {saving ? "..." : t("add")}
            </button>
          </form>
          {formError && (
            <div style={{ marginTop: 10 }}>
              <ErrorBox message={formError} />
            </div>
          )}
        </Card>
      </div>

      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, gap: 10, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <div style={{ fontWeight: 500 }}>{t("projectList")}</div>
            <ImportExport exportPath="/api/v1/projects/export/csv" importPath="/api/v1/projects/import/csv" onImported={load} />
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("searchProjectsPh")}
              style={{ ...inputStyle, width: 220 }}
            />
            <select value={statusF} onChange={(e) => setStatusF(e.target.value)} style={{ ...inputStyle, width: "auto" }}>
              <option value="">{t("allStatuses")}</option>
              <option value="planned">{t("stPlanned")}</option>
              <option value="active">{t("stActive")}</option>
              <option value="on_hold">{t("stOnHold")}</option>
              <option value="completed">{t("stCompleted")}</option>
              <option value="cancelled">{t("stCancelled")}</option>
            </select>
          </div>
        </div>
        {loading && <Loading text={t("loadingData")} />}
        {error && <ErrorBox message={error} />}
        {!loading && !error && projects.length === 0 && (
          <div style={{ color: "var(--text-muted)", fontSize: 14 }}>
            {t("noProjectsList")}
          </div>
        )}
        {!loading && !error && projects.length > 0 && (
          <Table
            headers={[t("code"), t("projectName"), t("contractValue"), t("status"), ""]}
            rows={projects.map((p) => [
              <span key={p.id} style={{ fontFamily: "monospace", fontSize: 12 }}>
                {p.code}
              </span>,
              p.name,
              `${fmt(Number(p.contract_value))} ${t("egp")}`,
              <span key={p.id + "s"} style={{ color: "var(--text-muted)" }}>
                {statusLabel[p.status] || p.status}
              </span>,
              <div key={p.id + "l"} style={{ display: "flex", gap: 8, alignItems: "center", justifyContent: "flex-end" }}>
                <Link
                  href={`/projects/${p.id}`}
                  style={{ color: "var(--brand)", fontSize: 13, fontWeight: 500, textDecoration: "none" }}
                >
                  {t("manageProject")} →
                </Link>
                <RowActions
                  editLabel={t("edit")}
                  deleteLabel={t("cancelProject")}
                  onEdit={() => openEditProj(p)}
                  onDelete={p.status !== "cancelled" ? () => setCancelProjId(p.id) : undefined}
                />
              </div>,
            ])}
          />
        )}
      </Card>

      <EditDialog
        open={!!editProj}
        title={t("edit") + " — " + t("projectName")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveProj}
        onCancel={() => setEditProj(null)}
        error={dialogError}
      >
        <Field label={t("projectName")}>
          <input value={eName} onChange={(e) => setEName(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("contractValue")}>
          <input type="number" value={eValue} onChange={(e) => setEValue(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("retentionAmount") + " %"}>
          <input type="number" value={eRetention} onChange={(e) => setERetention(e.target.value)} style={dialogInput} />
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!cancelProjId}
        title={t("cancelProject")}
        message={t("confirmCancelMsg")}
        confirmLabel={t("cancelProject")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmCancelProj}
        onCancel={() => setCancelProjId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  fontSize: 12,
  color: "var(--text-muted)",
  display: "block",
  marginBottom: 4,
};
const baseInput: React.CSSProperties = {
  width: "100%",
  padding: "9px 10px",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 14,
  background: "var(--surface)",
};
const btnStyle: React.CSSProperties = {
  background: "var(--brand)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "10px 18px",
  fontSize: 14,
  fontWeight: 500,
  whiteSpace: "nowrap",
};
