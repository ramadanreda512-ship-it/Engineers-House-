"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";
import { Project, BOQItem, VariationOrder, ProgressBilling, Page, ProjectBudgetReport, Milestone, ProjectProgressData } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

type Tab = "boq" | "variations" | "billings" | "budget" | "milestones";

export default function ProjectDetailPage() {
  const { t, dir } = useLang();
  const params = useParams();
  const projectId = params.id as string;

  const [project, setProject] = useState<Project | null>(null);
  const [boq, setBoq] = useState<BOQItem[]>([]);
  const [vos, setVos] = useState<VariationOrder[]>([]);
  const [billings, setBillings] = useState<ProgressBilling[]>([]);
  const [tab, setTab] = useState<Tab>("boq");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const [projects, b, v, bl] = await Promise.all([
        api.get<Page<Project>>("/api/v1/projects?size=100"),
        api.get<BOQItem[]>(`/api/v1/projects/${projectId}/boq`),
        api.get<VariationOrder[]>(`/api/v1/projects/${projectId}/variation-orders`),
        api.get<ProgressBilling[]>(`/api/v1/projects/${projectId}/billings`),
      ]);
      setProject(projects.items.find((p) => p.id === projectId) || null);
      setBoq(b);
      setVos(v);
      setBillings(bl);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <Link href="/projects" style={{ color: "var(--brand)", fontSize: 13, textDecoration: "none" }}>
          ← {t("navProjects")}
        </Link>
      </div>
      <PageTitle>{project?.name || ""}</PageTitle>

      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && (
        <>
          <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", flexWrap: "wrap" }}>
            <TabBtn active={tab === "boq"} onClick={() => setTab("boq")} label={t("boq")} />
            <TabBtn active={tab === "variations"} onClick={() => setTab("variations")} label={t("variationOrders")} />
            <TabBtn active={tab === "billings"} onClick={() => setTab("billings")} label={t("billings")} />
            <TabBtn active={tab === "budget"} onClick={() => setTab("budget")} label={t("budgetVsActual")} />
            <TabBtn active={tab === "milestones"} onClick={() => setTab("milestones")} label={t("milestones")} />
          </div>

          {tab === "boq" && <BoqTab projectId={projectId} boq={boq} reload={load} dir={dir} />}
          {tab === "variations" && <VariationsTab projectId={projectId} vos={vos} reload={load} dir={dir} />}
          {tab === "billings" && <BillingsTab projectId={projectId} billings={billings} reload={load} dir={dir} />}
          {tab === "budget" && <BudgetTab projectId={projectId} />}
          {tab === "milestones" && <MilestonesTab projectId={projectId} />}
        </>
      )}
    </div>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "8px 16px",
        borderRadius: 8,
        border: "1px solid var(--border)",
        background: active ? "var(--brand)" : "var(--surface)",
        color: active ? "#fff" : "var(--text)",
        fontSize: 14,
        fontWeight: 500,
      }}
    >
      {label}
    </button>
  );
}

function BoqTab({ projectId, boq, reload, dir }: { projectId: string; boq: BOQItem[]; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [form, setForm] = useState({ item_code: "", description: "", unit: "", planned_qty: "", unit_rate: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setSaving(true);
    try {
      await api.post(`/api/v1/projects/${projectId}/boq`, {
        item_code: form.item_code,
        description: form.description,
        unit: form.unit,
        planned_qty: Number(form.planned_qty) || 0,
        unit_rate: Number(form.unit_rate) || 0,
      });
      setForm({ item_code: "", description: "", unit: "", planned_qty: "", unit_rate: "" });
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  async function updateProgress(itemId: string, executed: string) {
    try {
      await api.patch(`/api/v1/projects/${projectId}/boq/${itemId}/progress`, {
        executed_qty: Number(executed) || 0,
      });
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  return (
    <>
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("boq")} — {t("add")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.6fr 0.6fr 0.8fr 0.8fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("itemCode")}</label><input value={form.item_code} onChange={(e) => setForm({ ...form, item_code: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("description")}</label><input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("unit")}</label><input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} required style={inputStyle} placeholder="m³" /></div>
            <div><label style={labelStyle}>{t("plannedQty")}</label><input type="number" value={form.planned_qty} onChange={(e) => setForm({ ...form, planned_qty: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("unitRate")}</label><input type="number" value={form.unit_rate} onChange={(e) => setForm({ ...form, unit_rate: e.target.value })} required style={inputStyle} /></div>
            <button type="submit" disabled={saving} style={btnStyle}>{saving ? "..." : t("add")}</button>
          </form>
          {err && <div style={{ marginTop: 10 }}><ErrorBox message={err} /></div>}
        </Card>
      </div>
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("boq")}</div>
        {boq.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noBoq")}</div> : (
          <Table
            headers={[t("itemCode"), t("description"), t("unit"), t("plannedQty"), t("executedQty"), t("progress")]}
            rows={boq.map((item) => {
              const pct = item.planned_qty > 0 ? Math.round((item.executed_qty / item.planned_qty) * 100) : 0;
              return [
                <span key={item.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{item.item_code}</span>,
                item.description,
                item.unit,
                String(item.planned_qty),
                <input key={item.id + "e"} type="number" defaultValue={item.executed_qty} onBlur={(e) => updateProgress(item.id, e.target.value)} style={{ ...inputStyle, width: 90 }} />,
                `${pct}%`,
              ];
            })}
          />
        )}
      </Card>
    </>
  );
}

function VariationsTab({ projectId, vos, reload, dir }: { projectId: string; vos: VariationOrder[]; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [form, setForm] = useState({ number: "", description: "", amount: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };
  const statusLabel: Record<string, string> = { approved: t("statusApproved"), pending: t("statusPending"), draft: t("statusPending") };

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setSaving(true);
    try {
      await api.post(`/api/v1/projects/${projectId}/variation-orders`, {
        number: form.number,
        description: form.description,
        amount: Number(form.amount) || 0,
      });
      setForm({ number: "", description: "", amount: "" });
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  async function approve(voId: string) {
    try {
      await api.post(`/api/v1/projects/${projectId}/variation-orders/${voId}/approve`);
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  return (
    <>
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("variationOrders")} — {t("add")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.8fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("itemCode")}</label><input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} required style={inputStyle} placeholder="VO-001" /></div>
            <div><label style={labelStyle}>{t("description")}</label><input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("amount")}</label><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required style={inputStyle} /></div>
            <button type="submit" disabled={saving} style={btnStyle}>{saving ? "..." : t("add")}</button>
          </form>
          {err && <div style={{ marginTop: 10 }}><ErrorBox message={err} /></div>}
        </Card>
      </div>
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("variationOrders")}</div>
        {vos.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noVariations")}</div> : (
          <Table
            headers={[t("invoiceNumber"), t("description"), t("amount"), t("status"), ""]}
            rows={vos.map((vo) => [
              <span key={vo.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{vo.number}</span>,
              vo.description,
              `${fmt(vo.amount)} ${t("egp")}`,
              <Badge key={vo.id + "s"} text={statusLabel[vo.status] || vo.status} kind={vo.status === "approved" ? "completed" : "lead"} />,
              vo.status !== "approved" ? <button key={vo.id + "a"} onClick={() => approve(vo.id)} style={linkBtn}>{t("statusApproved")}</button> : "—",
            ])}
          />
        )}
      </Card>
    </>
  );
}

function BillingsTab({ projectId, billings, reload, dir }: { projectId: string; billings: ProgressBilling[]; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [form, setForm] = useState({ number: "", billing_date: "", cumulative_pct: "" });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setSaving(true);
    try {
      await api.post(`/api/v1/projects/${projectId}/billings`, {
        number: form.number,
        billing_date: form.billing_date || new Date().toISOString().slice(0, 10),
        cumulative_pct: Number(form.cumulative_pct) || 0,
      });
      setForm({ number: "", billing_date: "", cumulative_pct: "" });
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("billings")} — {t("add")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "0.8fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("invoiceNumber")}</label><input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} required style={inputStyle} placeholder="IPC-01" /></div>
            <div><label style={labelStyle}>{t("date")}</label><input type="date" value={form.billing_date} onChange={(e) => setForm({ ...form, billing_date: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("progress")} %</label><input type="number" value={form.cumulative_pct} onChange={(e) => setForm({ ...form, cumulative_pct: e.target.value })} required style={inputStyle} placeholder="40" /></div>
            <button type="submit" disabled={saving} style={btnStyle}>{saving ? "..." : t("add")}</button>
          </form>
          {err && <div style={{ marginTop: 10 }}><ErrorBox message={err} /></div>}
        </Card>
      </div>
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("billings")}</div>
        {billings.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noBillings")}</div> : (
          <Table
            headers={[t("invoiceNumber"), t("progress"), t("amount"), t("retentionAmount"), t("netPayable")]}
            rows={billings.map((b) => [
              <span key={b.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{b.number}</span>,
              `${b.cumulative_pct}%`,
              `${fmt(b.period_gross)} ${t("egp")}`,
              `${fmt(b.retention_amount)} ${t("egp")}`,
              `${fmt(b.net_payable)} ${t("egp")}`,
            ])}
          />
        )}
      </Card>
    </>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const linkBtn: React.CSSProperties = { background: "transparent", color: "var(--brand)", border: "none", fontSize: 13, fontWeight: 500, padding: 0 };

function BudgetTab({ projectId }: { projectId: string }) {
  const { t } = useLang();
  const [report, setReport] = useState<ProjectBudgetReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<ProjectBudgetReport>(`/api/v1/projects/${projectId}/budget-report`)
      .then(setReport)
      .catch((e) => setError(e instanceof Error ? e.message : "Error"))
      .finally(() => setLoading(false));
  }, [projectId]);

  const catLabel: Record<string, string> = { materials: t("catMaterials"), labor: t("catLabor"), other: t("catOther") };

  if (loading) return <Loading text={t("loadingData")} />;
  if (error) return <ErrorBox message={error} />;
  if (!report) return null;

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 16 }}>
        <div style={statBox}><div style={statLbl}>{t("contractValue")}</div><div style={statVal}>{fmt(report.contract_value)} {t("egp")}</div></div>
        <div style={statBox}><div style={statLbl}>{t("totalActual")}</div><div style={statVal}>{fmt(report.total_actual)} {t("egp")}</div></div>
        <div style={statBox}><div style={statLbl}>{t("projectedMargin")}</div><div style={{ ...statVal, color: report.projected_margin >= 0 ? "#1a7d3c" : "#c0392b" }}>{fmt(report.projected_margin)} {t("egp")}</div></div>
        <div style={statBox}><div style={statLbl}>{t("invoiced")} / {t("received")}</div><div style={statVal}>{fmt(report.invoiced_amount)} / {fmt(report.received_amount)}</div></div>
      </div>
      <Table
        headers={[t("category"), t("budget"), t("actual"), t("variance"), "%"]}
        rows={[
          ...report.rows.map((r) => [
            catLabel[r.category] || r.category,
            fmt(r.budget),
            fmt(r.actual),
            <span key={r.category} style={{ color: r.variance >= 0 ? "#1a7d3c" : "#c0392b", fontWeight: 600 }}>{fmt(r.variance)}</span>,
            `${r.variance_pct}%`,
          ]),
          [<strong key="t">{t("total")}</strong>, <strong key="b">{fmt(report.total_budget)}</strong>, <strong key="a">{fmt(report.total_actual)}</strong>, <strong key="v">{fmt(report.total_variance)}</strong>, ""],
        ]}
      />
    </div>
  );
}

const statBox: React.CSSProperties = { padding: 12, background: "var(--bg)", borderRadius: 8 };
const statLbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)" };
const statVal: React.CSSProperties = { fontSize: 17, fontWeight: 600 };


function MilestonesTab({ projectId }: { projectId: string }) {
  const { t, dir } = useLang();
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [progress, setProgress] = useState<ProjectProgressData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [f, setF] = useState({ title: "", target_date: "", weight: "1" });
  const msInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)", textAlign: dir === "rtl" ? "right" : "left" };

  const stLabel: Record<string, string> = {
    pending: t("msPending"), in_progress: t("msInProgress"),
    completed: t("msCompleted"), delayed: t("msDelayed"),
  };
  const stKind: Record<string, string> = {
    pending: "lead", in_progress: "lead", completed: "completed", delayed: "withdrawn",
  };

  async function load() {
    try {
      const [ms, pr] = await Promise.all([
        api.get<Milestone[]>(`/api/v1/projects/${projectId}/milestones`),
        api.get<ProjectProgressData>(`/api/v1/projects/${projectId}/progress`),
      ]);
      setMilestones(ms);
      setProgress(pr);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [projectId]);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/projects/${projectId}/milestones`, {
        title: f.title, target_date: f.target_date || null,
        weight: Number(f.weight) || 1, sort_order: milestones.length + 1,
      });
      setF({ title: "", target_date: "", weight: "1" });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function setPct(m: Milestone, pct: number) {
    try {
      await api.patch(`/api/v1/projects/milestones/${m.id}`, {
        progress_pct: pct,
        status: pct === 100 ? "completed" : pct > 0 ? "in_progress" : "pending",
      });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function remove(id: string) {
    try { await api.del(`/api/v1/projects/milestones/${id}`); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      {error && <ErrorBox message={error} />}

      {progress && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: 16 }}>
          <div style={msStatBox}>
            <div style={msStatLbl}>{t("overallProgress")}</div>
            <div style={{ ...msStatVal, color: "var(--brand)" }}>{progress.overall_progress_pct}%</div>
          </div>
          <div style={msStatBox}>
            <div style={msStatLbl}>{t("milestoneProgress")}</div>
            <div style={msStatVal}>{progress.milestone_progress_pct}%</div>
          </div>
          <div style={msStatBox}>
            <div style={msStatLbl}>{t("boqProgress")}</div>
            <div style={msStatVal}>{progress.boq_progress_pct}%</div>
          </div>
        </div>
      )}

      <div style={{ marginBottom: 16 }}>
        <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 0.7fr auto", gap: 10, alignItems: "end" }}>
          <div>
            <label style={msLbl}>{t("milestoneTitle")}</label>
            <input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} required style={msInput} />
          </div>
          <div>
            <label style={msLbl}>{t("targetDate")}</label>
            <input type="date" value={f.target_date} onChange={(e) => setF({ ...f, target_date: e.target.value })} style={msInput} />
          </div>
          <div>
            <label style={msLbl}>{t("weightCol")}</label>
            <input type="number" min="0.1" step="0.1" value={f.weight} onChange={(e) => setF({ ...f, weight: e.target.value })} style={msInput} />
          </div>
          <button type="submit" style={msBtn}>+ {t("newMilestone")}</button>
        </form>
      </div>

      {milestones.length === 0 ? (
        <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noMilestones")}</div>
      ) : (
        <Table
          headers={[t("milestoneTitle"), t("targetDate"), t("weightCol"), t("progressCol"), t("status"), ""]}
          rows={milestones.map((m) => [
            <span key={m.id} style={{ fontWeight: 500 }}>{m.title}</span>,
            m.target_date || "—",
            String(m.weight),
            <div key={m.id + "p"} style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 160 }}>
              <input
                type="range" min="0" max="100" step="5"
                defaultValue={m.progress_pct}
                onMouseUp={(e) => setPct(m, Number((e.target as HTMLInputElement).value))}
                onTouchEnd={(e) => setPct(m, Number((e.target as HTMLInputElement).value))}
                style={{ flex: 1 }}
              />
              <span style={{ fontSize: 13, fontWeight: 600, minWidth: 38 }}>{m.progress_pct}%</span>
            </div>,
            <Badge key={m.id + "s"} text={stLabel[m.status] || m.status} kind={stKind[m.status]} />,
            <button key={m.id + "d"} onClick={() => remove(m.id)} style={msMini}>✕</button>,
          ])}
        />
      )}
    </div>
  );
}

const msStatBox: React.CSSProperties = { padding: 12, background: "var(--bg)", borderRadius: 8 };
const msStatLbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)" };
const msStatVal: React.CSSProperties = { fontSize: 20, fontWeight: 700 };
const msLbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const msBtn: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const msMini: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "#a32d2d" };
