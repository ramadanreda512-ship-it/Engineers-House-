"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Approval, Budget, BudgetVarianceReport, GLAccount } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

type Tab = "approvals" | "budgets" | "variance";

export default function GovernancePage() {
  const { t } = useLang();
  const [tab, setTab] = useState<Tab>("approvals");
  return (
    <div>
      <PageTitle>{t("governanceTitle")}</PageTitle>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem", flexWrap: "wrap" }}>
        <TabBtn active={tab === "approvals"} onClick={() => setTab("approvals")} label={t("approvals")} />
        <TabBtn active={tab === "budgets"} onClick={() => setTab("budgets")} label={t("budgets")} />
        <TabBtn active={tab === "variance"} onClick={() => setTab("variance")} label={t("budgetVariance")} />
      </div>
      {tab === "approvals" && <ApprovalsTab />}
      {tab === "budgets" && <BudgetsTab />}
      {tab === "variance" && <VarianceTab />}
    </div>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid var(--border)", background: active ? "var(--brand)" : "var(--surface)", color: active ? "#fff" : "var(--text)", fontSize: 14, fontWeight: 500 }}>
      {label}
    </button>
  );
}

function ApprovalsTab() {
  const { t } = useLang();
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try { setApprovals(await api.get<Approval[]>("/api/v1/governance/approvals")); setError(null); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function decide(id: string, action: "approve" | "reject") {
    try { await api.post(`/api/v1/governance/approvals/${id}/${action}`, {}); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  const statusLabel: Record<string, string> = { pending: t("statusPending"), approved: t("statusApproved"), rejected: t("statusRejected") };
  const statusKind: Record<string, string> = { pending: "lead", approved: "completed", rejected: "withdrawn" };

  if (loading) return <Loading text={t("loadingData")} />;
  return (
    <>
      {error && <ErrorBox message={error} />}
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("approvals")}</div>
        {approvals.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noApprovals")}</div> : (
          <Table
            headers={[t("title"), t("amount"), t("requestStatus"), ""]}
            rows={approvals.map((a) => [
              a.title,
              `${fmt(a.amount)} ${t("egp")}`,
              <Badge key={a.id} text={statusLabel[a.status]} kind={statusKind[a.status]} />,
              a.status === "pending" ? (
                <span key={a.id + "x"} style={{ display: "flex", gap: 6 }}>
                  <button onClick={() => decide(a.id, "approve")} style={{ ...miniBtn, color: "#1a7d3c" }}>{t("approve")}</button>
                  <button onClick={() => decide(a.id, "reject")} style={{ ...miniBtn, color: "#a32d2d" }}>{t("reject")}</button>
                </span>
              ) : <span key={a.id + "n"} />,
            ])}
          />
        )}
      </Card>
    </>
  );
}

function BudgetsTab() {
  const { t, dir } = useLang();
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [accounts, setAccounts] = useState<GLAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const year = new Date().getFullYear();
  const [form, setForm] = useState({ account_id: "", fiscal_year: String(year), amount: "" });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function load() {
    setLoading(true);
    try {
      const [bs, accs] = await Promise.all([
        api.get<Budget[]>("/api/v1/governance/budgets"),
        api.get<GLAccount[]>("/api/v1/accounting/accounts"),
      ]);
      setBudgets(bs);
      setAccounts(accs.filter((a) => !a.is_group));
      setError(null);
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const accName = (id: string) => { const a = accounts.find((x) => x.id === id); return a ? `${a.code} — ${a.name}` : "—"; };

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post("/api/v1/governance/budgets", {
        account_id: form.account_id, fiscal_year: Number(form.fiscal_year), amount: Number(form.amount) || 0,
      });
      setForm({ account_id: "", fiscal_year: String(year), amount: "" });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (loading) return <Loading text={t("loadingData")} />;
  return (
    <>
      {error && <ErrorBox message={error} />}
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newBudget")}</div>
          <form onSubmit={add} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("account")}</label>
              <select value={form.account_id} onChange={(e) => setForm({ ...form, account_id: e.target.value })} required style={inputStyle}>
                <option value="">{t("selectAccount")}</option>
                {accounts.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
              </select>
            </div>
            <div><label style={labelStyle}>{t("fiscalYear")}</label><input type="number" value={form.fiscal_year} onChange={(e) => setForm({ ...form, fiscal_year: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("budgetAmount")}</label><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required style={inputStyle} /></div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
        </Card>
      </div>
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("budgets")}</div>
        {budgets.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noBudgets")}</div> : (
          <Table
            headers={[t("account"), t("fiscalYear"), t("budgetAmount")]}
            rows={budgets.map((b) => [accName(b.account_id), String(b.fiscal_year), `${fmt(b.amount)} ${t("egp")}`])}
          />
        )}
      </Card>
    </>
  );
}

function VarianceTab() {
  const { t } = useLang();
  const year = new Date().getFullYear();
  const [fy, setFy] = useState(year);
  const [data, setData] = useState<BudgetVarianceReport | null>(null);
  const [loading, setLoading] = useState(true);

  async function load(y: number) {
    setLoading(true);
    try { setData(await api.get<BudgetVarianceReport>(`/api/v1/governance/budgets/variance?fiscal_year=${y}`)); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(year); /* eslint-disable-next-line */ }, []);

  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, gap: 10 }}>
        <div style={{ fontWeight: 500 }}>{t("budgetVariance")}</div>
        <input type="number" value={fy} onChange={(e) => { setFy(Number(e.target.value)); load(Number(e.target.value)); }} style={{ ...baseInput, maxWidth: 120 }} />
      </div>
      {loading ? <Loading text={t("loadingData")} /> : data && (
        <Table
          headers={[t("accountCode"), t("account"), t("budget"), t("actual"), t("variance")]}
          rows={[
            ...data.rows.map((r) => [
              <span key={r.account_id} style={{ fontFamily: "monospace", fontSize: 12 }}>{r.account_code}</span>,
              r.account_name,
              fmt(r.budget),
              fmt(r.actual),
              <span key={r.account_id + "v"} style={{ color: r.variance >= 0 ? "#1a7d3c" : "#c0392b", fontWeight: 600 }}>{fmt(r.variance)}</span>,
            ]),
            [<strong key="t">{t("total")}</strong>, "", <strong key="b">{fmt(data.total_budget)}</strong>, <strong key="a">{fmt(data.total_actual)}</strong>, <strong key="v">{fmt(data.total_variance)}</strong>],
          ]}
        />
      )}
    </Card>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
