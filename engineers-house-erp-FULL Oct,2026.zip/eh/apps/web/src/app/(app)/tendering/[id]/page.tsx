"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";
import { Tender, BOQTree, CostEstimate } from "@/lib/types";
import { PageTitle, Card, Badge, Loading, ErrorBox, fmt, ConfirmDialog } from "@/components/ui";
import { useLang } from "@/lib/i18n";

type Tab = "boq" | "estimates";

export default function TenderDetailPage() {
  const { t, dir } = useLang();
  const params = useParams();
  const tenderId = params.id as string;

  const [tender, setTender] = useState<Tender | null>(null);
  const [tree, setTree] = useState<BOQTree | null>(null);
  const [estimates, setEstimates] = useState<CostEstimate[]>([]);
  const [tab, setTab] = useState<Tab>("boq");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [convertConfirm, setConvertConfirm] = useState(false);

  const statusLabel: Record<string, string> = {
    draft: t("tenderStatusDraft"), submitted: t("tenderStatusSubmitted"),
    under_evaluation: t("tenderStatusUnderEval"), won: t("tenderStatusWon"),
    lost: t("tenderStatusLost"), cancelled: t("statusCancelled"),
  };

  async function load() {
    setLoading(true);
    try {
      const [tn, tr, est] = await Promise.all([
        api.get<Tender>(`/api/v1/tendering/tenders/${tenderId}`),
        api.get<BOQTree>(`/api/v1/tendering/tenders/${tenderId}/boq`),
        api.get<CostEstimate[]>(`/api/v1/tendering/tenders/${tenderId}/estimates`),
      ]);
      setTender(tn);
      setTree(tr);
      setEstimates(est);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenderId]);

  async function setStatus(status: string) {
    try {
      await api.post(`/api/v1/tendering/tenders/${tenderId}/status?status=${status}`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function convert() {
    setConvertConfirm(false);
    try {
      await api.post(`/api/v1/tendering/tenders/${tenderId}/convert`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <Link href="/tendering" style={{ color: "var(--brand)", fontSize: 13, textDecoration: "none" }}>
          ← {t("tenders")}
        </Link>
      </div>

      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && tender && (
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
            <PageTitle>{tender.code} — {tender.title}</PageTitle>
            <Badge text={statusLabel[tender.status] || tender.status} kind={tender.status === "won" ? "completed" : tender.status === "lost" ? "withdrawn" : "lead"} />
          </div>

          {/* Status / action bar */}
          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <div style={{ fontSize: 14 }}>
                  {t("bidValue")}: <strong>{fmt(tender.bid_value)} {t("egp")}</strong>
                </div>
                <div style={{ flex: 1 }} />
                {tender.status !== "won" && tender.status !== "lost" && (
                  <>
                    <button onClick={() => setStatus("won")} style={btnGreen}>{t("markWon")}</button>
                    <button onClick={() => setStatus("lost")} style={btnGrey}>{t("markLost")}</button>
                  </>
                )}
                {tender.status === "won" && !tender.converted_project_id && (
                  <button onClick={() => setConvertConfirm(true)} style={btnStyle}>{t("convertToProject")}</button>
                )}
                {tender.converted_project_id && (
                  <Link href={`/projects/${tender.converted_project_id}`} style={{ color: "var(--brand)", fontSize: 13, fontWeight: 500, textDecoration: "none" }}>
                    {t("convertedTo")} →
                  </Link>
                )}
              </div>
            </Card>
          </div>

          <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem" }}>
            <TabBtn active={tab === "boq"} onClick={() => setTab("boq")} label={t("boqStructure")} />
            <TabBtn active={tab === "estimates"} onClick={() => setTab("estimates")} label={t("estimates")} />
          </div>

          {tab === "boq" && tree && <BoqTab tree={tree} reload={load} dir={dir} />}
          {tab === "estimates" && <EstimatesTab tenderId={tenderId} estimates={estimates} reload={load} dir={dir} />}
        </>
      )}

      <ConfirmDialog
        open={convertConfirm}
        title={t("convertToProject")}
        message={t("confirmConvertMsg")}
        confirmLabel={t("convertToProject")}
        cancelLabel={t("cancel")}
        onConfirm={convert}
        onCancel={() => setConvertConfirm(false)}
      />
    </div>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid var(--border)", background: active ? "var(--brand)" : "var(--surface)", color: active ? "#fff" : "var(--text)", fontSize: 14, fontWeight: 500 }}>
      {label}
    </button>
  );
}

function BoqTab({ tree, reload, dir }: { tree: BOQTree; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [err, setErr] = useState<string | null>(null);
  const [newSection, setNewSection] = useState({ code: "", name: "" });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function addSection(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    try {
      await api.post(`/api/v1/tendering/tenders/${tree.tender_id}/sections`, { code: newSection.code, name: newSection.name });
      setNewSection({ code: "", name: "" });
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  async function delSection(id: string) {
    try { await api.del(`/api/v1/tendering/sections/${id}`); reload(); } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div style={{ fontWeight: 500 }}>{t("boqStructure")}</div>
          <div style={{ fontSize: 15 }}>{t("grandTotal")}: <strong style={{ color: "var(--brand)" }}>{fmt(tree.grand_total)} {t("egp")}</strong></div>
        </div>

        {tree.sections.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: 14, marginBottom: 14 }}>{t("noBoqYet")}</div>}

        {tree.sections.map((section) => (
          <SectionBlock key={section.id} section={section} reload={reload} onDelete={() => delSection(section.id)} dir={dir} />
        ))}

        <form onSubmit={addSection} style={{ display: "flex", gap: 10, alignItems: "end", marginTop: 16, paddingTop: 16, borderTop: "1px solid var(--border)" }}>
          <div style={{ width: 110 }}><label style={labelStyle}>{t("code")}</label><input value={newSection.code} onChange={(e) => setNewSection({ ...newSection, code: e.target.value })} required style={inputStyle} placeholder="1" /></div>
          <div style={{ flex: 1 }}><label style={labelStyle}>{t("section")}</label><input value={newSection.name} onChange={(e) => setNewSection({ ...newSection, name: e.target.value })} required style={inputStyle} placeholder={t("section")} /></div>
          <button type="submit" style={btnStyle}>+ {t("addSection")}</button>
        </form>
        {err && <div style={{ marginTop: 10 }}><ErrorBox message={err} /></div>}
      </Card>
    </>
  );
}

function SectionBlock({ section, reload, onDelete, dir }: { section: BOQTree["sections"][number]; reload: () => void; onDelete: () => void; dir: string }) {
  const { t } = useLang();
  const [newDiv, setNewDiv] = useState({ code: "", name: "" });
  const [showAdd, setShowAdd] = useState(false);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function addDivision(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/tendering/sections/${section.id}/divisions`, { code: newDiv.code, name: newDiv.name });
      setNewDiv({ code: "", name: "" });
      setShowAdd(false);
      reload();
    } catch { /* ignore */ }
  }

  return (
    <div style={{ marginBottom: 16, border: "1px solid var(--border)", borderRadius: 10, overflow: "hidden" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", background: "var(--bg)" }}>
        <div style={{ fontWeight: 600 }}>{section.code} — {section.name}</div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>{fmt(section.subtotal)} {t("egp")}</span>
          <button onClick={() => setShowAdd(!showAdd)} style={miniBtn}>+ {t("division")}</button>
          <button onClick={onDelete} style={{ ...miniBtn, color: "#a32d2d" }}>🗑️</button>
        </div>
      </div>

      <div style={{ padding: "8px 14px" }}>
        {section.divisions.map((div) => (
          <DivisionBlock key={div.id} division={div} reload={reload} dir={dir} />
        ))}
        {showAdd && (
          <form onSubmit={addDivision} style={{ display: "flex", gap: 8, alignItems: "end", marginTop: 8 }}>
            <div style={{ width: 100 }}><label style={labelStyle}>{t("code")}</label><input value={newDiv.code} onChange={(e) => setNewDiv({ ...newDiv, code: e.target.value })} required style={inputStyle} placeholder="1.1" /></div>
            <div style={{ flex: 1 }}><label style={labelStyle}>{t("division")}</label><input value={newDiv.name} onChange={(e) => setNewDiv({ ...newDiv, name: e.target.value })} required style={inputStyle} /></div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
        )}
      </div>
    </div>
  );
}

function DivisionBlock({ division, reload, dir }: { division: BOQTree["sections"][number]["divisions"][number]; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [form, setForm] = useState({ item_code: "", description: "", unit: "", quantity: "", unit_rate: "" });
  const [showAdd, setShowAdd] = useState(false);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function addElement(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/tendering/divisions/${division.id}/elements`, {
        item_code: form.item_code, description: form.description, unit: form.unit,
        quantity: Number(form.quantity) || 0, unit_rate: Number(form.unit_rate) || 0,
      });
      setForm({ item_code: "", description: "", unit: "", quantity: "", unit_rate: "" });
      setShowAdd(false);
      reload();
    } catch { /* ignore */ }
  }

  async function delElement(id: string) {
    try { await api.del(`/api/v1/tendering/elements/${id}`); reload(); } catch { /* ignore */ }
  }
  async function delDivision() {
    try { await api.del(`/api/v1/tendering/divisions/${division.id}`); reload(); } catch { /* ignore */ }
  }

  return (
    <div style={{ marginBottom: 10, marginInlineStart: 12, borderInlineStart: "2px solid var(--border)", paddingInlineStart: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <div style={{ fontWeight: 500, fontSize: 14 }}>{division.code} — {division.name}</div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 12, color: "var(--text-muted)" }}>{fmt(division.subtotal)} {t("egp")}</span>
          <button onClick={() => setShowAdd(!showAdd)} style={miniBtn}>+ {t("element")}</button>
          <button onClick={delDivision} style={{ ...miniBtn, color: "#a32d2d" }}>🗑️</button>
        </div>
      </div>

      {division.elements.length > 0 && (
        <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ color: "var(--text-muted)", fontSize: 12 }}>
              <th style={th}>{t("itemCode")}</th><th style={th}>{t("description")}</th><th style={th}>{t("unit")}</th>
              <th style={thR}>{t("quantity")}</th><th style={thR}>{t("itemRate")}</th><th style={thR}>{t("itemAmount")}</th><th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {division.elements.map((el) => (
              <tr key={el.id} style={{ borderTop: "1px solid var(--border)" }}>
                <td style={{ ...td, fontFamily: "monospace", fontSize: 12 }}>{el.item_code}</td>
                <td style={td}>{el.description}</td>
                <td style={td}>{el.unit}</td>
                <td style={tdR}>{fmt(el.quantity)}</td>
                <td style={tdR}>{fmt(el.unit_rate)}</td>
                <td style={{ ...tdR, fontWeight: 500 }}>{fmt(el.amount)}</td>
                <td style={td}><button onClick={() => delElement(el.id)} style={{ ...miniBtn, color: "#a32d2d", padding: "2px 6px" }}>🗑️</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showAdd && (
        <form onSubmit={addElement} style={{ display: "grid", gridTemplateColumns: "0.7fr 1.4fr 0.5fr 0.7fr 0.7fr auto", gap: 6, alignItems: "end", marginTop: 8 }}>
          <input placeholder={t("itemCode")} value={form.item_code} onChange={(e) => setForm({ ...form, item_code: e.target.value })} required style={inputStyle} />
          <input placeholder={t("description")} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required style={inputStyle} />
          <input placeholder={t("unit")} value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} required style={inputStyle} />
          <input type="number" placeholder={t("quantity")} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} style={inputStyle} />
          <input type="number" placeholder={t("itemRate")} value={form.unit_rate} onChange={(e) => setForm({ ...form, unit_rate: e.target.value })} style={inputStyle} />
          <button type="submit" style={btnStyle}>{t("add")}</button>
        </form>
      )}
    </div>
  );
}

function EstimatesTab({ tenderId, estimates, reload, dir }: { tenderId: string; estimates: CostEstimate[]; reload: () => void; dir: string }) {
  const { t } = useLang();
  const [overhead, setOverhead] = useState("10");
  const [margin, setMargin] = useState("15");
  const [lines, setLines] = useState([{ category: "material", description: "", quantity: "1", unit_cost: "" }]);
  const [err, setErr] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const catLabel: Record<string, string> = {
    labour: t("catLabour"), material: t("catMaterial"), equipment: t("catEquipment"),
    subcontractor: t("catSubcontractor"), other: t("catOther"),
  };

  async function createEstimate(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    try {
      await api.post(`/api/v1/tendering/tenders/${tenderId}/estimates`, {
        overhead_pct: Number(overhead) || 0,
        margin_pct: Number(margin) || 0,
        lines: lines.filter((l) => l.description && l.unit_cost).map((l) => ({
          category: l.category, description: l.description,
          quantity: Number(l.quantity) || 1, unit_cost: Number(l.unit_cost) || 0,
        })),
      });
      setLines([{ category: "material", description: "", quantity: "1", unit_cost: "" }]);
      reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  async function delEstimate(id: string) {
    try { await api.del(`/api/v1/tendering/estimates/${id}`); reload(); } catch { /* ignore */ }
  }

  return (
    <>
      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newEstimate")}</div>
          <form onSubmit={createEstimate}>
            <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
              <div style={{ width: 140 }}><label style={labelStyle}>{t("overhead")}</label><input type="number" value={overhead} onChange={(e) => setOverhead(e.target.value)} style={inputStyle} /></div>
              <div style={{ width: 140 }}><label style={labelStyle}>{t("margin")}</label><input type="number" value={margin} onChange={(e) => setMargin(e.target.value)} style={inputStyle} /></div>
            </div>
            {lines.map((line, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 1.6fr 0.7fr 0.9fr", gap: 8, marginBottom: 8 }}>
                <select value={line.category} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, category: e.target.value } : l))} style={inputStyle}>
                  {["labour", "material", "equipment", "subcontractor", "other"].map((c) => <option key={c} value={c}>{catLabel[c]}</option>)}
                </select>
                <input placeholder={t("description")} value={line.description} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, description: e.target.value } : l))} style={inputStyle} />
                <input type="number" placeholder={t("quantity")} value={line.quantity} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, quantity: e.target.value } : l))} style={inputStyle} />
                <input type="number" placeholder={t("unitCost")} value={line.unit_cost} onChange={(e) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, unit_cost: e.target.value } : l))} style={inputStyle} />
              </div>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
              <button type="button" onClick={() => setLines((p) => [...p, { category: "material", description: "", quantity: "1", unit_cost: "" }])} style={btnGrey}>+ {t("estimateLines")}</button>
              <button type="submit" style={btnStyle}>{t("add")}</button>
            </div>
          </form>
          {err && <div style={{ marginTop: 10 }}><ErrorBox message={err} /></div>}
        </Card>
      </div>

      {estimates.length === 0 ? (
        <Card><div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noEstimates")}</div></Card>
      ) : (
        estimates.map((est) => (
          <div key={est.id} style={{ marginBottom: 12 }}>
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div style={{ fontWeight: 500 }}>{est.title} (v{est.version})</div>
                <button onClick={() => delEstimate(est.id)} style={{ ...miniBtn, color: "#a32d2d" }}>🗑️</button>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 10 }}>
                <MiniStat label={t("directCost")} value={est.direct_cost} t={t} />
                <MiniStat label={t("totalCost")} value={est.total_cost} t={t} />
                <MiniStat label={t("margin")} value={est.margin_amount} t={t} />
                <MiniStat label={t("sellingPrice")} value={est.selling_price} t={t} highlight />
              </div>
            </Card>
          </div>
        ))
      )}
    </>
  );
}

function MiniStat({ label, value, t, highlight }: { label: string; value: number; t: (k: string) => string; highlight?: boolean }) {
  return (
    <div style={{ padding: 10, background: "var(--bg)", borderRadius: 8 }}>
      <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: highlight ? "var(--brand)" : "var(--text)" }}>{fmt(value)} {t("egp")}</div>
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const btnGreen: React.CSSProperties = { ...btnStyle, background: "#0f6e56" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500 };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 8px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
const th: React.CSSProperties = { textAlign: "start", padding: "4px 6px", fontWeight: 500 };
const thR: React.CSSProperties = { textAlign: "end", padding: "4px 6px", fontWeight: 500 };
const td: React.CSSProperties = { padding: "5px 6px", textAlign: "start" };
const tdR: React.CSSProperties = { padding: "5px 6px", textAlign: "end" };
