"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { Tender, TenderSummary, Page } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Metric, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function TenderingPage() {
  const { t, dir } = useLang();
  const [summary, setSummary] = useState<TenderSummary | null>(null);
  const [tenders, setTenders] = useState<Tender[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [client, setClient] = useState("");
  const [bu, setBu] = useState("construction");
  const [estValue, setEstValue] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const statusLabel: Record<string, string> = {
    draft: t("tenderStatusDraft"),
    submitted: t("tenderStatusSubmitted"),
    under_evaluation: t("tenderStatusUnderEval"),
    won: t("tenderStatusWon"),
    lost: t("tenderStatusLost"),
    cancelled: t("statusCancelled"),
  };
  const statusKind: Record<string, string> = {
    draft: "lead", submitted: "waitlisted", under_evaluation: "waitlisted",
    won: "completed", lost: "withdrawn", cancelled: "withdrawn",
  };
  const buLabel: Record<string, string> = {
    construction: t("buConstruction"), industrial_automation: t("buAutomation"),
    electrical: t("buElectrical"), plc_scada: t("buPlcScada"),
    maintenance: t("buMaintenance"), consulting: t("buConsulting"),
  };

  async function load() {
    setLoading(true);
    try {
      const [sum, tn] = await Promise.all([
        api.get<TenderSummary>("/api/v1/tendering/summary"),
        api.get<Page<Tender>>("/api/v1/tendering/tenders?size=100"),
      ]);
      setSummary(sum);
      setTenders(tn.items);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addTender(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await api.post("/api/v1/tendering/tenders", {
        title,
        client_name: client || null,
        business_unit: bu,
        estimated_value: Number(estValue) || 0,
      });
      setTitle("");
      setClient("");
      setEstValue("");
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("tenderingTitle")}</PageTitle>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && summary && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.5rem" }}>
            <Metric label={t("totalTenders")} value={fmt(summary.total_tenders)} />
            <Metric label={t("wonTenders")} value={fmt(summary.won_tenders)} />
            <Metric label={t("winRate")} value={`${summary.win_rate}%`} />
            <Metric label={t("pipelineValue")} value={fmt(summary.total_pipeline_value)} sub={t("egp")} />
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newTender")}</div>
              <form onSubmit={addTender} style={{ display: "grid", gridTemplateColumns: "1.6fr 1.2fr 1.1fr 1fr auto", gap: 10, alignItems: "end" }}>
                <div><label style={labelStyle}>{t("tenderTitle")}</label><input value={title} onChange={(e) => setTitle(e.target.value)} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("client")}</label><input value={client} onChange={(e) => setClient(e.target.value)} style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("businessUnit")}</label>
                  <select value={bu} onChange={(e) => setBu(e.target.value)} style={inputStyle}>
                    <option value="construction">{t("buConstruction")}</option>
                    <option value="industrial_automation">{t("buAutomation")}</option>
                    <option value="electrical">{t("buElectrical")}</option>
                    <option value="plc_scada">{t("buPlcScada")}</option>
                    <option value="maintenance">{t("buMaintenance")}</option>
                    <option value="consulting">{t("buConsulting")}</option>
                  </select>
                </div>
                <div><label style={labelStyle}>{t("estimatedValue")}</label><input type="number" value={estValue} onChange={(e) => setEstValue(e.target.value)} style={inputStyle} /></div>
                <button type="submit" disabled={saving} style={btnStyle}>{saving ? "..." : t("add")}</button>
              </form>
              {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
            </Card>
          </div>

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("tenders")}</div>
            {tenders.length === 0 ? (
              <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noTenders")}</div>
            ) : (
              <Table
                headers={[t("code"), t("tenderTitle"), t("businessUnit"), t("bidValue"), t("status"), ""]}
                rows={tenders.map((tn) => [
                  <span key={tn.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{tn.code}</span>,
                  tn.title,
                  <span key={tn.id + "b"} style={{ color: "var(--text-muted)", fontSize: 13 }}>{buLabel[tn.business_unit] || tn.business_unit}</span>,
                  `${fmt(tn.bid_value)} ${t("egp")}`,
                  <Badge key={tn.id + "s"} text={statusLabel[tn.status] || tn.status} kind={statusKind[tn.status] || "lead"} />,
                  <Link key={tn.id + "l"} href={`/tendering/${tn.id}`} style={{ color: "var(--brand)", fontSize: 13, fontWeight: 500, textDecoration: "none" }}>
                    {t("manageTender")} →
                  </Link>,
                ])}
              />
            )}
          </Card>
        </>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
