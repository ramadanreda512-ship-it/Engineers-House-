"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Partner, PartnerTx, PartnerSummaryData, ProfitDistPreview, GLAccount } from "@/lib/types";
import { PageTitle, Card, Metric, Table, Badge, Loading, ErrorBox, fmt, ConfirmDialog } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function PartnersPage() {
  const { t, dir } = useLang();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [summary, setSummary] = useState<PartnerSummaryData | null>(null);
  const [accounts, setAccounts] = useState<GLAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Partner | null>(null);

  const [form, setForm] = useState({ name: "", equity_percent: "", phone: "" });
  const [formError, setFormError] = useState<string | null>(null);
  const [showProfit, setShowProfit] = useState(false);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  async function load() {
    setLoading(true);
    try {
      const [ps, sm, accs] = await Promise.all([
        api.get<Partner[]>("/api/v1/partners"),
        api.get<PartnerSummaryData>("/api/v1/partners/summary"),
        api.get<GLAccount[]>("/api/v1/accounting/accounts"),
      ]);
      setPartners(ps);
      setSummary(sm);
      setAccounts(accs.filter((a) => !a.is_group));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function addPartner(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    try {
      await api.post("/api/v1/partners", {
        name: form.name, equity_percent: Number(form.equity_percent) || 0, phone: form.phone || null,
      });
      setForm({ name: "", equity_percent: "", phone: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;
  if (selected) return <PartnerDetail partner={selected} accounts={accounts} onBack={() => { setSelected(null); load(); }} />;

  return (
    <div>
      <PageTitle>{t("partnersTitle")}</PageTitle>
      {error && <ErrorBox message={error} />}

      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
          <Metric label={t("partnersCount")} value={String(summary.total_partners)} />
          <Metric label={t("totalCapital")} value={`${fmt(summary.total_capital)} ${t("egp")}`} />
          <Metric label={t("totalEquityPct")} value={`${summary.total_equity_percent}%`} />
          <Metric label={t("totalOwed")} value={`${fmt(summary.total_owed_to_partners)} ${t("egp")}`} />
        </div>
      )}

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontWeight: 500 }}>{t("newPartner")}</div>
            <button onClick={() => setShowProfit(!showProfit)} style={btnGrey}>{t("profitDistribution")}</button>
          </div>
          <form onSubmit={addPartner} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("partnerName")}</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("equityPercent")}</label><input type="number" step="0.01" value={form.equity_percent} onChange={(e) => setForm({ ...form, equity_percent: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("phone")}</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} style={inputStyle} /></div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
          {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
        </Card>
      </div>

      {showProfit && <ProfitDistributionCard accounts={accounts} onDone={() => { setShowProfit(false); load(); }} />}

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("partnersTitle")}</div>
        {partners.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noPartners")}</div> : (
          <Table
            headers={[t("accountCode"), t("partnerName"), t("equityPercent"), t("capitalContribution"), t("currentBalance"), ""]}
            rows={partners.map((p) => [
              <span key={p.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{p.code}</span>,
              p.name,
              `${p.equity_percent}%`,
              `${fmt(p.capital_contribution)} ${t("egp")}`,
              <span key={p.id + "b"} style={{ fontWeight: 600, color: p.current_balance >= 0 ? "var(--brand)" : "#c0392b" }}>{fmt(p.current_balance)} {t("egp")}</span>,
              <button key={p.id + "v"} onClick={() => setSelected(p)} style={miniBtn}>{t("viewStatement")}</button>,
            ])}
          />
        )}
      </Card>
    </div>
  );
}

function ProfitDistributionCard({ accounts, onDone }: { accounts: GLAccount[]; onDone: () => void }) {
  const { t } = useLang();
  const [profit, setProfit] = useState("");
  const [cash, setCash] = useState("");
  const [preview, setPreview] = useState<ProfitDistPreview | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function doPreview() {
    setError(null);
    try { setPreview(await api.post<ProfitDistPreview>("/api/v1/partners/profit-distribution/preview", { total_profit: Number(profit) || 0 })); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }
  async function doDistribute() {
    setError(null);
    try {
      await api.post("/api/v1/partners/profit-distribution", { total_profit: Number(profit) || 0, cash_account_id: cash || null });
      onDone();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <div style={{ marginBottom: "1.25rem" }}>
      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("profitDistribution")}</div>
        <div style={{ display: "flex", gap: 10, alignItems: "end", marginBottom: 12, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 160 }}><label style={labelStyle}>{t("totalProfit")}</label><input type="number" value={profit} onChange={(e) => setProfit(e.target.value)} style={baseInput} /></div>
          <div style={{ flex: 1, minWidth: 160 }}><label style={labelStyle}>{t("cashAccount")}</label>
            <select value={cash} onChange={(e) => setCash(e.target.value)} style={baseInput}>
              <option value="">—</option>
              {accounts.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
            </select>
          </div>
          <button onClick={doPreview} style={btnGrey}>{t("preview")}</button>
          {preview && <button onClick={doDistribute} style={btnStyle}>{t("distribute")}</button>}
        </div>
        {error && <ErrorBox message={error} />}
        {preview && (
          <Table
            headers={[t("partnerName"), t("equityPercent"), t("amount")]}
            rows={[
              ...preview.lines.map((l) => [l.partner_name, `${l.equity_percent}%`, `${fmt(l.amount)} ${t("egp")}`]),
              [<strong key="t">{t("distributed")}</strong>, "", <strong key="d">{fmt(preview.distributed)} {t("egp")}</strong>],
            ]}
          />
        )}
      </Card>
    </div>
  );
}

function PartnerDetail({ partner, accounts, onBack }: { partner: Partner; accounts: GLAccount[]; onBack: () => void }) {
  const { t, dir } = useLang();
  const [txs, setTxs] = useState<PartnerTx[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ tx_type: "capital_contribution", amount: "", cash_account_id: "", description: "" });
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const txLabel: Record<string, string> = {
    capital_contribution: t("txCapital"), additional_investment: t("txAdditional"),
    withdrawal: t("txWithdrawal"), loan_disbursed: t("txLoanOut"), loan_repaid: t("txLoanRepaid"),
    profit_distribution: t("txProfit"), expense_charged: t("txExpense"),
  };

  async function load() {
    try { setTxs(await api.get<PartnerTx[]>(`/api/v1/partners/${partner.id}/transactions`)); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function addTx(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post(`/api/v1/partners/${partner.id}/transactions`, {
        tx_type: form.tx_type, amount: Number(form.amount) || 0,
        cash_account_id: form.cash_account_id || null, description: form.description || null,
      });
      setForm({ tx_type: "capital_contribution", amount: "", cash_account_id: "", description: "" });
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  return (
    <div>
      <button onClick={onBack} style={{ ...btnGrey, marginBottom: 16 }}>← {t("backToList")}</button>
      <PageTitle>{partner.name} ({partner.code})</PageTitle>
      {error && <ErrorBox message={error} />}

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("addTransaction")}</div>
          <form onSubmit={addTx} style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1.4fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("txType")}</label>
              <select value={form.tx_type} onChange={(e) => setForm({ ...form, tx_type: e.target.value })} style={inputStyle}>
                <option value="capital_contribution">{t("txCapital")}</option>
                <option value="additional_investment">{t("txAdditional")}</option>
                <option value="withdrawal">{t("txWithdrawal")}</option>
                <option value="loan_disbursed">{t("txLoanOut")}</option>
                <option value="loan_repaid">{t("txLoanRepaid")}</option>
                <option value="expense_charged">{t("txExpense")}</option>
              </select>
            </div>
            <div><label style={labelStyle}>{t("amount")}</label><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("cashAccount")}</label>
              <select value={form.cash_account_id} onChange={(e) => setForm({ ...form, cash_account_id: e.target.value })} style={inputStyle}>
                <option value="">—</option>
                {accounts.map((a) => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
              </select>
            </div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
        </Card>
      </div>

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("partnerStatement")}</div>
        {txs.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noTransactions")}</div> : (
          <Table
            headers={[t("entryDate"), t("txType"), t("description"), t("amount")]}
            rows={txs.map((tx) => [
              tx.tx_date,
              <Badge key={tx.id} text={txLabel[tx.tx_type] || tx.tx_type} kind="lead" />,
              tx.description || "—",
              `${fmt(tx.amount)} ${t("egp")}`,
            ])}
          />
        )}
      </Card>
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500 };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
