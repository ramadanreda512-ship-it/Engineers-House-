"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import {
  FinancialSnapshot,
  CrmSummaryData,
  ProjectsSummaryData,
  TrainingSummaryData,
  PipelineData,
} from "@/lib/types";
import { Loading, ErrorBox } from "@/components/ui";
import { useLang } from "@/lib/i18n";

/* ============ Glow Command-Center Dashboard ============ */

const C = {
  bg: "#070b16",
  card: "rgba(15, 22, 41, 0.72)",
  border: "rgba(120, 140, 255, 0.14)",
  text: "#e6ecff",
  dim: "#8b96b8",
  cyan: "#22d3ee",
  violet: "#a78bfa",
  emerald: "#34d399",
  amber: "#fbbf24",
  rose: "#fb7185",
  blue: "#60a5fa",
};

export default function DashboardPage() {
  const { t, dir } = useLang();
  const [snap, setSnap] = useState<FinancialSnapshot | null>(null);
  const [crm, setCrm] = useState<CrmSummaryData | null>(null);
  const [pipe, setPipe] = useState<PipelineData | null>(null);
  const [proj, setProj] = useState<ProjectsSummaryData | null>(null);
  const [train, setTrain] = useState<TrainingSummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string>("");

  const load = useCallback(async () => {
    try {
      const [s, c, p, pr, tr] = await Promise.all([
        api.get<FinancialSnapshot>("/api/v1/analyst/snapshot"),
        api.get<CrmSummaryData>("/api/v1/crm/summary"),
        api.get<PipelineData>("/api/v1/crm/pipeline"),
        api.get<ProjectsSummaryData>("/api/v1/projects/summary"),
        api.get<TrainingSummaryData>("/api/v1/training/summary"),
      ]);
      setSnap(s); setCrm(c); setPipe(p); setProj(pr); setTrain(tr);
      setUpdatedAt(new Date().toLocaleTimeString());
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const iv = setInterval(load, 60000); // live pulse every 60s
    return () => clearInterval(iv);
  }, [load]);

  if (loading) return <Loading text={t("loadingData")} />;
  if (error && !snap) return <ErrorBox message={error} />;
  if (!snap || !crm || !pipe || !proj || !train) return null;

  const margin = snap.total_revenue > 0 ? Math.round((snap.net_profit / snap.total_revenue) * 100) : 0;
  const collectPct = train.total_fees > 0 ? Math.round((train.total_collected / train.total_fees) * 100) : 0;
  const maxStage = Math.max(...pipe.stages.filter(s => !["won","lost"].includes(s.stage)).map(s => s.total_value), 1);
  const stageColors: Record<string, string> = { new: C.cyan, qualified: C.blue, proposal: C.violet, negotiation: C.amber };
  const stageLabel: Record<string, string> = {
    new: t("dStageNew"), qualified: t("dStageQualified"),
    proposal: t("dStageProposal"), negotiation: t("dStageNegotiation"),
  };

  return (
    <div style={{ margin: "-24px", padding: "28px", minHeight: "calc(100vh - 0px)", background: `radial-gradient(1100px 500px at 85% -10%, rgba(103,72,255,0.16), transparent 60%), radial-gradient(900px 420px at 8% 110%, rgba(34,211,238,0.10), transparent 55%), ${C.bg}`, color: C.text, direction: dir as "rtl" | "ltr" }}>
      <style>{`
        @keyframes dashFadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
        @keyframes dashPulse { 0%,100% { opacity: .55; } 50% { opacity: 1; } }
        @keyframes dashSweep { from { background-position: 0% 50%; } to { background-position: 200% 50%; } }
        @keyframes dashRing { from { stroke-dashoffset: 260; } to {} }
        .dcard { animation: dashFadeUp .5s ease both; backdrop-filter: blur(8px); transition: transform .18s ease, box-shadow .18s ease; }
        .dcard:hover { transform: translateY(-3px); }
        .dbar { transition: width 1s cubic-bezier(.2,.8,.2,1); }
      `}</style>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 22 }}>
        <div>
          <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: .3, background: `linear-gradient(90deg, ${C.cyan}, ${C.violet}, ${C.cyan})`, backgroundSize: "200% 100%", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", animation: "dashSweep 6s linear infinite" }}>
            {t("dashTitle")}
          </div>
          <div style={{ color: C.dim, fontSize: 13, marginTop: 2, display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: 99, background: C.emerald, boxShadow: `0 0 10px ${C.emerald}`, animation: "dashPulse 2s infinite" }} />
            {t("dashSubtitle")}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: C.dim, fontSize: 12 }}>{t("dashUpdated")}: {updatedAt}</span>
          <button onClick={load} style={{ background: "rgba(34,211,238,0.10)", color: C.cyan, border: `1px solid rgba(34,211,238,0.35)`, borderRadius: 10, padding: "8px 18px", fontSize: 13, fontWeight: 600, cursor: "pointer", boxShadow: "0 0 18px rgba(34,211,238,0.15)" }}>
            ⟳ {t("dashRefresh")}
          </button>
        </div>
      </div>

      {/* Hero KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 14, marginBottom: 16 }}>
        <Hero label={t("dNetProfit")} value={snap.net_profit} suffix={t("egp")} color={snap.net_profit >= 0 ? C.emerald : C.rose} big delay={0} sub={`${t("dMargin")} ${margin}%`} />
        <Hero label={t("dRevenue")} value={snap.total_revenue} suffix={t("egp")} color={C.cyan} delay={1} />
        <Hero label={t("dExpenses")} value={snap.total_expense} suffix={t("egp")} color={C.rose} delay={2} />
        <Hero label={t("dCash")} value={snap.cash_position} suffix={t("egp")} color={C.blue} delay={3} />
      </div>

      {/* Row 2: donut + pipeline + finance mini */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(290px, 1fr))", gap: 14, marginBottom: 16 }}>
        {/* Profit ring */}
        <GlowCard delay={2} accent={C.emerald} title={t("dRevVsExp")}>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <ProfitRing revenue={snap.total_revenue} expense={snap.total_expense} />
            <div style={{ display: "grid", gap: 10 }}>
              <LegendDot color={C.cyan} label={t("dRevenue")} value={snap.total_revenue} suffix={t("egp")} />
              <LegendDot color={C.rose} label={t("dExpenses")} value={snap.total_expense} suffix={t("egp")} />
              <LegendDot color={C.emerald} label={t("dNetProfit")} value={snap.net_profit} suffix={t("egp")} />
            </div>
          </div>
        </GlowCard>

        {/* Pipeline funnel */}
        <GlowCard delay={3} accent={C.violet} title={`${t("dPipelineSec")} · ${crm.total_accounts} ${t("totalCustomers")}`} href="/crm">
          {pipe.stages.filter(s => !["won","lost"].includes(s.stage)).map((s) => (
            <div key={s.stage} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: C.dim, marginBottom: 4 }}>
                <span>{stageLabel[s.stage] || s.stage} · {s.count}</span>
                <span style={{ color: C.text, fontWeight: 700 }}>{fmtK(s.total_value)}</span>
              </div>
              <div style={{ height: 9, background: "rgba(255,255,255,0.05)", borderRadius: 99 }}>
                <div className="dbar" style={{ height: "100%", width: `${Math.max((s.total_value / maxStage) * 100, s.count ? 6 : 0)}%`, borderRadius: 99, background: `linear-gradient(90deg, ${stageColors[s.stage]}88, ${stageColors[s.stage]})`, boxShadow: `0 0 12px ${stageColors[s.stage]}66` }} />
              </div>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 14, paddingTop: 12, borderTop: `1px solid ${C.border}` }}>
            <MiniStat label={t("dForecast")} value={fmtK(pipe.weighted_forecast)} color={C.violet} />
            <MiniStat label={t("dWon")} value={fmtK(pipe.won_total)} color={C.emerald} />
            <MiniStat label={t("dOpenDeals")} value={String(pipe.stages.filter(s => !["won","lost"].includes(s.stage)).reduce((a, s) => a + s.count, 0))} color={C.cyan} />
          </div>
        </GlowCard>

        {/* Balances */}
        <GlowCard delay={4} accent={C.blue} title={t("navAccounting")} href="/accounting">
          <div style={{ display: "grid", gap: 12 }}>
            <BalanceRow label={t("dReceivables")} value={snap.receivables} suffix={t("egp")} color={C.cyan} />
            <BalanceRow label={t("dPayables")} value={snap.payables} suffix={t("egp")} color={C.rose} />
            <BalanceRow label={t("dEquity")} value={snap.total_equity} suffix={t("egp")} color={C.violet} />
            <BalanceRow label={t("dTenders")} value={snap.tender_pipeline_value} suffix={`${t("egp")} · ${snap.open_tenders} ${t("dOpenTenders")}`} color={C.amber} />
          </div>
        </GlowCard>
      </div>

      {/* Row 3: projects + training */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(290px, 1fr))", gap: 14, marginBottom: 16 }}>
        <GlowCard delay={5} accent={C.cyan} title={`${t("dProjectsSec")} · ${proj.total_projects}`} href="/projects">
          <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
            <MiniStat label={t("dContracts")} value={fmtK(proj.total_contract_value)} color={C.cyan} big />
            <MiniStat label={t("dInvoiced")} value={fmtK(proj.total_invoiced)} color={C.blue} big />
            <MiniStat label={t("dCollected")} value={fmtK(proj.total_received)} color={C.emerald} big />
            <MiniStat label={t("actualCostK")} value={fmtK(proj.total_actual_cost)} color={C.rose} big />
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
            {Object.entries(proj.by_status).map(([st, n]) => (
              <span key={st} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "rgba(255,255,255,0.06)", border: `1px solid ${C.border}`, color: C.dim }}>{st}: <b style={{ color: C.text }}>{n}</b></span>
            ))}
          </div>
        </GlowCard>

        <GlowCard delay={6} accent={C.amber} title={`${t("dTrainingSec")} · ${train.total_students} ${t("dStudents")} · ${train.active_cohorts} ${t("dCohorts")}`} href="/training">
          <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 12 }}>
            <MiniStat label={t("totalFeesK")} value={fmtK(train.total_fees)} color={C.amber} big />
            <MiniStat label={t("dCollected")} value={fmtK(train.total_collected)} color={C.emerald} big />
            <MiniStat label={t("dOutstanding")} value={fmtK(train.total_outstanding)} color={C.rose} big />
          </div>
          <div style={{ fontSize: 12, color: C.dim, marginBottom: 5 }}>{t("collectedK")} {collectPct}%</div>
          <div style={{ height: 9, background: "rgba(255,255,255,0.05)", borderRadius: 99 }}>
            <div className="dbar" style={{ height: "100%", width: `${collectPct}%`, borderRadius: 99, background: `linear-gradient(90deg, ${C.amber}88, ${C.emerald})`, boxShadow: `0 0 12px ${C.emerald}66` }} />
          </div>
        </GlowCard>
      </div>

      {/* Quick nav */}
      <div style={{ fontSize: 13, color: C.dim, margin: "4px 0 10px" }}>{t("dQuickNav")}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10 }}>
        {[
          { href: "/crm", label: t("navCrm"), icon: "👥", color: C.violet },
          { href: "/projects", label: t("navProjects"), icon: "🏗️", color: C.cyan },
          { href: "/training", label: t("navTraining"), icon: "🎓", color: C.amber },
          { href: "/accounting", label: t("navAccounting"), icon: "📒", color: C.blue },
          { href: "/partners", label: t("partnersTitle"), icon: "🤝", color: C.emerald },
          { href: "/analyst", label: t("analystTitle"), icon: "🤖", color: C.rose },
        ].map((l, i) => (
          <Link key={l.href} href={l.href} className="dcard" style={{ animationDelay: `${0.35 + i * 0.05}s`, display: "flex", alignItems: "center", gap: 10, padding: "13px 14px", background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, color: C.text, textDecoration: "none", fontSize: 13.5, fontWeight: 600, boxShadow: `inset 0 0 0 1px transparent` }}>
            <span style={{ fontSize: 18, filter: `drop-shadow(0 0 6px ${l.color})` }}>{l.icon}</span>
            {l.label}
            <span style={{ marginInlineStart: "auto", color: l.color }}>›</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

/* ============ Building blocks ============ */

function fmtK(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return n.toLocaleString();
}

function useCountUp(target: number, ms = 900): number {
  const [v, setV] = useState(0);
  const ref = useRef<number>(0);
  useEffect(() => {
    const start = performance.now();
    const from = ref.current;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min((now - start) / ms, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else ref.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

function Hero({ label, value, suffix, color, big, delay = 0, sub }: { label: string; value: number; suffix: string; color: string; big?: boolean; delay?: number; sub?: string }) {
  const v = useCountUp(value);
  return (
    <div className="dcard" style={{ animationDelay: `${delay * 0.07}s`, position: "relative", overflow: "hidden", padding: "18px 20px", background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, boxShadow: `0 0 34px ${color}1f, inset 0 1px 0 rgba(255,255,255,0.05)` }}>
      <div style={{ position: "absolute", top: 0, insetInlineStart: 0, width: "45%", height: 3, background: `linear-gradient(90deg, ${color}, transparent)`, boxShadow: `0 0 14px ${color}` }} />
      <div style={{ color: C.dim, fontSize: 12.5, marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: big ? 30 : 24, fontWeight: 800, color, textShadow: `0 0 22px ${color}55`, fontVariantNumeric: "tabular-nums" }}>
        {Math.round(v).toLocaleString()} <span style={{ fontSize: 12, color: C.dim, fontWeight: 500 }}>{suffix}</span>
      </div>
      {sub && <div style={{ fontSize: 12, color: C.dim, marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

function GlowCard({ children, title, accent, delay = 0, href }: { children: React.ReactNode; title: string; accent: string; delay?: number; href?: string }) {
  return (
    <div className="dcard" style={{ animationDelay: `${delay * 0.07}s`, padding: "18px 20px", background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, boxShadow: `0 0 30px ${accent}14` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>
          <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: 99, background: accent, boxShadow: `0 0 10px ${accent}`, marginInlineEnd: 8 }} />
          {title}
        </div>
        {href && <Link href={href} style={{ color: accent, fontSize: 12, textDecoration: "none", fontWeight: 600 }}>›</Link>}
      </div>
      {children}
    </div>
  );
}

function ProfitRing({ revenue, expense }: { revenue: number; expense: number }) {
  const total = revenue + expense || 1;
  const revPct = revenue / total;
  const r = 42, circ = 2 * Math.PI * r;
  return (
    <svg width="120" height="120" viewBox="0 0 120 120" style={{ flexShrink: 0 }}>
      <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="12" />
      <circle cx="60" cy="60" r={r} fill="none" stroke={C.rose} strokeWidth="12" strokeLinecap="round"
        strokeDasharray={`${(1 - revPct) * circ} ${circ}`} strokeDashoffset={-revPct * circ}
        transform="rotate(-90 60 60)" style={{ filter: `drop-shadow(0 0 6px ${C.rose}88)` }} />
      <circle cx="60" cy="60" r={r} fill="none" stroke={C.cyan} strokeWidth="12" strokeLinecap="round"
        strokeDasharray={`${revPct * circ} ${circ}`}
        transform="rotate(-90 60 60)" style={{ filter: `drop-shadow(0 0 8px ${C.cyan}aa)`, animation: "dashRing 1.2s ease" }} />
      <text x="60" y="57" textAnchor="middle" fill={C.text} fontSize="17" fontWeight="800">{Math.round(revPct * 100)}%</text>
      <text x="60" y="74" textAnchor="middle" fill={C.dim} fontSize="9.5">REV</text>
    </svg>
  );
}

function LegendDot({ color, label, value, suffix }: { color: string; label: string; value: number; suffix: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
      <span style={{ width: 9, height: 9, borderRadius: 99, background: color, boxShadow: `0 0 8px ${color}` }} />
      <span style={{ color: C.dim }}>{label}</span>
      <b style={{ color: C.text, marginInlineStart: "auto", fontVariantNumeric: "tabular-nums" }}>{value.toLocaleString()} <span style={{ fontSize: 10, color: C.dim }}>{suffix}</span></b>
    </div>
  );
}

function MiniStat({ label, value, color, big }: { label: string; value: string; color: string; big?: boolean }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: C.dim, marginBottom: 3 }}>{label}</div>
      <div style={{ fontSize: big ? 19 : 16, fontWeight: 800, color, textShadow: `0 0 16px ${color}44`, fontVariantNumeric: "tabular-nums" }}>{value}</div>
    </div>
  );
}

function BalanceRow({ label, value, suffix, color }: { label: string; value: number; suffix: string; color: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 12px", background: "rgba(255,255,255,0.03)", borderRadius: 10, border: `1px solid rgba(255,255,255,0.05)` }}>
      <span style={{ fontSize: 13, color: C.dim }}>{label}</span>
      <b style={{ fontSize: 15, color, textShadow: `0 0 14px ${color}44`, fontVariantNumeric: "tabular-nums" }}>{value.toLocaleString()} <span style={{ fontSize: 10.5, color: C.dim, fontWeight: 500 }}>{suffix}</span></b>
    </div>
  );
}
