"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { InventoryItem, InventorySummary, Page } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Metric, Loading, ErrorBox, fmt, RowActions, ConfirmDialog, EditDialog, Field, dialogInput } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function InventoryPage() {
  const { t, dir } = useLang();
  const [summary, setSummary] = useState<InventorySummary | null>(null);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({ sku: "", name: "", unit: "pcs", reorder_level: "0", unit_cost: "" });
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [moveItem, setMoveItem] = useState<string | null>(null);
  const [moveQty, setMoveQty] = useState("");
  const [moveType, setMoveType] = useState<"in" | "out">("in");
  const [moveError, setMoveError] = useState<string | null>(null);

  // edit/delete item
  const [editItem, setEditItem] = useState<InventoryItem | null>(null);
  const [eName, setEName] = useState("");
  const [eUnit, setEUnit] = useState("");
  const [eReorder, setEReorder] = useState("");
  const [eCost, setECost] = useState("");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [deleteItemId, setDeleteItemId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const [sum, its] = await Promise.all([
        api.get<InventorySummary>("/api/v1/inventory/summary"),
        api.get<Page<InventoryItem>>("/api/v1/inventory/items?size=100"),
      ]);
      setSummary(sum);
      setItems(its.items);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addItem(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await api.post("/api/v1/inventory/items", {
        sku: form.sku,
        name: form.name,
        unit: form.unit,
        reorder_level: Number(form.reorder_level) || 0,
        unit_cost: Number(form.unit_cost) || 0,
      });
      setForm({ sku: "", name: "", unit: "pcs", reorder_level: "0", unit_cost: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  async function recordMove(itemId: string) {
    setMoveError(null);
    try {
      await api.post(`/api/v1/inventory/items/${itemId}/movements`, {
        movement_type: moveType,
        quantity: Number(moveQty) || 0,
      });
      setMoveQty("");
      setMoveItem(null);
      await load();
    } catch (e) {
      setMoveError(e instanceof Error ? e.message : "Error");
    }
  }

  function openEditItem(it: InventoryItem) {
    setEditItem(it);
    setEName(it.name);
    setEUnit(it.unit);
    setEReorder(String(it.reorder_level));
    setECost(String(it.unit_cost));
    setDialogError(null);
  }

  async function saveItem() {
    if (!editItem) return;
    setDialogError(null);
    try {
      await api.patch(`/api/v1/inventory/items/${editItem.id}`, {
        name: eName,
        unit: eUnit,
        reorder_level: Number(eReorder) || 0,
        unit_cost: Number(eCost) || 0,
      });
      setEditItem(null);
      await load();
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteItem() {
    if (!deleteItemId) return;
    try {
      await api.del(`/api/v1/inventory/items/${deleteItemId}`);
      setDeleteItemId(null);
      await load();
    } catch (e) {
      setDeleteItemId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("inventoryTitle")}</PageTitle>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && summary && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.5rem" }}>
            <Metric label={t("totalItems")} value={fmt(summary.total_items)} />
            <Metric label={t("lowStock")} value={fmt(summary.low_stock_items)} />
            <Metric label={t("stockValue")} value={fmt(summary.total_stock_value)} sub={t("egp")} />
            <Metric label={t("navInventory")} value={fmt(summary.open_purchase_orders)} sub="PO" />
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newItem")}</div>
              <form onSubmit={addItem} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.5fr 0.6fr 0.9fr 0.9fr auto", gap: 10, alignItems: "end" }}>
                <div><label style={labelStyle}>{t("sku")}</label><input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} required style={inputStyle} placeholder="CABLE-25" /></div>
                <div><label style={labelStyle}>{t("itemName")}</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("unit")}</label><input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("reorderLevel")}</label><input type="number" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("unitCost")}</label><input type="number" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: e.target.value })} style={inputStyle} /></div>
                <button type="submit" disabled={saving} style={btnStyle}>{saving ? "..." : t("add")}</button>
              </form>
              {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
            </Card>
          </div>

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("items")}</div>
            {items.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noItems")}</div> : (
              <Table
                headers={[t("sku"), t("itemName"), t("onHand"), t("reorderLevel"), t("unitCost"), ""]}
                rows={items.map((item) => {
                  const low = item.quantity_on_hand <= item.reorder_level;
                  return [
                    <span key={item.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{item.sku}</span>,
                    item.name,
                    <span key={item.id + "q"} style={{ color: low ? "#c0431f" : "var(--text)", fontWeight: low ? 600 : 400 }}>
                      {fmt(item.quantity_on_hand)} {item.unit}
                    </span>,
                    String(item.reorder_level),
                    `${fmt(item.unit_cost)} ${t("egp")}`,
                    <div key={item.id + "b"} style={{ display: "flex", gap: 6, alignItems: "center", justifyContent: "flex-end" }}>
                      <button onClick={() => { setMoveItem(moveItem === item.id ? null : item.id); setMoveQty(""); setMoveError(null); }} style={linkBtn}>
                        {moveItem === item.id ? "▲" : t("movements")}
                      </button>
                      <RowActions editLabel={t("edit")} deleteLabel={t("delete")} onEdit={() => openEditItem(item)} onDelete={() => setDeleteItemId(item.id)} />
                    </div>,
                  ];
                })}
              />
            )}

            {moveItem && (
              <div style={{ marginTop: 16, padding: 16, background: "var(--bg)", borderRadius: 10, border: "1px solid var(--border)", display: "flex", gap: 10, alignItems: "end", flexWrap: "wrap" }}>
                <div>
                  <label style={labelStyle}>{t("woType")}</label>
                  <select value={moveType} onChange={(e) => setMoveType(e.target.value as "in" | "out")} style={{ ...inputStyle, width: 130 }}>
                    <option value="in">{t("movementIn")}</option>
                    <option value="out">{t("movementOut")}</option>
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>{t("quantity")}</label>
                  <input type="number" value={moveQty} onChange={(e) => setMoveQty(e.target.value)} style={{ ...inputStyle, width: 130 }} />
                </div>
                <button onClick={() => recordMove(moveItem)} style={btnStyle}>{t("add")}</button>
                {moveError && <div style={{ width: "100%" }}><ErrorBox message={moveError} /></div>}
              </div>
            )}
          </Card>
        </>
      )}

      <EditDialog
        open={!!editItem}
        title={t("edit") + " — " + t("itemName")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveItem}
        onCancel={() => setEditItem(null)}
        error={dialogError}
      >
        <Field label={t("itemName")}>
          <input value={eName} onChange={(e) => setEName(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("unit")}>
          <input value={eUnit} onChange={(e) => setEUnit(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("reorderLevel")}>
          <input type="number" value={eReorder} onChange={(e) => setEReorder(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("unitCost")}>
          <input type="number" value={eCost} onChange={(e) => setECost(e.target.value)} style={dialogInput} />
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!deleteItemId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteItem}
        onCancel={() => setDeleteItemId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const linkBtn: React.CSSProperties = { background: "transparent", color: "var(--brand)", border: "none", fontSize: 13, fontWeight: 500, padding: 0 };
