"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Invoice, Payment, FinanceSummary, Expense, Page } from "@/lib/types";
import {
  PageTitle,
  Card,
  Table,
  Badge,
  Metric,
  Loading,
  ErrorBox,
  fmt,
  RowActions,
  ConfirmDialog,
  EditDialog,
  Field,
  dialogInput,
} from "@/components/ui";
import { useLang } from "@/lib/i18n";

interface Line {
  description: string;
  quantity: string;
  unit_price: string;
}

export default function FinancePage() {
  const { t, dir } = useLang();
  const [summary, setSummary] = useState<FinanceSummary | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // create-expense form
  const [expCategory, setExpCategory] = useState("");
  const [expAmount, setExpAmount] = useState("");
  const [expError, setExpError] = useState<string | null>(null);

  // edit/delete expense
  const [editExpense, setEditExpense] = useState<Expense | null>(null);
  const [eCat, setECat] = useState("");
  const [eAmt, setEAmt] = useState("");
  const [expDialogError, setExpDialogError] = useState<string | null>(null);
  const [deleteExpenseId, setDeleteExpenseId] = useState<string | null>(null);

  // create-invoice form
  const [customer, setCustomer] = useState("");
  const [taxRate, setTaxRate] = useState("14");
  const [lines, setLines] = useState<Line[]>([
    { description: "", quantity: "1", unit_price: "" },
  ]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // payment + expanded
  const [expanded, setExpanded] = useState<string | null>(null);
  const [payments, setPayments] = useState<Record<string, Payment[]>>({});
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("cash");
  const [payError, setPayError] = useState<string | null>(null);

  const statusLabel: Record<string, string> = {
    issued: t("statusIssued"),
    partially_paid: t("statusPartiallyPaid"),
    paid: t("statusPaid"),
    cancelled: t("statusCancelled"),
  };

  async function load() {
    setLoading(true);
    try {
      const [sum, inv] = await Promise.all([
        api.get<FinanceSummary>("/api/v1/finance/summary"),
        api.get<Page<Invoice>>("/api/v1/finance/invoices?size=100"),
      ]);
      setSummary(sum);
      setInvoices(inv.items);
      const exp = await api.get<Page<Expense>>("/api/v1/finance/expenses?size=100");
      setExpenses(exp.items);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function updateLine(i: number, field: keyof Line, value: string) {
    setLines((prev) =>
      prev.map((l, idx) => (idx === i ? { ...l, [field]: value } : l)),
    );
  }

  async function createInvoice(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await api.post("/api/v1/finance/invoices", {
        customer_name: customer,
        tax_rate: Number(taxRate) || 0,
        lines: lines
          .filter((l) => l.description && l.unit_price)
          .map((l) => ({
            description: l.description,
            quantity: Number(l.quantity) || 1,
            unit_price: Number(l.unit_price) || 0,
          })),
      });
      setCustomer("");
      setTaxRate("14");
      setLines([{ description: "", quantity: "1", unit_price: "" }]);
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  async function toggleExpand(invoiceId: string) {
    if (expanded === invoiceId) {
      setExpanded(null);
      return;
    }
    setExpanded(invoiceId);
    setPayAmount("");
    setPayError(null);
    try {
      const p = await api.get<Payment[]>(
        `/api/v1/finance/invoices/${invoiceId}/payments`,
      );
      setPayments((prev) => ({ ...prev, [invoiceId]: p }));
    } catch {
      // ignore
    }
  }

  async function recordPayment(invoiceId: string) {
    setPayError(null);
    try {
      await api.post(`/api/v1/finance/invoices/${invoiceId}/payments`, {
        amount: Number(payAmount) || 0,
        method: payMethod,
      });
      setPayAmount("");
      const p = await api.get<Payment[]>(
        `/api/v1/finance/invoices/${invoiceId}/payments`,
      );
      setPayments((prev) => ({ ...prev, [invoiceId]: p }));
      await load();
    } catch (e) {
      setPayError(e instanceof Error ? e.message : "Error");
    }
  }

  async function createExpense(e: React.FormEvent) {
    e.preventDefault();
    setExpError(null);
    try {
      await api.post("/api/v1/finance/expenses", {
        category: expCategory,
        amount: Number(expAmount) || 0,
      });
      setExpCategory("");
      setExpAmount("");
      await load();
    } catch (e) {
      setExpError(e instanceof Error ? e.message : "Error");
    }
  }

  function openEditExpense(ex: Expense) {
    setEditExpense(ex);
    setECat(ex.category);
    setEAmt(String(ex.amount));
    setExpDialogError(null);
  }

  async function saveExpense() {
    if (!editExpense) return;
    setExpDialogError(null);
    try {
      await api.patch(`/api/v1/finance/expenses/${editExpense.id}`, {
        category: eCat,
        amount: Number(eAmt) || 0,
      });
      setEditExpense(null);
      await load();
    } catch (e) {
      setExpDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteExpense() {
    if (!deleteExpenseId) return;
    try {
      await api.del(`/api/v1/finance/expenses/${deleteExpenseId}`);
      setDeleteExpenseId(null);
      await load();
    } catch (e) {
      setDeleteExpenseId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("financeTitle")}</PageTitle>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && summary && (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
              gap: 12,
              marginBottom: "1.5rem",
            }}
          >
            <Metric label={t("totalInvoiced")} value={fmt(summary.total_invoiced)} sub={t("egp")} />
            <Metric label={t("totalCollected")} value={fmt(summary.total_collected)} sub={t("egp")} />
            <Metric label={t("totalOutstanding")} value={fmt(summary.total_outstanding)} sub={t("egp")} />
            <Metric label={t("netCash")} value={fmt(summary.net_cash)} sub={t("egp")} />
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newInvoice")}</div>
              <form onSubmit={createInvoice}>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "2fr 1fr",
                    gap: 10,
                    marginBottom: 12,
                  }}
                >
                  <div>
                    <label style={labelStyle}>{t("customerName")}</label>
                    <input
                      value={customer}
                      onChange={(e) => setCustomer(e.target.value)}
                      required
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <label style={labelStyle}>{t("taxRate")}</label>
                    <input
                      type="number"
                      value={taxRate}
                      onChange={(e) => setTaxRate(e.target.value)}
                      style={inputStyle}
                    />
                  </div>
                </div>

                {lines.map((line, i) => (
                  <div
                    key={i}
                    style={{
                      display: "grid",
                      gridTemplateColumns: "2fr 0.8fr 1fr",
                      gap: 10,
                      marginBottom: 8,
                    }}
                  >
                    <input
                      placeholder={t("lineDescription")}
                      value={line.description}
                      onChange={(e) => updateLine(i, "description", e.target.value)}
                      style={inputStyle}
                    />
                    <input
                      type="number"
                      placeholder={t("quantity")}
                      value={line.quantity}
                      onChange={(e) => updateLine(i, "quantity", e.target.value)}
                      style={inputStyle}
                    />
                    <input
                      type="number"
                      placeholder={t("unitPrice")}
                      value={line.unit_price}
                      onChange={(e) => updateLine(i, "unit_price", e.target.value)}
                      style={inputStyle}
                    />
                  </div>
                ))}

                <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
                  <button
                    type="button"
                    onClick={() =>
                      setLines((prev) => [
                        ...prev,
                        { description: "", quantity: "1", unit_price: "" },
                      ])
                    }
                    style={secondaryBtn}
                  >
                    + {t("addLine")}
                  </button>
                  <button type="submit" disabled={saving} style={btnStyle}>
                    {saving ? "..." : t("createInvoice")}
                  </button>
                </div>
                {formError && (
                  <div style={{ marginTop: 10 }}>
                    <ErrorBox message={formError} />
                  </div>
                )}
              </form>
            </Card>
          </div>

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("invoices")}</div>
            {invoices.length === 0 && (
              <div style={{ color: "var(--text-muted)", fontSize: 14 }}>
                {t("noInvoices")}
              </div>
            )}
            {invoices.length > 0 && (
              <Table
                headers={[
                  t("invoiceNumber"),
                  t("customer"),
                  t("invoiceTotal"),
                  t("paid"),
                  t("status"),
                  "",
                ]}
                rows={invoices.map((inv) => [
                  <span key={inv.id} style={{ fontFamily: "monospace", fontSize: 12 }}>
                    {inv.number}
                  </span>,
                  inv.customer_name,
                  `${fmt(inv.total)} ${t("egp")}`,
                  `${fmt(inv.paid_amount)} ${t("egp")}`,
                  <Badge key={inv.id + "s"} text={statusLabel[inv.status] || inv.status} kind={inv.status} />,
                  <button
                    key={inv.id + "b"}
                    onClick={() => toggleExpand(inv.id)}
                    style={linkBtn}
                  >
                    {expanded === inv.id ? "▲" : t("recordPayment")}
                  </button>,
                ])}
              />
            )}

            {expanded && (
              <div
                style={{
                  marginTop: 16,
                  padding: 16,
                  background: "var(--bg)",
                  borderRadius: 10,
                  border: "1px solid var(--border)",
                }}
              >
                <div style={{ fontWeight: 500, marginBottom: 10 }}>
                  {t("payments")}
                </div>
                {(payments[expanded] || []).length === 0 && (
                  <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 10 }}>
                    —
                  </div>
                )}
                {(payments[expanded] || []).map((p) => (
                  <div
                    key={p.id}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      fontSize: 13,
                      padding: "6px 0",
                      borderBottom: "1px solid var(--border)",
                    }}
                  >
                    <span>{fmt(p.amount)} {t("egp")}</span>
                    <span style={{ color: "var(--text-muted)" }}>
                      {new Date(p.paid_at).toLocaleDateString()}
                    </span>
                  </div>
                ))}

                {invoices.find((i) => i.id === expanded)?.status !== "paid" &&
                  invoices.find((i) => i.id === expanded)?.status !== "cancelled" && (
                    <div
                      style={{
                        display: "flex",
                        gap: 10,
                        alignItems: "end",
                        marginTop: 12,
                        flexWrap: "wrap",
                      }}
                    >
                      <div>
                        <label style={labelStyle}>{t("amount")}</label>
                        <input
                          type="number"
                          value={payAmount}
                          onChange={(e) => setPayAmount(e.target.value)}
                          style={{ ...inputStyle, width: 140 }}
                        />
                      </div>
                      <div>
                        <label style={labelStyle}>{t("paymentMethod")}</label>
                        <select
                          value={payMethod}
                          onChange={(e) => setPayMethod(e.target.value)}
                          style={{ ...inputStyle, width: 140 }}
                        >
                          <option value="cash">{t("methodCash")}</option>
                          <option value="bank">{t("methodBank")}</option>
                          <option value="cheque">{t("methodCheque")}</option>
                        </select>
                      </div>
                      <button onClick={() => recordPayment(expanded)} style={btnStyle}>
                        {t("recordPayment")}
                      </button>
                    </div>
                  )}
                {payError && (
                  <div style={{ marginTop: 10 }}>
                    <ErrorBox message={payError} />
                  </div>
                )}
              </div>
            )}
          </Card>

          <div style={{ marginTop: "1.5rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("expensesTitle")}</div>
              <form onSubmit={createExpense} style={{ display: "flex", gap: 10, alignItems: "end", marginBottom: 16, flexWrap: "wrap" }}>
                <div style={{ flex: 1, minWidth: 160 }}>
                  <label style={labelStyle}>{t("expenseCategory")}</label>
                  <input value={expCategory} onChange={(e) => setExpCategory(e.target.value)} required style={inputStyle} placeholder={t("expenseCategory")} />
                </div>
                <div style={{ width: 150 }}>
                  <label style={labelStyle}>{t("amount")}</label>
                  <input type="number" value={expAmount} onChange={(e) => setExpAmount(e.target.value)} required style={inputStyle} />
                </div>
                <button type="submit" style={btnStyle}>{t("add")}</button>
              </form>
              {expError && <div style={{ marginBottom: 10 }}><ErrorBox message={expError} /></div>}
              {expenses.length === 0 ? (
                <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noExpenses")}</div>
              ) : (
                <Table
                  headers={[t("expenseCategory"), t("amount"), t("date"), ""]}
                  rows={expenses.map((ex) => [
                    ex.category,
                    `${fmt(ex.amount)} ${t("egp")}`,
                    <span key={ex.id + "d"} style={{ color: "var(--text-muted)" }}>{ex.spent_at}</span>,
                    <RowActions key={ex.id + "act"} editLabel={t("edit")} deleteLabel={t("delete")} onEdit={() => openEditExpense(ex)} onDelete={() => setDeleteExpenseId(ex.id)} />,
                  ])}
                />
              )}
            </Card>
          </div>
        </>
      )}

      <EditDialog
        open={!!editExpense}
        title={t("edit") + " — " + t("expensesTitle")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveExpense}
        onCancel={() => setEditExpense(null)}
        error={expDialogError}
      >
        <Field label={t("expenseCategory")}>
          <input value={eCat} onChange={(e) => setECat(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("amount")}>
          <input type="number" value={eAmt} onChange={(e) => setEAmt(e.target.value)} style={dialogInput} />
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!deleteExpenseId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteExpense}
        onCancel={() => setDeleteExpenseId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  fontSize: 12,
  color: "var(--text-muted)",
  display: "block",
  marginBottom: 4,
};
const baseInput: React.CSSProperties = {
  width: "100%",
  padding: "9px 10px",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 14,
  background: "var(--surface)",
};
const btnStyle: React.CSSProperties = {
  background: "var(--brand)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "10px 18px",
  fontSize: 14,
  fontWeight: 500,
  whiteSpace: "nowrap",
};
const secondaryBtn: React.CSSProperties = {
  background: "var(--surface)",
  color: "var(--brand)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  padding: "10px 18px",
  fontSize: 14,
  fontWeight: 500,
};
const linkBtn: React.CSSProperties = {
  background: "transparent",
  color: "var(--brand)",
  border: "none",
  fontSize: 13,
  fontWeight: 500,
};
