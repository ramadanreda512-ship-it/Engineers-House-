"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import {
  Course,
  Cohort,
  Page,
  TrainingLead,
  LeadsSummaryData,
} from "@/lib/types";
import { Card, Metric, Table, Badge, Loading, ErrorBox } from "@/components/ui";
import { useLang } from "@/lib/i18n";

const SOURCES = [
  "whatsapp", "phone_call", "facebook", "instagram",
  "walk_in", "referral", "website", "other",
];
const LOST_REASONS = ["price", "timing", "location", "competitor", "no_response", "other"];

export default function LeadsBoard() {
  const { t, dir } = useLang();
  const [leads, setLeads] = useState<TrainingLead[]>([]);
  const [summary, setSummary] = useState<LeadsSummaryData | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [cohorts, setCohorts] = useState<Cohort[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [statusFilter, setStatusFilter] = useState<string>("");
  const [dueFilter, setDueFilter] = useState<string>("");
  const [search, setSearch] = useState("");

  // quick-add form
  const [showAdd, setShowAdd] = useState(false);
  const [f, setF] = useState({ name: "", phone: "", source: "whatsapp", interested_course_id: "", next_follow_up: "" });

  // dialogs
  const [contactLead, setContactLead] = useState<TrainingLead | null>(null);
  const [convertLead, setConvertLead] = useState<TrainingLead | null>(null);
  const [loseLead, setLoseLead] = useState<TrainingLead | null>(null);

  const srcLabel: Record<string, string> = {
    whatsapp: t("srcWhatsapp"), phone_call: t("srcPhone"), facebook: t("srcFacebook"),
    instagram: t("srcInstagram"), walk_in: t("srcWalkIn"), referral: t("srcReferral"),
    website: t("srcWebsite"), other: t("srcOther"),
  };
  const stLabel: Record<string, string> = {
    new: t("lsNew"), contacted: t("lsContacted"), follow_up: t("lsFollowUp"),
    interested: t("lsInterested"), registered: t("lsRegistered"), lost: t("lsLost"),
  };
  const stKind: Record<string, string> = {
    new: "lead", contacted: "lead", follow_up: "lead",
    interested: "lead", registered: "completed", lost: "withdrawn",
  };
  const lostLabel: Record<string, string> = {
    price: t("lrPrice"), timing: t("lrTiming"), location: t("lrLocation"),
    competitor: t("lrCompetitor"), no_response: t("lrNoResponse"), other: t("lrOther"),
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ size: "200" });
      if (statusFilter) params.set("status", statusFilter);
      if (dueFilter) params.set("due", dueFilter);
      if (search) params.set("search", search);
      const [ld, sm, crs, coh] = await Promise.all([
        api.get<Page<TrainingLead>>(`/api/v1/training/leads?${params}`),
        api.get<LeadsSummaryData>("/api/v1/training/leads/summary"),
        api.get<Page<Course>>("/api/v1/training/courses?size=100"),
        api.get<Page<Cohort>>("/api/v1/training/cohorts?size=100"),
      ]);
      setLeads(ld.items);
      setSummary(sm);
      setCourses(crs.items);
      setCohorts(coh.items);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }, [statusFilter, dueFilter, search]);

  useEffect(() => { load(); }, [load]);

  const courseName = (id: string | null) =>
    id ? courses.find((c) => c.id === id)?.title || "—" : "—";
  const isOverdue = (d: string | null) =>
    d && new Date(d) < new Date(new Date().toDateString());

  async function addLead(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post("/api/v1/training/leads", {
        name: f.name,
        phone: f.phone || null,
        source: f.source,
        interested_course_id: f.interested_course_id || null,
        next_follow_up: f.next_follow_up || null,
      });
      setF({ name: "", phone: "", source: "whatsapp", interested_course_id: "", next_follow_up: "" });
      setShowAdd(false);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  const openInquiries = summary
    ? (summary.by_status.new || 0) + (summary.by_status.contacted || 0) +
      (summary.by_status.follow_up || 0) + (summary.by_status.interested || 0)
    : 0;

  return (
    <div>
      {error && <ErrorBox message={error} />}

      {/* KPI cards — due_today highlighted (the daily pain point) */}
      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
          <div style={{ ...kpiHi, borderColor: summary.due_today > 0 ? "#c0392b" : "var(--border)" }}>
            <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{t("dueTodayK")}</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: summary.due_today > 0 ? "#c0392b" : "var(--text)" }}>{summary.due_today}</div>
          </div>
          <div style={kpiHi}>
            <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{t("overdueK")}</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: summary.overdue > 0 ? "#e67e22" : "var(--text)" }}>{summary.overdue}</div>
          </div>
          <Metric label={t("newLeadsK")} value={String(summary.by_status.new || 0)} />
          <Metric label={t("conversionK")} value={`${summary.conversion_rate_pct}%`} />
          <Metric label={t("leadsTab")} value={String(openInquiries)} />
        </div>
      )}

      {/* Toolbar: add + filters */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, marginBottom: 14 }}>
        <button onClick={() => setShowAdd(!showAdd)} style={btn}>+ {t("newLead")}</button>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t("leadName")} style={{ ...input, width: 160 }} />
          <button onClick={() => setDueFilter(dueFilter === "today" ? "" : "today")} style={dueFilter === "today" ? chipActive : chip}>{t("dueTodayK")}</button>
          <button onClick={() => setDueFilter(dueFilter === "overdue" ? "" : "overdue")} style={dueFilter === "overdue" ? chipActive : chip}>{t("overdueK")}</button>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ ...input, width: "auto" }}>
            <option value="">{t("allLeads")}</option>
            {["new", "contacted", "follow_up", "interested", "registered", "lost"].map((s) => (
              <option key={s} value={s}>{stLabel[s]}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick-add form */}
      {showAdd && (
        <div style={{ marginBottom: "1.25rem" }}>
          <Card>
            <form onSubmit={addLead} style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1.4fr 1fr auto", gap: 10, alignItems: "end" }}>
              <div><label style={lbl}>{t("leadName")}</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required style={input} /></div>
              <div><label style={lbl}>{t("phone")}</label><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} style={input} /></div>
              <div><label style={lbl}>{t("leadSource")}</label>
                <select value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} style={input}>
                  {SOURCES.map((s) => <option key={s} value={s}>{srcLabel[s]}</option>)}
                </select>
              </div>
              <div><label style={lbl}>{t("interestedCourse")}</label>
                <select value={f.interested_course_id} onChange={(e) => setF({ ...f, interested_course_id: e.target.value })} style={input}>
                  <option value="">—</option>
                  {courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
                </select>
              </div>
              <div><label style={lbl}>{t("nextFollowUp")}</label><input type="date" value={f.next_follow_up} onChange={(e) => setF({ ...f, next_follow_up: e.target.value })} style={input} /></div>
              <button type="submit" style={btn}>{t("save")}</button>
            </form>
          </Card>
        </div>
      )}

      {/* Leads table */}
      <Card>
        {leads.length === 0 ? (
          <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noLeads")}</div>
        ) : (
          <Table
            headers={[t("leadName"), t("phone"), t("leadSource"), t("interestedCourse"), t("status"), t("nextFollowUp"), t("contactsCount"), ""]}
            rows={leads.map((l) => [
              <span key={l.id} style={{ fontWeight: 500 }}>{l.name}</span>,
              l.phone ? (
                <a key={l.id + "p"} href={`https://wa.me/${l.phone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer" style={{ color: "#25D366", textDecoration: "none" }}>{l.phone}</a>
              ) : "—",
              <Badge key={l.id + "s"} text={srcLabel[l.source] || l.source} kind="lead" />,
              courseName(l.interested_course_id),
              <Badge key={l.id + "st"} text={l.status === "lost" && l.lost_reason ? `${stLabel[l.status]} · ${lostLabel[l.lost_reason]}` : stLabel[l.status]} kind={stKind[l.status]} />,
              l.next_follow_up ? (
                <span key={l.id + "f"} style={{ color: isOverdue(l.next_follow_up) && !["registered", "lost"].includes(l.status) ? "#c0392b" : "var(--text)", fontWeight: isOverdue(l.next_follow_up) ? 600 : 400 }}>{l.next_follow_up}</span>
              ) : "—",
              <span key={l.id + "c"} style={{ textAlign: "center", display: "block" }}>{l.contact_count}</span>,
              !["registered", "lost"].includes(l.status) ? (
                <span key={l.id + "a"} style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <button onClick={() => setContactLead(l)} style={miniBlue}>{t("logContact")}</button>
                  <button onClick={() => setConvertLead(l)} style={{ ...mini, color: "#1a7d3c" }}>{t("convertLead")}</button>
                  <button onClick={() => setLoseLead(l)} style={mini}>{t("loseLead")}</button>
                </span>
              ) : <span key={l.id + "a"} style={{ color: "var(--text-muted)", fontSize: 12 }}>—</span>,
            ])}
          />
        )}
      </Card>

      {/* Analysis sections */}
      {summary && (Object.keys(summary.conversion_by_source).length > 0 || Object.keys(summary.lost_reasons).length > 0) && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 14, marginTop: "1.25rem" }}>
          {Object.keys(summary.conversion_by_source).length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 12 }}>{t("sourcesAnalysis")}</div>
              {Object.entries(summary.conversion_by_source).sort((a, b) => b[1].rate_pct - a[1].rate_pct).map(([src, d]) => (
                <div key={src} style={{ marginBottom: 10 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                    <span>{srcLabel[src] || src}</span>
                    <span style={{ color: "var(--text-muted)" }}>{d.registered}/{d.total} · <b style={{ color: "#1a7d3c" }}>{d.rate_pct}%</b></span>
                  </div>
                  <div style={{ height: 8, background: "var(--bg)", borderRadius: 99 }}>
                    <div style={{ height: "100%", width: `${d.rate_pct}%`, borderRadius: 99, background: "linear-gradient(90deg, #1a7d3c88, #1a7d3c)" }} />
                  </div>
                </div>
              ))}
            </Card>
          )}
          {Object.keys(summary.lost_reasons).length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, marginBottom: 12 }}>{t("lostAnalysis")}</div>
              {Object.entries(summary.lost_reasons).sort((a, b) => b[1] - a[1]).map(([r, n]) => (
                <div key={r} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--border)", fontSize: 13 }}>
                  <span>{lostLabel[r] || r}</span>
                  <b style={{ color: "#c0392b" }}>{n}</b>
                </div>
              ))}
            </Card>
          )}
        </div>
      )}

      {contactLead && (
        <ContactDialog lead={contactLead} onClose={() => setContactLead(null)} onDone={() => { setContactLead(null); load(); }} />
      )}
      {convertLead && (
        <ConvertDialog lead={convertLead} cohorts={cohorts} onClose={() => setConvertLead(null)} onDone={() => { setConvertLead(null); load(); }} />
      )}
      {loseLead && (
        <LoseDialog lead={loseLead} reasons={LOST_REASONS} lostLabel={lostLabel} onClose={() => setLoseLead(null)} onDone={() => { setLoseLead(null); load(); }} />
      )}
    </div>
  );
}

/* ---------- Dialogs ---------- */

function Overlay({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 }}>
      <div style={{ background: "var(--surface)", borderRadius: 14, padding: 24, width: "100%", maxWidth: 460, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>{children}</div>
    </div>
  );
}

function ContactDialog({ lead, onClose, onDone }: { lead: TrainingLead; onClose: () => void; onDone: () => void }) {
  const { t } = useLang();
  const [note, setNote] = useState("");
  const [next, setNext] = useState("");
  const [status, setStatus] = useState("");
  const [err, setErr] = useState<string | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/training/leads/${lead.id}/log-contact`, {
        note, next_follow_up: next || null, status: status || null,
      });
      onDone();
    } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }
  return (
    <Overlay>
      <h3 style={{ marginTop: 0 }}>{t("logContact")} — {lead.name}</h3>
      {err && <ErrorBox message={err} />}
      <form onSubmit={submit}>
        <label style={lbl}>{t("contactNote")}</label>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} required rows={3} style={{ ...input, resize: "vertical" }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
          <div><label style={lbl}>{t("nextFollowUp")}</label><input type="date" value={next} onChange={(e) => setNext(e.target.value)} style={input} /></div>
          <div><label style={lbl}>{t("status")}</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)} style={input}>
              <option value="">—</option>
              <option value="contacted">{t("lsContacted")}</option>
              <option value="follow_up">{t("lsFollowUp")}</option>
              <option value="interested">{t("lsInterested")}</option>
            </select>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 18, justifyContent: "flex-end" }}>
          <button type="button" onClick={onClose} style={btnGrey}>{t("cancel")}</button>
          <button type="submit" style={btn}>{t("save")}</button>
        </div>
      </form>
    </Overlay>
  );
}

function ConvertDialog({ lead, cohorts, onClose, onDone }: { lead: TrainingLead; cohorts: Cohort[]; onClose: () => void; onDone: () => void }) {
  const { t } = useLang();
  const [cohortId, setCohortId] = useState("");
  const [fee, setFee] = useState("");
  const [installments, setInstallments] = useState("1");
  const [err, setErr] = useState<string | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/training/leads/${lead.id}/convert`, {
        cohort_id: cohortId || null,
        total_fee: Number(fee) || 0,
        installments_count: Number(installments) || 1,
      });
      onDone();
    } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }
  return (
    <Overlay>
      <h3 style={{ marginTop: 0 }}>{t("convertLead")} — {lead.name}</h3>
      {err && <ErrorBox message={err} />}
      <form onSubmit={submit}>
        <label style={lbl}>{t("chooseCohort")}</label>
        <select value={cohortId} onChange={(e) => setCohortId(e.target.value)} style={input}>
          <option value="">{t("noCohortJustStudent")}</option>
          {cohorts.map((c) => <option key={c.id} value={c.id}>{c.code}</option>)}
        </select>
        {cohortId && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <div><label style={lbl}>{t("totalFeesK")}</label><input type="number" value={fee} onChange={(e) => setFee(e.target.value)} style={input} /></div>
            <div><label style={lbl}>{t("installments")}</label><input type="number" min="1" value={installments} onChange={(e) => setInstallments(e.target.value)} style={input} /></div>
          </div>
        )}
        <div style={{ display: "flex", gap: 10, marginTop: 18, justifyContent: "flex-end" }}>
          <button type="button" onClick={onClose} style={btnGrey}>{t("cancel")}</button>
          <button type="submit" style={{ ...btn, background: "#1a7d3c" }}>{t("convertLead")}</button>
        </div>
      </form>
    </Overlay>
  );
}

function LoseDialog({ lead, reasons, lostLabel, onClose, onDone }: { lead: TrainingLead; reasons: string[]; lostLabel: Record<string, string>; onClose: () => void; onDone: () => void }) {
  const { t } = useLang();
  const [reason, setReason] = useState("price");
  const [note, setNote] = useState("");
  const [err, setErr] = useState<string | null>(null);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/training/leads/${lead.id}/lose`, { lost_reason: reason, note: note || null });
      onDone();
    } catch (e) { setErr(e instanceof Error ? e.message : "Error"); }
  }
  return (
    <Overlay>
      <h3 style={{ marginTop: 0 }}>{t("loseLead")} — {lead.name}</h3>
      {err && <ErrorBox message={err} />}
      <form onSubmit={submit}>
        <label style={lbl}>{t("lostReason")}</label>
        <select value={reason} onChange={(e) => setReason(e.target.value)} style={input}>
          {reasons.map((r) => <option key={r} value={r}>{lostLabel[r]}</option>)}
        </select>
        <label style={{ ...lbl, marginTop: 10 }}>{t("contactNote")}</label>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} style={{ ...input, resize: "vertical" }} />
        <div style={{ display: "flex", gap: 10, marginTop: 18, justifyContent: "flex-end" }}>
          <button type="button" onClick={onClose} style={btnGrey}>{t("cancel")}</button>
          <button type="submit" style={{ ...btn, background: "#c0392b" }}>{t("loseLead")}</button>
        </div>
      </form>
    </Overlay>
  );
}

/* ---------- styles ---------- */
const input: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const lbl: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const btn: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, cursor: "pointer", whiteSpace: "nowrap" };
const btnGrey: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 16px", fontSize: 13, cursor: "pointer" };
const mini: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "#a32d2d" };
const miniBlue: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, cursor: "pointer", color: "var(--brand)" };
const chip: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 99, padding: "6px 14px", fontSize: 12, cursor: "pointer", color: "var(--text)" };
const chipActive: React.CSSProperties = { ...chip, background: "var(--brand)", color: "#fff", borderColor: "var(--brand)" };
const kpiHi: React.CSSProperties = { padding: "14px 16px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12 };
