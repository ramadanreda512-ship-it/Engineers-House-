"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { Course, Cohort, Page, TrainingSummaryData, CohortFinanceRow } from "@/lib/types";
import { PageTitle, Card, Metric, Table, Badge, Loading, ErrorBox, fmt, RowActions, ConfirmDialog, EditDialog, Field, dialogInput } from "@/components/ui";
import { useLang } from "@/lib/i18n";
import ImportExport from "@/components/ImportExport";
import LeadsBoard from "./LeadsBoard";
import CategorySelect from "@/components/CategorySelect";

export default function TrainingPage() {
  const { t, dir } = useLang();
  const [mainTab, setMainTab] = useState<"leads" | "catalog">("leads");
  const [courses, setCourses] = useState<Course[]>([]);
  const [cohorts, setCohorts] = useState<Cohort[]>([]);
  const [summary, setSummary] = useState<TrainingSummaryData | null>(null);
  const [finance, setFinance] = useState<CohortFinanceRow[]>([]);
  const [courseSearch, setCourseSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // course form
  const [code, setCode] = useState("");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("PLC");
  const [price, setPrice] = useState("");
  const [savingCourse, setSavingCourse] = useState(false);

  // cohort form
  const [cohortCourse, setCohortCourse] = useState("");
  const [cohortCode, setCohortCode] = useState("");
  const [capacity, setCapacity] = useState("15");
  const [savingCohort, setSavingCohort] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // edit/delete course
  const [editCourse, setEditCourse] = useState<Course | null>(null);
  const [eTitle, setETitle] = useState("");
  const [eCategory, setECategory] = useState("");
  const [ePrice, setEPrice] = useState("");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [deleteCourseId, setDeleteCourseId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const cq = courseSearch ? `&search=${encodeURIComponent(courseSearch)}` : "";
      const [crs, coh, sm, fin] = await Promise.all([
        api.get<Page<Course>>(`/api/v1/training/courses?size=100${cq}`),
        api.get<Page<Cohort>>("/api/v1/training/cohorts?size=100"),
        api.get<TrainingSummaryData>("/api/v1/training/summary"),
        api.get<CohortFinanceRow[]>("/api/v1/training/reports/cohort-finance"),
      ]);
      setCourses(crs.items);
      setCohorts(coh.items);
      setSummary(sm);
      setFinance(fin);
      if (crs.items.length && !cohortCourse) setCohortCourse(crs.items[0].id);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : t("loadCoursesError"));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courseSearch]);

  async function addCourse(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingCourse(true);
    try {
      await api.post("/api/v1/training/courses", {
        code,
        title,
        category,
        price: Number(price) || 0,
      });
      setCode("");
      setTitle("");
      setPrice("");
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : t("addCourseError"));
    } finally {
      setSavingCourse(false);
    }
  }

  async function addCohort(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingCohort(true);
    try {
      await api.post("/api/v1/training/cohorts", {
        course_id: cohortCourse,
        code: cohortCode,
        capacity: Number(capacity) || 1,
      });
      setCohortCode("");
      setCapacity("15");
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSavingCohort(false);
    }
  }

  const courseName = (id: string) =>
    courses.find((c) => c.id === id)?.title || "—";

  function openEditCourse(c: Course) {
    setEditCourse(c);
    setETitle(c.title);
    setECategory(c.category);
    setEPrice(String(c.price));
    setDialogError(null);
  }

  async function saveCourse() {
    if (!editCourse) return;
    setDialogError(null);
    try {
      await api.patch(`/api/v1/training/courses/${editCourse.id}`, {
        title: eTitle,
        category: eCategory,
        price: Number(ePrice) || 0,
      });
      setEditCourse(null);
      await load();
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteCourse() {
    if (!deleteCourseId) return;
    try {
      await api.del(`/api/v1/training/courses/${deleteCourseId}`);
      setDeleteCourseId(null);
      await load();
    } catch (e) {
      setDeleteCourseId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("navTraining")}</PageTitle>

      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem" }}>
        <button
          onClick={() => setMainTab("leads")}
          style={mainTab === "leads" ? tabActive : tabInactive}
        >
          {t("leadsTab")}
        </button>
        <button
          onClick={() => setMainTab("catalog")}
          style={mainTab === "catalog" ? tabActive : tabInactive}
        >
          {t("catalogTab")}
        </button>
      </div>

      {mainTab === "leads" && <LeadsBoard />}

      {mainTab === "catalog" && (
      <>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && (
        <>
          {summary && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
              <Metric label={t("totalCoursesK")} value={String(summary.total_courses)} />
              <Metric label={t("activeCohortsK")} value={String(summary.active_cohorts)} />
              <Metric label={t("totalStudentsK")} value={String(summary.total_students)} />
              <Metric label={t("totalFeesK")} value={`${fmt(summary.total_fees)} ${t("egp")}`} />
              <Metric label={t("collectedK")} value={`${fmt(summary.total_collected)} ${t("egp")}`} />
              <Metric label={t("outstandingK")} value={`${fmt(summary.total_outstanding)} ${t("egp")}`} />
              <Metric label={t("completionRateK")} value={`${summary.completion_rate_pct}%`} />
            </div>
          )}

          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: "1rem", flexWrap: "wrap" }}>
            <span style={{ fontSize: 13, color: "var(--text-muted)", fontWeight: 500 }}>{t("totalStudentsK")}:</span>
            <ImportExport exportPath="/api/v1/training/students-export" importPath="/api/v1/training/students-import" onImported={load} />
          </div>

          {/* Courses */}
          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("addCourse")}</div>
              <form
                onSubmit={addCourse}
                style={{
                  display: "grid",
                  gridTemplateColumns: "0.7fr 1.3fr 1fr 0.8fr auto",
                  gap: 10,
                  alignItems: "end",
                }}
              >
                <div>
                  <label style={labelStyle}>{t("code")}</label>
                  <input value={code} onChange={(e) => setCode(e.target.value)} required style={inputStyle} placeholder="PLC-101" />
                </div>
                <div>
                  <label style={labelStyle}>{t("courseName")}</label>
                  <input value={title} onChange={(e) => setTitle(e.target.value)} required style={inputStyle} placeholder={t("courseNamePlaceholder")} />
                </div>
                <div>
                  <label style={labelStyle}>{t("category")}</label>
                  <CategorySelect kind="course" value={category} onChange={setCategory} />
                </div>
                <div>
                  <label style={labelStyle}>{t("price")}</label>
                  <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} style={inputStyle} placeholder="3000" />
                </div>
                <button type="submit" disabled={savingCourse} style={btnStyle}>
                  {savingCourse ? "..." : t("add")}
                </button>
              </form>
            </Card>
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, gap: 10, flexWrap: "wrap" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                  <div style={{ fontWeight: 500 }}>{t("courseList")}</div>
                  <ImportExport exportPath="/api/v1/training/courses-export" importPath="/api/v1/training/courses-import" onImported={load} />
                </div>
                <input
                  value={courseSearch}
                  onChange={(e) => setCourseSearch(e.target.value)}
                  placeholder={t("searchCoursesPh")}
                  style={{ ...inputStyle, maxWidth: 260 }}
                />
              </div>
              {courses.length === 0 ? (
                <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noCourses")}</div>
              ) : (
                <Table
                  headers={[t("code"), t("courseName"), t("category"), t("price"), ""]}
                  rows={courses.map((c) => [
                    <span key={c.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{c.code}</span>,
                    c.title,
                    <span key={c.id + "c"} style={{ color: "var(--text-muted)" }}>{c.category}</span>,
                    `${fmt(Number(c.price))} ${t("egp")}`,
                    <RowActions key={c.id + "act"} editLabel={t("edit")} deleteLabel={t("delete")} onEdit={() => openEditCourse(c)} onDelete={() => setDeleteCourseId(c.id)} />,
                  ])}
                />
              )}
            </Card>
          </div>

          {/* Cohorts */}
          {courses.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <Card>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>
                  {t("cohorts")} — {t("add")}
                </div>
                <form
                  onSubmit={addCohort}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1.5fr 1fr 0.7fr auto",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <label style={labelStyle}>{t("courseName")}</label>
                    <select value={cohortCourse} onChange={(e) => setCohortCourse(e.target.value)} style={inputStyle}>
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>{c.title}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>{t("code")}</label>
                    <input value={cohortCode} onChange={(e) => setCohortCode(e.target.value)} required style={inputStyle} placeholder="PLC-2026-01" />
                  </div>
                  <div>
                    <label style={labelStyle}>{t("capacity")}</label>
                    <input type="number" value={capacity} onChange={(e) => setCapacity(e.target.value)} style={inputStyle} />
                  </div>
                  <button type="submit" disabled={savingCohort} style={btnStyle}>
                    {savingCohort ? "..." : t("add")}
                  </button>
                </form>
                {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
              </Card>
            </div>
          )}

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("cohorts")}</div>
            {cohorts.length === 0 ? (
              <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noCohorts")}</div>
            ) : (
              <Table
                headers={[t("code"), t("courseName"), t("capacity"), ""]}
                rows={cohorts.map((ch) => [
                  <span key={ch.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{ch.code}</span>,
                  courseName(ch.course_id),
                  String(ch.capacity),
                  <Link key={ch.id + "l"} href={`/training/cohorts/${ch.id}`} style={{ color: "var(--brand)", fontSize: 13, fontWeight: 500, textDecoration: "none" }}>
                    {t("manageCohort")} →
                  </Link>,
                ])}
              />
            )}
          </Card>

          {finance.length > 0 && (
            <div style={{ marginTop: "1.25rem" }}>
              <Card>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("cohortFinanceTitle")}</div>
                <Table
                  headers={[t("code"), t("courseName"), t("enrolledCol"), t("totalFeesK"), t("collectedK"), t("outstandingK"), t("attendanceRateCol")]}
                  rows={finance.map((r) => [
                    <span key={r.cohort_id} style={{ fontFamily: "monospace", fontSize: 12 }}>{r.cohort_code}</span>,
                    r.course_title,
                    `${r.enrolled} / ${r.capacity}`,
                    `${fmt(r.total_fees)} ${t("egp")}`,
                    <span key={r.cohort_id + "c"} style={{ color: "#1a7d3c", fontWeight: 600 }}>{fmt(r.collected)} {t("egp")}</span>,
                    <span key={r.cohort_id + "o"} style={{ color: r.outstanding > 0 ? "#c0392b" : "var(--text)", fontWeight: 600 }}>{fmt(r.outstanding)} {t("egp")}</span>,
                    `${r.attendance_rate_pct}%`,
                  ])}
                />
              </Card>
            </div>
          )}
        </>
      )}

      <EditDialog
        open={!!editCourse}
        title={t("edit") + " — " + t("courseName")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveCourse}
        onCancel={() => setEditCourse(null)}
        error={dialogError}
      >
        <Field label={t("courseName")}>
          <input value={eTitle} onChange={(e) => setETitle(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("category")}>
          <CategorySelect kind="course" value={eCategory} onChange={setECategory} />
        </Field>
        <Field label={t("price")}>
          <input type="number" value={ePrice} onChange={(e) => setEPrice(e.target.value)} style={dialogInput} />
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!deleteCourseId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteCourse}
        onCancel={() => setDeleteCourseId(null)}
      />
      </>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const tabActive: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 10, padding: "9px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer" };
const tabInactive: React.CSSProperties = { background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 10, padding: "9px 20px", fontSize: 14, fontWeight: 500, cursor: "pointer" };
