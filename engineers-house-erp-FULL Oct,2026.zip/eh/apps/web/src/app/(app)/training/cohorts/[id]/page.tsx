"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";
import { Cohort, Enrollment, Student, Installment, Page, CohortPnlData, CohortCostRow } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Loading, ErrorBox, fmt } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function CohortDetailPage() {
  const { t, dir } = useLang();
  const params = useParams();
  const cohortId = params.id as string;

  const [cohort, setCohort] = useState<Cohort | null>(null);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [studentId, setStudentId] = useState("");
  const [fee, setFee] = useState("");
  const [downPayment, setDownPayment] = useState("");
  const [installmentCount, setInstallmentCount] = useState("1");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [newStudentName, setNewStudentName] = useState("");
  const [addingStudent, setAddingStudent] = useState(false);

  const [installments, setInstallments] = useState<Record<string, Installment[]>>({});
  const [expanded, setExpanded] = useState<string | null>(null);

  const statusLabel: Record<string, string> = {
    active: t("statusEnrolled"),
    waitlisted: t("statusWaitlisted"),
    completed: t("statusCompleted"),
    withdrawn: t("statusCancelled"),
  };

  async function load() {
    setLoading(true);
    try {
      const [enr, std, cohorts] = await Promise.all([
        api.get<Page<Enrollment>>(`/api/v1/training/cohorts/${cohortId}/enrollments`),
        api.get<Page<Student>>("/api/v1/training/students?size=100"),
        api.get<Page<Cohort>>("/api/v1/training/cohorts?size=100"),
      ]);
      setEnrollments(enr.items);
      setStudents(std.items);
      setCohort(cohorts.items.find((c) => c.id === cohortId) || null);
      if (std.items.length && !studentId) setStudentId(std.items[0].id);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cohortId]);

  async function createStudent(e: React.FormEvent) {
    e.preventDefault();
    if (!newStudentName.trim()) return;
    setAddingStudent(true);
    try {
      const s = await api.post<Student>("/api/v1/training/students", {
        full_name: newStudentName,
      });
      setNewStudentName("");
      await load();
      setStudentId(s.id);
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setAddingStudent(false);
    }
  }

  async function enroll(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSaving(true);
    try {
      await api.post("/api/v1/training/enrollments", {
        student_id: studentId,
        cohort_id: cohortId,
        total_fee: Number(fee) || 0,
        down_payment: Number(downPayment) || 0,
        installment_count: Number(installmentCount) || 1,
      });
      setFee("");
      setDownPayment("");
      setInstallmentCount("1");
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSaving(false);
    }
  }

  async function act(enrollmentId: string, action: "withdraw" | "complete") {
    try {
      await api.post(`/api/v1/training/enrollments/${enrollmentId}/${action}`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function refreshInstallments(enrollmentId: string) {
    const inst = await api.get<Installment[]>(
      `/api/v1/training/enrollments/${enrollmentId}/installments`,
    );
    setInstallments((prev) => ({ ...prev, [enrollmentId]: inst }));
  }

  async function payInstallment(enrollmentId: string, installmentId: string, paid: boolean) {
    try {
      const action = paid ? "unpay" : "pay";
      await api.post(`/api/v1/training/installments/${installmentId}/${action}`);
      await refreshInstallments(enrollmentId);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function deleteInstallment(enrollmentId: string, installmentId: string) {
    try {
      await api.del(`/api/v1/training/installments/${installmentId}`);
      await refreshInstallments(enrollmentId);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function deleteEnrollment(enrollmentId: string) {
    try {
      await api.del(`/api/v1/training/enrollments/${enrollmentId}`);
      setExpanded(null);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function toggleInstallments(enrollmentId: string) {
    if (expanded === enrollmentId) {
      setExpanded(null);
      return;
    }
    setExpanded(enrollmentId);
    try {
      const inst = await api.get<Installment[]>(
        `/api/v1/training/enrollments/${enrollmentId}/installments`,
      );
      setInstallments((prev) => ({ ...prev, [enrollmentId]: inst }));
    } catch {
      // ignore
    }
  }

  const studentName = (id: string) =>
    students.find((s) => s.id === id)?.full_name || "—";

  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <Link href="/training" style={{ color: "var(--brand)", fontSize: 13, textDecoration: "none" }}>
          ← {t("navTraining")}
        </Link>
      </div>
      <PageTitle>
        {t("cohort")}: {cohort?.code || ""}
      </PageTitle>

      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && (
        <>
          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("student")} — {t("add")}</div>
              <form onSubmit={createStudent} style={{ display: "flex", gap: 10, alignItems: "end" }}>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>{t("name")}</label>
                  <input value={newStudentName} onChange={(e) => setNewStudentName(e.target.value)} style={inputStyle} placeholder={t("name")} />
                </div>
                <button type="submit" disabled={addingStudent} style={btnStyle}>
                  {addingStudent ? "..." : t("add")}
                </button>
              </form>
            </Card>
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("enrollStudent")}</div>
              {students.length === 0 ? (
                <div style={{ color: "var(--text-muted)", fontSize: 14 }}>
                  {t("selectStudent")} — {t("noEnrollments")}
                </div>
              ) : (
                <form
                  onSubmit={enroll}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1.6fr 1fr 1fr 0.8fr auto",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <label style={labelStyle}>{t("student")}</label>
                    <select value={studentId} onChange={(e) => setStudentId(e.target.value)} style={inputStyle}>
                      {students.map((s) => (
                        <option key={s.id} value={s.id}>{s.full_name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>{t("fee")}</label>
                    <input type="number" value={fee} onChange={(e) => setFee(e.target.value)} required style={inputStyle} placeholder="2000" />
                  </div>
                  <div>
                    <label style={labelStyle}>{t("downPayment")}</label>
                    <input type="number" value={downPayment} onChange={(e) => setDownPayment(e.target.value)} style={inputStyle} placeholder="500" />
                  </div>
                  <div>
                    <label style={labelStyle}>{t("installmentsCount")}</label>
                    <input type="number" min="1" max="12" value={installmentCount} onChange={(e) => setInstallmentCount(e.target.value)} style={inputStyle} />
                  </div>
                  <button type="submit" disabled={saving} style={btnStyle}>
                    {saving ? "..." : t("enrollStudent")}
                  </button>
                </form>
              )}
              {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
            </Card>
          </div>

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("enrollments")}</div>
            {enrollments.length === 0 ? (
              <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noEnrollments")}</div>
            ) : (
              <Table
                headers={[t("student"), t("status"), t("waitlistPosition"), t("fee"), ""]}
                rows={enrollments.map((en) => [
                  studentName(en.student_id),
                  <Badge key={en.id + "s"} text={statusLabel[en.status] || en.status} kind={en.status} />,
                  en.waitlist_position ? `#${en.waitlist_position}` : "—",
                  `${fmt(en.total_fee)} ${t("egp")}`,
                  <div key={en.id + "a"} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button onClick={() => toggleInstallments(en.id)} style={linkBtn}>
                      {t("installments")}
                    </button>
                    {en.status === "active" && (
                      <button onClick={() => act(en.id, "complete")} style={linkBtn}>
                        {t("complete")}
                      </button>
                    )}
                    {(en.status === "active" || en.status === "waitlisted") && (
                      <button onClick={() => act(en.id, "withdraw")} style={{ ...linkBtn, color: "#a32d2d" }}>
                        {t("withdraw")}
                      </button>
                    )}
                    <button
                      onClick={() => { if (confirm(t("confirmDeleteEnrollment"))) deleteEnrollment(en.id); }}
                      style={{ ...linkBtn, color: "#c0392b" }}
                      title={t("deleteEnrollment")}
                    >
                      🗑
                    </button>
                  </div>,
                ])}
              />
            )}

            {expanded && (
              <div
                style={{
                  marginTop: 16,
                  padding: 16,
                  background: "var(--bg)",
                  borderRadius: 10,
                  border: "1px solid var(--border)",
                }}
              >
                <div style={{ fontWeight: 500, marginBottom: 10 }}>
                  {t("installments")} — {studentName(enrollments.find((e) => e.id === expanded)?.student_id || "")}
                </div>
                {(installments[expanded] || []).length === 0 ? (
                  <div style={{ fontSize: 13, color: "var(--text-muted)" }}>—</div>
                ) : (
                  <Table
                    headers={["#", t("amount"), t("date"), t("status"), ""]}
                    rows={(installments[expanded] || []).map((ins) => [
                      String(ins.sequence),
                      `${fmt(ins.amount)} ${t("egp")}`,
                      ins.due_date,
                      <Badge key={ins.id} text={ins.status === "paid" ? t("paidStatus") : ins.status === "overdue" ? t("overdueStatus") : t("pendingStatus")} kind={ins.status === "paid" ? "completed" : ins.status === "overdue" ? "waitlisted" : "lead"} />,
                      <div key={ins.id + "a"} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <button
                          onClick={() => payInstallment(expanded, ins.id, ins.status === "paid")}
                          style={{ ...linkBtn, color: ins.status === "paid" ? "#a32d2d" : "#1a7d3c" }}
                        >
                          {ins.status === "paid" ? t("markUnpaid") : t("collectInstallment")}
                        </button>
                        <button
                          onClick={() => { if (confirm(t("confirmDeleteInstallment"))) deleteInstallment(expanded, ins.id); }}
                          style={{ ...linkBtn, color: "#c0392b" }}
                          title={t("deleteInstallment")}
                        >
                          🗑
                        </button>
                      </div>,
                    ])}
                  />
                )}
              </div>
            )}
          </Card>

          <div style={{ marginTop: "1.25rem" }}>
            <CohortPnlPanel cohortId={cohortId} />
          </div>
        </>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const linkBtn: React.CSSProperties = { background: "transparent", color: "var(--brand)", border: "none", fontSize: 13, fontWeight: 500, padding: 0 };

/* ---------- Cohort P&L + manual costs ---------- */
function CohortPnlPanel({ cohortId }: { cohortId: string }) {
  const { t } = useLang();
  const [pnl, setPnl] = useState<CohortPnlData | null>(null);
  const [costs, setCosts] = useState<CohortCostRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [ct, setCt] = useState("hall");
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");

  const ctLabel: Record<string, string> = {
    hall: t("ctHall"), materials: t("ctMaterials"), marketing: t("ctMarketing"), other: t("ctOther"),
  };

  async function load() {
    try {
      const [p, c] = await Promise.all([
        api.get<CohortPnlData>(`/api/v1/training/cohorts/${cohortId}/pnl`),
        api.get<CohortCostRow[]>(`/api/v1/training/cohorts/${cohortId}/costs`),
      ]);
      setPnl(p);
      setCosts(c);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [cohortId]);

  async function addCost(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.post(`/api/v1/training/cohorts/${cohortId}/costs`, {
        cost_type: ct, amount: Number(amount) || 0, description: desc || null,
      });
      setAmount(""); setDesc("");
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  async function delCost(id: string) {
    try { await api.del(`/api/v1/training/costs/${id}`); await load(); }
    catch (e) { setError(e instanceof Error ? e.message : "Error"); }
  }

  if (!pnl) return null;

  return (
    <Card>
      <div style={{ fontWeight: 600, marginBottom: 14, fontSize: 16 }}>{t("pnlTitle")}</div>
      {error && <ErrorBox message={error} />}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12, marginBottom: 18 }}>
        <PnlBox label={t("pnlRevenue")} value={pnl.revenue} color="#2563eb" />
        <PnlBox label={`${t("instructorShare")}${pnl.instructor_name ? ` (${pnl.instructor_name} · ${pnl.instructor_share_pct}%)` : ""}`} value={pnl.instructor_share} color="#a855f7" />
        <PnlBox label={t("manualCosts")} value={pnl.manual_costs} color="#e67e22" />
        <PnlBox label={t("totalCostsK")} value={pnl.total_costs} color="#dc2626" />
        <PnlBox label={`${t("cohortProfit")} (${pnl.margin_pct}%)`} value={pnl.profit} color={pnl.profit >= 0 ? "#16a34a" : "#dc2626"} big />
      </div>

      <form onSubmit={addCost} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1.6fr auto", gap: 10, alignItems: "end", marginBottom: 14 }}>
        <div>
          <label style={labelStyle}>{t("costType")}</label>
          <select value={ct} onChange={(e) => setCt(e.target.value)} style={baseInput}>
            {["hall", "materials", "marketing", "other"].map((k) => <option key={k} value={k}>{ctLabel[k]}</option>)}
          </select>
        </div>
        <div><label style={labelStyle}>{t("amount")}</label><input type="number" min="1" value={amount} onChange={(e) => setAmount(e.target.value)} required style={baseInput} /></div>
        <div><label style={labelStyle}>{t("description")}</label><input value={desc} onChange={(e) => setDesc(e.target.value)} style={baseInput} /></div>
        <button type="submit" style={btnStyle}>+ {t("addCost")}</button>
      </form>

      {costs.length === 0 ? (
        <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{t("noCosts")}</div>
      ) : (
        <Table
          headers={[t("costType"), t("description"), t("amount"), ""]}
          rows={costs.map((c) => [
            <Badge key={c.id} text={ctLabel[c.cost_type] || c.cost_type} kind="lead" />,
            c.description || "—",
            `${fmt(c.amount)} ${t("egp")}`,
            <button key={c.id + "d"} onClick={() => delCost(c.id)} style={{ ...linkBtn, color: "#c0392b" }}>✕</button>,
          ])}
        />
      )}
    </Card>
  );
}

function PnlBox({ label, value, color, big }: { label: string; value: number; color: string; big?: boolean }) {
  const { t } = useLang();
  return (
    <div style={{ padding: "12px 14px", background: "var(--bg)", borderRadius: 10, border: "1px solid var(--border)" }}>
      <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: big ? 22 : 18, fontWeight: 800, color }}>{fmt(value)} <span style={{ fontSize: 11, fontWeight: 500, color: "var(--text-muted)" }}>{t("egp")}</span></div>
    </div>
  );
}
