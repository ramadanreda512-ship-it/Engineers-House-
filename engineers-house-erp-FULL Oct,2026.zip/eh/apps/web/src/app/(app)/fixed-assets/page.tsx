"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { FixedAsset, AssetSummaryData } from "@/lib/types";
import { PageTitle, Card, Metric, Table, Badge, Loading, ErrorBox, fmt, ConfirmDialog } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function FixedAssetsPage() {
  const { t, dir } = useLang();
  const [assets, setAssets] = useState<FixedAsset[]>([]);
  const [summary, setSummary] = useState<AssetSummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [depreciateId, setDepreciateId] = useState<string | null>(null);
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: dir === "rtl" ? "right" : "left" };

  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({ name: "", category: "computer", purchase_date: today, purchase_value: "", salvage_value: "", useful_life_months: "60" });
  const [formError, setFormError] = useState<string | null>(null);

  const catLabel: Record<string, string> = {
    computer: t("catComputer"), plc_equipment: t("catPlc"), instrument: t("catInstrument"),
    training_kit: t("catTrainingKit"), vehicle: t("catVehicle"), office_furniture: t("catFurniture"),
    building: t("catBuilding"), other: t("catOther"),
  };

  async function load() {
    setLoading(true);
    try {
      const [as, sm] = await Promise.all([
        api.get<FixedAsset[]>("/api/v1/fixed-assets"),
        api.get<AssetSummaryData>("/api/v1/fixed-assets/summary"),
      ]);
      setAssets(as);
      setSummary(sm);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  async function addAsset(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    try {
      await api.post("/api/v1/fixed-assets", {
        name: form.name, category: form.category, purchase_date: form.purchase_date,
        purchase_value: Number(form.purchase_value) || 0, salvage_value: Number(form.salvage_value) || 0,
        useful_life_months: Number(form.useful_life_months) || 60,
      });
      setForm({ name: "", category: "computer", purchase_date: today, purchase_value: "", salvage_value: "", useful_life_months: "60" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDepreciate() {
    if (!depreciateId) return;
    try {
      await api.post(`/api/v1/fixed-assets/${depreciateId}/depreciate`, {});
      setDepreciateId(null);
      await load();
    } catch (e) {
      setDepreciateId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  if (loading) return <Loading text={t("loadingData")} />;

  return (
    <div>
      <PageTitle>{t("fixedAssetsTitle")}</PageTitle>
      {error && <ErrorBox message={error} />}

      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.25rem" }}>
          <Metric label={t("assetsCount")} value={String(summary.total_assets)} />
          <Metric label={t("totalPurchaseValue")} value={`${fmt(summary.total_purchase_value)} ${t("egp")}`} />
          <Metric label={t("totalDepreciation")} value={`${fmt(summary.total_accumulated_depreciation)} ${t("egp")}`} />
          <Metric label={t("totalBookValue")} value={`${fmt(summary.total_book_value)} ${t("egp")}`} />
        </div>
      )}

      <div style={{ marginBottom: "1.25rem" }}>
        <Card>
          <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newAsset")}</div>
          <form onSubmit={addAsset} style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr 1fr 1fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
            <div><label style={labelStyle}>{t("assetName")}</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("category")}</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} style={inputStyle}>
                {Object.entries(catLabel).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div><label style={labelStyle}>{t("purchaseDate")}</label><input type="date" value={form.purchase_date} onChange={(e) => setForm({ ...form, purchase_date: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("purchaseValue")}</label><input type="number" value={form.purchase_value} onChange={(e) => setForm({ ...form, purchase_value: e.target.value })} required style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("salvageValue")}</label><input type="number" value={form.salvage_value} onChange={(e) => setForm({ ...form, salvage_value: e.target.value })} style={inputStyle} /></div>
            <div><label style={labelStyle}>{t("usefulLife")}</label><input type="number" value={form.useful_life_months} onChange={(e) => setForm({ ...form, useful_life_months: e.target.value })} style={inputStyle} /></div>
            <button type="submit" style={btnStyle}>{t("add")}</button>
          </form>
          {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
        </Card>
      </div>

      <Card>
        <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("fixedAssetsTitle")}</div>
        {assets.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noAssets")}</div> : (
          <Table
            headers={[t("accountCode"), t("assetName"), t("category"), t("purchaseValue"), t("monthlyDepreciation"), t("bookValue"), ""]}
            rows={assets.map((a) => [
              <span key={a.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{a.code}</span>,
              a.name,
              <Badge key={a.id + "c"} text={catLabel[a.category] || a.category} kind="lead" />,
              `${fmt(a.purchase_value)} ${t("egp")}`,
              `${fmt(a.monthly_depreciation)} ${t("egp")}`,
              <span key={a.id + "b"} style={{ fontWeight: 600 }}>{fmt(a.current_value)} {t("egp")}</span>,
              a.is_fully_depreciated
                ? <Badge key={a.id + "f"} text={t("fullyDepreciated")} kind="completed" />
                : <button key={a.id + "d"} onClick={() => setDepreciateId(a.id)} style={miniBtn}>{t("runDepreciation")}</button>,
            ])}
          />
        )}
      </Card>

      <ConfirmDialog
        open={!!depreciateId}
        title={t("runDepreciation")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("runDepreciation")}
        cancelLabel={t("cancel")}
        onConfirm={confirmDepreciate}
        onCancel={() => setDepreciateId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13, fontWeight: 500, whiteSpace: "nowrap" };
const miniBtn: React.CSSProperties = { background: "transparent", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 10px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
