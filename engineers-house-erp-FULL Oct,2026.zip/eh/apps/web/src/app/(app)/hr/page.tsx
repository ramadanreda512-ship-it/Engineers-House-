"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Employee, LeaveRequest, HrSummary, Page } from "@/lib/types";
import { PageTitle, Card, Table, Badge, Metric, Loading, ErrorBox, fmt, RowActions, ConfirmDialog, EditDialog, Field, dialogInput } from "@/components/ui";
import { useLang } from "@/lib/i18n";

export default function HrPage() {
  const { t, dir } = useLang();
  const [summary, setSummary] = useState<HrSummary | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [empForm, setEmpForm] = useState({ code: "", full_name: "", department: "", base_salary: "" });
  const [leaveForm, setLeaveForm] = useState({ employee_id: "", leave_type: "annual", start_date: "", end_date: "" });
  const [savingEmp, setSavingEmp] = useState(false);
  const [savingLeave, setSavingLeave] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // edit/delete employee
  const [editEmp, setEditEmp] = useState<Employee | null>(null);
  const [eName, setEName] = useState("");
  const [eDept, setEDept] = useState("");
  const [eSalary, setESalary] = useState("");
  const [eStatus, setEStatus] = useState("active");
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [deleteEmpId, setDeleteEmpId] = useState<string | null>(null);

  const leaveStatus: Record<string, string> = {
    pending: t("statusPending"),
    approved: t("statusApproved"),
    rejected: t("statusRejected"),
  };
  const leaveStatusKind: Record<string, string> = {
    pending: "waitlisted", approved: "completed", rejected: "withdrawn",
  };
  const leaveTypeLabel: Record<string, string> = {
    annual: t("leaveAnnual"), sick: t("leaveSick"), unpaid: t("leaveUnpaid"),
  };

  async function load() {
    setLoading(true);
    try {
      const [sum, emp, lv] = await Promise.all([
        api.get<HrSummary>("/api/v1/hr/summary"),
        api.get<Page<Employee>>("/api/v1/hr/employees?size=100"),
        api.get<Page<LeaveRequest>>("/api/v1/hr/leaves?size=100"),
      ]);
      setSummary(sum);
      setEmployees(emp.items);
      setLeaves(lv.items);
      if (emp.items.length && !leaveForm.employee_id) setLeaveForm((f) => ({ ...f, employee_id: emp.items[0].id }));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addEmployee(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingEmp(true);
    try {
      await api.post("/api/v1/hr/employees", {
        code: empForm.code,
        full_name: empForm.full_name,
        department: empForm.department || null,
        base_salary: Number(empForm.base_salary) || 0,
      });
      setEmpForm({ code: "", full_name: "", department: "", base_salary: "" });
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSavingEmp(false);
    }
  }

  async function addLeave(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSavingLeave(true);
    try {
      await api.post("/api/v1/hr/leaves", {
        employee_id: leaveForm.employee_id,
        leave_type: leaveForm.leave_type,
        start_date: leaveForm.start_date,
        end_date: leaveForm.end_date,
      });
      setLeaveForm((f) => ({ ...f, start_date: "", end_date: "" }));
      await load();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Error");
    } finally {
      setSavingLeave(false);
    }
  }

  async function decideLeave(leaveId: string, action: "approve" | "reject") {
    try {
      await api.post(`/api/v1/hr/leaves/${leaveId}/${action}`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  const empName = (id: string) => employees.find((e) => e.id === id)?.full_name || "—";

  function openEditEmp(emp: Employee) {
    setEditEmp(emp);
    setEName(emp.full_name);
    setEDept(emp.department || "");
    setESalary(String(emp.base_salary));
    setEStatus(emp.status);
    setDialogError(null);
  }

  async function saveEmp() {
    if (!editEmp) return;
    setDialogError(null);
    try {
      await api.patch(`/api/v1/hr/employees/${editEmp.id}`, {
        full_name: eName,
        department: eDept || null,
        base_salary: Number(eSalary) || 0,
        status: eStatus,
      });
      setEditEmp(null);
      await load();
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : "Error");
    }
  }

  async function confirmDeleteEmp() {
    if (!deleteEmpId) return;
    try {
      await api.del(`/api/v1/hr/employees/${deleteEmpId}`);
      setDeleteEmpId(null);
      await load();
    } catch (e) {
      setDeleteEmpId(null);
      setError(e instanceof Error ? e.message : "Error");
    }
  }
  const align = dir === "rtl" ? "right" : "left";
  const inputStyle: React.CSSProperties = { ...baseInput, textAlign: align };

  return (
    <div>
      <PageTitle>{t("hrTitle")}</PageTitle>
      {loading && <Loading text={t("loadingData")} />}
      {error && <ErrorBox message={error} />}

      {!loading && !error && summary && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: "1.5rem" }}>
            <Metric label={t("totalEmployees")} value={fmt(summary.total_employees)} />
            <Metric label={t("activeEmployees")} value={fmt(summary.active_employees)} />
            <Metric label={t("pendingLeaves")} value={fmt(summary.pending_leave_requests)} />
            <Metric label={t("monthlyPayroll")} value={fmt(summary.total_monthly_payroll)} sub={t("egp")} />
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("newEmployee")}</div>
              <form onSubmit={addEmployee} style={{ display: "grid", gridTemplateColumns: "0.8fr 1.5fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
                <div><label style={labelStyle}>{t("employeeCode")}</label><input value={empForm.code} onChange={(e) => setEmpForm({ ...empForm, code: e.target.value })} required style={inputStyle} placeholder="EMP-001" /></div>
                <div><label style={labelStyle}>{t("employeeName")}</label><input value={empForm.full_name} onChange={(e) => setEmpForm({ ...empForm, full_name: e.target.value })} required style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("department")}</label><input value={empForm.department} onChange={(e) => setEmpForm({ ...empForm, department: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>{t("baseSalary")}</label><input type="number" value={empForm.base_salary} onChange={(e) => setEmpForm({ ...empForm, base_salary: e.target.value })} style={inputStyle} /></div>
                <button type="submit" disabled={savingEmp} style={btnStyle}>{savingEmp ? "..." : t("add")}</button>
              </form>
            </Card>
          </div>

          <div style={{ marginBottom: "1.25rem" }}>
            <Card>
              <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("employees")}</div>
              {employees.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noEmployees")}</div> : (
                <Table
                  headers={[t("employeeCode"), t("employeeName"), t("department"), t("baseSalary"), t("leaveBalance"), ""]}
                  rows={employees.map((emp) => [
                    <span key={emp.id} style={{ fontFamily: "monospace", fontSize: 12 }}>{emp.code}</span>,
                    emp.full_name,
                    <span key={emp.id + "d"} style={{ color: "var(--text-muted)" }}>{emp.department || "—"}</span>,
                    `${fmt(emp.base_salary)} ${t("egp")}`,
                    `${emp.annual_leave_balance} ${t("days")}`,
                    <RowActions key={emp.id + "act"} editLabel={t("edit")} deleteLabel={t("delete")} onEdit={() => openEditEmp(emp)} onDelete={() => setDeleteEmpId(emp.id)} />,
                  ])}
                />
              )}
            </Card>
          </div>

          {/* Leave requests */}
          {employees.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <Card>
                <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("requestLeave")}</div>
                <form onSubmit={addLeave} style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
                  <div><label style={labelStyle}>{t("employee")}</label>
                    <select value={leaveForm.employee_id} onChange={(e) => setLeaveForm({ ...leaveForm, employee_id: e.target.value })} style={inputStyle}>
                      {employees.map((emp) => <option key={emp.id} value={emp.id}>{emp.full_name}</option>)}
                    </select>
                  </div>
                  <div><label style={labelStyle}>{t("leaveType")}</label>
                    <select value={leaveForm.leave_type} onChange={(e) => setLeaveForm({ ...leaveForm, leave_type: e.target.value })} style={inputStyle}>
                      <option value="annual">{t("leaveAnnual")}</option>
                      <option value="sick">{t("leaveSick")}</option>
                      <option value="unpaid">{t("leaveUnpaid")}</option>
                    </select>
                  </div>
                  <div><label style={labelStyle}>{t("startDate")}</label><input type="date" value={leaveForm.start_date} onChange={(e) => setLeaveForm({ ...leaveForm, start_date: e.target.value })} required style={inputStyle} /></div>
                  <div><label style={labelStyle}>{t("endDate")}</label><input type="date" value={leaveForm.end_date} onChange={(e) => setLeaveForm({ ...leaveForm, end_date: e.target.value })} required style={inputStyle} /></div>
                  <button type="submit" disabled={savingLeave} style={btnStyle}>{savingLeave ? "..." : t("add")}</button>
                </form>
                {formError && <div style={{ marginTop: 10 }}><ErrorBox message={formError} /></div>}
              </Card>
            </div>
          )}

          <Card>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>{t("leaves")}</div>
            {leaves.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: 14 }}>{t("noLeaves")}</div> : (
              <Table
                headers={[t("employee"), t("leaveType"), t("startDate"), t("days"), t("status"), ""]}
                rows={leaves.map((lv) => [
                  empName(lv.employee_id),
                  <span key={lv.id + "t"} style={{ color: "var(--text-muted)" }}>{leaveTypeLabel[lv.leave_type] || lv.leave_type}</span>,
                  lv.start_date,
                  String(lv.days),
                  <Badge key={lv.id + "s"} text={leaveStatus[lv.status] || lv.status} kind={leaveStatusKind[lv.status] || "lead"} />,
                  lv.status === "pending" ? (
                    <div key={lv.id + "a"} style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => decideLeave(lv.id, "approve")} style={linkBtn}>{t("approve")}</button>
                      <button onClick={() => decideLeave(lv.id, "reject")} style={{ ...linkBtn, color: "#a32d2d" }}>{t("reject")}</button>
                    </div>
                  ) : "—",
                ])}
              />
            )}
          </Card>
        </>
      )}

      <EditDialog
        open={!!editEmp}
        title={t("edit") + " — " + t("employee")}
        saveLabel={t("save")}
        cancelLabel={t("cancel")}
        onSave={saveEmp}
        onCancel={() => setEditEmp(null)}
        error={dialogError}
      >
        <Field label={t("employeeName")}>
          <input value={eName} onChange={(e) => setEName(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("department")}>
          <input value={eDept} onChange={(e) => setEDept(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("baseSalary")}>
          <input type="number" value={eSalary} onChange={(e) => setESalary(e.target.value)} style={dialogInput} />
        </Field>
        <Field label={t("status")}>
          <select value={eStatus} onChange={(e) => setEStatus(e.target.value)} style={dialogInput}>
            <option value="active">{t("statusEnrolled")}</option>
            <option value="on_leave">{t("leaves")}</option>
            <option value="terminated">{t("statusRejected")}</option>
          </select>
        </Field>
      </EditDialog>

      <ConfirmDialog
        open={!!deleteEmpId}
        title={t("confirmDelete")}
        message={t("confirmDeleteMsg")}
        confirmLabel={t("delete")}
        cancelLabel={t("cancel")}
        danger
        onConfirm={confirmDeleteEmp}
        onCancel={() => setDeleteEmpId(null)}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = { fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 };
const baseInput: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)" };
const btnStyle: React.CSSProperties = { background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 18px", fontSize: 14, fontWeight: 500, whiteSpace: "nowrap" };
const linkBtn: React.CSSProperties = { background: "transparent", color: "var(--brand)", border: "none", fontSize: 13, fontWeight: 500, padding: 0 };
