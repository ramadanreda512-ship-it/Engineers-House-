"use client";

import { useState } from "react";
import { usePathname } from "next/navigation";
import { api } from "@/lib/api";
import { useLang } from "@/lib/i18n";
import { HELP_CONTENT, helpKeyForPath } from "@/lib/helpContent";

interface ChatMsg {
  role: "user" | "assistant";
  text: string;
}

export default function HelpPanel() {
  const { t, lang } = useLang();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"guide" | "ask">("guide");

  const key = helpKeyForPath(pathname);
  const content = HELP_CONTENT[key];
  const L = (o: { ar: string; en: string }) => (lang === "ar" ? o.ar : o.en);

  return (
    <>
      {/* Floating help button */}
      <button
        onClick={() => setOpen(true)}
        title={t("helpButton")}
        style={{
          width: 34, height: 34, borderRadius: "50%", border: "1px solid var(--border)",
          background: "var(--surface)", color: "var(--brand)", cursor: "pointer",
          fontSize: 17, fontWeight: 700, marginInlineEnd: 12, lineHeight: 1,
        }}
      >
        ?
      </button>

      {!open ? null : (
        <div
          onClick={() => setOpen(false)}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)", zIndex: 60 }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            dir={lang === "ar" ? "rtl" : "ltr"}
            style={{
              position: "fixed", insetInlineEnd: 0, top: 0, height: "100vh",
              width: "min(440px, 100%)", background: "var(--bg)", boxShadow: "-8px 0 30px rgba(0,0,0,0.2)",
              display: "flex", flexDirection: "column", zIndex: 61,
            }}
          >
            {/* Header */}
            <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", background: "var(--surface)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontWeight: 700, fontSize: 16 }}>💡 {content ? L(content.title) : t("helpButton")}</div>
              <button onClick={() => setOpen(false)} style={{ background: "transparent", border: "none", fontSize: 22, cursor: "pointer", color: "var(--text-muted)" }}>✕</button>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", gap: 8, padding: "12px 20px", borderBottom: "1px solid var(--border)" }}>
              <button onClick={() => setTab("guide")} style={tab === "guide" ? tabActive : tabInactive}>📖 {t("helpGuideTab")}</button>
              <button onClick={() => setTab("ask")} style={tab === "ask" ? tabActive : tabInactive}>💬 {t("helpAskTab")}</button>
            </div>

            {/* Body */}
            <div style={{ flex: 1, overflowY: "auto", padding: "18px 20px" }}>
              {tab === "guide" && content && (
                <div>
                  <Section title={t("helpPurpose")}>
                    <p style={{ margin: 0, lineHeight: 1.8, fontSize: 14 }}>{L(content.purpose)}</p>
                  </Section>
                  <Section title={t("helpSteps")}>
                    <ol style={{ margin: 0, paddingInlineStart: 20, lineHeight: 2, fontSize: 14 }}>
                      {content.steps.map((s, i) => <li key={i}>{L(s)}</li>)}
                    </ol>
                  </Section>
                  <Section title={`💎 ${t("helpTips")}`}>
                    <ul style={{ margin: 0, paddingInlineStart: 20, lineHeight: 2, fontSize: 14 }}>
                      {content.tips.map((s, i) => <li key={i}>{L(s)}</li>)}
                    </ul>
                  </Section>
                </div>
              )}

              {tab === "ask" && <AskAssistant moduleKey={key} />}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ fontWeight: 700, fontSize: 13, color: "var(--brand)", marginBottom: 8 }}>{title}</div>
      {children}
    </div>
  );
}

function AskAssistant({ moduleKey }: { moduleKey: string }) {
  const { t } = useLang();
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiOff, setAiOff] = useState(false);

  async function send() {
    const q = input.trim();
    if (!q || loading) return;
    setMsgs((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setLoading(true);
    try {
      const res = await api.post<{ answer: string; ai_enabled: boolean }>(
        "/api/v1/help/ask",
        { module: moduleKey, question: q },
      );
      setMsgs((m) => [...m, { role: "assistant", text: res.answer }]);
      if (!res.ai_enabled) setAiOff(true);
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", text: e instanceof Error ? e.message : "Error" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {msgs.length === 0 && (
        <div style={{ fontSize: 13.5, color: "var(--text-muted)", lineHeight: 1.8, marginBottom: 14 }}>
          {t("helpAskHint")}
        </div>
      )}
      {aiOff && (
        <div style={{ background: "#fef3c7", color: "#92400e", padding: "10px 12px", borderRadius: 8, fontSize: 12.5, marginBottom: 12 }}>
          {t("helpAiOffNote")}
        </div>
      )}

      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10, marginBottom: 12 }}>
        {msgs.map((m, i) => (
          <div
            key={i}
            style={{
              alignSelf: m.role === "user" ? "flex-start" : "stretch",
              maxWidth: m.role === "user" ? "85%" : "100%",
              background: m.role === "user" ? "var(--brand)" : "var(--surface)",
              color: m.role === "user" ? "#fff" : "var(--text)",
              border: m.role === "assistant" ? "1px solid var(--border)" : "none",
              padding: "10px 13px", borderRadius: 12, fontSize: 13.5, lineHeight: 1.8,
              whiteSpace: "pre-wrap",
            }}
          >
            {m.text}
          </div>
        ))}
        {loading && <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{t("helpThinking")}</div>}
      </div>

      <div style={{ display: "flex", gap: 8, borderTop: "1px solid var(--border)", paddingTop: 12 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") send(); }}
          placeholder={t("helpAskPlaceholder")}
          style={{ flex: 1, padding: "9px 12px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13.5, background: "var(--surface)" }}
        />
        <button onClick={send} disabled={loading} style={{ background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 16px", fontSize: 13.5, fontWeight: 600, cursor: "pointer" }}>
          {t("helpSend")}
        </button>
      </div>
    </div>
  );
}

const tabActive: React.CSSProperties = { flex: 1, background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "8px", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const tabInactive: React.CSSProperties = { flex: 1, background: "var(--surface)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: "8px", fontSize: 13, cursor: "pointer" };
