"use client";

import React from "react";

export function PageTitle({ children }: { children: React.ReactNode }) {
  return (
    <h1 style={{ fontSize: 22, fontWeight: 700, margin: "0 0 1.25rem" }}>
      {children}
    </h1>
  );
}

export function Card({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 14,
        padding: "1rem 1.25rem",
      }}
    >
      {children}
    </div>
  );
}

export function Metric({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 10,
        padding: "1rem",
      }}
    >
      <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 6 }}>
        {label}
      </div>
      <div style={{ fontSize: 24, fontWeight: 700 }}>{value}</div>
      {sub && (
        <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 4 }}>
          {sub}
        </div>
      )}
    </div>
  );
}

export function Badge({ text, kind }: { text: string; kind?: string }) {
  const map: Record<string, [string, string]> = {
    lead: ["#e6f1fb", "#0c447c"],
    customer: ["#e1f5ee", "#0f6e56"],
    supplier: ["#f1efe8", "#444441"],
    active: ["#e1f5ee", "#0f6e56"],
    waitlisted: ["#faeeda", "#854f0b"],
    completed: ["#e6f1fb", "#0c447c"],
    withdrawn: ["#f1efe8", "#444441"],
  };
  const [bg, fg] = map[kind || ""] || ["#f1efe8", "#444441"];
  return (
    <span
      style={{
        background: bg,
        color: fg,
        fontSize: 12,
        padding: "3px 10px",
        borderRadius: 8,
        whiteSpace: "nowrap",
      }}
    >
      {text}
    </span>
  );
}

export function ErrorBox({ message }: { message: string }) {
  return (
    <div
      style={{
        background: "#fceaea",
        color: "#a32d2d",
        fontSize: 14,
        padding: "12px 14px",
        borderRadius: 8,
      }}
    >
      {message}
    </div>
  );
}

export function Loading({ text }: { text?: string }) {
  return (
    <div style={{ color: "var(--text-muted)", padding: "1rem 0" }}>
      {text || "…"}
    </div>
  );
}

export function Table({
  headers,
  rows,
}: {
  headers: string[];
  rows: React.ReactNode[][];
}) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
      <thead>
        <tr>
          {headers.map((h, i) => (
            <th
              key={i}
              style={{
                textAlign: "right",
                color: "var(--text-muted)",
                fontWeight: 500,
                padding: "8px 6px",
                borderBottom: "1px solid var(--border)",
              }}
            >
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, ri) => (
          <tr key={ri}>
            {row.map((cell, ci) => (
              <td
                key={ci}
                style={{
                  padding: "10px 6px",
                  borderBottom: "1px solid var(--border)",
                }}
              >
                {cell}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export const fmt = (n: number) =>
  new Intl.NumberFormat("ar-EG").format(Math.round(n));

// أزرار التعديل والحذف لكل صف، مع نافذة تأكيد قبل الحذف.
export function RowActions({
  onEdit,
  onDelete,
  editLabel = "تعديل",
  deleteLabel = "حذف",
}: {
  onEdit?: () => void;
  onDelete?: () => void;
  editLabel?: string;
  deleteLabel?: string;
}) {
  return (
    <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
      {onEdit && (
        <button onClick={onEdit} title={editLabel} style={actionBtn}>
          ✏️
        </button>
      )}
      {onDelete && (
        <button onClick={onDelete} title={deleteLabel} style={{ ...actionBtn, color: "#a32d2d" }}>
          🗑️
        </button>
      )}
    </div>
  );
}

const actionBtn: React.CSSProperties = {
  background: "transparent",
  border: "1px solid var(--border)",
  borderRadius: 6,
  padding: "4px 8px",
  fontSize: 13,
  cursor: "pointer",
  lineHeight: 1,
};

// نافذة تأكيد عامة (للحذف وغيره).
export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel,
  cancelLabel,
  danger,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message?: string;
  confirmLabel: string;
  cancelLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div
      onClick={onCancel}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "var(--surface)",
          borderRadius: 12,
          padding: 24,
          maxWidth: 420,
          width: "90%",
          boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
        }}
      >
        <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 8 }}>{title}</div>
        {message && (
          <div style={{ fontSize: 14, color: "var(--text-muted)", marginBottom: 20, lineHeight: 1.6 }}>
            {message}
          </div>
        )}
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button
            onClick={onCancel}
            style={{
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              padding: "9px 18px",
              fontSize: 14,
              fontWeight: 500,
              cursor: "pointer",
            }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            style={{
              background: danger ? "#c0392b" : "var(--brand)",
              color: "#fff",
              border: "none",
              borderRadius: 8,
              padding: "9px 18px",
              fontSize: 14,
              fontWeight: 500,
              cursor: "pointer",
            }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// نافذة تعديل عامة: تعرض الحقول الممرّرة كـ children داخل نموذج.
export function EditDialog({
  open,
  title,
  saveLabel,
  cancelLabel,
  onSave,
  onCancel,
  children,
  error,
}: {
  open: boolean;
  title: string;
  saveLabel: string;
  cancelLabel: string;
  onSave: () => void;
  onCancel: () => void;
  children: React.ReactNode;
  error?: string | null;
}) {
  if (!open) return null;
  return (
    <div
      onClick={onCancel}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.4)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "var(--surface)",
          borderRadius: 12,
          padding: 24,
          maxWidth: 480,
          width: "90%",
          maxHeight: "85vh",
          overflowY: "auto",
          boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
        }}
      >
        <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 16 }}>{title}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>{children}</div>
        {error && (
          <div style={{ marginTop: 12 }}>
            <ErrorBox message={error} />
          </div>
        )}
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 20 }}>
          <button
            onClick={onCancel}
            style={{
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              padding: "9px 18px",
              fontSize: 14,
              fontWeight: 500,
              cursor: "pointer",
            }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={onSave}
            style={{
              background: "var(--brand)",
              color: "#fff",
              border: "none",
              borderRadius: 8,
              padding: "9px 18px",
              fontSize: 14,
              fontWeight: 500,
              cursor: "pointer",
            }}
          >
            {saveLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// حقل إدخال للنماذج داخل نوافذ التعديل.
export function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label style={{ fontSize: 12, color: "var(--text-muted)", display: "block", marginBottom: 4 }}>
        {label}
      </label>
      {children}
    </div>
  );
}

export const dialogInput: React.CSSProperties = {
  width: "100%",
  padding: "9px 10px",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 14,
  background: "var(--surface)",
};
