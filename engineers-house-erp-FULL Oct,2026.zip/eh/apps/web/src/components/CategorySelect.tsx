"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Category } from "@/lib/types";
import { useLang } from "@/lib/i18n";

/**
 * A category picker that loads the active categories for a given kind
 * (course/project/customer) and lets the user either choose one or add a
 * brand-new category inline (which is created via the settings API and then
 * selected). The value bound is the category CODE, keeping backward
 * compatibility with the existing free-text `category` fields.
 */
export default function CategorySelect({
  kind,
  value,
  onChange,
  style,
}: {
  kind: "course" | "project" | "customer";
  value: string;
  onChange: (code: string) => void;
  style?: React.CSSProperties;
}) {
  const { t } = useLang();
  const [cats, setCats] = useState<Category[]>([]);
  const [adding, setAdding] = useState(false);
  const [newCode, setNewCode] = useState("");
  const [newNameAr, setNewNameAr] = useState("");
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    try {
      const list = await api.get<Category[]>(`/api/v1/settings/categories?kind=${kind}&active_only=true`);
      setCats(list);
      // Default to first category if nothing chosen yet.
      if (!value && list.length) onChange(list[0].code);
    } catch {
      // If settings unavailable, silently allow free text via the add form.
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [kind]);

  async function saveNew() {
    if (!newCode || !newNameAr) return;
    setErr(null);
    try {
      await api.post("/api/v1/settings/categories", {
        kind, code: newCode.toUpperCase(), name_ar: newNameAr, name_en: null,
      });
      const created = newCode.toUpperCase();
      setNewCode(""); setNewNameAr(""); setAdding(false);
      await load();
      onChange(created);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  const base: React.CSSProperties = { width: "100%", padding: "9px 10px", border: "1px solid var(--border)", borderRadius: 8, fontSize: 14, background: "var(--surface)", ...style };

  if (adding) {
    return (
      <div style={{ display: "grid", gap: 6 }}>
        <input value={newCode} onChange={(e) => setNewCode(e.target.value.toUpperCase())} placeholder={t("catCode")} style={base} />
        <input value={newNameAr} onChange={(e) => setNewNameAr(e.target.value)} placeholder={t("catNameAr")} style={base} />
        {err && <span style={{ fontSize: 12, color: "#c0392b" }}>{err}</span>}
        <div style={{ display: "flex", gap: 6 }}>
          <button type="button" onClick={saveNew} style={{ flex: 1, background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "7px", fontSize: 13, cursor: "pointer" }}>{t("saveCategory")}</button>
          <button type="button" onClick={() => { setAdding(false); setErr(null); }} style={{ flex: 1, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: "7px", fontSize: 13, cursor: "pointer" }}>{t("cancel")}</button>
        </div>
      </div>
    );
  }

  return (
    <select
      value={value}
      onChange={(e) => {
        if (e.target.value === "__add__") { setAdding(true); return; }
        onChange(e.target.value);
      }}
      style={base}
    >
      {cats.length === 0 && <option value="">{t("chooseCategory")}</option>}
      {cats.map((c) => (
        <option key={c.id} value={c.code}>{c.name_ar} ({c.code})</option>
      ))}
      <option value="__add__">{t("addNewInline")}</option>
    </select>
  );
}
