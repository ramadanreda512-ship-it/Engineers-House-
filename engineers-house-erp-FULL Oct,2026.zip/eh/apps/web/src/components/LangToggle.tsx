"use client";

import { useLang } from "@/lib/i18n";

export default function LangToggle() {
  const { lang, toggle } = useLang();
  return (
    <button
      onClick={toggle}
      title={lang === "ar" ? "Switch to English" : "التحويل إلى العربية"}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 12px",
        border: "1px solid var(--border)",
        borderRadius: 8,
        background: "var(--surface)",
        color: "var(--text)",
        fontSize: 13,
        fontWeight: 500,
      }}
    >
      <span style={{ opacity: lang === "ar" ? 1 : 0.4 }}>AR</span>
      <span style={{ color: "var(--text-muted)" }}>/</span>
      <span style={{ opacity: lang === "en" ? 1 : 0.4 }}>EN</span>
    </button>
  );
}
