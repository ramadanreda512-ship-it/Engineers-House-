"use client";

import { useRef, useState } from "react";
import { api } from "@/lib/api";
import { useLang } from "@/lib/i18n";

interface ImportResult {
  created: number;
  skipped: number;
  errors: { row: number; reason: string }[];
}

/** Reusable Import/Export toolbar: an Export button that downloads the
 * module's CSV, and an Import button that reads a local CSV file, posts it
 * to the module's import endpoint, and shows a compact result summary. */
export default function ImportExport({
  exportPath,
  importPath,
  onImported,
}: {
  exportPath: string;
  importPath: string;
  onImported?: () => void;
}) {
  const { t } = useLang();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function doExport() {
    setError(null);
    try {
      const data = await api.get<{ filename: string; content: string }>(exportPath);
      const blob = new Blob([data.content], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    }
  }

  async function doImport(file: File) {
    setError(null);
    setResult(null);
    setBusy(true);
    try {
      const content = await file.text();
      const res = await api.post<ImportResult>(importPath, { content });
      setResult(res);
      onImported?.();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
      <button onClick={doExport} style={btn} title={t("exportCsv")}>⬇ {t("exportCsv")}</button>
      <button
        onClick={() => fileRef.current?.click()}
        disabled={busy}
        style={{ ...btn, opacity: busy ? 0.6 : 1 }}
        title={t("importHint")}
      >
        ⬆ {busy ? "..." : t("importCsv")}
      </button>
      <input
        ref={fileRef}
        type="file"
        accept=".csv,text/csv"
        style={{ display: "none" }}
        onChange={(e) => { const f = e.target.files?.[0]; if (f) doImport(f); }}
      />
      {result && (
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>
          {t("importResult")}: <b style={{ color: "#1a7d3c" }}>{result.created} {t("importedCount")}</b>
          {result.skipped > 0 && <> · {result.skipped} {t("skippedCount")}</>}
          {result.errors.length > 0 && (
            <> · <b style={{ color: "#c0392b" }}>{result.errors.length} {t("importErrors")}</b>
              {" "}({result.errors.slice(0, 2).map((er) => `${t("rowWord")} ${er.row}`).join("، ")}{result.errors.length > 2 ? "…" : ""})
            </>
          )}
        </span>
      )}
      {error && <span style={{ fontSize: 12, color: "#c0392b" }}>{error}</span>}
    </div>
  );
}

const btn: React.CSSProperties = {
  background: "var(--surface)",
  color: "var(--text)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  padding: "7px 14px",
  fontSize: 13,
  fontWeight: 500,
  cursor: "pointer",
};
