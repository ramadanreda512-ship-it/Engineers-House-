"use client";

import { useState } from "react";
import { api } from "@/lib/api";
import { useLang } from "@/lib/i18n";

/** Header button letting ANY signed-in user change their own password. */
export default function ChangePassword() {
  const { t, lang } = useLang();
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  function close() {
    setOpen(false); setCurrent(""); setNext(""); setConfirm(""); setMsg(null);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (next.length < 8) return setMsg({ ok: false, text: t("pwTooShort") });
    if (next !== confirm) return setMsg({ ok: false, text: t("pwMismatch") });
    setBusy(true);
    try {
      await api.post("/api/v1/auth/me/change-password", {
        current_password: current, new_password: next,
      });
      setMsg({ ok: true, text: t("pwChanged") });
      setCurrent(""); setNext(""); setConfirm("");
    } catch {
      setMsg({ ok: false, text: t("pwWrongCurrent") });
    } finally {
      setBusy(false);
    }
  }

  const inp: React.CSSProperties = {
    width: "100%", padding: "9px 11px", border: "1px solid var(--border)",
    borderRadius: 8, fontSize: 14, background: "var(--surface)", marginBottom: 12,
  };
  const lbl: React.CSSProperties = { fontSize: 12.5, color: "var(--text-muted)", display: "block", marginBottom: 4 };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        title={t("pwButton")}
        style={{
          width: 34, height: 34, borderRadius: "50%", border: "1px solid var(--border)",
          background: "var(--surface)", cursor: "pointer", fontSize: 15, marginInlineEnd: 10,
        }}
      >
        🔑
      </button>
      {open && (
        <div onClick={close} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 70, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={submit}
            dir={lang === "ar" ? "rtl" : "ltr"}
            style={{ background: "var(--surface)", borderRadius: 14, padding: 24, width: "100%", maxWidth: 400 }}
          >
            <h3 style={{ marginTop: 0 }}>🔑 {t("pwTitle")}</h3>
            <label style={lbl}>{t("pwCurrent")}</label>
            <input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} required style={inp} autoComplete="current-password" />
            <label style={lbl}>{t("pwNew")}</label>
            <input type="password" value={next} onChange={(e) => setNext(e.target.value)} required style={inp} autoComplete="new-password" />
            <label style={lbl}>{t("pwConfirm")}</label>
            <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required style={inp} autoComplete="new-password" />
            <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 12 }}>{t("pwHint")}</div>
            {msg && (
              <div style={{ padding: "9px 12px", borderRadius: 8, fontSize: 13, marginBottom: 12, background: msg.ok ? "#dcfce7" : "#fee2e2", color: msg.ok ? "#166534" : "#991b1b" }}>
                {msg.text}
              </div>
            )}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button type="button" onClick={close} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, padding: "9px 18px", cursor: "pointer" }}>{t("cancel")}</button>
              <button type="submit" disabled={busy} style={{ background: "var(--brand)", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", fontWeight: 600, cursor: "pointer" }}>{busy ? "..." : t("save")}</button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
