"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import { getToken, clearToken } from "@/lib/api";
import { useLang } from "@/lib/i18n";
import LangToggle from "@/components/LangToggle";
import HelpPanel from "@/components/HelpPanel";
import ChangePassword from "@/components/ChangePassword";

const NAV = [
  { href: "/dashboard", key: "navDashboard", icon: "📊" },
  { href: "/crm", key: "navCrm", icon: "👥" },
  { href: "/training", key: "navTraining", icon: "🎓" },
  { href: "/projects", key: "navProjects", icon: "🏗️" },
  { href: "/tendering", key: "navTendering", icon: "📋" },
  { href: "/accounting", key: "navAccounting", icon: "📒" },
  { href: "/partners", key: "navPartners", icon: "🤝" },
  { href: "/fixed-assets", key: "navFixedAssets", icon: "🏢" },
  { href: "/analyst", key: "navAnalyst", icon: "🤖" },
  { href: "/governance", key: "navGovernance", icon: "✅" },
  { href: "/finance", key: "navFinance", icon: "💰" },
  { href: "/cmms", key: "navCmms", icon: "🛠️" },
  { href: "/inventory", key: "navInventory", icon: "📦" },
  { href: "/hr", key: "navHr", icon: "👔" },
  { href: "/settings", key: "navSettings", icon: "⚙️" },
] as const;

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { t } = useLang();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!getToken()) {
      router.replace("/login");
    } else {
      setReady(true);
    }
  }, [router]);

  if (!ready) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--text-muted)",
        }}
      >
        {t("loading")}
      </div>
    );
  }

  function logout() {
    clearToken();
    router.replace("/login");
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <aside
        style={{
          width: 210,
          background: "var(--surface)",
          borderInlineStart: "1px solid var(--border)",
          padding: "1.25rem 0.75rem",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "0 8px 18px",
          }}
        >
          <img
            src="/logo.jpg"
            alt="Engineers House"
            width={32}
            height={32}
            style={{ borderRadius: 7 }}
          />
          <strong style={{ fontSize: 14 }}>{t("brand")}</strong>
        </div>

        {NAV.map((item) => {
          const active =
            pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "10px 12px",
                marginBottom: 4,
                borderRadius: 8,
                textDecoration: "none",
                fontSize: 14,
                color: active ? "var(--brand-dark)" : "var(--text-muted)",
                background: active ? "var(--brand-light)" : "transparent",
                fontWeight: active ? 500 : 400,
              }}
            >
              <span style={{ fontSize: 17 }}>{item.icon}</span>
              {t(item.key)}
            </Link>
          );
        })}

        <div
          style={{
            marginTop: "auto",
            borderTop: "1px solid var(--border)",
            paddingTop: 12,
          }}
        >
          <button
            onClick={logout}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              width: "100%",
              padding: "10px 12px",
              border: "none",
              background: "transparent",
              color: "var(--text-muted)",
              fontSize: 14,
              borderRadius: 8,
            }}
          >
            <span style={{ fontSize: 17 }}>🚪</span> {t("logout")}
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, background: "var(--bg)" }}>
        <header
          style={{
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            padding: "0.75rem 1.5rem",
            borderBottom: "1px solid var(--border)",
            background: "var(--surface)",
          }}
        >
          <ChangePassword />
          <HelpPanel />
          <LangToggle />
        </header>
        <div style={{ padding: "1.5rem" }}>{children}</div>
      </main>
    </div>
  );
}
