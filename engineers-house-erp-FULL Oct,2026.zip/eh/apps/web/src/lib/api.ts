// عميل بسيط للاتصال بالـ API الخلفي (FastAPI) الذي يعمل على جهازك.
// يقرأ عنوان الخادم من متغير البيئة، ويرفق التوكن تلقائيًا مع كل طلب.

// عند فتح البرنامج من الإنترنت (رابط غير localhost) تمر كل الطلبات عبر نفس
// العنوان، ويقوم خادم الواجهة بتحويلها داخليًا إلى الـ API (انظر next.config).
// When opened from a non-local address, requests go to the same origin and the
// Next.js server proxies /api/* to the backend (see next.config.mjs).
const CONFIGURED_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "";

function resolveApiBase(): string {
  if (typeof window !== "undefined") {
    const host = window.location.hostname;
    const isLocal = host === "localhost" || host === "127.0.0.1";
    if (!isLocal) return "";
  }
  return CONFIGURED_BASE;
}

const API_BASE = resolveApiBase();

const TOKEN_KEY = "eh_access_token";
const REFRESH_KEY = "eh_refresh_token";

export function saveToken(token: string, refreshToken?: string) {
  if (typeof window !== "undefined") {
    localStorage.setItem(TOKEN_KEY, token);
    if (refreshToken) localStorage.setItem(REFRESH_KEY, refreshToken);
  }
}

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function getRefreshToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(REFRESH_KEY);
}

export function clearToken() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
  }
}

// Try to obtain a fresh access token using the stored refresh token.
// Returns the new access token, or null if refreshing isn't possible.
let refreshInFlight: Promise<string | null> | null = null;

async function tryRefresh(): Promise<string | null> {
  // De-duplicate concurrent refreshes: if several requests 401 at once,
  // they all await the same single refresh call.
  if (refreshInFlight) return refreshInFlight;
  const rt = getRefreshToken();
  if (!rt) return null;
  refreshInFlight = (async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: rt }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      saveToken(data.access_token as string, data.refresh_token as string);
      return data.access_token as string;
    } catch {
      return null;
    } finally {
      refreshInFlight = null;
    }
  })();
  return refreshInFlight;
}

// Redirect to the login page cleanly (only in the browser).
function redirectToLogin() {
  if (typeof window !== "undefined") {
    clearToken();
    if (!window.location.pathname.startsWith("/login")) {
      window.location.href = "/login";
    }
  }
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  _isRetry = false,
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  } catch {
    throw new ApiError(
      0,
      "تعذّر الاتصال بالخادم. تأكد أن الخادم الخلفي يعمل على المنفذ 8000.",
    );
  }

  // Access token expired / invalid: try ONE silent refresh, then retry.
  if (res.status === 401 && !_isRetry) {
    const newToken = await tryRefresh();
    if (newToken) {
      return request<T>(path, options, true);
    }
    // Refresh failed → session truly ended; send the user to login.
    redirectToLogin();
    throw new ApiError(401, "انتهت الجلسة. يرجى تسجيل الدخول من جديد.");
  }

  if (!res.ok) {
    let detail = `خطأ (${res.status})`;
    try {
      const body = await res.json();
      if (body?.detail) detail = String(body.detail);
    } catch {
      // ignore
    }
    throw new ApiError(res.status, detail);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

// تسجيل الدخول يستخدم نموذج OAuth2 (form-urlencoded) كما يتوقعه الخادم.
export interface AuthTokens {
  access_token: string;
  refresh_token: string;
}

export async function login(email: string, password: string): Promise<AuthTokens> {
  const body = new URLSearchParams({ username: email, password });
  let res: Response;
  try {
    res = await fetch(`${API_BASE}/api/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
    });
  } catch {
    throw new ApiError(
      0,
      "تعذّر الاتصال بالخادم. تأكد أن الخادم الخلفي يعمل على المنفذ 8000.",
    );
  }
  if (!res.ok) {
    let detail = "فشل تسجيل الدخول";
    try {
      const b = await res.json();
      if (b?.detail) detail = String(b.detail);
    } catch {
      // ignore
    }
    throw new ApiError(res.status, detail);
  }
  const data = await res.json();
  return { access_token: data.access_token, refresh_token: data.refresh_token };
}

// TEMPORARY troubleshooting helper: calls /auth/dev-login, which only
// works when the backend has DEV_LOGIN_ENABLED=true set. Returns null
// (instead of throwing) if the endpoint is disabled/not found, so the
// button can be hidden or show a clear message.
export async function devLogin(): Promise<AuthTokens | null> {
  const res = await fetch(`${API_BASE}/api/v1/auth/dev-login`, { method: "POST" });
  if (!res.ok) return null;
  const data = await res.json();
  return { access_token: data.access_token, refresh_token: data.refresh_token };
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
  del: <T>(path: string) => request<T>(path, { method: "DELETE" }),
};

export { API_BASE };
