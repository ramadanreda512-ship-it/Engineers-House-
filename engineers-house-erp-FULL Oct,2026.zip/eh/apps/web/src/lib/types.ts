// أنواع البيانات المطابقة لمخرجات الـ API

export interface UserOut {
  id: string;
  email: string;
  full_name: string;
  is_superadmin: boolean;
  roles: { id: string; name: string }[];
}

export interface Account {
  id: string;
  code: string | null;
  name: string;
  name_en: string | null;
  company_name: string | null;
  type: string;
  classification: string | null;
  industry: string | null;
  activity: string | null;
  source: string | null;
  country: string | null;
  governorate: string | null;
  city: string | null;
  address: string | null;
  gps: string | null;
  phone: string | null;
  email: string | null;
  whatsapp: string | null;
  website: string | null;
  linkedin: string | null;
  tax_number: string | null;
  commercial_reg: string | null;
  credit_limit: number;
  payment_terms_days: number;
  currency: string;
  sales_engineer: string | null;
  score: number;
  health: string | null;
  is_active: boolean;
  notes: string | null;
}

export interface CrmContact {
  id: string;
  account_id: string;
  name: string;
  email: string | null;
  phone: string | null;
  whatsapp: string | null;
  position: string | null;
  department: string | null;
  is_decision_maker: boolean;
  is_primary: boolean;
}

export interface CrmActivity {
  id: string;
  account_id: string;
  activity_type: string;
  subject: string;
  body: string | null;
  activity_date: string;
  due_date: string | null;
  is_done: boolean;
}

export interface CrmSummaryData {
  total_accounts: number;
  by_type: Record<string, number>;
  by_classification: Record<string, number>;
  open_pipeline_value: number;
  won_value: number;
  quotation_total: number;
}

export interface Course {
  id: string;
  code: string;
  title: string;
  category: string;
  price: number;
  passing_score: number | null;
}

export interface Student {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  job_title: string | null;
  national_id: string | null;
  source: string | null;
  notes: string | null;
}

export interface Project {
  id: string;
  code: string;
  name: string;
  contract_value: number;
  retention_pct?: number;
  status: string;
}

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}

export interface Cohort {
  id: string;
  course_id: string;
  instructor_id: string | null;
  code: string;
  start_date: string | null;
  end_date: string | null;
  capacity: number;
  location: string | null;
  status: string;
}

export interface Enrollment {
  id: string;
  student_id: string;
  cohort_id: string;
  status: string;
  waitlist_position: number | null;
  total_fee: number;
  discount: number;
  down_payment: number;
  enrolled_at: string;
}

export interface Installment {
  id: string;
  enrollment_id: string;
  sequence: number;
  amount: number;
  due_date: string;
  status: string;
}

export interface BOQItem {
  id: string;
  project_id: string;
  item_code: string;
  description: string;
  unit: string;
  planned_qty: number;
  executed_qty: number;
  unit_rate: number;
}

export interface VariationOrder {
  id: string;
  project_id: string;
  number: string;
  description: string;
  amount: number;
  status: string;
}

export interface ProgressBilling {
  id: string;
  project_id: string;
  number: string;
  billing_date: string;
  cumulative_pct: number;
  cumulative_gross: number;
  previous_gross: number;
  period_gross: number;
  retention_amount: number;
  net_payable: number;
  status: string;
}

export interface Invoice {
  id: string;
  number: string;
  customer_name: string;
  issue_date: string;
  due_date: string | null;
  status: string;
  tax_rate: number;
  subtotal: number;
  tax_amount: number;
  total: number;
  paid_amount: number;
  lines: InvoiceLine[];
}

export interface InvoiceLine {
  id: string;
  description: string;
  quantity: number;
  unit_price: number;
  line_total: number;
}

export interface Payment {
  id: string;
  invoice_id: string;
  amount: number;
  method: string;
  reference: string | null;
  paid_at: string;
}

export interface FinanceSummary {
  total_invoiced: number;
  total_collected: number;
  total_outstanding: number;
  total_expenses: number;
  net_cash: number;
  invoice_count: number;
  paid_invoice_count: number;
  overdue_invoice_count: number;
}

export interface Opportunity {
  id: string;
  account_id: string;
  title: string;
  stage: string;
  amount: number;
}

export interface QuotationLine {
  id: string;
  description: string;
  qty: number;
  unit_price: number;
  line_total: number;
}

export interface Quotation {
  id: string;
  account_id: string;
  opportunity_id: string | null;
  number: string;
  status: string;
  valid_until: string | null;
  subtotal: number;
  tax: number;
  total: number;
  lines: QuotationLine[];
}

// --- CMMS ---
export interface Asset {
  id: string;
  code: string;
  name: string;
  category: string | null;
  location: string | null;
  status: string;
  criticality: string;
}

export interface WorkOrder {
  id: string;
  number: string;
  asset_id: string;
  title: string;
  wo_type: string;
  priority: string;
  status: string;
  assigned_to: string | null;
  labor_cost: number;
  parts_cost: number;
}

export interface CmmsSummary {
  total_assets: number;
  operational_assets: number;
  open_work_orders: number;
  completed_work_orders: number;
  overdue_schedules: number;
  total_maintenance_cost: number;
}

// --- Inventory ---
export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: string | null;
  unit: string;
  quantity_on_hand: number;
  reorder_level: number;
  unit_cost: number;
}

export interface Supplier {
  id: string;
  name: string;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
}

export interface InventorySummary {
  total_items: number;
  low_stock_items: number;
  total_stock_value: number;
  open_purchase_orders: number;
}

// --- HR ---
export interface Employee {
  id: string;
  code: string;
  full_name: string;
  department: string | null;
  job_title: string | null;
  base_salary: number;
  annual_leave_balance: number;
  status: string;
}

export interface LeaveRequest {
  id: string;
  employee_id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  days: number;
  status: string;
}

export interface HrSummary {
  total_employees: number;
  active_employees: number;
  pending_leave_requests: number;
  total_monthly_payroll: number;
}

export interface Expense {
  id: string;
  category: string;
  description: string | null;
  amount: number;
  project_id: string | null;
  spent_at: string;
}

// --- Tendering ---
export interface Tender {
  id: string;
  code: string;
  title: string;
  client_account_id: string | null;
  client_name: string | null;
  business_unit: string;
  reference_no: string | null;
  submission_date: string | null;
  estimated_value: number;
  bid_bond_pct: number;
  status: string;
  bid_value: number;
  win_probability: number;
  notes: string | null;
  converted_project_id: string | null;
}

export interface BOQElement {
  id: string;
  division_id: string;
  item_code: string;
  description: string;
  unit: string;
  quantity: number;
  unit_rate: number;
  amount: number;
  sort_order: number;
}

export interface BOQDivision {
  id: string;
  section_id: string;
  code: string;
  name: string;
  sort_order: number;
  elements: BOQElement[];
  subtotal: number;
}

export interface BOQSection {
  id: string;
  tender_id: string;
  code: string;
  name: string;
  sort_order: number;
  divisions: BOQDivision[];
  subtotal: number;
}

export interface BOQTree {
  tender_id: string;
  sections: BOQSection[];
  grand_total: number;
}

export interface EstimateLine {
  id: string;
  category: string;
  cost_code: string | null;
  description: string;
  quantity: number;
  unit_cost: number;
  line_cost: number;
}

export interface CostEstimate {
  id: string;
  tender_id: string;
  version: number;
  title: string;
  estimate_type: string;
  overhead_pct: number;
  margin_pct: number;
  direct_cost: number;
  overhead_amount: number;
  total_cost: number;
  margin_amount: number;
  selling_price: number;
  lines: EstimateLine[];
}

export interface TenderSummary {
  total_tenders: number;
  won_tenders: number;
  lost_tenders: number;
  pending_tenders: number;
  total_pipeline_value: number;
  won_value: number;
  win_rate: number;
}

// --- Accounting ---
export interface GLAccount {
  id: string;
  code: string;
  name: string;
  account_type: string;
  parent_id: string | null;
  is_group: boolean;
  is_active: boolean;
  opening_balance: number;
}

export interface CostCenter {
  id: string;
  code: string;
  name: string;
  project_id: string | null;
  is_active: boolean;
}

export interface JournalLine {
  id: string;
  account_id: string;
  cost_center_id: string | null;
  description: string | null;
  debit: number;
  credit: number;
}

export interface JournalEntry {
  id: string;
  number: string;
  entry_date: string;
  description: string | null;
  reference: string | null;
  status: string;
  source: string;
  total_debit: number;
  total_credit: number;
  lines: JournalLine[];
}

export interface Voucher {
  id: string;
  number: string;
  voucher_type: string;
  voucher_date: string;
  amount: number;
  cash_account_id: string;
  counter_account_id: string;
  cost_center_id: string | null;
  description: string | null;
  payee: string | null;
  status: string;
  journal_entry_id: string | null;
}

export interface TrialBalanceRow {
  account_id: string;
  account_code: string;
  account_name: string;
  account_type: string;
  debit: number;
  credit: number;
}

export interface TrialBalance {
  rows: TrialBalanceRow[];
  total_debit: number;
  total_credit: number;
  is_balanced: boolean;
}

export interface IncomeStatement {
  total_revenue: number;
  total_expense: number;
  net_profit: number;
  revenue_lines: TrialBalanceRow[];
  expense_lines: TrialBalanceRow[];
}

export interface BalanceSheet {
  total_assets: number;
  total_liabilities: number;
  total_equity: number;
  retained_earnings: number;
  is_balanced: boolean;
  asset_lines: TrialBalanceRow[];
  liability_lines: TrialBalanceRow[];
  equity_lines: TrialBalanceRow[];
}

export interface ProjectCostRow {
  cost_center_id: string;
  cost_center_code: string;
  cost_center_name: string;
  account_code: string;
  account_name: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface ProjectCostReport {
  rows: ProjectCostRow[];
  total_debit: number;
  total_credit: number;
  total_balance: number;
}

// --- Partners ---
export interface Partner {
  id: string;
  code: string;
  name: string;
  email: string | null;
  phone: string | null;
  capital_contribution: number;
  equity_percent: number;
  is_active: boolean;
  notes: string | null;
  current_balance: number;
  total_contributions: number;
  total_withdrawals: number;
}

export interface PartnerTx {
  id: string;
  partner_id: string;
  tx_date: string;
  tx_type: string;
  amount: number;
  description: string | null;
  cash_account_id: string | null;
  journal_entry_id: string | null;
  status: string;
}

export interface PartnerSummaryData {
  total_partners: number;
  total_capital: number;
  total_equity_percent: number;
  total_owed_to_partners: number;
}

export interface ProfitDistLine {
  partner_id: string;
  partner_name: string;
  equity_percent: number;
  amount: number;
}

export interface ProfitDistPreview {
  total_profit: number;
  distributed: number;
  lines: ProfitDistLine[];
}

// --- Fixed Assets ---
export interface FixedAsset {
  id: string;
  code: string;
  name: string;
  category: string;
  purchase_date: string;
  purchase_value: number;
  salvage_value: number;
  useful_life_months: number;
  depreciation_method: string;
  accumulated_depreciation: number;
  current_value: number;
  location: string | null;
  serial_number: string | null;
  status: string;
  is_active: boolean;
  monthly_depreciation: number;
  months_depreciated: number;
  is_fully_depreciated: boolean;
}

export interface AssetSummaryData {
  total_assets: number;
  total_purchase_value: number;
  total_accumulated_depreciation: number;
  total_book_value: number;
}

// --- Project Budget ---
export interface BudgetVsActualRow {
  category: string;
  budget: number;
  actual: number;
  variance: number;
  variance_pct: number;
}

export interface ProjectBudgetReport {
  project_id: string;
  project_code: string;
  project_name: string;
  contract_value: number;
  rows: BudgetVsActualRow[];
  total_budget: number;
  total_actual: number;
  total_variance: number;
  invoiced_amount: number;
  received_amount: number;
  projected_margin: number;
}

// --- AI Analyst ---
export interface FinancialSnapshot {
  total_revenue: number;
  total_expense: number;
  net_profit: number;
  total_assets: number;
  total_liabilities: number;
  total_equity: number;
  cash_position: number;
  receivables: number;
  payables: number;
  active_projects: number;
  total_contract_value: number;
  partners_count: number;
  partners_capital: number;
  fixed_assets_book_value: number;
  open_tenders: number;
  tender_pipeline_value: number;
}

export interface AnalystResponse {
  answer: string;
  snapshot: FinancialSnapshot;
  ai_enabled: boolean;
}

// --- Governance ---
export interface Approval {
  id: string;
  entity_type: string;
  entity_id: string;
  title: string;
  amount: number;
  requested_by: string;
  approved_by: string | null;
  status: string;
  comments: string | null;
  decided_at: string | null;
}

export interface Budget {
  id: string;
  account_id: string;
  fiscal_year: number;
  fiscal_month: number | null;
  amount: number;
  description: string | null;
}

export interface BudgetVarianceRow {
  account_id: string;
  account_code: string;
  account_name: string;
  budget: number;
  actual: number;
  variance: number;
  variance_pct: number;
}

export interface BudgetVarianceReport {
  fiscal_year: number;
  rows: BudgetVarianceRow[];
  total_budget: number;
  total_actual: number;
  total_variance: number;
}

export interface TrainingSummaryData {
  total_courses: number;
  active_cohorts: number;
  total_students: number;
  active_enrollments: number;
  total_fees: number;
  total_collected: number;
  total_outstanding: number;
  completion_rate_pct: number;
}

export interface CohortFinanceRow {
  cohort_id: string;
  cohort_code: string;
  course_title: string;
  status: string;
  enrolled: number;
  capacity: number;
  total_fees: number;
  collected: number;
  outstanding: number;
  attendance_rate_pct: number;
}

export interface Milestone {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  target_date: string | null;
  weight: number;
  progress_pct: number;
  status: string;
  sort_order: number;
}

export interface ProjectProgressData {
  project_id: string;
  milestone_progress_pct: number;
  boq_progress_pct: number;
  overall_progress_pct: number;
}

export interface ProjectsSummaryData {
  total_projects: number;
  by_status: Record<string, number>;
  total_contract_value: number;
  total_invoiced: number;
  total_received: number;
  total_actual_cost: number;
}

export interface PipelineCard {
  id: string;
  title: string;
  account_id: string;
  account_name: string;
  value: number;
  probability: number;
  expected_close: string | null;
  loss_reason: string | null;
  competitor: string | null;
}

export interface PipelineStageCol {
  stage: string;
  count: number;
  total_value: number;
  items: PipelineCard[];
}

export interface PipelineData {
  stages: PipelineStageCol[];
  open_total: number;
  weighted_forecast: number;
  won_total: number;
  lost_total: number;
}

export interface Account360Data {
  account_id: string;
  projects_count: number;
  projects_value: number;
  invoices_count: number;
  invoices_total: number;
  invoices_paid: number;
  invoices_balance: number;
  quotations_count: number;
  quotations_total: number;
  open_opportunities: number;
  open_opportunities_value: number;
  won_value: number;
  students_count: number;
  training_fees: number;
  activities_count: number;
}

// --- Training leads (B2C funnel) ---
export interface TrainingLead {
  id: string;
  name: string;
  phone: string | null;
  whatsapp: string | null;
  source: string;
  interested_course_id: string | null;
  status: string;
  next_follow_up: string | null;
  lost_reason: string | null;
  notes: string | null;
  contact_count: number;
  student_id: string | null;
}

export interface LeadLog {
  id: string;
  note: string;
  created_at: string;
}

export interface LeadsSummaryData {
  total: number;
  by_status: Record<string, number>;
  due_today: number;
  overdue: number;
  conversion_by_source: Record<string, { total: number; registered: number; rate_pct: number }>;
  lost_reasons: Record<string, number>;
  conversion_rate_pct: number;
}

export interface CohortCostRow {
  id: string;
  cohort_id: string;
  cost_type: string;
  description: string | null;
  amount: number;
  cost_date: string | null;
}

export interface CohortPnlData {
  cohort_id: string;
  cohort_code: string;
  revenue: number;
  collected: number;
  instructor_name: string | null;
  instructor_share_pct: number;
  instructor_share: number;
  manual_costs: number;
  total_costs: number;
  profit: number;
  margin_pct: number;
}

// --- Settings: categories ---
export interface Category {
  id: string;
  kind: string;
  code: string;
  name_ar: string;
  name_en: string | null;
  is_active: boolean;
  is_system: boolean;
  sort_order: number;
}

export interface CategoryCounts {
  total: number;
  active: number;
  system: number;
}

// --- Users & roles administration ---
export interface RoleSummary {
  id: string;
  name: string;
  description: string;
  permission_count: number;
}

export interface TeamUser {
  id: string;
  email: string;
  full_name: string;
  phone: string | null;
  status: string;
  is_superadmin: boolean;
  is_2fa_enabled: boolean;
  roles: { id: string; name: string }[];
}

// --- Sales catalogue ---
export interface CrmProduct {
  id: string;
  code: string;
  name: string;
  name_en: string | null;
  category: string | null;
  unit: string;
  unit_price: number;
  unit_cost: number;
  currency: string;
  description: string | null;
  is_active: boolean;
}

// --- Loss analysis ---
export interface LossAnalysisData {
  won_count: number;
  lost_count: number;
  open_count: number;
  won_value: number;
  lost_value: number;
  win_rate_pct: number;
  avg_won_value: number;
  avg_lost_value: number;
  by_reason: { reason: string; count: number; value: number; pct: number }[];
  by_competitor: { competitor: string; count: number; value: number }[];
}

// --- Follow-up centre ---
export interface FollowUpItem {
  kind: string;
  id: string;
  account_id: string;
  account_name: string;
  account_phone: string | null;
  account_whatsapp: string | null;
  subject: string;
  due_date: string | null;
  days_overdue: number;
  activity_type: string | null;
  value: number;
  stage: string | null;
}

export interface FollowUpBoardData {
  due_today: FollowUpItem[];
  overdue: FollowUpItem[];
  upcoming: FollowUpItem[];
  stale_opportunities: FollowUpItem[];
  due_today_count: number;
  overdue_count: number;
  stale_count: number;
}

export interface QuotationLine {
  id: string;
  product_id: string | null;
  description: string;
  unit: string | null;
  qty: number;
  unit_price: number;
  discount_pct: number;
  line_total: number;
}

export interface QuotationFull {
  id: string;
  account_id: string;
  number: string;
  status: string;
  title: string | null;
  valid_until: string | null;
  currency: string;
  gross_total: number;
  line_discount_total: number;
  discount_amount: number;
  subtotal: number;
  tax_rate: number;
  tax: number;
  total: number;
  payment_terms: string | null;
  delivery_period: string | null;
  terms: string | null;
  notes: string | null;
  prepared_by: string | null;
  lines: QuotationLine[];
}

export interface QuotationPrintData {
  quotation: QuotationFull;
  account_name: string;
  account_name_en: string | null;
  account_address: string | null;
  account_phone: string | null;
  account_email: string | null;
  account_tax_number: string | null;
  contact_name: string | null;
}
