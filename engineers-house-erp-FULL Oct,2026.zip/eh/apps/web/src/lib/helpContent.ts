// Static, offline help content for each module, keyed by the first path
// segment (e.g. "/crm/..." -> "crm"). Bilingual. This is the always-available
// layer; the AI assistant is an optional enhancement on top of it.

export interface HelpSection {
  title: { ar: string; en: string };
  purpose: { ar: string; en: string };
  steps: { ar: string; en: string }[];
  tips: { ar: string; en: string }[];
}

export const HELP_CONTENT: Record<string, HelpSection> = {
  dashboard: {
    title: { ar: "لوحة التحكم", en: "Dashboard" },
    purpose: {
      ar: "نظرة سريعة على أهم أرقام شركتك: العملاء، الفرص، الإيرادات، والمهام. نقطة انطلاقك كل صباح.",
      en: "A quick overview of your company's key numbers: customers, opportunities, revenue and tasks.",
    },
    steps: [
      { ar: "راجع البطاقات العلوية لمعرفة حالة العمل اليوم.", en: "Scan the top cards for today's status." },
      { ar: "اضغط أي بطاقة أو رسم للانتقال إلى تفاصيله.", en: "Click any card or chart to drill in." },
      { ar: "تتحدث الأرقام تلقائيًا كل دقيقة.", en: "Numbers refresh automatically." },
    ],
    tips: [
      { ar: "ابدأ يومك من هنا ثم انتقل إلى «متابعات اليوم» في إدارة العملاء.", en: "Start here, then go to Follow-ups in CRM." },
    ],
  },
  crm: {
    title: { ar: "إدارة العملاء (CRM)", en: "Customer Management (CRM)" },
    purpose: {
      ar: "قلب المبيعات: تدير العملاء، الفرص البيعية، عروض الأسعار، كتالوج الخدمات، ومتابعات اليوم، وتحلل أسباب خسارة الصفقات.",
      en: "Your sales hub: customers, opportunities, quotations, catalogue, follow-ups and loss analysis.",
    },
    steps: [
      { ar: "أضف عميلًا جديدًا من زر «+ عميل جديد» واملأ بياناته الأساسية.", en: "Add a customer with '+ New customer'." },
      { ar: "افتح العميل لرؤية ملفه الكامل: جهات الاتصال، الأنشطة، ونظرة 360°.", en: "Open a customer for contacts, activities and 360° view." },
      { ar: "أنشئ عرض سعر من تبويب «عروض الأسعار»، واختر البنود من الكتالوج.", en: "Create a quotation and pick lines from the catalogue." },
      { ar: "اضغط «طباعة / PDF» لإرسال عرض احترافي للعميل.", en: "Click Print/PDF to send a professional quote." },
      { ar: "تابع «متابعات اليوم» لمعرفة من يجب أن تتصل به.", en: "Check Follow-ups for who to contact today." },
    ],
    tips: [
      { ar: "املأ «كتالوج الخدمات» أولًا — يجعل عروض الأسعار أسرع وأدق.", en: "Fill the catalogue first — quotes get faster and consistent." },
      { ar: "عند خسارة صفقة، سجّل السبب والمنافس؛ ستراهما في «تحليل الخسارة».", en: "Record loss reason & competitor to power loss analysis." },
      { ar: "الرقم الضريبي وجهة الاتصال يظهران في عرض السعر المطبوع.", en: "Tax number and contact appear on the printed quote." },
    ],
  },
  training: {
    title: { ar: "التدريب", en: "Training" },
    purpose: {
      ar: "إدارة الأكاديمية: الكورسات، الدفعات، الطلاب، الاستفسارات (B2C)، الأقساط، وربحية كل دفعة.",
      en: "Run the academy: courses, cohorts, students, inquiries, installments and cohort profit.",
    },
    steps: [
      { ar: "من تبويب «الاستفسارات» سجّل كل من يسأل عن كورس وتابعه حتى لا يضيع.", en: "Log every inquiry under Inquiries and follow up." },
      { ar: "أنشئ الكورس ثم الدفعة، وعيّن المدرب ونسبته.", en: "Create a course, then a cohort, assign the instructor and share." },
      { ar: "سجّل الطالب بمقدم حجز وعدد أقساط؛ النظام يقسّم المتبقي.", en: "Enroll with a deposit + installments; the rest is split." },
      { ar: "حصّل الأقساط بزر «تحصيل»، وصحّح أي خطأ بالحذف.", en: "Collect installments; fix mistakes with delete." },
      { ar: "راجع «ربحية الدفعة» لمعرفة صافي الربح بعد نصيب المدرب والتكاليف.", en: "Check cohort P&L for true profit." },
    ],
    tips: [
      { ar: "مقدم الحجز يُخصم أولًا ثم يُقسّم الباقي — مثال: 2000 بمقدم 500 على 3 = 500×3.", en: "Deposit is deducted first, then the balance is split." },
      { ar: "حدّد نسبة المدرب مرة واحدة؛ تُحسب تلقائيًا في كل دفعة.", en: "Set instructor share once; it's auto-computed per cohort." },
    ],
  },
  projects: {
    title: { ar: "المقاولات والمشاريع", en: "Projects" },
    purpose: {
      ar: "إدارة مشاريع التنفيذ: المراحل، نسبة الإنجاز، جداول الكميات، والمقاولون من الباطن.",
      en: "Execution projects: milestones, progress, BOQ and subcontractors.",
    },
    steps: [
      { ar: "أنشئ المشروع بقيمة العقد والعميل.", en: "Create a project with its contract value and client." },
      { ar: "أضف المراحل وأوزانها؛ يُحسب الإنجاز الكلي تلقائيًا.", en: "Add weighted milestones; overall progress is computed." },
      { ar: "افتح المشروع لإدارة جدول الكميات والمقاولين.", en: "Open a project to manage BOQ and subcontractors." },
    ],
    tips: [
      { ar: "اجعل مجموع أوزان المراحل 100% لتكون نسبة الإنجاز دقيقة.", en: "Keep milestone weights summing to 100%." },
    ],
  },
  tendering: {
    title: { ar: "المناقصات", en: "Tendering" },
    purpose: {
      ar: "تتبّع المناقصات التي تشارك فيها: المستندات، المواعيد النهائية، والحالة.",
      en: "Track tenders you bid on: documents, deadlines and status.",
    },
    steps: [
      { ar: "أضف المناقصة بجهة الطرح والموعد النهائي.", en: "Add a tender with its authority and deadline." },
      { ar: "افتحها لمتابعة بنودها وحالتها.", en: "Open it to track items and status." },
    ],
    tips: [
      { ar: "راقب المواعيد النهائية حتى لا تفوت تقديم عرضك.", en: "Watch deadlines so you never miss a submission." },
    ],
  },
  accounting: {
    title: { ar: "المحاسبة", en: "Accounting" },
    purpose: {
      ar: "الدفتر المحاسبي: دليل الحسابات والقيود المزدوجة لتتبّع كل حركة مالية.",
      en: "The ledger: chart of accounts and double-entry journals.",
    },
    steps: [
      { ar: "راجع دليل الحسابات المُعد مسبقًا.", en: "Review the pre-seeded chart of accounts." },
      { ar: "سجّل القيود المحاسبية بطرفيها المدين والدائن.", en: "Post journal entries with debit and credit." },
    ],
    tips: [
      { ar: "كل قيد يجب أن يتساوى فيه المدين مع الدائن.", en: "Every entry must balance: debits = credits." },
    ],
  },
  finance: {
    title: { ar: "المالية", en: "Finance" },
    purpose: {
      ar: "الفواتير والمدفوعات والمصروفات: تتبّع ما لك وما عليك ونقدية الشركة.",
      en: "Invoices, payments and expenses: track receivables and cash.",
    },
    steps: [
      { ar: "أصدر الفواتير للعملاء وتابع سدادها.", en: "Issue invoices and track their payment." },
      { ar: "سجّل المصروفات لتعرف صافي الربح.", en: "Record expenses to know net profit." },
    ],
    tips: [
      { ar: "سجّل المدفوعات فور استلامها لتبقى الأرقام دقيقة.", en: "Record payments immediately for accurate figures." },
    ],
  },
  cmms: {
    title: { ar: "الصيانة", en: "Maintenance (CMMS)" },
    purpose: {
      ar: "إدارة الأصول وأوامر الشغل: الصيانة الوقائية والتصحيحية للمعدات.",
      en: "Assets and work orders: preventive and corrective maintenance.",
    },
    steps: [
      { ar: "سجّل الأصول والمعدات.", en: "Register assets and equipment." },
      { ar: "أنشئ أوامر شغل وتابع تنفيذها.", en: "Create work orders and track them." },
    ],
    tips: [
      { ar: "الصيانة الوقائية المنتظمة أرخص من الأعطال المفاجئة.", en: "Planned maintenance beats surprise breakdowns." },
    ],
  },
  inventory: {
    title: { ar: "المخازن", en: "Inventory" },
    purpose: {
      ar: "إدارة الأصناف وحركة المخزون: الوارد والمنصرف والأرصدة.",
      en: "Items and stock movements: in, out and balances.",
    },
    steps: [
      { ar: "أضف الأصناف بوحداتها.", en: "Add items with their units." },
      { ar: "سجّل حركات الوارد والمنصرف.", en: "Record inbound and outbound movements." },
    ],
    tips: [
      { ar: "سجّل الحركة فور حدوثها ليبقى الرصيد صحيحًا.", en: "Log movements immediately to keep balances right." },
    ],
  },
  hr: {
    title: { ar: "الموارد البشرية", en: "HR" },
    purpose: {
      ar: "بيانات الموظفين والإجازات: سجل فريقك وطلبات الأجازات.",
      en: "Employee records and leave requests.",
    },
    steps: [
      { ar: "أضف الموظفين وبياناتهم.", en: "Add employees and their details." },
      { ar: "تابع طلبات الإجازات.", en: "Track leave requests." },
    ],
    tips: [
      { ar: "حدّث بيانات الموظفين دوريًا.", en: "Keep employee records up to date." },
    ],
  },
  partners: {
    title: { ar: "الشركاء", en: "Partners" },
    purpose: {
      ar: "إدارة الموردين والشركاء التجاريين.",
      en: "Manage suppliers and business partners.",
    },
    steps: [
      { ar: "أضف الشريك أو المورد وبيانات التواصل.", en: "Add a partner/supplier with contacts." },
    ],
    tips: [
      { ar: "وثّق شروط التعامل مع كل مورد.", en: "Document terms for each supplier." },
    ],
  },
  "fixed-assets": {
    title: { ar: "الأصول الثابتة", en: "Fixed Assets" },
    purpose: {
      ar: "سجل أصول الشركة الثابتة وإهلاكها.",
      en: "Register fixed assets and their depreciation.",
    },
    steps: [
      { ar: "أضف الأصل بقيمته وتاريخ شرائه.", en: "Add an asset with value and purchase date." },
    ],
    tips: [
      { ar: "تابع الإهلاك سنويًا لتقييم دقيق.", en: "Track depreciation for accurate valuation." },
    ],
  },
  analyst: {
    title: { ar: "المحلل الذكي", en: "Smart Analyst" },
    purpose: {
      ar: "تحليلات ورؤى ذكية عبر بيانات النظام لمساعدتك في القرارات.",
      en: "Smart insights across your data to support decisions.",
    },
    steps: [
      { ar: "استعرض التحليلات المتاحة.", en: "Browse the available analytics." },
    ],
    tips: [
      { ar: "كلما أدخلت بيانات أكثر، صارت التحليلات أدق.", en: "More data means sharper insights." },
    ],
  },
  governance: {
    title: { ar: "الموافقات والموازنات", en: "Governance" },
    purpose: {
      ar: "سلاسل الموافقات والموازنات: ضبط الاعتمادات المالية.",
      en: "Approval chains and budgets: control authorizations.",
    },
    steps: [
      { ar: "راجع طلبات الموافقة المعلّقة.", en: "Review pending approvals." },
    ],
    tips: [
      { ar: "حدّد الموازنات مبكرًا لضبط المصروفات.", en: "Set budgets early to control spending." },
    ],
  },
  settings: {
    title: { ar: "الإعدادات", en: "Settings" },
    purpose: {
      ar: "مركز التحكم: الفئات، النسخ الاحتياطي، وإدارة المستخدمين والصلاحيات.",
      en: "Control center: categories, backup, and user management.",
    },
    steps: [
      { ar: "من «نوع الفئة» أدر فئات الدورات والمشاريع والعملاء.", en: "Manage course/project/customer categories." },
      { ar: "من «النسخ الاحتياطي» نزّل نسخة أو استعد واحدة.", en: "Download or restore a backup." },
      { ar: "من «المستخدمون والصلاحيات» أضف موظفين وحدد أدوارهم.", en: "Add staff and set their roles." },
    ],
    tips: [
      { ar: "نزّل نسخة احتياطية أسبوعيًا واحفظها خارج اللاب توب.", en: "Back up weekly and keep a copy off the laptop." },
      { ar: "قبل أي تحديث للبرنامج، خذ نسخة احتياطية أولًا.", en: "Before any update, take a backup first." },
    ],
  },
};

// Resolve a pathname like "/crm/quotations/x" to its help key "crm".
export function helpKeyForPath(pathname: string): string {
  const seg = pathname.split("/").filter(Boolean)[0] || "dashboard";
  return HELP_CONTENT[seg] ? seg : "dashboard";
}
