# Engineers House ERP — الواجهة الأمامية (Web)

واجهة المستخدم بالعربية (Next.js) التي تتصل بالخادم الخلفي (FastAPI) وتعرض شاشات
حقيقية: تسجيل دخول، لوحة تحكم، إدارة العملاء، التدريب، والمقاولات — بلا PowerShell
ولا Swagger.

## المتطلبات

- Node.js الإصدار 18 أو أحدث.
- الخادم الخلفي (apps/api) يجب أن يكون **شغّالًا** على المنفذ 8000 قبل فتح الواجهة.

## التشغيل خطوة بخطوة (على قرص D)

افتح PowerShell ونفّذ الأوامر بالترتيب. (غيّر المسار حسب مكان مشروعك).

1) أضف Node إلى المسار لهذه الجلسة (لو ثبّته يدويًا على D):
```powershell
$env:Path = "D:\nodejs;" + $env:Path
```

2) حوّل ملفات npm المؤقتة إلى D (لأن قرص C ممتلئ):
```powershell
$env:TEMP="D:\temp"
$env:TMP="D:\temp"
$env:npm_config_cache="D:\npm-cache"
```

3) ادخل مجلد الواجهة:
```powershell
cd "D:\engineers-house-erp-phase1\eh\apps\web"
```

4) ثبّت المكتبات:
```powershell
npm install
```

5) شغّل الواجهة:
```powershell
npm run dev
```

6) افتح المتصفح على:
```
http://localhost:3000
```

## مهم جدًا

- **يجب تشغيل الخادم الخلفي أولًا** في نافذة PowerShell منفصلة:
  ```powershell
  cd "D:\engineers-house-erp-phase1\eh\apps\api"
  .venv\Scripts\activate
  python -m uvicorn app.main:app --reload
  ```
  الواجهة تتصل به على `http://localhost:8000`.

- بيانات الدخول الافتراضية:
  - البريد: `admin@engineershouse.com`
  - كلمة المرور: `ChangeMe!2026`

## إعداد عنوان الخادم

عنوان الخادم الخلفي محفوظ في ملف `.env.local`:
```
NEXT_PUBLIC_API_BASE=http://localhost:8000
```
لو غيّرت منفذ الخادم، عدّل هذا الملف ثم أعد تشغيل `npm run dev`.

## بنية المشروع

```
apps/web/
├── src/
│   ├── app/
│   │   ├── (auth)/login/      # شاشة تسجيل الدخول
│   │   ├── (app)/dashboard/   # لوحة التحكم
│   │   ├── (app)/crm/         # إدارة العملاء
│   │   ├── (app)/training/    # التدريب
│   │   ├── (app)/projects/    # المقاولات
│   │   └── layout.tsx         # التخطيط العام (عربي RTL)
│   ├── components/            # AppShell + عناصر الواجهة
│   └── lib/                   # عميل الـ API + الأنواع
└── package.json
```
