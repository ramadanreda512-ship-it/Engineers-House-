"""Tests for the Finance module: invoices, payments, expenses, summary."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_invoice(client, h, lines=None, tax_rate=14):
    body = {
        "customer_name": "Delta Foods Factory",
        "tax_rate": tax_rate,
        "lines": lines
        or [
            {"description": "PLC training (5 engineers)", "quantity": 5, "unit_price": 3000},
            {"description": "On-site commissioning", "quantity": 1, "unit_price": 5000},
        ],
    }
    return client.post("/api/v1/finance/invoices", json=body, headers=h)


def test_invoice_totals_are_server_computed(client, superadmin_token):
    h = _auth(superadmin_token)
    r = _make_invoice(client, h, tax_rate=14)
    assert r.status_code == 201, r.text
    inv = r.json()
    # subtotal = 5*3000 + 1*5000 = 20000; tax 14% = 2800; total = 22800
    assert inv["subtotal"] == 20000
    assert inv["tax_amount"] == 2800
    assert inv["total"] == 22800
    assert inv["paid_amount"] == 0
    assert inv["status"] == "issued"
    assert inv["number"].startswith("INV-")
    assert len(inv["lines"]) == 2
    assert inv["lines"][0]["line_total"] == 15000


def test_partial_then_full_payment_updates_status(client, superadmin_token):
    h = _auth(superadmin_token)
    inv = _make_invoice(client, h).json()
    invoice_id = inv["id"]
    total = inv["total"]  # 22800

    p1 = client.post(
        f"/api/v1/finance/invoices/{invoice_id}/payments",
        json={"amount": 10000, "method": "bank"},
        headers=h,
    )
    assert p1.status_code == 201, p1.text

    after1 = client.get(f"/api/v1/finance/invoices/{invoice_id}", headers=h).json()
    assert after1["paid_amount"] == 10000
    assert after1["status"] == "partially_paid"

    p2 = client.post(
        f"/api/v1/finance/invoices/{invoice_id}/payments",
        json={"amount": total - 10000, "method": "cash"},
        headers=h,
    )
    assert p2.status_code == 201

    after2 = client.get(f"/api/v1/finance/invoices/{invoice_id}", headers=h).json()
    assert after2["paid_amount"] == total
    assert after2["status"] == "paid"


def test_overpayment_is_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    inv = _make_invoice(client, h).json()
    invoice_id = inv["id"]

    over = client.post(
        f"/api/v1/finance/invoices/{invoice_id}/payments",
        json={"amount": inv["total"] + 1000},
        headers=h,
    )
    assert over.status_code == 400
    assert "exceeds" in over.json()["detail"].lower()


def test_cannot_pay_fully_paid_invoice(client, superadmin_token):
    h = _auth(superadmin_token)
    inv = _make_invoice(client, h).json()
    invoice_id = inv["id"]
    client.post(
        f"/api/v1/finance/invoices/{invoice_id}/payments",
        json={"amount": inv["total"]},
        headers=h,
    )
    again = client.post(
        f"/api/v1/finance/invoices/{invoice_id}/payments",
        json={"amount": 100},
        headers=h,
    )
    assert again.status_code == 409


def test_finance_summary_reflects_invoices_payments_expenses(client, superadmin_token):
    h = _auth(superadmin_token)
    inv = _make_invoice(client, h).json()  # total 22800
    client.post(
        f"/api/v1/finance/invoices/{inv['id']}/payments",
        json={"amount": 12800},
        headers=h,
    )
    client.post(
        "/api/v1/finance/expenses",
        json={"category": "salaries", "amount": 5000},
        headers=h,
    )

    summary = client.get("/api/v1/finance/summary", headers=h).json()
    assert summary["total_invoiced"] == 22800
    assert summary["total_collected"] == 12800
    assert summary["total_outstanding"] == 10000
    assert summary["total_expenses"] == 5000
    assert summary["net_cash"] == 7800  # 12800 collected - 5000 expenses
    assert summary["invoice_count"] == 1


def test_cancel_invoice_blocks_when_paid(client, superadmin_token):
    h = _auth(superadmin_token)
    inv = _make_invoice(client, h).json()
    client.post(
        f"/api/v1/finance/invoices/{inv['id']}/payments",
        json={"amount": 1000},
        headers=h,
    )
    cancel = client.post(f"/api/v1/finance/invoices/{inv['id']}/cancel", headers=h)
    assert cancel.status_code == 409
