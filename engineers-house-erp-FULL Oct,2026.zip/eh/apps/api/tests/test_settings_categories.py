"""Tests for the settings module: user-managed category lists used as
dropdown sources for course/project/customer categories."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_default_categories_seeded(client, superadmin_token):
    h = _auth(superadmin_token)
    courses = client.get("/api/v1/settings/categories?kind=course", headers=h).json()
    codes = {c["code"] for c in courses}
    assert {"PLC", "SCADA", "HMI"}.issubset(codes)
    assert all(c["is_system"] for c in courses)

    projects = client.get("/api/v1/settings/categories?kind=project", headers=h).json()
    assert len(projects) >= 3
    customers = client.get("/api/v1/settings/categories?kind=customer", headers=h).json()
    assert any(c["code"] == "FACTORY" for c in customers)


def test_counts(client, superadmin_token):
    h = _auth(superadmin_token)
    cnt = client.get("/api/v1/settings/categories/counts?kind=course", headers=h).json()
    assert cnt["total"] == cnt["system"]  # all seeded are system
    assert cnt["active"] == cnt["total"]


def test_create_edit_category(client, superadmin_token):
    h = _auth(superadmin_token)
    created = client.post(
        "/api/v1/settings/categories",
        json={"kind": "course", "code": "ROBOTICS",
              "name_ar": "الروبوتات", "name_en": "Robotics"},
        headers=h,
    )
    assert created.status_code == 201, created.text
    data = created.json()
    assert data["is_system"] is False
    assert data["is_active"] is True

    updated = client.patch(
        f"/api/v1/settings/categories/{data['id']}",
        json={"name_ar": "الروبوتات الصناعية", "is_active": False},
        headers=h,
    ).json()
    assert updated["name_ar"] == "الروبوتات الصناعية"
    assert updated["is_active"] is False


def test_duplicate_code_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post(
        "/api/v1/settings/categories",
        json={"kind": "project", "code": "SOLAR", "name_ar": "طاقة شمسية"},
        headers=h,
    )
    dup = client.post(
        "/api/v1/settings/categories",
        json={"kind": "project", "code": "SOLAR", "name_ar": "مكرر"},
        headers=h,
    )
    assert dup.status_code == 409

    # Same code under a different kind is allowed.
    ok = client.post(
        "/api/v1/settings/categories",
        json={"kind": "customer", "code": "SOLAR", "name_ar": "عميل طاقة"},
        headers=h,
    )
    assert ok.status_code == 201


def test_system_category_protected_but_custom_deletable(client, superadmin_token):
    h = _auth(superadmin_token)
    courses = client.get("/api/v1/settings/categories?kind=course", headers=h).json()
    plc = next(c for c in courses if c["code"] == "PLC")
    blocked = client.delete(f"/api/v1/settings/categories/{plc['id']}", headers=h)
    assert blocked.status_code == 409

    # A system category can still be deactivated.
    deact = client.patch(
        f"/api/v1/settings/categories/{plc['id']}",
        json={"is_active": False},
        headers=h,
    ).json()
    assert deact["is_active"] is False

    custom = client.post(
        "/api/v1/settings/categories",
        json={"kind": "course", "code": "TEMP", "name_ar": "مؤقت"},
        headers=h,
    ).json()
    removed = client.delete(f"/api/v1/settings/categories/{custom['id']}", headers=h)
    assert removed.status_code == 204


def test_active_only_filter(client, superadmin_token):
    h = _auth(superadmin_token)
    custom = client.post(
        "/api/v1/settings/categories",
        json={"kind": "customer", "code": "INACTIVE1", "name_ar": "غير نشط"},
        headers=h,
    ).json()
    client.patch(
        f"/api/v1/settings/categories/{custom['id']}",
        json={"is_active": False},
        headers=h,
    )
    all_cats = client.get("/api/v1/settings/categories?kind=customer", headers=h).json()
    active = client.get(
        "/api/v1/settings/categories?kind=customer&active_only=true", headers=h
    ).json()
    assert len(active) < len(all_cats)
    assert all(c["is_active"] for c in active)
