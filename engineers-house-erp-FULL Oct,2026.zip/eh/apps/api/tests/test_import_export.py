"""Tests for CSV import/export (CRM, Training, Projects), professional
course fields, and public certificate verification."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


# ---------- Course professional fields ----------
def test_course_level_and_description(client, superadmin_token):
    h = _auth(superadmin_token)
    r = client.post(
        "/api/v1/training/courses",
        json={
            "code": "PLC-201",
            "title": "Siemens S7-1500 Advanced",
            "category": "PLC",
            "level": "advanced",
            "duration_hours": 40,
            "price": 9000,
            "mode": "hybrid",
            "description": "Advanced PLC programming with TIA Portal",
            "prerequisites": "PLC-101 or equivalent experience",
        },
        headers=h,
    )
    assert r.status_code == 201, r.text
    data = r.json()
    assert data["level"] == "advanced"
    assert data["prerequisites"].startswith("PLC-101")


# ---------- Training import/export ----------
def test_students_import_then_export(client, superadmin_token):
    h = _auth(superadmin_token)
    csv_text = (
        "Full Name,Email,Phone,Company,Job Title\n"
        "أحمد سمير,ahmed@x.com,0100000001,مصنع كيان,مهندس صيانة\n"
        "Sara Adel,sara@y.com,0100000002,Siemens,Automation Eng\n"
        ",missing@name.com,,,\n"
    )
    res = client.post(
        "/api/v1/training/students-import", json={"content": csv_text}, headers=h
    )
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["created"] == 2
    assert len(body["errors"]) == 1  # the row missing a name

    exp = client.get("/api/v1/training/students-export", headers=h).json()
    assert exp["filename"].startswith("students-")
    assert "أحمد سمير" in exp["content"]
    assert "Siemens" in exp["content"]


def test_courses_import_skips_duplicates(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post(
        "/api/v1/training/courses",
        json={"code": "SCD-01", "title": "SCADA Basics", "category": "SCADA"},
        headers=h,
    )
    csv_text = (
        "Code,Title,Category,Level,Duration Hours,Price,Mode\n"
        "SCD-01,SCADA Basics Again,SCADA,beginner,20,3000,onsite\n"
        "HMI-01,HMI Design,HMI,intermediate,16,2500,online\n"
    )
    res = client.post(
        "/api/v1/training/courses-import", json={"content": csv_text}, headers=h
    ).json()
    assert res["created"] == 1
    assert res["skipped"] == 1

    exp = client.get("/api/v1/training/courses-export", headers=h).json()
    assert "HMI-01" in exp["content"]


# ---------- CRM import ----------
def test_crm_accounts_import(client, superadmin_token):
    h = _auth(superadmin_token)
    csv_text = (
        "Name,Type,Classification,City,Phone,Credit Limit\n"
        "مصنع النور,customer,factory,السويس,0111111111,250000\n"
        "شركة الأمل,lead,contractor,القاهرة,0122222222,0\n"
    )
    res = client.post(
        "/api/v1/crm/accounts-import", json={"content": csv_text}, headers=h
    ).json()
    assert res["created"] == 2

    listed = client.get("/api/v1/crm/accounts?search=النور", headers=h).json()
    assert listed["total"] == 1
    acc = listed["items"][0]
    assert acc["code"] is not None  # auto-code assigned
    assert acc["credit_limit"] == 250000.0


# ---------- Projects import/export ----------
def test_projects_import_then_export(client, superadmin_token):
    h = _auth(superadmin_token)
    csv_text = (
        "Code,Name,Contract Value,Status\n"
        "PRJ-IMP1,مشروع مستورد,500000,active\n"
        "PRJ-IMP2,Second Import,750000,badstatus\n"
    )
    res = client.post(
        "/api/v1/projects/import/csv", json={"content": csv_text}, headers=h
    ).json()
    assert res["created"] == 2

    # Invalid status falls back to planned.
    listed = client.get("/api/v1/projects?search=Second", headers=h).json()
    assert listed["items"][0]["status"] == "planned"

    exp = client.get("/api/v1/projects/export/csv", headers=h).json()
    assert "PRJ-IMP1" in exp["content"]


# ---------- Certificate verification ----------
def test_certificate_public_verification(client, superadmin_token):
    h = _auth(superadmin_token)
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "CERT-C1", "title": "Cert Course", "category": "PLC"},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "CERT-2026-01", "capacity": 10},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students", json={"full_name": "خالد عمر"}, headers=h
    ).json()
    enr = client.post(
        "/api/v1/training/enrollments",
        json={
            "student_id": student["id"],
            "cohort_id": cohort["id"],
            "total_fee": 1000,
            "installments_count": 1,
        },
        headers=h,
    ).json()
    client.post(
        f"/api/v1/training/enrollments/{enr['id']}/complete", headers=h
    )
    cert = client.post(
        f"/api/v1/training/enrollments/{enr['id']}/certificate", headers=h
    )
    assert cert.status_code in (200, 201), cert.text
    code = cert.json()["verification_code"]

    # Public verification (no auth header at all).
    ver = client.get(f"/api/v1/training/certificates/verify/{code}")
    assert ver.status_code == 200
    body = ver.json()
    assert body["valid"] is True
    assert body["student_name"] == "خالد عمر"
    assert body["course_title"] == "Cert Course"

    # Wrong code is invalid.
    bad = client.get("/api/v1/training/certificates/verify/NOPE123")
    assert bad.json()["valid"] is False
