"""Tests for the edit/delete capabilities added across modules,
including the engineering guard rules (block delete when in use)."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


# === Training: course + student ===
def test_update_and_delete_course(client, superadmin_token):
    h = _auth(superadmin_token)
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "ED-1", "title": "Old Title", "category": "PLC", "price": 1000},
        headers=h,
    ).json()
    upd = client.patch(
        f"/api/v1/training/courses/{course['id']}",
        json={"title": "New Title", "price": 1500},
        headers=h,
    )
    assert upd.status_code == 200
    assert upd.json()["title"] == "New Title"
    assert upd.json()["price"] == 1500

    deleted = client.delete(f"/api/v1/training/courses/{course['id']}", headers=h)
    assert deleted.status_code == 204


def test_cannot_delete_course_with_cohorts(client, superadmin_token):
    h = _auth(superadmin_token)
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "ED-2", "title": "Has Cohort", "category": "PLC", "price": 1000},
        headers=h,
    ).json()
    client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "C-ED2", "capacity": 5},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/training/courses/{course['id']}", headers=h)
    assert blocked.status_code == 409


def test_cannot_delete_student_with_enrollments(client, superadmin_token):
    h = _auth(superadmin_token)
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "ED-3", "title": "Course Three", "category": "PLC", "price": 1000},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "C-ED3", "capacity": 5},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students", json={"full_name": "Enrolled One"}, headers=h
    ).json()
    client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"], "total_fee": 1000},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/training/students/{student['id']}", headers=h)
    assert blocked.status_code == 409


# === CMMS: asset ===
def test_cannot_delete_asset_with_work_orders(client, superadmin_token):
    h = _auth(superadmin_token)
    asset = client.post(
        "/api/v1/cmms/assets", json={"code": "ED-A1", "name": "Pump"}, headers=h
    ).json()
    client.post(
        "/api/v1/cmms/work-orders",
        json={"asset_id": asset["id"], "title": "Fix"},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/cmms/assets/{asset['id']}", headers=h)
    assert blocked.status_code == 409

    # but update works
    upd = client.patch(
        f"/api/v1/cmms/assets/{asset['id']}", json={"status": "retired"}, headers=h
    )
    assert upd.status_code == 200
    assert upd.json()["status"] == "retired"


# === Inventory: item ===
def test_cannot_delete_item_with_movements(client, superadmin_token):
    h = _auth(superadmin_token)
    item = client.post(
        "/api/v1/inventory/items",
        json={"sku": "ED-I1", "name": "Cable", "unit_cost": 100},
        headers=h,
    ).json()
    client.post(
        f"/api/v1/inventory/items/{item['id']}/movements",
        json={"movement_type": "in", "quantity": 10},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/inventory/items/{item['id']}", headers=h)
    assert blocked.status_code == 409


def test_update_and_delete_unused_item(client, superadmin_token):
    h = _auth(superadmin_token)
    item = client.post(
        "/api/v1/inventory/items",
        json={"sku": "ED-I2", "name": "Bolt", "unit_cost": 5},
        headers=h,
    ).json()
    upd = client.patch(
        f"/api/v1/inventory/items/{item['id']}", json={"unit_cost": 7}, headers=h
    )
    assert upd.status_code == 200
    assert upd.json()["unit_cost"] == 7
    assert client.delete(f"/api/v1/inventory/items/{item['id']}", headers=h).status_code == 204


# === HR: employee ===
def test_cannot_delete_employee_with_payroll(client, superadmin_token):
    h = _auth(superadmin_token)
    emp = client.post(
        "/api/v1/hr/employees",
        json={"code": "ED-E1", "full_name": "Paid One", "base_salary": 8000},
        headers=h,
    ).json()
    client.post(
        "/api/v1/hr/payroll",
        json={"employee_id": emp["id"], "period": "2026-06"},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/hr/employees/{emp['id']}", headers=h)
    assert blocked.status_code == 409

    upd = client.patch(
        f"/api/v1/hr/employees/{emp['id']}", json={"status": "terminated"}, headers=h
    )
    assert upd.status_code == 200
    assert upd.json()["status"] == "terminated"


# === Projects: project cancel + contract lock ===
def test_project_update_cancel_and_contract_lock(client, superadmin_token):
    h = _auth(superadmin_token)
    proj = client.post(
        "/api/v1/projects",
        json={"code": "ED-P1", "name": "Old Name", "contract_value": 100000, "retention_pct": 10},
        headers=h,
    ).json()
    # update name freely
    upd = client.patch(
        f"/api/v1/projects/{proj['id']}", json={"name": "New Name"}, headers=h
    )
    assert upd.status_code == 200
    assert upd.json()["name"] == "New Name"

    # add a billing, then contract value becomes locked
    client.post(
        f"/api/v1/projects/{proj['id']}/billings",
        json={"number": "IPC-1", "billing_date": "2026-06-01", "cumulative_pct": 30},
        headers=h,
    )
    locked = client.patch(
        f"/api/v1/projects/{proj['id']}", json={"contract_value": 200000}, headers=h
    )
    assert locked.status_code == 409

    # cancel works
    cancelled = client.post(f"/api/v1/projects/{proj['id']}/cancel", headers=h)
    assert cancelled.status_code == 200
    assert cancelled.json()["status"] == "cancelled"


# === Finance: expense ===
def test_update_and_delete_expense(client, superadmin_token):
    h = _auth(superadmin_token)
    exp = client.post(
        "/api/v1/finance/expenses",
        json={"category": "rent", "amount": 5000},
        headers=h,
    ).json()
    upd = client.patch(
        f"/api/v1/finance/expenses/{exp['id']}", json={"amount": 6000}, headers=h
    )
    assert upd.status_code == 200
    assert upd.json()["amount"] == 6000
    assert client.delete(f"/api/v1/finance/expenses/{exp['id']}", headers=h).status_code == 204
