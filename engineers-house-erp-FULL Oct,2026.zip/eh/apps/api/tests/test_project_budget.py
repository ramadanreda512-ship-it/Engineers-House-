"""Tests for the project budget vs actual feature, including actuals pulled
from accounting cost-center postings."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc_id(client, h, code):
    accs = client.get("/api/v1/accounting/accounts", headers=h).json()
    return next(a["id"] for a in accs if a["code"] == code)


def test_project_with_budget_fields(client, superadmin_token):
    h = _auth(superadmin_token)
    p = client.post("/api/v1/projects", json={
        "code": "PB-1", "name": "Budget Project", "contract_value": 500000,
        "budget_materials": 200000, "budget_labor": 100000, "budget_other": 50000,
    }, headers=h)
    assert p.status_code == 201, p.text
    assert p.json()["budget_materials"] == 200000

    report = client.get(f"/api/v1/projects/{p.json()['id']}/budget-report", headers=h).json()
    assert report["total_budget"] == 350000
    assert report["total_actual"] == 0
    assert report["projected_margin"] == 500000  # contract - 0 actual


def test_budget_actuals_from_cost_center(client, superadmin_token):
    h = _auth(superadmin_token)
    # Create a cost center and a project linked to it.
    cc = client.post("/api/v1/accounting/cost-centers", json={"code": "PB2", "name": "Budget CC"}, headers=h).json()
    p = client.post("/api/v1/projects", json={
        "code": "PB-2", "name": "Tracked Project", "contract_value": 300000,
        "budget_materials": 100000, "budget_labor": 50000, "budget_other": 20000,
        "cost_center_id": cc["id"],
    }, headers=h).json()

    # Post material cost (510101) and labor (510102) to the cost center.
    cash = _acc_id(client, h, "1101")
    mat = _acc_id(client, h, "510101")
    lab = _acc_id(client, h, "510102")
    client.post("/api/v1/accounting/journal-entries", json={
        "description": "Materials",
        "lines": [
            {"account_id": mat, "debit": 80000, "cost_center_id": cc["id"]},
            {"account_id": cash, "credit": 80000},
        ]}, headers=h)
    client.post("/api/v1/accounting/journal-entries", json={
        "description": "Labor",
        "lines": [
            {"account_id": lab, "debit": 30000, "cost_center_id": cc["id"]},
            {"account_id": cash, "credit": 30000},
        ]}, headers=h)

    report = client.get(f"/api/v1/projects/{p['id']}/budget-report", headers=h).json()
    mat_row = next(r for r in report["rows"] if r["category"] == "materials")
    lab_row = next(r for r in report["rows"] if r["category"] == "labor")
    assert mat_row["actual"] == 80000
    assert mat_row["variance"] == 20000  # 100k budget - 80k actual
    assert lab_row["actual"] == 30000
    assert report["total_actual"] == 110000
    assert report["projected_margin"] == 190000  # 300k - 110k
