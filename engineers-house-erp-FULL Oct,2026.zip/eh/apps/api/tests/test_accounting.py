"""Tests for the accounting module: chart of accounts, double-entry journals,
vouchers, and the financial statements derived from posted entries."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc(client, h, code, name, atype, is_group=False, parent_id=None):
    return client.post(
        "/api/v1/accounting/accounts",
        json={"code": code, "name": name, "account_type": atype, "is_group": is_group, "parent_id": parent_id},
        headers=h,
    )


def test_default_chart_of_accounts_seeded(client, superadmin_token):
    h = _auth(superadmin_token)
    accounts = client.get("/api/v1/accounting/accounts", headers=h).json()
    # The seed creates a starting chart of accounts.
    assert len(accounts) >= 10
    codes = {a["code"] for a in accounts}
    assert "1101" in codes  # cash
    assert "510101" in codes  # material cost (matches the legacy program)


def test_account_code_unique(client, superadmin_token):
    h = _auth(superadmin_token)
    assert _acc(client, h, "9001", "Test A", "asset").status_code == 201
    assert _acc(client, h, "9001", "Test B", "asset").status_code == 409


def test_group_account_cannot_take_entries(client, superadmin_token):
    h = _auth(superadmin_token)
    grp = _acc(client, h, "9100", "Group", "expense", is_group=True).json()
    leaf = _acc(client, h, "9101", "Leaf", "asset").json()
    r = client.post(
        "/api/v1/accounting/journal-entries",
        json={
            "description": "bad",
            "lines": [
                {"account_id": grp["id"], "debit": 100},
                {"account_id": leaf["id"], "credit": 100},
            ],
        },
        headers=h,
    )
    assert r.status_code == 400


def test_unbalanced_entry_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    a1 = _acc(client, h, "9201", "Cash", "asset").json()
    a2 = _acc(client, h, "9202", "Revenue", "revenue").json()
    r = client.post(
        "/api/v1/accounting/journal-entries",
        json={
            "lines": [
                {"account_id": a1["id"], "debit": 100},
                {"account_id": a2["id"], "credit": 90},
            ],
        },
        headers=h,
    )
    assert r.status_code == 422  # schema validation catches imbalance


def test_balanced_entry_posts_and_appears_in_ledger(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc(client, h, "9301", "Cash", "asset").json()
    rev = _acc(client, h, "9302", "Service Revenue", "revenue").json()
    entry = client.post(
        "/api/v1/accounting/journal-entries",
        json={
            "description": "Cash sale",
            "lines": [
                {"account_id": cash["id"], "debit": 5000},
                {"account_id": rev["id"], "credit": 5000},
            ],
        },
        headers=h,
    )
    assert entry.status_code == 201, entry.text
    assert entry.json()["number"].startswith("JV-")
    assert entry.json()["total_debit"] == 5000

    ledger = client.get(f"/api/v1/accounting/accounts/{cash['id']}/ledger", headers=h).json()
    assert ledger["closing_balance"] == 5000
    assert len(ledger["lines"]) == 1


def test_voucher_creates_balanced_entry(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc(client, h, "9401", "Cash", "asset").json()
    customer = _acc(client, h, "9402", "Customer X", "asset").json()
    # Receipt: debit cash, credit customer (collecting a receivable)
    rv = client.post(
        "/api/v1/accounting/vouchers",
        json={
            "voucher_type": "receipt",
            "amount": 3000,
            "cash_account_id": cash["id"],
            "counter_account_id": customer["id"],
            "payee": "Customer X",
        },
        headers=h,
    )
    assert rv.status_code == 201, rv.text
    assert rv.json()["number"].startswith("RV-")

    cash_ledger = client.get(f"/api/v1/accounting/accounts/{cash['id']}/ledger", headers=h).json()
    assert cash_ledger["closing_balance"] == 3000


def test_trial_balance_balances(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc(client, h, "9501", "Cash", "asset").json()
    capital = _acc(client, h, "9502", "Capital", "equity").json()
    client.post(
        "/api/v1/accounting/journal-entries",
        json={
            "description": "Owner investment",
            "lines": [
                {"account_id": cash["id"], "debit": 100000},
                {"account_id": capital["id"], "credit": 100000},
            ],
        },
        headers=h,
    )
    tb = client.get("/api/v1/accounting/reports/trial-balance", headers=h).json()
    assert tb["is_balanced"] is True
    assert tb["total_debit"] == tb["total_credit"]


def test_income_statement_and_balance_sheet(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc(client, h, "9601", "Cash", "asset").json()
    rev = _acc(client, h, "9602", "Revenue", "revenue").json()
    exp = _acc(client, h, "9603", "Expense", "expense").json()
    cap = _acc(client, h, "9604", "Capital", "equity").json()

    # Capital injection: cash 50,000 / capital 50,000
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [
            {"account_id": cash["id"], "debit": 50000},
            {"account_id": cap["id"], "credit": 50000},
        ]}, headers=h)
    # Revenue: cash 20,000 / revenue 20,000
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [
            {"account_id": cash["id"], "debit": 20000},
            {"account_id": rev["id"], "credit": 20000},
        ]}, headers=h)
    # Expense: expense 8,000 / cash 8,000
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [
            {"account_id": exp["id"], "debit": 8000},
            {"account_id": cash["id"], "credit": 8000},
        ]}, headers=h)

    income = client.get("/api/v1/accounting/reports/income-statement", headers=h).json()
    assert income["total_revenue"] == 20000
    assert income["total_expense"] == 8000
    assert income["net_profit"] == 12000

    bs = client.get("/api/v1/accounting/reports/balance-sheet", headers=h).json()
    # assets = cash 62,000; equity = capital 50,000 + retained 12,000 = 62,000
    assert bs["total_assets"] == 62000
    assert bs["retained_earnings"] == 12000
    assert bs["is_balanced"] is True


def test_project_cost_report_by_cost_center(client, superadmin_token):
    h = _auth(superadmin_token)
    cc = client.post("/api/v1/accounting/cost-centers", json={"code": "P1", "name": "Project Alpha"}, headers=h).json()
    cash = _acc(client, h, "9701", "Cash", "asset").json()
    matcost = _acc(client, h, "9702", "Material Cost", "expense").json()
    # Spend 15,000 on materials for the project cost center
    client.post("/api/v1/accounting/journal-entries", json={
        "description": "Materials for Alpha",
        "lines": [
            {"account_id": matcost["id"], "debit": 15000, "cost_center_id": cc["id"]},
            {"account_id": cash["id"], "credit": 15000},
        ]}, headers=h)

    report = client.get(f"/api/v1/accounting/reports/project-costs?cost_center_id={cc['id']}", headers=h).json()
    assert report["total_debit"] == 15000
    assert len(report["rows"]) == 1
    assert report["rows"][0]["cost_center_code"] == "P1"


def test_cannot_delete_account_with_entries(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc(client, h, "9801", "Cash", "asset").json()
    rev = _acc(client, h, "9802", "Revenue", "revenue").json()
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [
            {"account_id": cash["id"], "debit": 100},
            {"account_id": rev["id"], "credit": 100},
        ]}, headers=h)
    blocked = client.delete(f"/api/v1/accounting/accounts/{cash['id']}", headers=h)
    assert blocked.status_code == 409
