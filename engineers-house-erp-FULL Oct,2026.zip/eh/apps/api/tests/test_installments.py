"""Tests for the installment/payment fixes: booking deposit + remaining
balance split, paying/un-paying installments, adding/deleting installments,
and deleting a wrong enrollment."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _setup(client, h, price=2000):
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "PLC-X", "title": "PLC", "category": "PLC", "price": price},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "CC-X", "capacity": 10},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students", json={"full_name": "طالب"}, headers=h
    ).json()
    return cohort, student


def test_down_payment_splits_remaining_balance(client, superadmin_token):
    """The core scenario: total 2000, deposit 500 -> 1500 split over 3."""
    h = _auth(superadmin_token)
    cohort, student = _setup(client, h)
    enr = client.post(
        "/api/v1/training/enrollments",
        json={
            "student_id": student["id"], "cohort_id": cohort["id"],
            "total_fee": 2000, "down_payment": 500, "installment_count": 3,
        },
        headers=h,
    ).json()

    fin = client.get(f"/api/v1/training/enrollments/{enr['id']}/finance", headers=h).json()
    assert fin["net_fee"] == 2000.0
    assert fin["down_payment"] == 500.0
    assert fin["installments_total"] == 1500.0
    amounts = [i["amount"] for i in fin["installments"]]
    assert amounts == [500.0, 500.0, 500.0]
    # Deposit already counts as paid.
    assert fin["paid_total"] == 500.0
    assert fin["outstanding"] == 1500.0


def test_pay_and_unpay_installment(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort, student = _setup(client, h)
    enr = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"],
              "total_fee": 2000, "down_payment": 500, "installment_count": 3},
        headers=h,
    ).json()
    fin = client.get(f"/api/v1/training/enrollments/{enr['id']}/finance", headers=h).json()
    first = fin["installments"][0]["id"]

    paid = client.post(f"/api/v1/training/installments/{first}/pay", headers=h)
    assert paid.status_code == 200
    assert paid.json()["status"] == "paid"
    fin2 = client.get(f"/api/v1/training/enrollments/{enr['id']}/finance", headers=h).json()
    assert fin2["paid_total"] == 1000.0
    assert fin2["outstanding"] == 1000.0

    # Paying twice is rejected.
    again = client.post(f"/api/v1/training/installments/{first}/pay", headers=h)
    assert again.status_code == 409

    # Undo the payment.
    undo = client.post(f"/api/v1/training/installments/{first}/unpay", headers=h)
    assert undo.json()["status"] == "pending"
    fin3 = client.get(f"/api/v1/training/enrollments/{enr['id']}/finance", headers=h).json()
    assert fin3["paid_total"] == 500.0


def test_add_and_delete_installment(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort, student = _setup(client, h)
    enr = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"],
              "total_fee": 2000, "down_payment": 500, "installment_count": 3},
        headers=h,
    ).json()

    added = client.post(
        f"/api/v1/training/enrollments/{enr['id']}/installments",
        json={"amount": 250, "due_date": "2026-12-01"},
        headers=h,
    )
    assert added.status_code == 201, added.text
    assert added.json()["sequence"] == 4  # auto-assigned after the 3 existing

    listed = client.get(
        f"/api/v1/training/enrollments/{enr['id']}/installments", headers=h
    ).json()
    assert len(listed) == 4

    removed = client.request(
        "DELETE", f"/api/v1/training/installments/{added.json()['id']}", headers=h
    )
    assert removed.status_code == 204
    listed2 = client.get(
        f"/api/v1/training/enrollments/{enr['id']}/installments", headers=h
    ).json()
    assert len(listed2) == 3


def test_delete_enrollment_fixes_wrong_entry(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort, student = _setup(client, h)
    enr = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"],
              "total_fee": 2000, "installment_count": 2},
        headers=h,
    ).json()

    removed = client.request(
        "DELETE", f"/api/v1/training/enrollments/{enr['id']}", headers=h
    )
    assert removed.status_code == 204

    # After deleting the enrollment, the student can now be deleted too.
    del_student = client.request(
        "DELETE", f"/api/v1/training/students/{student['id']}", headers=h
    )
    assert del_student.status_code == 204


def test_deposit_covering_full_fee_makes_no_installments(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort, student = _setup(client, h)
    enr = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"],
              "total_fee": 2000, "down_payment": 2000, "installment_count": 3},
        headers=h,
    ).json()
    fin = client.get(f"/api/v1/training/enrollments/{enr['id']}/finance", headers=h).json()
    assert fin["installments_total"] == 0.0
    assert fin["outstanding"] == 0.0
    assert fin["paid_total"] == 2000.0
