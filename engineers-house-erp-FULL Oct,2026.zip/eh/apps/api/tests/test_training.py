"""Tests for the Training/LMS module: course->cohort->session, enrollment
capacity, installment generation, idempotent attendance, and certificate
issuance gated on completion.
"""
from datetime import UTC, date, datetime


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_course_and_cohort(client, h, capacity=2):
    course = client.post(
        "/api/v1/training/courses",
        json={
            "code": "PLC-101",
            "title": "PLC Fundamentals (Siemens S7-1200)",
            "category": "PLC",
            "duration_hours": 40,
            "price": 6000,
            "mode": "onsite",
        },
        headers=h,
    )
    assert course.status_code == 201, course.text
    course_id = course.json()["id"]

    cohort = client.post(
        "/api/v1/training/cohorts",
        json={
            "course_id": course_id,
            "code": "PLC-2026-01",
            "capacity": capacity,
            "start_date": str(date.today()),
        },
        headers=h,
    )
    assert cohort.status_code == 201, cohort.text
    return course_id, cohort.json()["id"]


def test_course_cohort_session_creation(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h)

    session = client.post(
        f"/api/v1/training/cohorts/{cohort_id}/sessions",
        json={
            "title": "Session 1: Ladder Logic Basics",
            "scheduled_at": datetime.now(UTC).isoformat(),
            "duration_min": 180,
        },
        headers=h,
    )
    assert session.status_code == 201, session.text
    assert session.json()["cohort_id"] == cohort_id


def test_enrollment_generates_installment_schedule(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h)

    student = client.post(
        "/api/v1/training/students",
        json={"full_name": "Mahmoud Saeed", "email": "mahmoud@example.com"},
        headers=h,
    )
    assert student.status_code == 201
    student_id = student.json()["id"]

    enrollment = client.post(
        "/api/v1/training/enrollments",
        json={
            "student_id": student_id,
            "cohort_id": cohort_id,
            "total_fee": 6000,
            "discount": 500,
            "installment_count": 3,
        },
        headers=h,
    )
    assert enrollment.status_code == 201, enrollment.text
    body = enrollment.json()
    assert body["total_fee"] == 6000.0
    assert body["discount"] == 500.0
    assert body["status"] == "active"


def test_cohort_capacity_waitlists_instead_of_rejecting(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h, capacity=1)

    s1 = client.post(
        "/api/v1/training/students", json={"full_name": "Student One"}, headers=h
    ).json()["id"]
    s2 = client.post(
        "/api/v1/training/students", json={"full_name": "Student Two"}, headers=h
    ).json()["id"]

    ok = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": s1, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    )
    assert ok.status_code == 201
    assert ok.json()["status"] == "active"

    full = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": s2, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    )
    assert full.status_code == 201, full.text
    assert full.json()["status"] == "waitlisted"
    assert full.json()["waitlist_position"] == 1


def test_withdrawing_active_enrollment_promotes_first_waitlisted(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h, capacity=1)

    s1 = client.post(
        "/api/v1/training/students", json={"full_name": "First Active"}, headers=h
    ).json()["id"]
    s2 = client.post(
        "/api/v1/training/students", json={"full_name": "Waiting One"}, headers=h
    ).json()["id"]
    s3 = client.post(
        "/api/v1/training/students", json={"full_name": "Waiting Two"}, headers=h
    ).json()["id"]

    active_enrollment = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": s1, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()

    wl1 = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": s2, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()
    assert wl1["status"] == "waitlisted"
    assert wl1["waitlist_position"] == 1

    wl2 = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": s3, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()
    assert wl2["status"] == "waitlisted"
    assert wl2["waitlist_position"] == 2

    withdraw = client.post(
        f"/api/v1/training/enrollments/{active_enrollment['id']}/withdraw", headers=h
    )
    assert withdraw.status_code == 200, withdraw.text
    assert withdraw.json()["status"] == "withdrawn"

    # wl1 (first in line) must now be promoted to active with no waitlist
    # position; wl2 must remain untouched at the back of the line.
    wl1_after = client.get(f"/api/v1/training/enrollments/{wl1['id']}", headers=h).json()
    assert wl1_after["status"] == "active"
    assert wl1_after["waitlist_position"] is None

    wl2_after = client.get(f"/api/v1/training/enrollments/{wl2['id']}", headers=h).json()
    assert wl2_after["status"] == "waitlisted"
    assert wl2_after["waitlist_position"] == 2


def test_double_withdraw_is_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h, capacity=5)
    student_id = client.post(
        "/api/v1/training/students", json={"full_name": "Solo Student"}, headers=h
    ).json()["id"]
    enrollment = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student_id, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()

    first = client.post(f"/api/v1/training/enrollments/{enrollment['id']}/withdraw", headers=h)
    assert first.status_code == 200

    second = client.post(f"/api/v1/training/enrollments/{enrollment['id']}/withdraw", headers=h)
    assert second.status_code == 409


def test_attendance_marking_is_idempotent(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h)

    session_resp = client.post(
        f"/api/v1/training/cohorts/{cohort_id}/sessions",
        json={"title": "Session 1", "scheduled_at": datetime.now(UTC).isoformat()},
        headers=h,
    )
    session_id = session_resp.json()["id"]

    student_id = client.post(
        "/api/v1/training/students", json={"full_name": "Sara Ali"}, headers=h
    ).json()["id"]
    enrollment_id = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student_id, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()["id"]

    first = client.post(
        f"/api/v1/training/sessions/{session_id}/attendance",
        json={"enrollment_id": enrollment_id, "status": "present"},
        headers=h,
    )
    assert first.status_code == 201
    first_id = first.json()["id"]

    second = client.post(
        f"/api/v1/training/sessions/{session_id}/attendance",
        json={"enrollment_id": enrollment_id, "status": "late"},
        headers=h,
    )
    assert second.status_code == 201
    assert second.json()["id"] == first_id  # same record updated, not duplicated
    assert second.json()["status"] == "late"


def test_certificate_requires_completed_enrollment(client, superadmin_token):
    h = _auth(superadmin_token)
    _, cohort_id = _make_course_and_cohort(client, h)

    student_id = client.post(
        "/api/v1/training/students", json={"full_name": "Khaled Mostafa"}, headers=h
    ).json()["id"]
    enrollment_id = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student_id, "cohort_id": cohort_id, "total_fee": 1000},
        headers=h,
    ).json()["id"]

    too_early = client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h
    )
    assert too_early.status_code == 400

    complete = client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/complete", headers=h
    )
    assert complete.status_code == 200
    assert complete.json()["status"] == "completed"

    cert = client.post(f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h)
    assert cert.status_code == 201, cert.text
    assert cert.json()["serial"].startswith("EH-CERT-")

    duplicate = client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h
    )
    assert duplicate.status_code == 409


def test_training_rbac_blocks_user_without_permission(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "notrainer@test.com", "password": "Secret123", "full_name": "No Trainer"},
    )
    token = client.post(
        "/api/v1/auth/login", data={"username": "notrainer@test.com", "password": "Secret123"}
    ).json()["access_token"]
    r = client.post(
        "/api/v1/training/courses",
        json={"code": "X-1", "title": "X", "category": "PLC"},
        headers=_auth(token),
    )
    assert r.status_code == 403


def _course_with_passing_score(client, h, passing_score=70):
    course = client.post(
        "/api/v1/training/courses",
        json={
            "code": "PLC-EXAM-1",
            "title": "PLC Certification (graded)",
            "category": "PLC",
            "price": 7000,
            "passing_score": passing_score,
        },
        headers=h,
    )
    assert course.status_code == 201, course.text
    course_id = course.json()["id"]
    assert course.json()["passing_score"] == float(passing_score)

    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course_id, "code": "PLC-EXAM-2026-01", "capacity": 10},
        headers=h,
    ).json()
    return cohort["id"]


def _enroll_and_complete(client, h, cohort_id, name):
    student_id = client.post(
        "/api/v1/training/students", json={"full_name": name}, headers=h
    ).json()["id"]
    enrollment_id = client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student_id, "cohort_id": cohort_id, "total_fee": 7000},
        headers=h,
    ).json()["id"]
    client.post(f"/api/v1/training/enrollments/{enrollment_id}/complete", headers=h)
    return enrollment_id


def test_certificate_blocked_when_no_assessment_on_graded_course(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort_id = _course_with_passing_score(client, h, passing_score=70)
    enrollment_id = _enroll_and_complete(client, h, cohort_id, "Ungraded Student")

    cert = client.post(f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h)
    assert cert.status_code == 400
    assert "no assessment" in cert.json()["detail"].lower()


def test_certificate_blocked_when_score_below_passing(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort_id = _course_with_passing_score(client, h, passing_score=70)
    enrollment_id = _enroll_and_complete(client, h, cohort_id, "Low Scorer")

    assessment = client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/assessments",
        json={"title": "Final Exam", "score": 55},
        headers=h,
    )
    assert assessment.status_code == 201, assessment.text

    cert = client.post(f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h)
    assert cert.status_code == 400
    assert "below" in cert.json()["detail"].lower()


def test_certificate_issued_when_best_score_meets_passing(client, superadmin_token):
    h = _auth(superadmin_token)
    cohort_id = _course_with_passing_score(client, h, passing_score=70)
    enrollment_id = _enroll_and_complete(client, h, cohort_id, "High Scorer")

    # First attempt fails, retake passes; best score should be used.
    client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/assessments",
        json={"title": "Final Exam (attempt 1)", "score": 60},
        headers=h,
    )
    client.post(
        f"/api/v1/training/enrollments/{enrollment_id}/assessments",
        json={"title": "Final Exam (attempt 2)", "score": 85},
        headers=h,
    )

    cert = client.post(f"/api/v1/training/enrollments/{enrollment_id}/certificate", headers=h)
    assert cert.status_code == 201, cert.text
    assert cert.json()["serial"].startswith("EH-CERT-")
