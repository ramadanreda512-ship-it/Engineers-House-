"""Tests for the CMMS module: assets, work orders, schedules, summary."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_asset(client, h, code="PUMP-01"):
    return client.post(
        "/api/v1/cmms/assets",
        json={"code": code, "name": "Centrifugal Pump", "criticality": "high"},
        headers=h,
    )


def test_asset_code_must_be_unique(client, superadmin_token):
    h = _auth(superadmin_token)
    first = _make_asset(client, h, "DUP-1")
    assert first.status_code == 201
    dup = _make_asset(client, h, "DUP-1")
    assert dup.status_code == 409


def test_work_order_lifecycle_updates_asset_status(client, superadmin_token):
    h = _auth(superadmin_token)
    asset = _make_asset(client, h, "MOTOR-01").json()

    wo = client.post(
        "/api/v1/cmms/work-orders",
        json={
            "asset_id": asset["id"],
            "title": "Bearing replacement",
            "wo_type": "corrective",
            "priority": "high",
        },
        headers=h,
    )
    assert wo.status_code == 201, wo.text
    wo_id = wo.json()["id"]
    assert wo.json()["number"].startswith("WO-")
    assert wo.json()["status"] == "open"

    started = client.post(f"/api/v1/cmms/work-orders/{wo_id}/start", headers=h)
    assert started.status_code == 200
    assert started.json()["status"] == "in_progress"

    asset_mid = client.get(f"/api/v1/cmms/assets/{asset['id']}", headers=h).json()
    assert asset_mid["status"] == "under_maintenance"

    done = client.post(
        f"/api/v1/cmms/work-orders/{wo_id}/complete",
        json={"labor_cost": 800, "parts_cost": 1500, "downtime_hours": 4},
        headers=h,
    )
    assert done.status_code == 200
    assert done.json()["status"] == "completed"
    assert done.json()["completed_at"] is not None

    asset_after = client.get(f"/api/v1/cmms/assets/{asset['id']}", headers=h).json()
    assert asset_after["status"] == "operational"


def test_cannot_complete_twice(client, superadmin_token):
    h = _auth(superadmin_token)
    asset = _make_asset(client, h, "FAN-01").json()
    wo_id = client.post(
        "/api/v1/cmms/work-orders",
        json={"asset_id": asset["id"], "title": "Clean filters"},
        headers=h,
    ).json()["id"]
    client.post(f"/api/v1/cmms/work-orders/{wo_id}/complete", json={}, headers=h)
    again = client.post(f"/api/v1/cmms/work-orders/{wo_id}/complete", json={}, headers=h)
    assert again.status_code == 409


def test_schedule_generates_work_order_and_advances(client, superadmin_token):
    h = _auth(superadmin_token)
    asset = _make_asset(client, h, "COMP-01").json()
    sched = client.post(
        "/api/v1/cmms/schedules",
        json={
            "asset_id": asset["id"],
            "title": "Quarterly inspection",
            "interval_days": 90,
            "next_due_on": "2026-01-01",
        },
        headers=h,
    )
    assert sched.status_code == 201, sched.text
    sched_id = sched.json()["id"]

    gen = client.post(f"/api/v1/cmms/schedules/{sched_id}/generate", headers=h)
    assert gen.status_code == 201, gen.text
    assert gen.json()["wo_type"] == "preventive"
    assert gen.json()["title"].startswith("PM:")

    schedules = client.get("/api/v1/cmms/schedules", headers=h).json()
    advanced = [s for s in schedules if s["id"] == sched_id][0]
    assert advanced["last_done_on"] is not None
    assert advanced["next_due_on"] != "2026-01-01"  # rolled forward


def test_cmms_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    asset = _make_asset(client, h, "SUM-01").json()
    wo_id = client.post(
        "/api/v1/cmms/work-orders",
        json={"asset_id": asset["id"], "title": "Repair"},
        headers=h,
    ).json()["id"]
    client.post(
        f"/api/v1/cmms/work-orders/{wo_id}/complete",
        json={"labor_cost": 1000, "parts_cost": 500},
        headers=h,
    )
    summary = client.get("/api/v1/cmms/summary", headers=h).json()
    assert summary["total_assets"] >= 1
    assert summary["completed_work_orders"] >= 1
    assert summary["total_maintenance_cost"] >= 1500
