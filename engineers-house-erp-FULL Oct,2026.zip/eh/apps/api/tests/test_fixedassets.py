"""Tests for fixed assets with straight-line depreciation and ledger posting."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc_id(client, h, code):
    accs = client.get("/api/v1/accounting/accounts", headers=h).json()
    return next(a["id"] for a in accs if a["code"] == code)


def _make_asset(client, h, value=60000, life=60, salvage=0):
    return client.post("/api/v1/fixed-assets", json={
        "name": "Server Rack", "category": "computer",
        "purchase_date": "2026-01-01", "purchase_value": value,
        "salvage_value": salvage, "useful_life_months": life,
    }, headers=h)


def test_create_asset_autocode_and_book_value(client, superadmin_token):
    h = _auth(superadmin_token)
    r = _make_asset(client, h)
    assert r.status_code == 201, r.text
    assert r.json()["code"] == "AST-001"
    assert r.json()["current_value"] == 60000
    assert r.json()["accumulated_depreciation"] == 0


def test_monthly_depreciation_calculation(client, superadmin_token):
    h = _auth(superadmin_token)
    # 60,000 over 60 months = 1,000/month
    a = _make_asset(client, h, value=60000, life=60).json()
    assets = client.get("/api/v1/fixed-assets", headers=h).json()
    me = next(x for x in assets if x["id"] == a["id"])
    assert me["monthly_depreciation"] == 1000


def test_run_depreciation_posts_ledger_and_reduces_value(client, superadmin_token):
    h = _auth(superadmin_token)
    a = _make_asset(client, h, value=60000, life=60).json()
    run = client.post(f"/api/v1/fixed-assets/{a['id']}/depreciate",
                      json={"period_date": "2026-02-01"}, headers=h)
    assert run.status_code == 201, run.text
    assert run.json()["amount"] == 1000
    assert run.json()["accumulated_depreciation"] == 1000
    assert run.json()["current_value"] == 59000

    # Depreciation expense account (5203) should now carry a 1,000 debit.
    exp = _acc_id(client, h, "5203")
    ledger = client.get(f"/api/v1/accounting/accounts/{exp}/ledger", headers=h).json()
    assert ledger["closing_balance"] == 1000


def test_depreciation_stops_at_salvage(client, superadmin_token):
    h = _auth(superadmin_token)
    # Small asset: 1,000 value, 500 salvage, 1 month life -> depreciable 500
    a = _make_asset(client, h, value=1000, life=1, salvage=500).json()
    run1 = client.post(f"/api/v1/fixed-assets/{a['id']}/depreciate", json={}, headers=h)
    assert run1.json()["amount"] == 500
    assert run1.json()["current_value"] == 500
    assert run1.json()["is_fully_depreciated"] is True
    # A second run should be rejected.
    run2 = client.post(f"/api/v1/fixed-assets/{a['id']}/depreciate", json={}, headers=h)
    assert run2.status_code == 409


def test_cannot_delete_asset_with_depreciation(client, superadmin_token):
    h = _auth(superadmin_token)
    a = _make_asset(client, h).json()
    client.post(f"/api/v1/fixed-assets/{a['id']}/depreciate", json={}, headers=h)
    blocked = client.delete(f"/api/v1/fixed-assets/{a['id']}", headers=h)
    assert blocked.status_code == 409


def test_asset_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    _make_asset(client, h, value=60000)
    _make_asset(client, h, value=40000)
    s = client.get("/api/v1/fixed-assets/summary", headers=h).json()
    assert s["total_assets"] >= 2
    assert s["total_purchase_value"] >= 100000
    assert s["total_book_value"] >= 100000
