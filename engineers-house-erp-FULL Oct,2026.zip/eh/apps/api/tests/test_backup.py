"""Tests for full-database backup and restore."""
import json


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_backup_stats(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post("/api/v1/crm/accounts", json={"name": "Acme", "type": "customer"}, headers=h)
    stats = client.get("/api/v1/backup/stats", headers=h).json()
    assert stats["total_rows"] > 0
    assert stats["highlights"]["customers"] >= 1


def test_export_produces_json_file(client, superadmin_token):
    h = _auth(superadmin_token)
    exp = client.get("/api/v1/backup/export", headers=h)
    assert exp.status_code == 200, exp.text
    body = exp.json()
    assert body["filename"].startswith("engineers-house-backup-")
    assert body["filename"].endswith(".json")
    data = json.loads(body["content"])
    assert data["format_version"] >= 1
    assert "tables" in data
    assert data["table_count"] > 0


def test_backup_restore_roundtrip(client, superadmin_token):
    """The core disaster-recovery flow: back up, wipe, restore, verify."""
    h = _auth(superadmin_token)

    # Seed data across several modules.
    acc = client.post(
        "/api/v1/crm/accounts", json={"name": "مصنع كيان", "type": "customer"}, headers=h
    ).json()
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "PLC-101", "title": "PLC Basics", "category": "PLC", "price": 6000},
        headers=h,
    ).json()
    client.post(
        "/api/v1/projects",
        json={"code": "PRJ-BK", "name": "Backup Project", "contract_value": 100000},
        headers=h,
    )

    # Back up.
    backup = client.get("/api/v1/backup/export", headers=h).json()["content"]
    original = json.loads(backup)
    assert original["row_count"] > 0

    # Disaster: delete some data.
    client.request("DELETE", f"/api/v1/crm/accounts/{acc['id']}", headers=h)
    client.request("DELETE", f"/api/v1/training/courses/{course['id']}", headers=h)
    assert client.get("/api/v1/crm/accounts?search=كيان", headers=h).json()["total"] == 0

    # Restore.
    res = client.post("/api/v1/backup/restore", json={"content": backup}, headers=h)
    assert res.status_code == 200, res.text
    assert res.json()["restored_rows"] == original["row_count"]

    # Everything is back.
    assert client.get("/api/v1/crm/accounts?search=كيان", headers=h).json()["total"] == 1
    assert client.get("/api/v1/training/courses?search=PLC-101", headers=h).json()["total"] == 1

    # Admin login still works after a full restore.
    relogin = client.post(
        "/api/v1/auth/login",
        data={"username": "admin@test.com", "password": "Passw0rd!"},
    )
    assert relogin.status_code == 200


def test_restore_rejects_invalid_json(client, superadmin_token):
    h = _auth(superadmin_token)
    bad = client.post("/api/v1/backup/restore", json={"content": "not json {{{"}, headers=h)
    assert bad.status_code == 400


def test_restore_rejects_missing_tables_key(client, superadmin_token):
    h = _auth(superadmin_token)
    bad = client.post(
        "/api/v1/backup/restore",
        json={"content": json.dumps({"format_version": 2})},
        headers=h,
    )
    assert bad.status_code == 400
