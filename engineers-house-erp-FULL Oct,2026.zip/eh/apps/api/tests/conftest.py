"""Test fixtures: in-memory SQLite, dependency overrides, auth helpers."""
from __future__ import annotations

import os

os.environ["AUTO_CREATE_TABLES"] = "false"
os.environ["DATABASE_URL"] = "sqlite://"
os.environ["JWT_SECRET"] = "test-secret"
# Several older tests create users through /auth/register.
os.environ["PUBLIC_REGISTRATION_ENABLED"] = "true"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.pool import StaticPool  # noqa: E402

import app.modules.accounting.models  # noqa: E402,F401
import app.modules.cmms.models  # noqa: E402,F401
import app.modules.crm.models  # noqa: E402,F401
import app.modules.finance.models  # noqa: E402,F401
import app.modules.fixedassets.models  # noqa: E402,F401
import app.modules.governance.models  # noqa: E402,F401
import app.modules.hr.models  # noqa: E402,F401
import app.modules.identity.models  # noqa: E402,F401
import app.modules.inventory.models  # noqa: E402,F401
import app.modules.partners.models  # noqa: E402,F401
import app.modules.projects.models  # noqa: E402,F401
import app.modules.settings.models  # noqa: E402,F401
import app.modules.tendering.models  # noqa: E402,F401
import app.modules.training.models  # noqa: E402,F401
from app.core.database import get_db  # noqa: E402
from app.core.security import hash_password  # noqa: E402
from app.main import app  # noqa: E402
from app.modules.identity.models import Tenant, User  # noqa: E402
from app.shared.base_model import Base  # noqa: E402

engine = create_engine(
    "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
)
TestingSession = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def _override_get_db():
    db = TestingSession()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = _override_get_db


@pytest.fixture(autouse=True)
def _schema():
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


@pytest.fixture
def client():
    from app.core import throttle

    throttle.reset_all()  # keep login lockouts from leaking between tests
    return TestClient(app)


@pytest.fixture
def superadmin_token(client):
    db = TestingSession()
    tenant = Tenant(name="EH", slug="eh")
    db.add(tenant)
    db.flush()
    db.add(
        User(
            tenant_id=tenant.id,
            email="admin@test.com",
            hashed_password=hash_password("Passw0rd!"),
            full_name="Admin",
            is_superadmin=True,
        )
    )
    db.commit()
    from app.seed import (
        _seed_categories,
        _seed_chart_of_accounts,
        _seed_permissions_and_roles,
    )
    _seed_chart_of_accounts(db, tenant.id)
    _seed_categories(db, tenant.id)
    _seed_permissions_and_roles(db, tenant.id)
    db.commit()
    db.close()
    resp = client.post(
        "/api/v1/auth/login", data={"username": "admin@test.com", "password": "Passw0rd!"}
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["access_token"]
