"""Tests for the B2C training leads funnel and cohort profitability."""
from datetime import date, timedelta


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _mk_lead(client, h, **kw):
    body = {"name": "مستفسر تجريبي", "phone": "0100000009", "source": "whatsapp"}
    body.update(kw)
    return client.post("/api/v1/training/leads", json=body, headers=h)


def test_lead_lifecycle_contact_and_convert(client, superadmin_token):
    h = _auth(superadmin_token)
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "PLC-L1", "title": "PLC Basics", "category": "PLC", "price": 5000},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "PLC-L-2026", "capacity": 10},
        headers=h,
    ).json()

    lead = _mk_lead(client, h, name="أحمد مهتم", interested_course_id=course["id"]).json()
    assert lead["status"] == "new"

    # Log a contact: status auto-moves to contacted, counter increments.
    logged = client.post(
        f"/api/v1/training/leads/{lead['id']}/log-contact",
        json={"note": "كلمته واتساب، مهتم بالمواعيد المسائية",
              "next_follow_up": str(date.today() + timedelta(days=2))},
        headers=h,
    ).json()
    assert logged["status"] == "contacted"
    assert logged["contact_count"] == 1

    logs = client.get(f"/api/v1/training/leads/{lead['id']}/logs", headers=h).json()
    assert len(logs) == 1

    # Convert into a student + enrollment in one click.
    conv = client.post(
        f"/api/v1/training/leads/{lead['id']}/convert",
        json={"cohort_id": cohort["id"], "total_fee": 5000, "installments_count": 2},
        headers=h,
    )
    assert conv.status_code == 200, conv.text
    assert conv.json()["enrollment_id"] is not None

    # Lead now registered; double conversion blocked.
    again = client.post(
        f"/api/v1/training/leads/{lead['id']}/convert", json={}, headers=h
    )
    assert again.status_code == 409

    # The student really exists with the lead's data.
    students = client.get("/api/v1/training/students?search=أحمد مهتم", headers=h).json()
    assert students["total"] == 1
    assert students["items"][0]["source"] == "whatsapp"


def test_lead_lose_with_reason_and_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    l1 = _mk_lead(client, h, name="ضائع سعر", source="facebook").json()
    _mk_lead(client, h, name="متابعة اليوم", source="instagram",
             next_follow_up=str(date.today()))
    _mk_lead(client, h, name="متابعة متأخرة", source="whatsapp",
             next_follow_up=str(date.today() - timedelta(days=3)))

    lost = client.post(
        f"/api/v1/training/leads/{l1['id']}/lose",
        json={"lost_reason": "price", "note": "قال السعر مرتفع"},
        headers=h,
    ).json()
    assert lost["status"] == "lost"
    assert lost["lost_reason"] == "price"

    summary = client.get("/api/v1/training/leads/summary", headers=h).json()
    assert summary["total"] == 3
    assert summary["due_today"] == 1
    assert summary["overdue"] == 1
    assert summary["lost_reasons"]["price"] == 1
    assert summary["conversion_by_source"]["facebook"]["total"] == 1

    # due filters
    today_list = client.get("/api/v1/training/leads?due=today", headers=h).json()
    assert today_list["total"] == 1
    overdue_list = client.get("/api/v1/training/leads?due=overdue", headers=h).json()
    assert overdue_list["total"] == 1


def test_cohort_pnl_with_instructor_share_and_costs(client, superadmin_token):
    h = _auth(superadmin_token)
    inst = client.post(
        "/api/v1/training/instructors",
        json={"name": "م. رمضان", "specialization": "PLC", "revenue_share_pct": 30},
        headers=h,
    ).json()
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "PNL-C1", "title": "PNL Course", "category": "PLC", "price": 5000},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "PNL-2026", "capacity": 10,
              "instructor_id": inst["id"]},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students", json={"full_name": "طالب ربحية"}, headers=h
    ).json()
    client.post(
        "/api/v1/training/enrollments",
        json={"student_id": student["id"], "cohort_id": cohort["id"],
              "total_fee": 10000, "installments_count": 1},
        headers=h,
    )
    # Manual costs: hall 1000 + materials 500.
    client.post(
        f"/api/v1/training/cohorts/{cohort['id']}/costs",
        json={"cost_type": "hall", "amount": 1000, "description": "إيجار قاعة"},
        headers=h,
    )
    c2 = client.post(
        f"/api/v1/training/cohorts/{cohort['id']}/costs",
        json={"cost_type": "materials", "amount": 500},
        headers=h,
    )
    assert c2.status_code == 201, c2.text

    pnl = client.get(f"/api/v1/training/cohorts/{cohort['id']}/pnl", headers=h).json()
    assert pnl["revenue"] == 10000.0
    assert pnl["instructor_share_pct"] == 30.0
    assert pnl["instructor_share"] == 3000.0
    assert pnl["manual_costs"] == 1500.0
    assert pnl["total_costs"] == 4500.0
    assert pnl["profit"] == 5500.0
    assert pnl["margin_pct"] == 55.0

    report = client.get("/api/v1/training/reports/profitability", headers=h).json()
    assert report[0]["cohort_code"] == "PNL-2026"

    # Deleting a cost changes the P&L.
    costs = client.get(f"/api/v1/training/cohorts/{cohort['id']}/costs", headers=h).json()
    client.delete(f"/api/v1/training/costs/{costs[0]['id']}", headers=h)
    pnl2 = client.get(f"/api/v1/training/cohorts/{cohort['id']}/pnl", headers=h).json()
    assert pnl2["manual_costs"] in (500.0, 1000.0)
