"""Tests for the partners (shareholders) module, including equity guards,
ledger-posting transactions, and profit distribution by equity percentage."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc_id(client, h, code):
    accs = client.get("/api/v1/accounting/accounts", headers=h).json()
    return next(a["id"] for a in accs if a["code"] == code)


def test_create_partner_autocode(client, superadmin_token):
    h = _auth(superadmin_token)
    r = client.post("/api/v1/partners", json={"name": "Ramadan Reda", "equity_percent": 60}, headers=h)
    assert r.status_code == 201, r.text
    assert r.json()["code"] == "PRT-001"
    assert r.json()["equity_percent"] == 60


def test_equity_cannot_exceed_100(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post("/api/v1/partners", json={"name": "AA", "equity_percent": 70}, headers=h)
    blocked = client.post("/api/v1/partners", json={"name": "BB", "equity_percent": 40}, headers=h)
    assert blocked.status_code == 400


def test_capital_contribution_posts_ledger_and_balance(client, superadmin_token):
    h = _auth(superadmin_token)
    p = client.post("/api/v1/partners", json={"name": "Contributor", "equity_percent": 50}, headers=h).json()
    cash = _acc_id(client, h, "1101")
    tx = client.post(
        f"/api/v1/partners/{p['id']}/transactions",
        json={"tx_type": "capital_contribution", "amount": 100000, "cash_account_id": cash},
        headers=h,
    )
    assert tx.status_code == 201, tx.text
    # A journal entry should have been posted.
    assert tx.json()["journal_entry_id"] is not None

    # Partner now appears with a credit balance of 100,000 (company owes partner).
    partners = client.get("/api/v1/partners", headers=h).json()
    me = next(x for x in partners if x["id"] == p["id"])
    assert me["current_balance"] == 100000
    assert me["total_contributions"] == 100000
    assert me["capital_contribution"] == 100000

    # The cash account ledger should reflect the debit of 100,000.
    ledger = client.get(f"/api/v1/accounting/accounts/{cash}/ledger", headers=h).json()
    assert ledger["closing_balance"] == 100000


def test_withdrawal_reduces_balance(client, superadmin_token):
    h = _auth(superadmin_token)
    p = client.post("/api/v1/partners", json={"name": "WW", "equity_percent": 50}, headers=h).json()
    cash = _acc_id(client, h, "1101")
    client.post(f"/api/v1/partners/{p['id']}/transactions",
                json={"tx_type": "capital_contribution", "amount": 50000, "cash_account_id": cash}, headers=h)
    client.post(f"/api/v1/partners/{p['id']}/transactions",
                json={"tx_type": "withdrawal", "amount": 20000, "cash_account_id": cash}, headers=h)
    partners = client.get("/api/v1/partners", headers=h).json()
    me = next(x for x in partners if x["id"] == p["id"])
    assert me["current_balance"] == 30000
    assert me["total_withdrawals"] == 20000


def test_partner_statement(client, superadmin_token):
    h = _auth(superadmin_token)
    p = client.post("/api/v1/partners", json={"name": "SS", "equity_percent": 50}, headers=h).json()
    cash = _acc_id(client, h, "1101")
    client.post(f"/api/v1/partners/{p['id']}/transactions",
                json={"tx_type": "capital_contribution", "amount": 80000, "cash_account_id": cash}, headers=h)
    client.post(f"/api/v1/partners/{p['id']}/transactions",
                json={"tx_type": "withdrawal", "amount": 30000, "cash_account_id": cash}, headers=h)
    stmt = client.get(f"/api/v1/partners/{p['id']}/statement", headers=h).json()
    assert len(stmt["lines"]) == 2
    assert stmt["closing_balance"] == 50000
    assert stmt["lines"][0]["credit"] == 80000
    assert stmt["lines"][1]["debit"] == 30000


def test_profit_distribution_by_equity(client, superadmin_token):
    h = _auth(superadmin_token)
    a = client.post("/api/v1/partners", json={"name": "P60", "equity_percent": 60}, headers=h).json()
    b = client.post("/api/v1/partners", json={"name": "P40", "equity_percent": 40}, headers=h).json()
    cash = _acc_id(client, h, "1101")

    # Preview a 100,000 profit distribution.
    preview = client.post("/api/v1/partners/profit-distribution/preview",
                          json={"total_profit": 100000}, headers=h).json()
    assert preview["distributed"] == 100000
    amounts = {line["partner_id"]: line["amount"] for line in preview["lines"]}
    assert amounts[a["id"]] == 60000
    assert amounts[b["id"]] == 40000

    # Execute it.
    done = client.post("/api/v1/partners/profit-distribution",
                       json={"total_profit": 100000, "cash_account_id": cash}, headers=h)
    assert done.status_code == 201

    # Each partner now has a debit (distribution reduces what they're owed).
    stmt_a = client.get(f"/api/v1/partners/{a['id']}/statement", headers=h).json()
    assert stmt_a["closing_balance"] == -60000


def test_cannot_delete_partner_with_transactions(client, superadmin_token):
    h = _auth(superadmin_token)
    p = client.post("/api/v1/partners", json={"name": "Locked", "equity_percent": 50}, headers=h).json()
    cash = _acc_id(client, h, "1101")
    client.post(f"/api/v1/partners/{p['id']}/transactions",
                json={"tx_type": "capital_contribution", "amount": 1000, "cash_account_id": cash}, headers=h)
    blocked = client.delete(f"/api/v1/partners/{p['id']}", headers=h)
    assert blocked.status_code == 409


def test_partner_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post("/api/v1/partners", json={"name": "XX", "equity_percent": 55}, headers=h)
    cash = _acc_id(client, h, "1101")
    partners = client.get("/api/v1/partners", headers=h).json()
    pid = partners[0]["id"]
    client.post(f"/api/v1/partners/{pid}/transactions",
                json={"tx_type": "capital_contribution", "amount": 200000, "cash_account_id": cash}, headers=h)
    summary = client.get("/api/v1/partners/summary", headers=h).json()
    assert summary["total_partners"] >= 1
    assert summary["total_capital"] >= 200000
