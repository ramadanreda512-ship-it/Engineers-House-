def test_register_and_login_and_me(client):
    r = client.post(
        "/api/v1/auth/register",
        json={"email": "eng@test.com", "password": "Secret123", "full_name": "Eng One"},
    )
    assert r.status_code == 201, r.text

    r = client.post(
        "/api/v1/auth/login", data={"username": "eng@test.com", "password": "Secret123"}
    )
    assert r.status_code == 200
    tokens = r.json()
    assert tokens["access_token"] and tokens["refresh_token"]

    me = client.get(
        "/api/v1/auth/me", headers={"Authorization": f"Bearer {tokens['access_token']}"}
    )
    assert me.status_code == 200
    assert me.json()["email"] == "eng@test.com"


def test_login_rejects_bad_password(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "x@test.com", "password": "Secret123", "full_name": "X Y"},
    )
    r = client.post("/api/v1/auth/login", data={"username": "x@test.com", "password": "wrong"})
    assert r.status_code == 400


def test_refresh_rotates_tokens(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "r@test.com", "password": "Secret123", "full_name": "R R"},
    )
    login = client.post(
        "/api/v1/auth/login", data={"username": "r@test.com", "password": "Secret123"}
    ).json()
    r = client.post("/api/v1/auth/refresh", json={"refresh_token": login["refresh_token"]})
    assert r.status_code == 200
    assert r.json()["access_token"]
