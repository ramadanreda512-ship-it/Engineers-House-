def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_rbac_blocks_user_without_permission(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "noperm@test.com", "password": "Secret123", "full_name": "No Perm"},
    )
    token = client.post(
        "/api/v1/auth/login", data={"username": "noperm@test.com", "password": "Secret123"}
    ).json()["access_token"]
    r = client.post("/api/v1/crm/accounts", json={"name": "Acme"}, headers=_auth(token))
    assert r.status_code == 403


def test_lead_to_opportunity_to_quotation_flow(client, superadmin_token):
    h = _auth(superadmin_token)

    acc = client.post(
        "/api/v1/crm/accounts",
        json={"name": "Delta Factory", "type": "lead", "industry": "Food & Beverage"},
        headers=h,
    )
    assert acc.status_code == 201, acc.text
    account_id = acc.json()["id"]

    opp = client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": account_id, "title": "PLC retrofit", "value": 50000, "probability": 40},
        headers=h,
    )
    assert opp.status_code == 201, opp.text
    opp_id = opp.json()["id"]

    quote = client.post(
        "/api/v1/crm/quotations",
        json={
            "account_id": account_id,
            "opportunity_id": opp_id,
            "tax_rate": 0.15,
            "lines": [
                {"description": "Siemens S7-1200 CPU", "qty": 2, "unit_price": 1200},
                {"description": "Commissioning (days)", "qty": 5, "unit_price": 400},
            ],
        },
        headers=h,
    )
    assert quote.status_code == 201, quote.text
    body = quote.json()
    assert body["subtotal"] == 4400.0
    assert body["tax"] == 660.0
    assert body["total"] == 5060.0
    assert body["number"].startswith("Q-")
    assert len(body["lines"]) == 2


def test_accounts_are_listed(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post("/api/v1/crm/accounts", json={"name": "One"}, headers=h)
    client.post("/api/v1/crm/accounts", json={"name": "Two"}, headers=h)
    r = client.get("/api/v1/crm/accounts", headers=h)
    assert r.status_code == 200
    assert r.json()["total"] == 2


def test_account_update_and_delete(client, superadmin_token):
    h = {"Authorization": f"Bearer {superadmin_token}"}
    acc = client.post(
        "/api/v1/crm/accounts",
        json={"name": "Editable Co", "type": "lead"},
        headers=h,
    ).json()

    # update
    upd = client.patch(
        f"/api/v1/crm/accounts/{acc['id']}",
        json={"name": "Renamed Co", "type": "customer", "industry": "Cement"},
        headers=h,
    )
    assert upd.status_code == 200, upd.text
    assert upd.json()["name"] == "Renamed Co"
    assert upd.json()["type"] == "customer"
    assert upd.json()["industry"] == "Cement"

    # delete (no dependents)
    deleted = client.delete(f"/api/v1/crm/accounts/{acc['id']}", headers=h)
    assert deleted.status_code == 204
    gone = client.get(f"/api/v1/crm/accounts/{acc['id']}", headers=h)
    assert gone.status_code == 404


def test_account_delete_blocked_with_dependents(client, superadmin_token):
    h = {"Authorization": f"Bearer {superadmin_token}"}
    acc = client.post(
        "/api/v1/crm/accounts",
        json={"name": "Has Opp Co", "type": "customer"},
        headers=h,
    ).json()
    client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": acc["id"], "title": "Big deal", "value": 1000},
        headers=h,
    )
    blocked = client.delete(f"/api/v1/crm/accounts/{acc['id']}", headers=h)
    assert blocked.status_code == 409
