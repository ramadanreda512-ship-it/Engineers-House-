"""Tests for the Training + Projects enterprise upgrade: search, KPI
summaries, instructor listing, cohort finance report, project milestones,
and weighted progress roll-up."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


# ---------- Training ----------
def _mk_course(client, h, code="PLC-01", title="PLC Basics", category="PLC", price=5000):
    return client.post(
        "/api/v1/training/courses",
        json={"code": code, "title": title, "category": category, "price": price},
        headers=h,
    ).json()


def test_instructors_can_be_listed(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post(
        "/api/v1/training/instructors",
        json={"name": "Eng. Ramadan", "specialization": "PLC"},
        headers=h,
    )
    listed = client.get("/api/v1/training/instructors", headers=h)
    assert listed.status_code == 200, listed.text
    assert len(listed.json()) == 1
    assert listed.json()[0]["name"] == "Eng. Ramadan"


def test_student_full_profile(client, superadmin_token):
    h = _auth(superadmin_token)
    r = client.post(
        "/api/v1/training/students",
        json={
            "full_name": "أحمد محمد",
            "phone": "+201000000001",
            "company": "شركة كيان",
            "job_title": "مهندس صيانة",
            "national_id": "29001010101010",
            "source": "facebook",
        },
        headers=h,
    )
    assert r.status_code == 201, r.text
    data = r.json()
    assert data["company"] == "شركة كيان"
    assert data["national_id"] == "29001010101010"


def test_student_search(client, superadmin_token):
    h = _auth(superadmin_token)
    client.post(
        "/api/v1/training/students",
        json={"full_name": "Mohamed Aly", "company": "Siemens"},
        headers=h,
    )
    client.post(
        "/api/v1/training/students",
        json={"full_name": "Sara Adel"},
        headers=h,
    )
    res = client.get("/api/v1/training/students?search=siemens", headers=h).json()
    assert res["total"] == 1
    assert res["items"][0]["full_name"] == "Mohamed Aly"


def test_course_search_and_category_filter(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk_course(client, h, code="PLC-01", title="Siemens PLC Level 1", category="PLC")
    _mk_course(client, h, code="SCD-01", title="SCADA WinCC", category="SCADA")
    res = client.get("/api/v1/training/courses?search=siemens", headers=h).json()
    assert res["total"] == 1
    cat = client.get("/api/v1/training/courses?category=SCADA", headers=h).json()
    assert cat["total"] == 1
    assert cat["items"][0]["category"] == "SCADA"


def test_training_summary_and_cohort_finance(client, superadmin_token):
    h = _auth(superadmin_token)
    course = _mk_course(client, h)
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "PLC-2026-01", "capacity": 10},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students",
        json={"full_name": "Khaled Omar"},
        headers=h,
    ).json()
    enr = client.post(
        "/api/v1/training/enrollments",
        json={
            "student_id": student["id"],
            "cohort_id": cohort["id"],
            "total_fee": 5000,
            "discount": 500,
            "installments_count": 2,
        },
        headers=h,
    )
    assert enr.status_code == 201, enr.text

    summary = client.get("/api/v1/training/summary", headers=h).json()
    assert summary["total_courses"] == 1
    assert summary["total_students"] == 1
    assert summary["active_enrollments"] == 1
    assert summary["total_fees"] == 4500.0

    report = client.get("/api/v1/training/reports/cohort-finance", headers=h).json()
    assert len(report) == 1
    row = report[0]
    assert row["cohort_code"] == "PLC-2026-01"
    assert row["enrolled"] == 1
    assert row["total_fees"] == 4500.0
    assert row["outstanding"] == 4500.0 - row["collected"]


# ---------- Projects ----------
def _mk_project(client, h, code="PRJ-01", name="Panel Project", value=100000):
    return client.post(
        "/api/v1/projects",
        json={"code": code, "name": name, "contract_value": value},
        headers=h,
    ).json()


def test_project_search_and_status_filter(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk_project(client, h, code="PRJ-KAYAN", name="Kayan Panels")
    _mk_project(client, h, code="PRJ-NOUR", name="Nour Automation")
    res = client.get("/api/v1/projects?search=kayan", headers=h).json()
    assert res["total"] == 1
    planned = client.get("/api/v1/projects?status=planned", headers=h).json()
    assert planned["total"] == 2


def test_milestone_crud_and_progress(client, superadmin_token):
    h = _auth(superadmin_token)
    proj = _mk_project(client, h)
    m1 = client.post(
        f"/api/v1/projects/{proj['id']}/milestones",
        json={"title": "التصميم", "weight": 1, "sort_order": 1},
        headers=h,
    )
    assert m1.status_code == 201, m1.text
    m2 = client.post(
        f"/api/v1/projects/{proj['id']}/milestones",
        json={"title": "التنفيذ", "weight": 3, "sort_order": 2},
        headers=h,
    ).json()

    listed = client.get(f"/api/v1/projects/{proj['id']}/milestones", headers=h).json()
    assert len(listed) == 2
    assert listed[0]["title"] == "التصميم"

    # Complete milestone 1 (25% of weight), set milestone 2 to 50%.
    done = client.patch(
        f"/api/v1/projects/milestones/{m1.json()['id']}",
        json={"status": "completed"},
        headers=h,
    ).json()
    assert done["progress_pct"] == 100
    client.patch(
        f"/api/v1/projects/milestones/{m2['id']}",
        json={"progress_pct": 50, "status": "in_progress"},
        headers=h,
    )

    prog = client.get(f"/api/v1/projects/{proj['id']}/progress", headers=h).json()
    # weighted: (1*100 + 3*50) / 4 = 62.5
    assert prog["milestone_progress_pct"] == 62.5
    assert prog["overall_progress_pct"] == 62.5  # no BOQ yet

    # Deleting a milestone changes the roll-up.
    client.delete(f"/api/v1/projects/milestones/{m2['id']}", headers=h)
    prog2 = client.get(f"/api/v1/projects/{proj['id']}/progress", headers=h).json()
    assert prog2["milestone_progress_pct"] == 100.0


def test_progress_combines_boq_and_milestones(client, superadmin_token):
    h = _auth(superadmin_token)
    proj = _mk_project(client, h, code="PRJ-BOQ", name="BOQ Progress")
    client.post(
        f"/api/v1/projects/{proj['id']}/boq",
        json={"item_code": "B1", "description": "Panels", "unit": "pc",
              "planned_qty": 10, "unit_rate": 1000},
        headers=h,
    )
    boq = client.get(f"/api/v1/projects/{proj['id']}/boq", headers=h).json()
    client.patch(
        f"/api/v1/projects/{proj['id']}/boq/{boq[0]['id']}/progress",
        json={"executed_qty": 5},
        headers=h,
    )
    prog = client.get(f"/api/v1/projects/{proj['id']}/progress", headers=h).json()
    assert prog["boq_progress_pct"] == 50.0
    assert prog["overall_progress_pct"] == 50.0  # BOQ only, no milestones


def test_projects_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk_project(client, h, code="PRJ-A", name="Alpha", value=200000)
    _mk_project(client, h, code="PRJ-B", name="Beta", value=300000)
    summary = client.get("/api/v1/projects/summary", headers=h).json()
    assert summary["total_projects"] == 2
    assert summary["total_contract_value"] == 500000.0
    assert "planned" in summary["by_status"]
