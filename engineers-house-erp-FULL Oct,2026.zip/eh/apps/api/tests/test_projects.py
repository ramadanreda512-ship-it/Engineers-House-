"""Tests for the construction Projects module: BOQ tracking, variation order
approval gating, progress billing (IPC) math, retention, and subcontract
payments.
"""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_project(client, h, contract_value=1_000_000, retention_pct=10):
    r = client.post(
        "/api/v1/projects",
        json={
            "code": "PRJ-2026-001",
            "name": "PLC/SCADA Retrofit - Delta Factory",
            "contract_value": contract_value,
            "retention_pct": retention_pct,
        },
        headers=h,
    )
    assert r.status_code == 201, r.text
    return r.json()["id"]


def test_create_project_and_boq_item(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h)

    boq = client.post(
        f"/api/v1/projects/{project_id}/boq",
        json={
            "item_code": "2.1",
            "description": "Supply & install Siemens S7-1200 CPU panel",
            "unit": "no",
            "planned_qty": 10,
            "unit_rate": 1500,
        },
        headers=h,
    )
    assert boq.status_code == 201, boq.text
    assert boq.json()["executed_qty"] == 0.0


def test_boq_progress_cannot_exceed_planned_quantity(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h)
    item = client.post(
        f"/api/v1/projects/{project_id}/boq",
        json={
            "item_code": "1.1",
            "description": "Cable trays",
            "unit": "m",
            "planned_qty": 100,
            "unit_rate": 20,
        },
        headers=h,
    ).json()

    over = client.patch(
        f"/api/v1/projects/{project_id}/boq/{item['id']}/progress",
        json={"executed_qty": 150},
        headers=h,
    )
    assert over.status_code == 400

    ok = client.patch(
        f"/api/v1/projects/{project_id}/boq/{item['id']}/progress",
        json={"executed_qty": 80},
        headers=h,
    )
    assert ok.status_code == 200
    assert ok.json()["executed_qty"] == 80.0


def test_variation_order_must_be_approved_before_affecting_billing(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h, contract_value=100_000, retention_pct=10)

    vo = client.post(
        f"/api/v1/projects/{project_id}/variation-orders",
        json={"number": "VO-001", "description": "Additional HMI panel", "amount": 20_000},
        headers=h,
    )
    assert vo.status_code == 201
    vo_id = vo.json()["id"]
    assert vo.json()["status"] == "pending"

    # Billing at 50% BEFORE approval: only the base contract counts.
    billing_before = client.post(
        f"/api/v1/projects/{project_id}/billings",
        json={"number": "IPC-01", "billing_date": "2026-06-01", "cumulative_pct": 50},
        headers=h,
    )
    assert billing_before.status_code == 201, billing_before.text
    body = billing_before.json()
    assert body["cumulative_gross"] == 50_000.0  # 100,000 * 50%, VO not yet counted
    assert body["retention_amount"] == 5_000.0  # 10% of period gross
    assert body["net_payable"] == 45_000.0

    approve = client.post(
        f"/api/v1/projects/{project_id}/variation-orders/{vo_id}/approve", headers=h
    )
    assert approve.status_code == 200
    assert approve.json()["status"] == "approved"

    # Next billing at 100%: now (100,000 + 20,000) * 100% = 120,000 cumulative.
    billing_after = client.post(
        f"/api/v1/projects/{project_id}/billings",
        json={"number": "IPC-02", "billing_date": "2026-07-01", "cumulative_pct": 100},
        headers=h,
    )
    assert billing_after.status_code == 201, billing_after.text
    body2 = billing_after.json()
    assert body2["cumulative_gross"] == 120_000.0
    assert body2["previous_gross"] == 50_000.0
    assert body2["period_gross"] == 70_000.0  # 120,000 - 50,000
    assert body2["retention_amount"] == 7_000.0
    assert body2["net_payable"] == 63_000.0


def test_billing_cumulative_pct_cannot_regress(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h, contract_value=100_000)

    client.post(
        f"/api/v1/projects/{project_id}/billings",
        json={"number": "IPC-01", "billing_date": "2026-06-01", "cumulative_pct": 60},
        headers=h,
    )
    regress = client.post(
        f"/api/v1/projects/{project_id}/billings",
        json={"number": "IPC-02", "billing_date": "2026-07-01", "cumulative_pct": 40},
        headers=h,
    )
    assert regress.status_code == 400
    assert "lower" in regress.json()["detail"].lower()


def test_retention_release(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h)

    release = client.post(
        f"/api/v1/projects/{project_id}/retention-releases",
        json={"amount": 15000, "note": "Final handover, defects-liability period elapsed"},
        headers=h,
    )
    assert release.status_code == 201, release.text
    assert release.json()["amount"] == 15000.0


def test_subcontract_payment_follows_same_pct_completion_logic(client, superadmin_token):
    h = _auth(superadmin_token)
    project_id = _make_project(client, h)

    subcontractor = client.post(
        "/api/v1/projects/subcontractors",
        json={"name": "Nile Electrical Works", "trade": "Electrical"},
        headers=h,
    ).json()

    subcontract = client.post(
        f"/api/v1/projects/{project_id}/subcontracts",
        json={
            "subcontractor_id": subcontractor["id"],
            "scope": "Cable routing and termination",
            "contract_value": 50_000,
            "retention_pct": 5,
        },
        headers=h,
    )
    assert subcontract.status_code == 201, subcontract.text
    subcontract_id = subcontract.json()["id"]

    payment1 = client.post(
        f"/api/v1/projects/{project_id}/subcontracts/{subcontract_id}/payments",
        json={"cumulative_pct": 40},
        headers=h,
    )
    assert payment1.status_code == 201, payment1.text
    p1 = payment1.json()
    assert p1["period_gross"] == 20_000.0  # 50,000 * 40%
    assert p1["retention_amount"] == 1_000.0  # 5%
    assert p1["net_payable"] == 19_000.0

    payment2 = client.post(
        f"/api/v1/projects/{project_id}/subcontracts/{subcontract_id}/payments",
        json={"cumulative_pct": 100},
        headers=h,
    )
    assert payment2.status_code == 201, payment2.text
    p2 = payment2.json()
    assert p2["period_gross"] == 30_000.0  # (50,000*100%) - (50,000*40%)
    assert p2["retention_amount"] == 1_500.0
    assert p2["net_payable"] == 28_500.0


def test_projects_rbac_blocks_user_without_permission(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "noproj@test.com", "password": "Secret123", "full_name": "No Proj"},
    )
    token = client.post(
        "/api/v1/auth/login", data={"username": "noproj@test.com", "password": "Secret123"}
    ).json()["access_token"]
    r = client.post(
        "/api/v1/projects",
        json={"code": "X-1", "name": "X", "contract_value": 1000},
        headers=_auth(token),
    )
    assert r.status_code == 403
