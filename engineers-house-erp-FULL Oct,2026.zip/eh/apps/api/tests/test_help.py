"""Tests for the in-app help assistant. Without an API key configured (the
test default), it must degrade gracefully rather than error."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_help_requires_auth(client):
    r = client.post("/api/v1/help/ask", json={"module": "crm", "question": "كيف؟"})
    assert r.status_code == 401


def test_help_graceful_without_api_key(client, superadmin_token):
    r = client.post(
        "/api/v1/help/ask",
        json={"module": "crm", "question": "كيف أعمل عرض سعر؟"},
        headers=_auth(superadmin_token),
    )
    assert r.status_code == 200
    body = r.json()
    assert body["ai_enabled"] is False
    assert len(body["answer"]) > 0


def test_help_accepts_any_module(client, superadmin_token):
    r = client.post(
        "/api/v1/help/ask",
        json={"module": "unknown-module", "question": "مرحبا"},
        headers=_auth(superadmin_token),
    )
    assert r.status_code == 200


def test_help_validates_question_length(client, superadmin_token):
    r = client.post(
        "/api/v1/help/ask",
        json={"module": "crm", "question": ""},
        headers=_auth(superadmin_token),
    )
    assert r.status_code == 422
