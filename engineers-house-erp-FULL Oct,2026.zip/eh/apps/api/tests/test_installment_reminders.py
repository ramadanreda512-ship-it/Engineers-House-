"""Tests for the installment reminder/overdue scan logic (broker-free)."""
from datetime import UTC, date, timedelta

from app.modules.training import service as training_service
from app.modules.training.models import (
    Cohort,
    Course,
    Enrollment,
    Installment,
    Student,
)


def _seed_enrollment_with_installments(db, tenant_id, due_dates):
    course = Course(tenant_id=tenant_id, code="C1", title="C", category="PLC")
    db.add(course)
    db.flush()
    cohort = Cohort(tenant_id=tenant_id, course_id=course.id, code="CH1", capacity=10)
    db.add(cohort)
    db.flush()
    student = Student(tenant_id=tenant_id, full_name="Test Student")
    db.add(student)
    db.flush()
    from datetime import datetime

    enrollment = Enrollment(
        tenant_id=tenant_id,
        student_id=student.id,
        cohort_id=cohort.id,
        status="active",
        total_fee=1000,
        enrolled_at=datetime.now(UTC),
    )
    db.add(enrollment)
    db.flush()
    for i, dd in enumerate(due_dates, start=1):
        db.add(
            Installment(
                enrollment_id=enrollment.id, sequence=i, amount=100, due_date=dd, status="pending"
            )
        )
    db.commit()
    return enrollment


def test_process_reminders_flags_due_soon_and_marks_overdue(client, superadmin_token):
    # Use the test session directly via the app's overridden dependency.
    import uuid

    from tests.conftest import TestingSession

    db = TestingSession()
    tenant_id = uuid.uuid4()
    today = date.today()
    _seed_enrollment_with_installments(
        db,
        tenant_id,
        due_dates=[
            today - timedelta(days=5),   # overdue
            today + timedelta(days=2),   # due soon (within 3-day window)
            today + timedelta(days=30),  # future, no action
        ],
    )

    summary = training_service.process_installment_reminders(db, reminder_window_days=3)
    assert summary["overdue_count"] == 1
    assert summary["due_soon_count"] == 1

    # The overdue one should now be persisted as status='overdue'.
    overdue = [i for i in db.query(Installment).all() if i.status == "overdue"]
    assert len(overdue) == 1
    db.close()
