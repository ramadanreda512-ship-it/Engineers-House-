"""Tests for CRM Phase 1: sales catalogue, professional quotations with
discounts/VAT, loss analysis, and the follow-up centre."""
from datetime import date, timedelta


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _account(client, h, name="مصنع اختبار"):
    return client.post(
        "/api/v1/crm/accounts",
        json={"name": name, "type": "customer", "phone": "01000000000"},
        headers=h,
    ).json()


# ---------------- Sales catalogue ----------------
def test_product_catalogue_crud(client, superadmin_token):
    h = _auth(superadmin_token)
    created = client.post(
        "/api/v1/crm/products",
        json={"code": "PLC-PANEL", "name": "لوحة تحكم PLC", "category": "لوحات",
              "unit": "piece", "unit_price": 45000, "unit_cost": 32000},
        headers=h,
    )
    assert created.status_code == 201, created.text
    assert created.json()["is_active"] is True

    dup = client.post(
        "/api/v1/crm/products",
        json={"code": "PLC-PANEL", "name": "مكرر"},
        headers=h,
    )
    assert dup.status_code == 409

    updated = client.patch(
        f"/api/v1/crm/products/{created.json()['id']}",
        json={"unit_price": 47000, "is_active": False},
        headers=h,
    ).json()
    assert updated["unit_price"] == 47000.0
    assert updated["is_active"] is False

    active = client.get("/api/v1/crm/products?active_only=true", headers=h).json()
    assert all(p["is_active"] for p in active)

    removed = client.request(
        "DELETE", f"/api/v1/crm/products/{created.json()['id']}", headers=h
    )
    assert removed.status_code == 204


# ---------------- Quotation money ----------------
def test_quotation_line_discount_header_discount_and_vat(client, superadmin_token):
    """2 x 45,000 with 10% line discount, minus 1,000 header discount,
    plus 14% VAT = 108,300."""
    h = _auth(superadmin_token)
    acc = _account(client, h)
    q = client.post(
        "/api/v1/crm/quotations",
        json={
            "account_id": acc["id"],
            "title": "توريد لوحة تحكم",
            "tax_rate": 0.14,
            "discount_amount": 1000,
            "lines": [
                {"description": "لوحة تحكم PLC", "unit": "piece", "qty": 2,
                 "unit_price": 45000, "discount_pct": 10},
                {"description": "تركيب وبرمجة", "qty": 1, "unit_price": 15000},
            ],
        },
        headers=h,
    )
    assert q.status_code == 201, q.text
    d = q.json()
    assert d["gross_total"] == 105000.0
    assert d["line_discount_total"] == 9000.0
    assert d["discount_amount"] == 1000.0
    assert d["subtotal"] == 95000.0
    assert d["tax"] == 13300.0
    assert d["total"] == 108300.0
    # The discounted line stores its net value.
    assert d["lines"][0]["line_total"] == 81000.0


def test_header_discount_cannot_exceed_net(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _account(client, h)
    d = client.post(
        "/api/v1/crm/quotations",
        json={"account_id": acc["id"], "discount_amount": 99999,
              "lines": [{"description": "بند", "qty": 1, "unit_price": 1000}]},
        headers=h,
    ).json()
    assert d["discount_amount"] == 1000.0
    assert d["subtotal"] == 0.0
    assert d["total"] == 0.0


def test_quotation_edit_recalculates_and_freezes_when_accepted(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _account(client, h)
    q = client.post(
        "/api/v1/crm/quotations",
        json={"account_id": acc["id"], "tax_rate": 0.14,
              "lines": [{"description": "بند", "qty": 1, "unit_price": 10000}]},
        headers=h,
    ).json()
    assert q["total"] == 11400.0

    edited = client.patch(
        f"/api/v1/crm/quotations/{q['id']}",
        json={"discount_amount": 2000, "title": "معدّل"},
        headers=h,
    ).json()
    assert edited["subtotal"] == 8000.0
    assert edited["total"] == 9120.0
    assert edited["title"] == "معدّل"

    # Replacing lines recalculates everything.
    relined = client.patch(
        f"/api/v1/crm/quotations/{q['id']}",
        json={"discount_amount": 0,
              "lines": [{"description": "بند جديد", "qty": 3, "unit_price": 1000}]},
        headers=h,
    ).json()
    assert relined["gross_total"] == 3000.0
    assert relined["total"] == 3420.0

    client.patch(f"/api/v1/crm/quotations/{q['id']}/status/accepted", headers=h)
    frozen = client.patch(
        f"/api/v1/crm/quotations/{q['id']}", json={"title": "لا يجب"}, headers=h
    )
    assert frozen.status_code == 409


def test_quotation_print_bundle(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = client.post(
        "/api/v1/crm/accounts",
        json={"name": "مصنع كيان", "type": "customer", "tax_number": "123-456",
              "address": "السويس", "phone": "0100"},
        headers=h,
    ).json()
    client.post(
        f"/api/v1/crm/accounts/{acc['id']}/contacts",
        json={"name": "م. خالد", "position": "مدير الصيانة", "is_primary": True},
        headers=h,
    )
    q = client.post(
        "/api/v1/crm/quotations",
        json={"account_id": acc["id"],
              "lines": [{"description": "بند", "qty": 1, "unit_price": 500}]},
        headers=h,
    ).json()
    pr = client.get(f"/api/v1/crm/quotations/{q['id']}/print", headers=h).json()
    assert pr["account_name"] == "مصنع كيان"
    assert pr["account_tax_number"] == "123-456"
    assert pr["contact_name"] == "م. خالد"
    assert pr["quotation"]["number"] == q["number"]


# ---------------- Loss analysis ----------------
def test_loss_analysis_groups_reasons_and_competitors(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _account(client, h)

    def opp(title, value):
        return client.post(
            "/api/v1/crm/opportunities",
            json={"account_id": acc["id"], "title": title, "value": value,
                  "probability": 50},
            headers=h,
        ).json()

    won = opp("صفقة مكسوبة", 200000)
    l1, l2, l3 = opp("خسارة ١", 80000), opp("خسارة ٢", 150000), opp("خسارة ٣", 30000)
    client.post(f"/api/v1/crm/opportunities/{won['id']}/win", headers=h)
    client.post(f"/api/v1/crm/opportunities/{l1['id']}/lose",
                json={"loss_reason": "السعر مرتفع", "competitor": "الفا"}, headers=h)
    client.post(f"/api/v1/crm/opportunities/{l2['id']}/lose",
                json={"loss_reason": "السعر مرتفع", "competitor": "بيتا"}, headers=h)
    client.post(f"/api/v1/crm/opportunities/{l3['id']}/lose",
                json={"loss_reason": "مدة التنفيذ", "competitor": "الفا"}, headers=h)

    la = client.get("/api/v1/crm/reports/loss-analysis", headers=h).json()
    assert la["won_count"] == 1
    assert la["lost_count"] == 3
    assert la["win_rate_pct"] == 25.0
    assert la["avg_won_value"] == 200000.0
    # Top reason first.
    assert la["by_reason"][0]["reason"] == "السعر مرتفع"
    assert la["by_reason"][0]["count"] == 2
    assert la["by_reason"][0]["value"] == 230000.0
    # Competitor appearing most often first.
    assert la["by_competitor"][0]["competitor"] == "الفا"
    assert la["by_competitor"][0]["count"] == 2


def test_losing_a_deal_requires_a_reason(client, superadmin_token):
    """Discipline: a deal cannot be marked lost without saying why — that is
    exactly what makes the loss report meaningful."""
    h = _auth(superadmin_token)
    acc = _account(client, h)
    o = client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": acc["id"], "title": "بلا سبب", "value": 1000},
        headers=h,
    ).json()
    assert client.post(
        f"/api/v1/crm/opportunities/{o['id']}/lose", json={}, headers=h
    ).status_code == 422

    ok = client.post(
        f"/api/v1/crm/opportunities/{o['id']}/lose",
        json={"loss_reason": "لا يوجد منافس مذكور"},
        headers=h,
    )
    assert ok.status_code == 200
    la = client.get("/api/v1/crm/reports/loss-analysis", headers=h).json()
    assert la["by_reason"][0]["count"] == 1
    # No competitor recorded, so the competitor breakdown stays empty.
    assert la["by_competitor"] == []


# ---------------- Follow-up centre ----------------
def test_follow_up_board_buckets(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _account(client, h, "مصنع المتابعة")
    today = date.today()

    def activity(subject, due, atype="task"):
        return client.post(
            f"/api/v1/crm/accounts/{acc['id']}/activities",
            json={"activity_type": atype, "subject": subject,
                  "activity_date": str(today), "due_date": str(due)},
            headers=h,
        )

    activity("اتصال اليوم", today, "call")
    activity("مهمة متأخرة", today - timedelta(days=5))
    activity("زيارة قادمة", today + timedelta(days=3), "site_visit")

    board = client.get("/api/v1/crm/follow-ups", headers=h).json()
    assert board["due_today_count"] == 1
    assert board["overdue_count"] == 1
    assert board["due_today"][0]["subject"] == "اتصال اليوم"
    assert board["due_today"][0]["account_phone"] == "01000000000"
    assert board["overdue"][0]["days_overdue"] == 5
    assert len(board["upcoming"]) == 1


def test_stale_opportunity_detection(client, superadmin_token):
    """An open opportunity on an account with no activity at all is stale."""
    h = _auth(superadmin_token)
    acc = _account(client, h, "عميل صامت")
    client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": acc["id"], "title": "فرصة راكدة", "value": 50000},
        headers=h,
    )
    board = client.get("/api/v1/crm/follow-ups", headers=h).json()
    assert board["stale_count"] == 1
    assert board["stale_opportunities"][0]["subject"] == "فرصة راكدة"
    assert board["stale_opportunities"][0]["value"] == 50000.0

    # Completed activities don't create follow-ups, and won deals aren't stale.
    done = client.post(
        f"/api/v1/crm/accounts/{acc['id']}/activities",
        json={"activity_type": "call", "subject": "تم", "activity_date": str(date.today()),
              "due_date": str(date.today()), "is_done": True},
        headers=h,
    )
    assert done.status_code == 201
    board2 = client.get("/api/v1/crm/follow-ups", headers=h).json()
    assert board2["stale_count"] == 0
