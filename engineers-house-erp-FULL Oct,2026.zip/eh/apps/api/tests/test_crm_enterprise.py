"""Tests for the enterprise CRM upgrade: full customer profile, auto-code,
search/filter/sort, contacts, activities timeline, and the dashboard summary."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _mk(client, h, **kw):
    body = {"name": "Acme Industrial", "type": "customer"}
    body.update(kw)
    return client.post("/api/v1/crm/accounts", json=body, headers=h)


def test_account_autocode_and_full_profile(client, superadmin_token):
    h = _auth(superadmin_token)
    r = _mk(client, h,
            name="شركة المدينة", name_en="Madina Co", classification="factory",
            city="السويس", tax_number="123-456", credit_limit=500000,
            payment_terms_days=30, score=80, health="good")
    assert r.status_code == 201, r.text
    data = r.json()
    assert data["code"] == "CUST-0001"
    assert data["name_en"] == "Madina Co"
    assert data["classification"] == "factory"
    assert data["credit_limit"] == 500000
    assert data["score"] == 80


def test_autocode_increments(client, superadmin_token):
    h = _auth(superadmin_token)
    a = _mk(client, h, name="First Co").json()
    b = _mk(client, h, name="Second Co").json()
    assert a["code"] == "CUST-0001"
    assert b["code"] == "CUST-0002"


def test_search_by_name_and_code(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk(client, h, name="Siemens Egypt", company_name="Siemens")
    _mk(client, h, name="Schneider Electric")
    res = client.get("/api/v1/crm/accounts?search=siemens", headers=h).json()
    assert res["total"] == 1
    assert "Siemens" in res["items"][0]["name"]


def test_filter_by_type_and_classification(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk(client, h, name="Lead One", type="lead")
    _mk(client, h, name="Client One", type="customer", classification="government")
    leads = client.get("/api/v1/crm/accounts?type=lead", headers=h).json()
    assert all(a["type"] == "lead" for a in leads["items"])
    gov = client.get("/api/v1/crm/accounts?classification=government", headers=h).json()
    assert gov["total"] == 1


def test_sort_by_score(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk(client, h, name="Low Score", score=10)
    _mk(client, h, name="High Score", score=95)
    res = client.get("/api/v1/crm/accounts?sort=score", headers=h).json()
    assert res["items"][0]["score"] == 95


def test_contacts_with_decision_maker(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk(client, h).json()
    c = client.post(f"/api/v1/crm/accounts/{acc['id']}/contacts", json={
        "name": "Eng. Ahmed", "position": "Plant Manager", "department": "Operations",
        "is_decision_maker": True, "is_primary": True, "whatsapp": "+201000000000",
    }, headers=h)
    assert c.status_code == 201, c.text
    assert c.json()["is_decision_maker"] is True

    listed = client.get(f"/api/v1/crm/accounts/{acc['id']}/contacts", headers=h).json()
    assert len(listed) == 1
    assert listed[0]["department"] == "Operations"


def test_activity_timeline(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk(client, h).json()
    # Log a call and a task.
    client.post(f"/api/v1/crm/accounts/{acc['id']}/activities", json={
        "activity_type": "call", "subject": "Intro call", "body": "Discussed needs",
    }, headers=h)
    task = client.post(f"/api/v1/crm/accounts/{acc['id']}/activities", json={
        "activity_type": "task", "subject": "Send quotation", "due_date": "2026-07-01",
    }, headers=h)
    assert task.status_code == 201, task.text

    timeline = client.get(f"/api/v1/crm/accounts/{acc['id']}/activities", headers=h).json()
    assert len(timeline) == 2

    # Mark the task done.
    done = client.patch(f"/api/v1/crm/activities/{task.json()['id']}", json={"is_done": True}, headers=h)
    assert done.status_code == 200
    assert done.json()["is_done"] is True


def test_crm_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk(client, h, name="Client A", type="customer")
    _mk(client, h, name="Lead B", type="lead")
    summary = client.get("/api/v1/crm/summary", headers=h).json()
    assert summary["total_accounts"] >= 2
    assert "customer" in summary["by_type"]
    assert "lead" in summary["by_type"]


def test_backward_compat_minimal_create(client, superadmin_token):
    h = _auth(superadmin_token)
    # The original minimal payload (name + type only) must still work.
    r = client.post("/api/v1/crm/accounts", json={"name": "Minimal Co", "type": "lead"}, headers=h)
    assert r.status_code == 201
    assert r.json()["currency"] == "EGP"
