"""Tests for the AI Financial Analyst. The snapshot is always computed; the AI
call is skipped gracefully when no API key is configured (the test environment)."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc_id(client, h, code):
    accs = client.get("/api/v1/accounting/accounts", headers=h).json()
    return next(a["id"] for a in accs if a["code"] == code)


def test_snapshot_reflects_postings(client, superadmin_token):
    h = _auth(superadmin_token)
    cash = _acc_id(client, h, "1101")
    rev = _acc_id(client, h, "4101")
    # Record 50,000 revenue.
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [
            {"account_id": cash, "debit": 50000},
            {"account_id": rev, "credit": 50000},
        ]}, headers=h)

    snap = client.get("/api/v1/analyst/snapshot", headers=h)
    assert snap.status_code == 200, snap.text
    data = snap.json()
    assert data["total_revenue"] == 50000
    assert data["cash_position"] == 50000


def test_ask_returns_snapshot_without_api_key(client, superadmin_token):
    h = _auth(superadmin_token)
    r = client.post("/api/v1/analyst/ask", json={"question": "ما هو وضعي المالي؟"}, headers=h)
    assert r.status_code == 200, r.text
    body = r.json()
    # Without an API key in the test env, AI is disabled but the snapshot is present.
    assert body["ai_enabled"] is False
    assert "snapshot" in body
    assert "answer" in body
