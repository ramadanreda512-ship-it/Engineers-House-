"""Tests for the HR module: employees, leave approval, payroll."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_employee(client, h, code="EMP-001", salary=8000, balance=21):
    return client.post(
        "/api/v1/hr/employees",
        json={
            "code": code,
            "full_name": "Mohamed Ali",
            "department": "Engineering",
            "base_salary": salary,
            "annual_leave_balance": balance,
        },
        headers=h,
    )


def test_employee_code_unique(client, superadmin_token):
    h = _auth(superadmin_token)
    assert _make_employee(client, h, "DUP-E").status_code == 201
    assert _make_employee(client, h, "DUP-E").status_code == 409


def test_leave_days_computed_and_balance_decremented_on_approval(client, superadmin_token):
    h = _auth(superadmin_token)
    emp = _make_employee(client, h, "LV-1", balance=21).json()

    leave = client.post(
        "/api/v1/hr/leaves",
        json={
            "employee_id": emp["id"],
            "leave_type": "annual",
            "start_date": "2026-07-01",
            "end_date": "2026-07-05",
        },
        headers=h,
    )
    assert leave.status_code == 201, leave.text
    assert leave.json()["days"] == 5  # inclusive
    assert leave.json()["status"] == "pending"
    leave_id = leave.json()["id"]

    approved = client.post(f"/api/v1/hr/leaves/{leave_id}/approve", headers=h)
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"

    emp_after = client.get(f"/api/v1/hr/employees/{emp['id']}", headers=h).json()
    assert emp_after["annual_leave_balance"] == 16  # 21 - 5


def test_leave_exceeding_balance_is_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    emp = _make_employee(client, h, "LV-2", balance=3).json()
    leave = client.post(
        "/api/v1/hr/leaves",
        json={
            "employee_id": emp["id"],
            "leave_type": "annual",
            "start_date": "2026-07-01",
            "end_date": "2026-07-10",
        },
        headers=h,
    )
    assert leave.status_code == 400


def test_cannot_decide_leave_twice(client, superadmin_token):
    h = _auth(superadmin_token)
    emp = _make_employee(client, h, "LV-3").json()
    leave_id = client.post(
        "/api/v1/hr/leaves",
        json={"employee_id": emp["id"], "start_date": "2026-08-01", "end_date": "2026-08-02"},
        headers=h,
    ).json()["id"]
    client.post(f"/api/v1/hr/leaves/{leave_id}/approve", headers=h)
    second = client.post(f"/api/v1/hr/leaves/{leave_id}/reject", headers=h)
    assert second.status_code == 409


def test_payroll_net_computed_and_unique_per_period(client, superadmin_token):
    h = _auth(superadmin_token)
    emp = _make_employee(client, h, "PAY-1", salary=10000).json()

    pay = client.post(
        "/api/v1/hr/payroll",
        json={
            "employee_id": emp["id"],
            "period": "2026-06",
            "allowances": 2000,
            "deductions": 1500,
        },
        headers=h,
    )
    assert pay.status_code == 201, pay.text
    assert pay.json()["net_pay"] == 10500  # 10000 + 2000 - 1500

    dup = client.post(
        "/api/v1/hr/payroll",
        json={"employee_id": emp["id"], "period": "2026-06"},
        headers=h,
    )
    assert dup.status_code == 409


def test_hr_summary(client, superadmin_token):
    h = _auth(superadmin_token)
    _make_employee(client, h, "SUM-E1", salary=9000)
    summary = client.get("/api/v1/hr/summary", headers=h).json()
    assert summary["total_employees"] >= 1
    assert summary["active_employees"] >= 1
    assert summary["total_monthly_payroll"] >= 9000
