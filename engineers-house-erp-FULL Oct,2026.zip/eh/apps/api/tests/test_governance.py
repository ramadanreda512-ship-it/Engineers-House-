"""Tests for the governance module: approval workflow and budget variance."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _acc_id(client, h, code):
    accs = client.get("/api/v1/accounting/accounts", headers=h).json()
    return next(a["id"] for a in accs if a["code"] == code)


def _je(client, h):
    cash = _acc_id(client, h, "1101")
    rev = _acc_id(client, h, "4101")
    return client.post("/api/v1/accounting/journal-entries", json={
        "lines": [{"account_id": cash, "debit": 1000}, {"account_id": rev, "credit": 1000}],
    }, headers=h).json()


def test_approval_request_and_approve(client, superadmin_token):
    h = _auth(superadmin_token)
    entry = _je(client, h)
    req = client.post("/api/v1/governance/approvals", json={
        "entity_type": "journal_entry", "entity_id": entry["id"],
        "title": "Large journal entry", "amount": 1000,
    }, headers=h)
    assert req.status_code == 201, req.text
    assert req.json()["status"] == "pending"

    approval_id = req.json()["id"]
    done = client.post(f"/api/v1/governance/approvals/{approval_id}/approve",
                       json={"comments": "Looks good"}, headers=h)
    assert done.status_code == 200
    assert done.json()["status"] == "approved"
    assert done.json()["approved_by"] is not None


def test_approval_reject_and_double_decision_blocked(client, superadmin_token):
    h = _auth(superadmin_token)
    entry = _je(client, h)
    req = client.post("/api/v1/governance/approvals", json={
        "entity_type": "journal_entry", "entity_id": entry["id"], "title": "JE", "amount": 1000,
    }, headers=h).json()
    client.post(f"/api/v1/governance/approvals/{req['id']}/reject", json={"comments": "No"}, headers=h)
    # Deciding again should fail.
    again = client.post(f"/api/v1/governance/approvals/{req['id']}/approve", json={}, headers=h)
    assert again.status_code == 409


def test_pending_filter(client, superadmin_token):
    h = _auth(superadmin_token)
    entry = _je(client, h)
    client.post("/api/v1/governance/approvals", json={
        "entity_type": "journal_entry", "entity_id": entry["id"], "title": "JE", "amount": 1000,
    }, headers=h)
    pending = client.get("/api/v1/governance/approvals?status=pending", headers=h).json()
    assert len(pending) >= 1
    assert all(a["status"] == "pending" for a in pending)


def test_budget_create_unique_and_variance(client, superadmin_token):
    h = _auth(superadmin_token)
    mat = _acc_id(client, h, "510101")
    cash = _acc_id(client, h, "1101")
    # Annual budget for material cost: 100,000 for 2026.
    b = client.post("/api/v1/governance/budgets", json={
        "account_id": mat, "fiscal_year": 2026, "amount": 100000,
    }, headers=h)
    assert b.status_code == 201, b.text

    # Duplicate (same account+year+no month) should fail.
    dup = client.post("/api/v1/governance/budgets", json={
        "account_id": mat, "fiscal_year": 2026, "amount": 50000,
    }, headers=h)
    assert dup.status_code == 409

    # Post 70,000 actual material cost.
    client.post("/api/v1/accounting/journal-entries", json={
        "lines": [{"account_id": mat, "debit": 70000}, {"account_id": cash, "credit": 70000}],
    }, headers=h)

    variance = client.get("/api/v1/governance/budgets/variance?fiscal_year=2026", headers=h).json()
    row = next(r for r in variance["rows"] if r["account_code"] == "510101")
    assert row["budget"] == 100000
    assert row["actual"] == 70000
    assert row["variance"] == 30000


def test_budget_update_and_delete(client, superadmin_token):
    h = _auth(superadmin_token)
    rev = _acc_id(client, h, "4101")
    b = client.post("/api/v1/governance/budgets", json={
        "account_id": rev, "fiscal_year": 2026, "amount": 500000,
    }, headers=h).json()
    upd = client.patch(f"/api/v1/governance/budgets/{b['id']}", json={"amount": 600000}, headers=h)
    assert upd.status_code == 200
    assert upd.json()["amount"] == 600000
    assert client.delete(f"/api/v1/governance/budgets/{b['id']}", headers=h).status_code == 204
