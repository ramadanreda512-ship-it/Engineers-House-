"""Tests for the three team access levels (manager / supervisor / operator)
and the user-administration screen behind them."""
import pytest


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def role_ids(client, superadmin_token):
    roles = client.get("/api/v1/auth/roles", headers=_auth(superadmin_token)).json()
    return {r["name"]: r["id"] for r in roles}


def _make_user(client, admin_h, role_id, email, password="Passw0rd!23"):
    created = client.post(
        "/api/v1/auth/users",
        json={"email": email, "full_name": "موظف", "password": password,
              "role_id": role_id},
        headers=admin_h,
    )
    assert created.status_code == 201, created.text
    token = client.post(
        "/api/v1/auth/login", data={"username": email, "password": password}
    ).json()["access_token"]
    return created.json(), _auth(token)


def test_three_roles_exist_with_expected_scope(client, superadmin_token, role_ids):
    """Manager has everything, supervisor a broad subset, operator a small one."""
    h = _auth(superadmin_token)
    roles = {r["name"]: r for r in client.get("/api/v1/auth/roles", headers=h).json()}
    assert {"المدير", "المشرف", "المستخدم"}.issubset(roles.keys())
    manager = roles["المدير"]["permission_count"]
    supervisor = roles["المشرف"]["permission_count"]
    operator = roles["المستخدم"]["permission_count"]
    assert manager > supervisor > operator > 0


def test_supervisor_can_add_but_not_delete(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    _, sup_h = _make_user(client, h, role_ids["المشرف"], "sup1@test.com")

    # Can create operational data.
    student = client.post(
        "/api/v1/training/students", json={"full_name": "طالب"}, headers=sup_h
    )
    assert student.status_code == 201

    # Cannot delete it.
    blocked = client.request(
        "DELETE", f"/api/v1/training/students/{student.json()['id']}", headers=sup_h
    )
    assert blocked.status_code == 403

    # Cannot touch backups or category management.
    assert client.get("/api/v1/backup/stats", headers=sup_h).status_code == 403
    assert client.post(
        "/api/v1/settings/categories",
        json={"kind": "course", "code": "ZZ", "name_ar": "ز"},
        headers=sup_h,
    ).status_code == 403
    # But can read categories (needed for dropdowns).
    assert client.get(
        "/api/v1/settings/categories?kind=course", headers=sup_h
    ).status_code == 200


def test_operator_daily_entry_only(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    _, op_h = _make_user(client, h, role_ids["المستخدم"], "op1@test.com")

    # Daily front-desk work is allowed.
    assert client.post(
        "/api/v1/training/leads",
        json={"name": "مستفسر", "source": "whatsapp"},
        headers=op_h,
    ).status_code == 201
    assert client.get("/api/v1/training/courses", headers=op_h).status_code == 200

    # Money and structural changes are not.
    assert client.post(
        "/api/v1/training/courses",
        json={"code": "X1", "title": "دورة اختبار", "category": "PLC", "price": 100},
        headers=op_h,
    ).status_code == 403
    assert client.get("/api/v1/finance/invoices", headers=op_h).status_code == 403
    assert client.get("/api/v1/backup/stats", headers=op_h).status_code == 403


def test_only_manager_reaches_user_administration(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    _, sup_h = _make_user(client, h, role_ids["المشرف"], "sup2@test.com")
    _, op_h = _make_user(client, h, role_ids["المستخدم"], "op2@test.com")

    assert client.get("/api/v1/auth/users", headers=h).status_code == 200
    assert client.get("/api/v1/auth/users", headers=sup_h).status_code == 403
    assert client.get("/api/v1/auth/users", headers=op_h).status_code == 403


def test_suspend_blocks_login_and_reactivate_restores(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    user, _ = _make_user(client, h, role_ids["المستخدم"], "temp@test.com")

    suspended = client.patch(
        f"/api/v1/auth/users/{user['id']}", json={"status": "suspended"}, headers=h
    )
    assert suspended.json()["status"] == "suspended"
    blocked = client.post(
        "/api/v1/auth/login",
        data={"username": "temp@test.com", "password": "Passw0rd!23"},
    )
    assert blocked.status_code >= 400

    client.patch(f"/api/v1/auth/users/{user['id']}", json={"status": "active"}, headers=h)
    ok = client.post(
        "/api/v1/auth/login",
        data={"username": "temp@test.com", "password": "Passw0rd!23"},
    )
    assert ok.status_code == 200


def test_change_role_changes_access(client, superadmin_token, role_ids):
    """Promoting an operator to supervisor immediately widens their access."""
    h = _auth(superadmin_token)
    user, op_h = _make_user(client, h, role_ids["المستخدم"], "promote@test.com")
    # As operator: cannot create a course.
    assert client.post(
        "/api/v1/training/courses",
        json={"code": "P1", "title": "دورة اختبار", "category": "PLC", "price": 1000},
        headers=op_h,
    ).status_code == 403

    client.patch(
        f"/api/v1/auth/users/{user['id']}",
        json={"role_id": role_ids["المشرف"]},
        headers=h,
    )
    # Re-login to pick up the new role.
    token = client.post(
        "/api/v1/auth/login",
        data={"username": "promote@test.com", "password": "Passw0rd!23"},
    ).json()["access_token"]
    assert client.post(
        "/api/v1/training/courses",
        json={"code": "P2", "title": "دورة اختبار", "category": "PLC", "price": 1000},
        headers=_auth(token),
    ).status_code == 201


def test_password_reset_and_manager_account_protected(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    user, _ = _make_user(client, h, role_ids["المشرف"], "reset@test.com")

    assert client.post(
        f"/api/v1/auth/users/{user['id']}/reset-password",
        json={"new_password": "Brand!New2026"},
        headers=h,
    ).status_code == 204
    assert client.post(
        "/api/v1/auth/login",
        data={"username": "reset@test.com", "password": "Brand!New2026"},
    ).status_code == 200

    # The main manager account can neither be deleted nor suspended.
    users = client.get("/api/v1/auth/users", headers=h).json()
    admin = next(u for u in users if u["is_superadmin"])
    assert client.request(
        "DELETE", f"/api/v1/auth/users/{admin['id']}", headers=h
    ).status_code == 409
    assert client.patch(
        f"/api/v1/auth/users/{admin['id']}", json={"status": "suspended"}, headers=h
    ).status_code == 409


def test_duplicate_email_rejected(client, superadmin_token, role_ids):
    h = _auth(superadmin_token)
    _make_user(client, h, role_ids["المشرف"], "dup@test.com")
    again = client.post(
        "/api/v1/auth/users",
        json={"email": "dup@test.com", "full_name": "مكرر",
              "password": "Passw0rd!23", "role_id": role_ids["المشرف"]},
        headers=h,
    )
    assert again.status_code == 409
