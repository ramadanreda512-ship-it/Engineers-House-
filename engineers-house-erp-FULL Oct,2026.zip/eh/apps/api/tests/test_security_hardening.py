"""Security hardening required before the system goes online."""
import pytest

from app.core.config import Settings, validate_production


def _login(client, email, password):
    return client.post("/api/v1/auth/login", data={"username": email, "password": password})


def test_login_lockout_after_repeated_failures(client, superadmin_token):
    for _ in range(5):
        assert _login(client, "admin@test.com", "wrong-pass").status_code == 400
    blocked = _login(client, "admin@test.com", "wrong-pass")
    assert blocked.status_code == 429
    # Even the correct password is refused while locked.
    assert _login(client, "admin@test.com", "Passw0rd!").status_code == 429


def test_successful_login_clears_failures(client, superadmin_token):
    for _ in range(4):
        _login(client, "admin@test.com", "wrong-pass")
    assert _login(client, "admin@test.com", "Passw0rd!").status_code == 200
    # Counter reset: four more failures are still allowed before lockout.
    for _ in range(4):
        assert _login(client, "admin@test.com", "bad").status_code == 400


def test_change_own_password(client, superadmin_token):
    h = {"Authorization": f"Bearer {superadmin_token}"}
    wrong = client.post("/api/v1/auth/me/change-password",
                        json={"current_password": "nope", "new_password": "NewStrong!2026"},
                        headers=h)
    assert wrong.status_code == 400
    ok = client.post("/api/v1/auth/me/change-password",
                     json={"current_password": "Passw0rd!", "new_password": "NewStrong!2026"},
                     headers=h)
    assert ok.status_code == 204
    assert _login(client, "admin@test.com", "Passw0rd!").status_code == 400
    assert _login(client, "admin@test.com", "NewStrong!2026").status_code == 200


def test_change_password_requires_auth(client):
    r = client.post("/api/v1/auth/me/change-password",
                    json={"current_password": "a", "new_password": "abcdefgh"})
    assert r.status_code == 401


def test_registration_closed_when_disabled(client, monkeypatch):
    from app.core.config import get_settings

    monkeypatch.setattr(get_settings(), "public_registration_enabled", False)
    r = client.post("/api/v1/auth/register",
                    json={"email": "x@y.com", "password": "Passw0rd!23", "full_name": "زائر"})
    assert r.status_code == 404


def test_production_guard_rejects_unsafe_settings():
    with pytest.raises(RuntimeError):
        validate_production(Settings(environment="production", jwt_secret="short"))
    with pytest.raises(RuntimeError):
        validate_production(Settings(environment="production", jwt_secret="x" * 40,
                                     dev_login_enabled=True))
    with pytest.raises(RuntimeError):
        validate_production(Settings(environment="production", jwt_secret="x" * 40,
                                     public_registration_enabled=True))
    # A properly configured production server starts.
    validate_production(Settings(environment="production", jwt_secret="x" * 40,
                                 public_registration_enabled=False))
    # Development is never blocked.
    validate_production(Settings(environment="development", jwt_secret="short"))


def test_seed_does_not_reset_existing_passwords(monkeypatch, tmp_path):
    """A server restart must never bring back the documented default password."""
    import importlib
    import os

    db_file = tmp_path / "seed.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_file}")
    from app.core import config

    config.get_settings.cache_clear()
    try:
        import app.core.database as database

        importlib.reload(database)
        import app.seed as seed

        importlib.reload(seed)
        seed.run()
        from sqlalchemy import select

        from app.core.security import hash_password, verify_password
        from app.modules.identity.models import User

        with database.SessionLocal() as db:
            admin = db.scalar(select(User).where(User.email == "admin@engineershouse.com"))
            admin.hashed_password = hash_password("MyPrivate!Pass9")
            db.commit()
        seed.run()  # simulated restart
        with database.SessionLocal() as db:
            admin = db.scalar(select(User).where(User.email == "admin@engineershouse.com"))
            assert verify_password("MyPrivate!Pass9", admin.hashed_password)
            assert not verify_password("ChangeMe!2026", admin.hashed_password)
    finally:
        os.environ["DATABASE_URL"] = "sqlite://"
        config.get_settings.cache_clear()
        import app.core.database as database

        importlib.reload(database)
