"""Tests for the inventory & procurement module."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _make_item(client, h, sku="CABLE-25", unit_cost=100, reorder=10):
    return client.post(
        "/api/v1/inventory/items",
        json={
            "sku": sku,
            "name": "Cable 25mm",
            "unit": "m",
            "reorder_level": reorder,
            "unit_cost": unit_cost,
        },
        headers=h,
    )


def test_sku_must_be_unique(client, superadmin_token):
    h = _auth(superadmin_token)
    assert _make_item(client, h, "DUP-SKU").status_code == 201
    assert _make_item(client, h, "DUP-SKU").status_code == 409


def test_stock_movements_update_quantity(client, superadmin_token):
    h = _auth(superadmin_token)
    item = _make_item(client, h, "MOV-1").json()
    item_id = item["id"]
    assert item["quantity_on_hand"] == 0

    client.post(
        f"/api/v1/inventory/items/{item_id}/movements",
        json={"movement_type": "in", "quantity": 100},
        headers=h,
    )
    after_in = client.get(f"/api/v1/inventory/items/{item_id}", headers=h).json()
    assert after_in["quantity_on_hand"] == 100

    client.post(
        f"/api/v1/inventory/items/{item_id}/movements",
        json={"movement_type": "out", "quantity": 30},
        headers=h,
    )
    after_out = client.get(f"/api/v1/inventory/items/{item_id}", headers=h).json()
    assert after_out["quantity_on_hand"] == 70


def test_cannot_remove_more_than_on_hand(client, superadmin_token):
    h = _auth(superadmin_token)
    item = _make_item(client, h, "NEG-1").json()
    client.post(
        f"/api/v1/inventory/items/{item['id']}/movements",
        json={"movement_type": "in", "quantity": 10},
        headers=h,
    )
    over = client.post(
        f"/api/v1/inventory/items/{item['id']}/movements",
        json={"movement_type": "out", "quantity": 50},
        headers=h,
    )
    assert over.status_code == 400


def test_purchase_order_receive_raises_stock(client, superadmin_token):
    h = _auth(superadmin_token)
    item = _make_item(client, h, "PO-ITEM-1").json()
    supplier = client.post(
        "/api/v1/inventory/suppliers", json={"name": "Cable Supplier Co"}, headers=h
    ).json()

    po = client.post(
        "/api/v1/inventory/purchase-orders",
        json={
            "supplier_id": supplier["id"],
            "lines": [{"item_id": item["id"], "quantity": 200, "unit_price": 95}],
        },
        headers=h,
    )
    assert po.status_code == 201, po.text
    po_data = po.json()
    assert po_data["total"] == 19000  # 200 * 95
    assert po_data["status"] == "ordered"
    line_id = po_data["lines"][0]["id"]

    # Partial receipt
    recv = client.post(
        f"/api/v1/inventory/purchase-orders/{po_data['id']}/receive",
        json={"line_id": line_id, "received_qty": 120},
        headers=h,
    )
    assert recv.status_code == 200, recv.text
    assert recv.json()["status"] == "partially_received"

    item_after = client.get(f"/api/v1/inventory/items/{item['id']}", headers=h).json()
    assert item_after["quantity_on_hand"] == 120

    # Receive the rest -> fully received
    recv2 = client.post(
        f"/api/v1/inventory/purchase-orders/{po_data['id']}/receive",
        json={"line_id": line_id, "received_qty": 80},
        headers=h,
    )
    assert recv2.json()["status"] == "received"
    item_final = client.get(f"/api/v1/inventory/items/{item['id']}", headers=h).json()
    assert item_final["quantity_on_hand"] == 200


def test_over_receive_is_rejected(client, superadmin_token):
    h = _auth(superadmin_token)
    item = _make_item(client, h, "PO-ITEM-2").json()
    supplier = client.post("/api/v1/inventory/suppliers", json={"name": "S2"}, headers=h).json()
    po = client.post(
        "/api/v1/inventory/purchase-orders",
        json={
            "supplier_id": supplier["id"],
            "lines": [{"item_id": item["id"], "quantity": 50, "unit_price": 10}],
        },
        headers=h,
    ).json()
    over = client.post(
        f"/api/v1/inventory/purchase-orders/{po['id']}/receive",
        json={"line_id": po["lines"][0]["id"], "received_qty": 80},
        headers=h,
    )
    assert over.status_code == 400


def test_inventory_summary_and_low_stock(client, superadmin_token):
    h = _auth(superadmin_token)
    item = _make_item(client, h, "LOW-1", unit_cost=50, reorder=20).json()
    # add 10 -> below reorder level of 20 => low stock
    client.post(
        f"/api/v1/inventory/items/{item['id']}/movements",
        json={"movement_type": "in", "quantity": 10},
        headers=h,
    )
    summary = client.get("/api/v1/inventory/summary", headers=h).json()
    assert summary["total_items"] >= 1
    assert summary["low_stock_items"] >= 1
    assert summary["total_stock_value"] >= 500  # 10 * 50
