"""Tests for CRM phase 3+4: sales pipeline (stage moves, loss reasons,
weighted forecast), customer 360 view, and CSV export."""


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _mk_account(client, h, name="Kayan Factory"):
    return client.post(
        "/api/v1/crm/accounts",
        json={"name": name, "type": "customer", "classification": "factory"},
        headers=h,
    ).json()


def _mk_opp(client, h, account_id, title="Panel upgrade", value=100000, prob=50):
    return client.post(
        "/api/v1/crm/opportunities",
        json={
            "account_id": account_id,
            "title": title,
            "value": value,
            "probability": prob,
        },
        headers=h,
    ).json()


def test_opportunity_stage_moves_and_loss_reason(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk_account(client, h)
    opp = _mk_opp(client, h, acc["id"])

    # Advance through the funnel.
    r = client.patch(
        f"/api/v1/crm/opportunities/{opp['id']}",
        json={"stage": "qualified", "probability": 60},
        headers=h,
    )
    assert r.status_code == 200, r.text
    assert r.json()["stage"] == "qualified"

    # Mark lost with a reason and competitor.
    lost = client.patch(
        f"/api/v1/crm/opportunities/{opp['id']}",
        json={"stage": "lost", "loss_reason": "السعر", "competitor": "شركة منافسة"},
        headers=h,
    ).json()
    assert lost["stage"] == "lost"
    assert lost["probability"] == 0
    assert lost["loss_reason"] == "السعر"


def test_won_sets_probability_100(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk_account(client, h)
    opp = _mk_opp(client, h, acc["id"], prob=70)
    won = client.patch(
        f"/api/v1/crm/opportunities/{opp['id']}",
        json={"stage": "won"},
        headers=h,
    ).json()
    assert won["probability"] == 100


def test_pipeline_groups_and_forecast(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk_account(client, h)
    _mk_opp(client, h, acc["id"], title="Deal A", value=100000, prob=50)
    _mk_opp(client, h, acc["id"], title="Deal B", value=50000, prob=20)
    won = _mk_opp(client, h, acc["id"], title="Deal C", value=30000, prob=90)
    client.patch(
        f"/api/v1/crm/opportunities/{won['id']}", json={"stage": "won"}, headers=h
    )

    pipe = client.get("/api/v1/crm/pipeline", headers=h).json()
    assert pipe["open_total"] == 150000.0
    # weighted: 100000*0.5 + 50000*0.2 = 60000
    assert pipe["weighted_forecast"] == 60000.0
    assert pipe["won_total"] == 30000.0
    new_col = next(s for s in pipe["stages"] if s["stage"] == "new")
    assert new_col["count"] == 2
    assert new_col["items"][0]["account_name"] == "Kayan Factory"


def test_account_360(client, superadmin_token):
    h = _auth(superadmin_token)
    acc = _mk_account(client, h)
    # Linked project
    client.post(
        "/api/v1/projects",
        json={
            "code": "PRJ-360",
            "name": "Kayan Panels",
            "contract_value": 500000,
            "account_id": acc["id"],
        },
        headers=h,
    )
    # Linked opportunity (open)
    _mk_opp(client, h, acc["id"], value=80000)
    # Linked student + enrollment
    course = client.post(
        "/api/v1/training/courses",
        json={"code": "PLC-1", "title": "PLC Basics", "category": "PLC", "price": 4000},
        headers=h,
    ).json()
    cohort = client.post(
        "/api/v1/training/cohorts",
        json={"course_id": course["id"], "code": "PLC-C1", "capacity": 10},
        headers=h,
    ).json()
    student = client.post(
        "/api/v1/training/students",
        json={"full_name": "Eng Ali", "account_id": acc["id"]},
        headers=h,
    ).json()
    client.post(
        "/api/v1/training/enrollments",
        json={
            "student_id": student["id"],
            "cohort_id": cohort["id"],
            "total_fee": 4000,
            "discount": 0,
            "installments_count": 1,
        },
        headers=h,
    )

    v = client.get(f"/api/v1/crm/accounts/{acc['id']}/summary360", headers=h)
    assert v.status_code == 200, v.text
    data = v.json()
    assert data["projects_count"] == 1
    assert data["projects_value"] == 500000.0
    assert data["open_opportunities"] == 1
    assert data["open_opportunities_value"] == 80000.0
    assert data["students_count"] == 1
    assert data["training_fees"] == 4000.0


def test_accounts_export_csv(client, superadmin_token):
    h = _auth(superadmin_token)
    _mk_account(client, h, name="Export Co")
    r = client.get("/api/v1/crm/accounts-export", headers=h)
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["filename"].startswith("customers-")
    assert "Export Co" in data["content"]
    assert "Code" in data["content"]


def test_win_lose_move_endpoints(client, superadmin_token):
    """The dedicated win/lose/move endpoints (kanban quick actions)."""
    h = {"Authorization": f"Bearer {superadmin_token}"}
    acc = client.post(
        "/api/v1/crm/accounts", json={"name": "Kanban Co", "type": "customer"}, headers=h
    ).json()
    opp = client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": acc["id"], "title": "Panel deal", "value": 50000, "probability": 40},
        headers=h,
    ).json()

    # Move along open stages.
    moved = client.post(f"/api/v1/crm/opportunities/{opp['id']}/move/proposal", headers=h)
    assert moved.status_code == 200, moved.text
    assert moved.json()["stage"] == "proposal"

    # Invalid stage rejected.
    bad = client.post(f"/api/v1/crm/opportunities/{opp['id']}/move/won", headers=h)
    assert bad.status_code == 409

    # Win.
    won = client.post(f"/api/v1/crm/opportunities/{opp['id']}/win", headers=h)
    assert won.json()["stage"] == "won"
    assert won.json()["probability"] == 100

    # Lose another one with a reason.
    opp2 = client.post(
        "/api/v1/crm/opportunities",
        json={"account_id": acc["id"], "title": "SCADA deal", "value": 30000},
        headers=h,
    ).json()
    lost = client.post(
        f"/api/v1/crm/opportunities/{opp2['id']}/lose",
        json={"loss_reason": "السعر أعلى من المنافس", "competitor": "شركة X"},
        headers=h,
    )
    assert lost.json()["stage"] == "lost"
    assert lost.json()["loss_reason"] == "السعر أعلى من المنافس"


def test_quotation_status_flow(client, superadmin_token):
    """Quotation lifecycle: draft -> sent -> accepted."""
    h = {"Authorization": f"Bearer {superadmin_token}"}
    acc = client.post(
        "/api/v1/crm/accounts", json={"name": "Quote Co", "type": "customer"}, headers=h
    ).json()
    q = client.post(
        "/api/v1/crm/quotations",
        json={
            "account_id": acc["id"],
            "tax_rate": 0.14,
            "lines": [
                {"description": "لوحة تحكم PLC", "qty": 2, "unit_price": 15000},
                {"description": "برمجة وتشغيل", "qty": 1, "unit_price": 8000},
            ],
        },
        headers=h,
    )
    assert q.status_code == 201, q.text
    quote = q.json()
    assert quote["subtotal"] == 38000.0
    assert quote["total"] == 43320.0  # 38000 * 1.14
    assert quote["status"] == "draft"

    sent = client.patch(f"/api/v1/crm/quotations/{quote['id']}/status/sent", headers=h)
    assert sent.json()["status"] == "sent"
    accepted = client.patch(
        f"/api/v1/crm/quotations/{quote['id']}/status/accepted", headers=h
    )
    assert accepted.json()["status"] == "accepted"

    bad = client.patch(f"/api/v1/crm/quotations/{quote['id']}/status/nonsense", headers=h)
    assert bad.status_code == 409
