"""Idempotent seed: tables, default tenant, permission catalog, system roles, superadmin.

Run with:  python -m app.seed
"""
from __future__ import annotations

from sqlalchemy import func, select

import app.modules.crm.models  # noqa: F401
import app.modules.projects.models  # noqa: F401
import app.modules.training.models  # noqa: F401
from app.core.config import get_settings
from app.core.database import SessionLocal, engine
from app.core.security import hash_password
from app.modules.identity.models import Permission, Role, Tenant, User
from app.shared.base_model import Base

settings = get_settings()

PERMISSIONS = [
    ("crm.account.view", "crm"),
    ("crm.account.create", "crm"),
    ("crm.account.edit", "crm"),
    ("crm.contact.create", "crm"),
    ("crm.opportunity.view", "crm"),
    ("crm.opportunity.create", "crm"),
    ("crm.quotation.view", "crm"),
    ("crm.quotation.create", "crm"),
    ("crm.quotation.approve", "crm"),
    ("crm.account.delete", "crm"),
    ("crm.product.manage", "crm"),
    ("settings.category.view", "settings"),
    ("settings.category.manage", "settings"),
    ("backup.manage", "backup"),
    ("users.manage", "identity"),
    ("training.course.view", "training"),
    ("training.course.create", "training"),
    ("training.instructor.create", "training"),
    ("training.cohort.create", "training"),
    ("training.session.create", "training"),
    ("training.student.create", "training"),
    ("training.enrollment.create", "training"),
    ("training.enrollment.edit", "training"),
    ("training.attendance.mark", "training"),
    ("training.assessment.record", "training"),
    ("training.certificate.issue", "training"),
    ("training.course.delete", "training"),
    ("training.student.delete", "training"),
    ("training.enrollment.delete", "training"),
    ("training.cohort.delete", "training"),
    ("project.view", "project"),
    ("project.manage", "project"),
    ("project.create", "project"),
    ("project.boq.manage", "project"),
    ("project.variation.request", "project"),
    ("project.variation.approve", "project"),
    ("project.billing.create", "project"),
    ("project.retention.release", "project"),
    ("project.subcontractor.create", "project"),
    ("project.subcontract.award", "project"),
    ("project.subcontract.payment", "project"),
    ("project.delete", "project"),
    ("finance.invoice.view", "finance"),
    ("finance.invoice.create", "finance"),
    ("finance.payment.record", "finance"),
    ("finance.expense.create", "finance"),
    ("finance.expense.delete", "finance"),
    ("cmms.asset.view", "cmms"),
    ("cmms.asset.manage", "cmms"),
    ("cmms.workorder.manage", "cmms"),
    ("inventory.item.view", "inventory"),
    ("inventory.item.manage", "inventory"),
    ("inventory.movement.record", "inventory"),
    ("inventory.po.manage", "inventory"),
    ("hr.employee.view", "hr"),
    ("hr.employee.manage", "hr"),
    ("hr.leave.request", "hr"),
    ("hr.leave.approve", "hr"),
    ("hr.payroll.manage", "hr"),
    ("tender.view", "tendering"),
    ("tender.manage", "tendering"),
    ("accounting.view", "accounting"),
    ("accounting.manage", "accounting"),
    ("partners.view", "partners"),
    ("partners.manage", "partners"),
    ("fixedassets.view", "fixedassets"),
    ("fixedassets.manage", "fixedassets"),
    ("governance.view", "governance"),
    ("governance.manage", "governance"),
    ("governance.approve", "governance"),
]

ROLES = {
    # ===== The three main access levels for the team =====
    # 1) المدير — full control including deletion, approvals and backups.
    "المدير": ["*ALL*"],
    # 2) المشرف — can add and edit everything operational, but CANNOT delete,
    #    approve money, touch payroll/accounting, or restore backups.
    "المشرف": [
        "crm.account.view", "crm.account.create", "crm.account.edit",
        "crm.contact.create", "crm.opportunity.view", "crm.opportunity.create",
        "crm.quotation.view", "crm.quotation.create",
        "settings.category.view",
        "training.course.view", "training.course.create", "training.instructor.create",
        "training.cohort.create", "training.session.create", "training.student.create",
        "training.enrollment.create", "training.enrollment.edit",
        "training.attendance.mark", "training.assessment.record",
        "project.view", "project.create", "project.manage", "project.boq.manage",
        "project.variation.request", "project.subcontractor.create",
        "finance.invoice.view", "finance.payment.record",
        "inventory.item.view", "inventory.item.manage", "inventory.movement.record",
        "cmms.asset.view", "cmms.workorder.manage",
        "hr.employee.view", "hr.leave.request",
        "tender.view",
        "partners.view", "fixedassets.view", "governance.view", "accounting.view",
    ],
    # 3) المستخدم — daily front-desk data entry only: inquiries, students,
    #    attendance. No money figures, no deletion, no reports.
    "المستخدم": [
        "crm.account.view", "crm.account.create", "crm.contact.create",
        "settings.category.view",
        "training.course.view", "training.student.create",
        "training.attendance.mark",
        "inventory.item.view",
    ],
    "Sales Agent": [
        "crm.account.view", "crm.account.create", "crm.account.edit",
        "crm.contact.create", "crm.opportunity.view", "crm.opportunity.create",
        "crm.quotation.view", "crm.quotation.create",
    ],
    "Accountant": [
        "crm.quotation.view", "crm.quotation.approve",
        "project.billing.create", "project.retention.release", "project.subcontract.payment",
        "project.view",
        "finance.invoice.view", "finance.invoice.create",
        "finance.payment.record", "finance.expense.create",
    ],
    "Training Coordinator": [
        "settings.category.view", "settings.category.manage",
        "training.course.view", "training.course.create", "training.instructor.create",
        "training.cohort.create", "training.session.create", "training.student.create",
        "training.enrollment.create", "training.enrollment.edit",
        "training.assessment.record", "training.certificate.issue",
    ],
    "Instructor": [
        "training.course.view", "training.attendance.mark", "training.assessment.record",
    ],
    "Project Manager": [
        "settings.category.view", "settings.category.manage",
        "project.view", "project.create", "project.manage", "project.boq.manage",
        "project.variation.request", "project.subcontractor.create", "project.subcontract.award",
        "tender.view", "tender.manage",
    ],
    "Operations Manager": [
        "project.view", "project.variation.approve",
    ],
    "Maintenance Manager": [
        "cmms.asset.view", "cmms.asset.manage", "cmms.workorder.manage",
    ],
    "Warehouse Manager": [
        "inventory.item.view", "inventory.item.manage",
        "inventory.movement.record", "inventory.po.manage",
    ],
    "HR Manager": [
        "hr.employee.view", "hr.employee.manage",
        "hr.leave.request", "hr.leave.approve", "hr.payroll.manage",
    ],
    "Estimation Engineer": [
        "tender.view", "tender.manage", "project.view",
    ],
    "Chief Accountant": [
        "accounting.view", "accounting.manage",
        "finance.invoice.view", "finance.invoice.create",
        "finance.payment.record", "finance.expense.create",
        "partners.view", "partners.manage",
        "fixedassets.view", "fixedassets.manage",
        "governance.view", "governance.manage", "governance.approve",
    ],
}


def run() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        tenant = db.scalar(select(Tenant).where(Tenant.slug == settings.default_tenant_slug))
        if not tenant:
            tenant = Tenant(name=settings.default_tenant_name, slug=settings.default_tenant_slug)
            db.add(tenant)
            db.flush()

        _seed_permissions_and_roles(db, tenant.id)

        admin = db.scalar(select(User).where(User.email == settings.superadmin_email.lower()))
        if not admin:
            admin = User(
                tenant_id=tenant.id,
                email=settings.superadmin_email.lower(),
                hashed_password=hash_password(settings.superadmin_password),
                full_name="Super Admin",
                is_superadmin=True,
            )
            db.add(admin)
            print(f"Superadmin created: {admin.email}")
        else:
            # The admin account already exists. Its password is left untouched
            # (critical once the system is online: a restart must never bring
            # back the documented default password). Set SEED_RESET_PASSWORDS=true
            # only to deliberately recover a locked-out account.
            admin.is_superadmin = True
            if hasattr(admin, "status"):
                admin.status = "active"
            if settings.seed_reset_passwords:
                admin.hashed_password = hash_password(settings.superadmin_password)
                print(f"Superadmin {admin.email}: password RESET to default (requested)")
            else:
                print(f"Superadmin already existed: {admin.email} (password unchanged)")

        _seed_team_accounts(db, tenant.id)
        _seed_categories(db, tenant.id)
        _seed_chart_of_accounts(db, tenant.id)

        db.commit()
        print(f"Seed complete. Superadmin: {settings.superadmin_email}")
    finally:
        db.close()


# A minimal Egyptian-style chart of accounts to start from. Group accounts are
# non-postable headers; leaf accounts (is_group=False) take journal entries.
DEFAULT_ACCOUNTS = [
    ("1", "الأصول | Assets", "asset", True),
    ("11", "الأصول المتداولة | Current Assets", "asset", True),
    ("1101", "الخزينة | Cash on Hand", "asset", False),
    ("1102", "البنك | Bank", "asset", False),
    ("1103", "العملاء | Accounts Receivable", "asset", False),
    ("1104", "المخزون | Inventory", "asset", False),
    ("12", "الأصول الثابتة | Fixed Assets", "asset", True),
    ("1201", "معدات وآلات | Equipment", "asset", False),
    ("1202", "مجمع إهلاك الأصول | Accumulated Depreciation", "asset", False),
    ("2", "الالتزامات | Liabilities", "liability", True),
    ("2101", "الموردون | Accounts Payable", "liability", False),
    ("2102", "ضريبة القيمة المضافة | VAT Payable", "liability", False),
    ("3", "حقوق الملكية | Equity", "equity", True),
    ("3101", "رأس المال | Capital", "equity", False),
    ("3102", "جاري الشركاء | Partners' Current Accounts", "equity", False),
    ("3103", "أرباح محتجزة | Retained Earnings", "equity", False),
    ("4", "الإيرادات | Revenue", "revenue", True),
    ("4101", "إيرادات المشاريع | Project Revenue", "revenue", False),
    ("4102", "إيرادات التدريب | Training Revenue", "revenue", False),
    ("4103", "إيرادات الصيانة | Maintenance Revenue", "revenue", False),
    ("5", "المصروفات | Expenses", "expense", True),
    ("510101", "تكلفة المواد | Material Cost", "expense", False),
    ("510102", "رواتب وأجور تشغيلية | Operational Wages", "expense", False),
    ("510125", "عدد وأدوات مستهلكة | Consumable Tools", "expense", False),
    ("5201", "مصروفات إدارية | Administrative Expenses", "expense", False),
    ("5202", "رواتب إدارية | Administrative Salaries", "expense", False),
    ("5203", "إهلاك الأصول الثابتة | Depreciation Expense", "expense", False),
]


def _seed_permissions_and_roles(db, tenant_id) -> None:
    """Seed the permission catalog and the system roles for a tenant.
    Exposed separately so tests can build a realistic tenant too."""
    perms: dict[str, Permission] = {}
    for code, module in PERMISSIONS:
        p = db.scalar(select(Permission).where(Permission.code == code))
        if not p:
            p = Permission(code=code, module=module)
            db.add(p)
            db.flush()
        perms[code] = p

    for role_name, codes in ROLES.items():
        role = db.scalar(
            select(Role).where(Role.tenant_id == tenant_id, Role.name == role_name)
        )
        if not role:
            role = Role(tenant_id=tenant_id, name=role_name, is_system=True)
            db.add(role)
        # "*ALL*" is shorthand for "every permission in the catalog", so the
        # manager role stays complete automatically as new modules are added.
        if codes == ["*ALL*"]:
            role.permissions = list(perms.values())
        else:
            role.permissions = [perms[c] for c in codes]
    db.flush()


def _seed_team_accounts(db, tenant_id) -> None:
    """Create the three ready-to-use team logins (manager / supervisor /
    operator). Passwords are always reset on re-seed so the documented
    credentials keep working, exactly like the superadmin account."""
    # The roles were just added to this session; flush so they are queryable
    # by name below (otherwise the first lookup can miss them).
    db.flush()
    accounts = [
        ("supervisor@engineershouse.com", "Supervisor!2026", "مشرف النظام", "المشرف"),
        ("user@engineershouse.com", "User!2026", "مستخدم تشغيلي", "المستخدم"),
    ]
    for email, password, full_name, role_name in accounts:
        role = db.scalar(
            select(Role).where(Role.tenant_id == tenant_id, Role.name == role_name)
        )
        user = db.scalar(select(User).where(User.email == email))
        if not user:
            user = User(
                tenant_id=tenant_id,
                email=email,
                hashed_password=hash_password(password),
                full_name=full_name,
                is_superadmin=False,
                status="active",
            )
            db.add(user)
            db.flush()
            print(f"Team account created: {email} ({role_name})")
        else:
            # Existing staff passwords are never overwritten on restart.
            if get_settings().seed_reset_passwords:
                user.hashed_password = hash_password(password)
                user.status = "active"
                print(f"Team account reset: {email} ({role_name})")
            else:
                print(f"Team account exists: {email} (password unchanged)")
        if role:
            user.roles = [role]


def _seed_categories(db, tenant_id) -> None:
    """Seed the default lookup lists (course/project/customer categories).
    Idempotent: only inserts a (kind, code) that isn't already present, so
    user-added categories and edits are never overwritten on re-seed."""
    from app.modules.settings.models import Category

    defaults = {
        "course": [
            ("PLC", "التحكم المنطقي المبرمج", "PLC - Programmable Logic Controllers"),
            ("SCADA", "أنظمة التحكم والمراقبة", "SCADA - Supervisory Control"),
            ("HMI", "واجهات التشغيل", "HMI - Human Machine Interface"),
            ("DRIVES", "محركات التردد", "Variable Frequency Drives"),
            ("INSTRUMENT", "أجهزة القياس والتحكم", "Instrumentation & Control"),
            ("ELECTRICAL", "الأنظمة الكهربائية", "Electrical Power Systems"),
            ("MAINTENANCE", "الصيانة الصناعية", "Industrial Maintenance"),
            ("NETWORKS", "شبكات الاتصال الصناعية", "Industrial Networks"),
        ],
        "project": [
            ("AUTOMATION", "أتمتة صناعية", "Industrial Automation"),
            ("PANELS", "لوحات كهربائية", "Electrical Panels"),
            ("CONTROL", "أنظمة تحكم", "Control Systems"),
            ("MAINTENANCE", "عقود صيانة", "Maintenance Contracts"),
            ("CONSULTING", "استشارات هندسية", "Engineering Consulting"),
        ],
        "customer": [
            ("FACTORY", "مصنع", "Factory"),
            ("CONTRACTOR", "مقاول", "Contractor"),
            ("GOVERNMENT", "جهة حكومية", "Government"),
            ("INDIVIDUAL", "فرد", "Individual"),
            ("TRAINING_CLIENT", "عميل تدريب", "Training Client"),
            ("DISTRIBUTOR", "موزّع", "Distributor"),
        ],
    }
    for kind, rows in defaults.items():
        for order, (code, name_ar, name_en) in enumerate(rows):
            exists = db.scalar(
                select(Category).where(
                    Category.tenant_id == tenant_id,
                    Category.kind == kind,
                    Category.code == code,
                )
            )
            if not exists:
                db.add(Category(
                    tenant_id=tenant_id, kind=kind, code=code,
                    name_ar=name_ar, name_en=name_en,
                    is_active=True, is_system=True, sort_order=order,
                ))


def _seed_chart_of_accounts(db, tenant_id) -> None:
    from app.modules.accounting.models import GLAccount

    existing = db.scalar(
        select(func.count()).select_from(GLAccount).where(GLAccount.tenant_id == tenant_id)
    )
    if existing:
        return
    code_to_id: dict[str, object] = {}
    for code, name, atype, is_group in DEFAULT_ACCOUNTS:
        # Parent is the longest existing prefix of this code.
        parent_id = None
        for plen in range(len(code) - 1, 0, -1):
            if code[:plen] in code_to_id:
                parent_id = code_to_id[code[:plen]]
                break
        acc = GLAccount(
            tenant_id=tenant_id,
            code=code,
            name=name,
            account_type=atype,
            parent_id=parent_id,
            is_group=is_group,
            is_active=True,
            opening_balance=0,
        )
        db.add(acc)
        db.flush()
        code_to_id[code] = acc.id


if __name__ == "__main__":
    run()
