"""Shared CSV import helper for bulk data loading.

Parsing is lenient by design: header names are matched case-insensitively
and both English and common Arabic header aliases are accepted, so users
can re-import a file that was exported from the system or bring their own
spreadsheet saved as CSV.
"""
from __future__ import annotations

import csv
import io


def parse_csv_rows(content: str) -> list[dict[str, str]]:
    """Parse CSV text into a list of {normalized_header: value} dicts."""
    # Strip UTF-8 BOM if present (Excel adds it).
    content = content.lstrip("\ufeff")
    reader = csv.DictReader(io.StringIO(content))
    rows = []
    for raw in reader:
        row = {}
        for key, value in raw.items():
            if key is None:
                continue
            row[key.strip().lower()] = (value or "").strip()
        if any(v for v in row.values()):
            rows.append(row)
    return rows


def pick(row: dict[str, str], *aliases: str) -> str:
    """Return the first non-empty value among the given header aliases."""
    for a in aliases:
        v = row.get(a.lower(), "")
        if v:
            return v
    return ""


def to_float(value: str, default: float = 0.0) -> float:
    try:
        return float(value.replace(",", "")) if value else default
    except ValueError:
        return default


def to_int(value: str, default: int = 0) -> int:
    try:
        return int(float(value.replace(",", ""))) if value else default
    except ValueError:
        return default


# --- Shared Pydantic bodies for the import/export endpoints ---
from pydantic import BaseModel  # noqa: E402


class CsvImportBody(BaseModel):
    content: str


class CsvExportOut(BaseModel):
    filename: str
    content: str


class CsvImportResult(BaseModel):
    created: int
    skipped: int
    errors: list[dict]
