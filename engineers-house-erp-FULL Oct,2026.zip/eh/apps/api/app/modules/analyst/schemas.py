"""AI Financial Analyst schemas."""
from __future__ import annotations

from pydantic import BaseModel, Field


class AnalystQuestion(BaseModel):
    question: str = Field(min_length=2, max_length=2000)


class FinancialSnapshot(BaseModel):
    total_revenue: float
    total_expense: float
    net_profit: float
    total_assets: float
    total_liabilities: float
    total_equity: float
    cash_position: float
    receivables: float
    payables: float
    active_projects: int
    total_contract_value: float
    partners_count: int
    partners_capital: float
    fixed_assets_book_value: float
    open_tenders: int
    tender_pipeline_value: float


class AnalystResponse(BaseModel):
    answer: str
    snapshot: FinancialSnapshot
    ai_enabled: bool
