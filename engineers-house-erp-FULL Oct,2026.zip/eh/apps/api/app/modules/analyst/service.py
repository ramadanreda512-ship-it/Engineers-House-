"""AI Financial Analyst: gathers a full financial snapshot across modules and
optionally asks Claude to analyse it in Arabic.

The snapshot is always computed from live data (accounting, projects, partners,
fixed assets, tendering). If an Anthropic API key is configured, the question
and snapshot are sent to Claude with a CFO-style system prompt; otherwise the
endpoint returns the snapshot with a message explaining how to enable AI.
"""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.modules.accounting import service as acc_service

settings = get_settings()


def _round(x) -> float:
    return round(float(x or 0), 2)


def build_snapshot(db: Session, tenant_id: uuid.UUID) -> dict:
    # --- Accounting-derived figures ---
    income = acc_service.income_statement(db, tenant_id)
    balance = acc_service.balance_sheet(db, tenant_id)

    # Cash position = balance of cash + bank accounts (1101, 1102).
    cash = 0.0
    receivables = 0.0
    payables = 0.0
    for a in acc_service.list_accounts(db, tenant_id):
        if a.code in ("1101", "1102"):
            led = acc_service.account_ledger(db, tenant_id, a.id)
            cash += led["closing_balance"]
        elif a.code == "1103":  # accounts receivable
            led = acc_service.account_ledger(db, tenant_id, a.id)
            receivables += led["closing_balance"]
        elif a.code == "2101":  # accounts payable
            led = acc_service.account_ledger(db, tenant_id, a.id)
            payables += led["closing_balance"]

    # --- Projects ---
    from app.modules.projects.models import Project

    active_projects = int(
        db.scalar(
            select(func.count())
            .select_from(Project)
            .where(Project.tenant_id == tenant_id, Project.status.in_(("planned", "active")))
        )
        or 0
    )
    total_contract = float(
        db.scalar(
            select(func.coalesce(func.sum(Project.contract_value), 0)).where(
                Project.tenant_id == tenant_id
            )
        )
        or 0
    )

    # --- Partners ---
    from app.modules.partners.models import Partner

    partners_count = int(
        db.scalar(
            select(func.count()).select_from(Partner).where(Partner.tenant_id == tenant_id)
        )
        or 0
    )
    partners_capital = float(
        db.scalar(
            select(func.coalesce(func.sum(Partner.capital_contribution), 0)).where(
                Partner.tenant_id == tenant_id
            )
        )
        or 0
    )

    # --- Fixed assets ---
    from app.modules.fixedassets.models import FixedAsset

    fa_book = float(
        db.scalar(
            select(func.coalesce(func.sum(FixedAsset.current_value), 0)).where(
                FixedAsset.tenant_id == tenant_id
            )
        )
        or 0
    )

    # --- Tendering ---
    from app.modules.tendering.models import Tender

    open_tenders = int(
        db.scalar(
            select(func.count())
            .select_from(Tender)
            .where(
                Tender.tenant_id == tenant_id,
                Tender.status.in_(("draft", "submitted", "under_evaluation")),
            )
        )
        or 0
    )
    pipeline = float(
        db.scalar(
            select(func.coalesce(func.sum(Tender.estimated_value), 0)).where(
                Tender.tenant_id == tenant_id,
                Tender.status.in_(("draft", "submitted", "under_evaluation")),
            )
        )
        or 0
    )

    return {
        "total_revenue": _round(income["total_revenue"]),
        "total_expense": _round(income["total_expense"]),
        "net_profit": _round(income["net_profit"]),
        "total_assets": _round(balance["total_assets"]),
        "total_liabilities": _round(balance["total_liabilities"]),
        "total_equity": _round(balance["total_equity"]),
        "cash_position": _round(cash),
        "receivables": _round(receivables),
        "payables": _round(payables),
        "active_projects": active_projects,
        "total_contract_value": _round(total_contract),
        "partners_count": partners_count,
        "partners_capital": _round(partners_capital),
        "fixed_assets_book_value": _round(fa_book),
        "open_tenders": open_tenders,
        "tender_pipeline_value": _round(pipeline),
    }


def _build_prompt(snapshot: dict, question: str) -> str:
    return f"""بيانات الشركة المالية الحالية (بالجنيه المصري):

# قائمة الدخل
- إجمالي الإيرادات: {snapshot['total_revenue']:,.2f}
- إجمالي المصروفات: {snapshot['total_expense']:,.2f}
- صافي الربح: {snapshot['net_profit']:,.2f}

# المركز المالي
- إجمالي الأصول: {snapshot['total_assets']:,.2f}
- إجمالي الالتزامات: {snapshot['total_liabilities']:,.2f}
- إجمالي حقوق الملكية: {snapshot['total_equity']:,.2f}
- النقدية والبنك: {snapshot['cash_position']:,.2f}
- العملاء (مدينون): {snapshot['receivables']:,.2f}
- الموردون (دائنون): {snapshot['payables']:,.2f}

# المشاريع
- مشاريع نشطة: {snapshot['active_projects']}
- إجمالي قيمة العقود: {snapshot['total_contract_value']:,.2f}

# الشركاء
- عدد الشركاء: {snapshot['partners_count']}
- رأس المال المساهم: {snapshot['partners_capital']:,.2f}

# الأصول الثابتة
- القيمة الدفترية: {snapshot['fixed_assets_book_value']:,.2f}

# المناقصات
- مناقصات مفتوحة: {snapshot['open_tenders']}
- قيمة المحفظة المتوقعة: {snapshot['tender_pipeline_value']:,.2f}

# سؤال المستخدم:
{question}

# المطلوب:
قدّم تحليلاً مالياً احترافياً ومحدداً يشمل:
1. إجابة مباشرة على السؤال
2. تحليل الأرقام والمؤشرات ذات الصلة
3. اكتشاف أي مخاطر أو فرص
4. توصيات عملية قابلة للتنفيذ
استخدم العناوين (##) للأقسام، والقوائم النقطية، والأرقام بالجنيه المصري (ج.م)."""


def analyze(db: Session, tenant_id: uuid.UUID, question: str) -> dict:
    snapshot = build_snapshot(db, tenant_id)
    if not settings.anthropic_api_key:
        return {
            "answer": (
                "المحلل الذكي غير مُفعّل بعد. لتفعيله، أضف مفتاح Anthropic API في "
                "إعدادات الخادم (ANTHROPIC_API_KEY) ثم أعد التشغيل. في هذه الأثناء، "
                "تجد أدناه لقطة كاملة لوضعك المالي الحالي."
            ),
            "snapshot": snapshot,
            "ai_enabled": False,
        }

    prompt = _build_prompt(snapshot, question)
    try:
        import httpx  # imported lazily so the app runs even if httpx is absent
    except ModuleNotFoundError:
        return {
            "answer": (
                "مكتبة httpx غير مثبّتة على الخادم، وهي لازمة للاتصال بخدمة الذكاء "
                "الاصطناعي. ثبّتها بالأمر: pip install httpx ثم أعد التشغيل. "
                "تجد أدناه لقطتك المالية الكاملة."
            ),
            "snapshot": snapshot,
            "ai_enabled": False,
        }
    try:
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.anthropic_api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": settings.anthropic_model,
                "max_tokens": 2000,
                "system": (
                    "أنت محلل مالي خبير (CFO) لشركة هندسية مصرية، تتحدث العربية بطلاقة. "
                    "قدّم تحليلات احترافية ومحددة ومبنية على الأرقام."
                ),
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        answer = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        ) or "لا يوجد رد."
    except Exception as e:  # noqa: BLE001
        answer = f"تعذّر الاتصال بخدمة الذكاء الاصطناعي: {e}. تجد أدناه لقطتك المالية."
        return {"answer": answer, "snapshot": snapshot, "ai_enabled": False}

    return {"answer": answer, "snapshot": snapshot, "ai_enabled": True}
