"""AI Financial Analyst HTTP endpoints."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.analyst import service
from app.modules.analyst.schemas import AnalystQuestion, AnalystResponse, FinancialSnapshot
from app.modules.identity.models import User

router = APIRouter(prefix="/analyst", tags=["analyst"])


@router.get("/snapshot", response_model=FinancialSnapshot)
def snapshot(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("accounting.view")),
):
    return service.build_snapshot(db, user.tenant_id)


@router.post("/ask", response_model=AnalystResponse)
def ask(
    body: AnalystQuestion,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("accounting.view")),
):
    return service.analyze(db, user.tenant_id, body.question)
