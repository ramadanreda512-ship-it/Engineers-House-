"""Pydantic schemas for the identity module."""
from __future__ import annotations

import uuid

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str = Field(min_length=2, max_length=255)
    phone: str | None = None


class PermissionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    code: str
    module: str


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    permissions: list[PermissionOut] = []


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    email: EmailStr
    full_name: str
    phone: str | None = None
    status: str
    is_superadmin: bool
    is_2fa_enabled: bool
    roles: list[RoleOut] = []


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class MfaLoginRequest(BaseModel):
    email: EmailStr
    password: str
    otp_code: str


class RefreshRequest(BaseModel):
    refresh_token: str


class TwoFactorSetupResponse(BaseModel):
    secret: str
    otpauth_uri: str


class TwoFactorVerifyRequest(BaseModel):
    otp_code: str


# --- User administration (manager-only screen) ---
class TeamUserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=255)
    password: str = Field(min_length=8, max_length=128)
    role_id: uuid.UUID
    phone: str | None = None


class TeamUserUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=255)
    phone: str | None = None
    status: str | None = Field(default=None, pattern="^(active|suspended)$")
    role_id: uuid.UUID | None = None


class PasswordReset(BaseModel):
    new_password: str = Field(min_length=8, max_length=128)


class RoleSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    description: str = ""
    permission_count: int = 0


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)
