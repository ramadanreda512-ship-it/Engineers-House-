"""Business logic for authentication, registration, and 2FA."""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    generate_totp_secret,
    hash_password,
    totp_uri,
    verify_password,
    verify_totp,
)
from app.modules.identity import repository as repo
from app.modules.identity.models import Role, User
from app.shared.exceptions import BadRequest, Conflict, NotFound

settings = get_settings()


def register_user(
    db: Session, *, email: str, password: str, full_name: str, phone: str | None
) -> User:
    if repo.get_user_by_email(db, email):
        raise Conflict("Email already registered")
    tenant = repo.get_or_create_default_tenant(
        db, settings.default_tenant_name, settings.default_tenant_slug
    )
    user = User(
        tenant_id=tenant.id,
        email=email.lower(),
        hashed_password=hash_password(password),
        full_name=full_name,
        phone=phone,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def _issue_tokens(user: User) -> dict[str, str]:
    return {
        "access_token": create_access_token(str(user.id), {"tenant": str(user.tenant_id)}),
        "refresh_token": create_refresh_token(str(user.id)),
    }


def _authenticate(db: Session, email: str, password: str) -> User:
    user = repo.get_user_by_email(db, email)
    if not user or not verify_password(password, user.hashed_password):
        raise BadRequest("Invalid email or password")
    if user.status != "active":
        raise BadRequest("Account is not active")
    return user


def login(db: Session, email: str, password: str) -> dict[str, str]:
    user = _authenticate(db, email, password)
    if user.is_2fa_enabled:
        raise BadRequest("2FA enabled; use /auth/login/mfa")
    return _issue_tokens(user)


def dev_login(db: Session) -> dict[str, str]:
    """TEMPORARY local-troubleshooting login: issues a real, valid token for
    the configured superadmin account without checking any password. Only
    reachable when settings.dev_login_enabled is true (see the router)."""
    user = repo.get_user_by_email(db, settings.superadmin_email.lower())
    if not user:
        raise BadRequest("Superadmin account not found; run the seed script first")
    return _issue_tokens(user)


def login_mfa(db: Session, email: str, password: str, otp_code: str) -> dict[str, str]:
    user = _authenticate(db, email, password)
    if not user.is_2fa_enabled:
        raise BadRequest("2FA is not enabled for this account; use /auth/login")
    if not user.totp_secret or not verify_totp(user.totp_secret, otp_code):
        raise BadRequest("Invalid 2FA code")
    return _issue_tokens(user)


def refresh(db: Session, refresh_token: str) -> dict[str, str]:
    try:
        payload = decode_token(refresh_token)
    except Exception as exc:  # noqa: BLE001
        raise BadRequest("Invalid refresh token") from exc
    if payload.get("type") != "refresh":
        raise BadRequest("Invalid token type")
    import uuid

    user = db.get(User, uuid.UUID(str(payload.get("sub"))))
    if not user or user.status != "active":
        raise BadRequest("Invalid refresh token")
    return _issue_tokens(user)


def start_2fa_setup(db: Session, user: User) -> dict[str, str]:
    secret = generate_totp_secret()
    user.totp_secret = secret
    db.commit()
    return {"secret": secret, "otpauth_uri": totp_uri(secret, user.email)}


def confirm_2fa(db: Session, user: User, otp_code: str) -> None:
    if not user.totp_secret:
        raise BadRequest("Start 2FA setup first")
    if not verify_totp(user.totp_secret, otp_code):
        raise BadRequest("Invalid 2FA code")
    user.is_2fa_enabled = True
    db.commit()


# ==================== User administration ====================
def list_users(db: Session, tenant_id: uuid.UUID) -> list[User]:
    from sqlalchemy import select as _select

    return list(
        db.scalars(
            _select(User).where(User.tenant_id == tenant_id).order_by(User.full_name)
        ).all()
    )


def list_roles(db: Session, tenant_id: uuid.UUID) -> list[Role]:
    from sqlalchemy import select as _select

    return list(
        db.scalars(_select(Role).where(Role.tenant_id == tenant_id).order_by(Role.name)).all()
    )


def create_team_user(db: Session, tenant_id: uuid.UUID, body) -> User:
    """Create a staff account and assign it a single role."""
    from sqlalchemy import func
    from sqlalchemy import select as _select

    email = body.email.lower()
    exists = db.scalar(_select(User).where(func.lower(User.email) == email))
    if exists:
        raise Conflict("A user with this email already exists")
    role = db.scalar(
        _select(Role).where(Role.tenant_id == tenant_id, Role.id == body.role_id)
    )
    if not role:
        raise NotFound("Role")
    user = User(
        tenant_id=tenant_id,
        email=email,
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
        phone=body.phone,
        status="active",
        is_superadmin=False,
    )
    user.roles = [role]
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def update_team_user(db: Session, tenant_id: uuid.UUID, user_id: uuid.UUID, body) -> User:
    """Change a staff member's name/phone, their role, or activate/suspend
    them. The account's own superadmin flag is never changed here."""
    from sqlalchemy import select as _select

    user = db.scalar(
        _select(User).where(User.id == user_id, User.tenant_id == tenant_id)
    )
    if not user:
        raise NotFound("User")
    data = body.model_dump(exclude_unset=True)
    if "full_name" in data and data["full_name"]:
        user.full_name = data["full_name"]
    if "phone" in data:
        user.phone = data["phone"]
    if "status" in data and data["status"]:
        if user.is_superadmin and data["status"] != "active":
            raise Conflict("The main manager account cannot be suspended")
        user.status = data["status"]
    if data.get("role_id"):
        role = db.scalar(
            _select(Role).where(Role.tenant_id == tenant_id, Role.id == data["role_id"])
        )
        if not role:
            raise NotFound("Role")
        user.roles = [role]
    db.commit()
    db.refresh(user)
    return user


def reset_team_user_password(
    db: Session, tenant_id: uuid.UUID, user_id: uuid.UUID, new_password: str
) -> None:
    from sqlalchemy import select as _select

    user = db.scalar(
        _select(User).where(User.id == user_id, User.tenant_id == tenant_id)
    )
    if not user:
        raise NotFound("User")
    user.hashed_password = hash_password(new_password)
    db.commit()


def delete_team_user(db: Session, tenant_id: uuid.UUID, user_id: uuid.UUID) -> None:
    from sqlalchemy import select as _select

    user = db.scalar(
        _select(User).where(User.id == user_id, User.tenant_id == tenant_id)
    )
    if not user:
        raise NotFound("User")
    if user.is_superadmin:
        raise Conflict("The main manager account cannot be deleted")
    db.delete(user)
    db.commit()


def change_own_password(
    db: Session, user: User, current_password: str, new_password: str
) -> None:
    """Let any signed-in user replace their own password."""
    if not verify_password(current_password, user.hashed_password):
        raise BadRequest("Current password is incorrect")
    if current_password == new_password:
        raise BadRequest("New password must be different from the current one")
    user.hashed_password = hash_password(new_password)
    db.commit()
