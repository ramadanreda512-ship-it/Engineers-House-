"""Data access for identity entities."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.identity.models import Tenant, User


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(User.email == email.lower()))


def get_default_tenant(db: Session, slug: str) -> Tenant | None:
    return db.scalar(select(Tenant).where(Tenant.slug == slug))


def get_or_create_default_tenant(db: Session, name: str, slug: str) -> Tenant:
    tenant = get_default_tenant(db, slug)
    if tenant is None:
        tenant = Tenant(name=name, slug=slug)
        db.add(tenant)
        db.flush()
    return tenant


def add(db: Session, obj) -> None:
    db.add(obj)
