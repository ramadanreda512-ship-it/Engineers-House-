"""Auth & identity HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user
from app.core.rbac import require_permission
from app.modules.identity import service
from app.modules.identity.models import User
from app.modules.identity.schemas import (
    ChangePasswordRequest,
    MfaLoginRequest,
    PasswordReset,
    RefreshRequest,
    RegisterRequest,
    RoleSummary,
    TeamUserCreate,
    TeamUserUpdate,
    TokenResponse,
    TwoFactorSetupResponse,
    TwoFactorVerifyRequest,
    UserOut,
)

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=UserOut, status_code=201)
def register(body: RegisterRequest, db: Session = Depends(get_db)) -> User:
    from fastapi import HTTPException

    from app.core.config import get_settings

    # Staff accounts are created by the manager; self sign-up stays closed.
    if not get_settings().public_registration_enabled:
        raise HTTPException(status_code=404, detail="Not found")
    return service.register_user(
        db, email=body.email, password=body.password, full_name=body.full_name, phone=body.phone
    )


@router.post("/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    from fastapi import HTTPException

    from app.core import throttle

    throttle.check_allowed(form.username)
    try:
        tokens = service.login(db, form.username, form.password)
    except HTTPException:
        throttle.record_failure(form.username)
        raise
    throttle.record_success(form.username)
    return tokens


@router.post("/dev-login", response_model=TokenResponse)
def dev_login(db: Session = Depends(get_db)):
    """TEMPORARY: local troubleshooting only. Issues a valid token for the
    superadmin account without a password, when explicitly enabled via the
    DEV_LOGIN_ENABLED environment variable. Disabled by default."""
    from fastapi import HTTPException

    from app.core.config import get_settings

    if not get_settings().dev_login_enabled:
        raise HTTPException(status_code=404, detail="Not found")
    return service.dev_login(db)


@router.post("/login/mfa", response_model=TokenResponse)
def login_mfa(body: MfaLoginRequest, db: Session = Depends(get_db)):
    return service.login_mfa(db, body.email, body.password, body.otp_code)


@router.post("/refresh", response_model=TokenResponse)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    return service.refresh(db, body.refresh_token)


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)) -> User:
    return user


@router.post("/me/change-password", status_code=204)
def change_password(
    body: ChangePasswordRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    service.change_own_password(db, user, body.current_password, body.new_password)


@router.post("/2fa/setup", response_model=TwoFactorSetupResponse)
def setup_2fa(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return service.start_2fa_setup(db, user)


@router.post("/2fa/verify", status_code=204)
def verify_2fa(
    body: TwoFactorVerifyRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    service.confirm_2fa(db, user, body.otp_code)


# ==================== User administration ====================
# Only the manager (superadmin or someone holding users.manage) may run these.
USERS_MANAGE = "users.manage"


@router.get("/users", response_model=list[UserOut])
def list_users(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    return service.list_users(db, user.tenant_id)


@router.get("/roles", response_model=list[RoleSummary])
def list_roles(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    roles = service.list_roles(db, user.tenant_id)
    return [
        {
            "id": r.id,
            "name": r.name,
            "description": r.description or "",
            "permission_count": len(r.permissions),
        }
        for r in roles
    ]


@router.post("/users", response_model=UserOut, status_code=201)
def create_team_user(
    body: TeamUserCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    return service.create_team_user(db, user.tenant_id, body)


@router.patch("/users/{user_id}", response_model=UserOut)
def update_team_user(
    user_id: uuid.UUID,
    body: TeamUserUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    return service.update_team_user(db, user.tenant_id, user_id, body)


@router.post("/users/{user_id}/reset-password", status_code=204)
def reset_team_user_password(
    user_id: uuid.UUID,
    body: PasswordReset,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    service.reset_team_user_password(db, user.tenant_id, user_id, body.new_password)


@router.delete("/users/{user_id}", status_code=204)
def delete_team_user(
    user_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(USERS_MANAGE)),
):
    service.delete_team_user(db, user.tenant_id, user_id)
