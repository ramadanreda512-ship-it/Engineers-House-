"""Inventory & procurement models: items, stock movements, purchase orders.

Design notes:
- An InventoryItem tracks quantity on hand for a stock-keeping unit (SKU),
  with a reorder level used to flag low stock.
- Every change to on-hand quantity goes through a StockMovement (in/out/
  adjustment) so there is a full audit trail; quantity_on_hand is recomputed
  from movements and never set directly.
- A PurchaseOrder groups lines ordered from a supplier; receiving a PO line
  creates the corresponding 'in' stock movements.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class InventoryItem(Base, TimestampMixin):
    __tablename__ = "inventory_items"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    sku: Mapped[str] = mapped_column(String(40))  # unique per tenant
    name: Mapped[str] = mapped_column(String(255))
    category: Mapped[str | None] = mapped_column(String(60), nullable=True)
    unit: Mapped[str] = mapped_column(String(20), default="pcs")
    quantity_on_hand: Mapped[float] = mapped_column(Numeric(14, 2), default=0)  # computed
    reorder_level: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    unit_cost: Mapped[float] = mapped_column(Numeric(14, 2), default=0)

    movements: Mapped[list[StockMovement]] = relationship(
        back_populates="item", cascade="all, delete-orphan"
    )


class StockMovement(Base, TimestampMixin):
    __tablename__ = "stock_movements"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    item_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("inventory_items.id", ondelete="CASCADE")
    )
    # in / out / adjustment
    movement_type: Mapped[str] = mapped_column(String(12))
    quantity: Mapped[float] = mapped_column(Numeric(14, 2))  # always positive
    reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    moved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    item: Mapped[InventoryItem] = relationship(back_populates="movements")


class Supplier(Base, TimestampMixin):
    __tablename__ = "suppliers"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    name: Mapped[str] = mapped_column(String(255))
    contact_person: Mapped[str | None] = mapped_column(String(120), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)


class PurchaseOrder(Base, TimestampMixin):
    __tablename__ = "purchase_orders"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    number: Mapped[str] = mapped_column(String(40))  # auto: PO-YYYY-NNNN
    supplier_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("suppliers.id"))
    order_date: Mapped[date] = mapped_column(Date)
    # draft / ordered / partially_received / received / cancelled
    status: Mapped[str] = mapped_column(String(20), default="ordered")
    total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)  # computed
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    lines: Mapped[list[POLine]] = relationship(
        back_populates="order", cascade="all, delete-orphan", lazy="selectin"
    )


class POLine(Base, TimestampMixin):
    __tablename__ = "po_lines"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    order_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("purchase_orders.id", ondelete="CASCADE")
    )
    item_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("inventory_items.id"))
    quantity: Mapped[float] = mapped_column(Numeric(14, 2))
    received_qty: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    unit_price: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    line_total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)  # computed

    order: Mapped[PurchaseOrder] = relationship(back_populates="lines")
