"""Tenant-scoped data access for inventory & procurement."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.inventory.models import (
    InventoryItem,
    POLine,
    PurchaseOrder,
    StockMovement,
    Supplier,
)


def get_item(db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID) -> InventoryItem | None:
    return db.scalar(
        select(InventoryItem).where(
            InventoryItem.id == item_id, InventoryItem.tenant_id == tenant_id
        )
    )


def sku_exists(db: Session, tenant_id: uuid.UUID, sku: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(InventoryItem)
            .where(InventoryItem.tenant_id == tenant_id, InventoryItem.sku == sku)
        )
        or 0
    ) > 0


def list_items(db: Session, tenant_id: uuid.UUID, limit: int, offset: int):
    stmt = (
        select(InventoryItem)
        .where(InventoryItem.tenant_id == tenant_id)
        .order_by(InventoryItem.name.asc())
    )
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(
        select(func.count()).select_from(InventoryItem).where(InventoryItem.tenant_id == tenant_id)
    )
    return items, total or 0


def item_has_movements(db: Session, item_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(StockMovement)
            .where(StockMovement.item_id == item_id)
        )
        or 0
    ) > 0


def item_in_purchase_orders(db: Session, item_id: uuid.UUID) -> bool:
    return (
        db.scalar(select(func.count()).select_from(POLine).where(POLine.item_id == item_id))
        or 0
    ) > 0


def list_movements(db: Session, item_id: uuid.UUID):
    stmt = (
        select(StockMovement)
        .where(StockMovement.item_id == item_id)
        .order_by(StockMovement.moved_at.desc())
    )
    return db.scalars(stmt).all()


def get_supplier(db: Session, tenant_id: uuid.UUID, supplier_id: uuid.UUID) -> Supplier | None:
    return db.scalar(
        select(Supplier).where(Supplier.id == supplier_id, Supplier.tenant_id == tenant_id)
    )


def list_suppliers(db: Session, tenant_id: uuid.UUID):
    stmt = select(Supplier).where(Supplier.tenant_id == tenant_id).order_by(Supplier.name.asc())
    return db.scalars(stmt).all()


def get_po(db: Session, tenant_id: uuid.UUID, po_id: uuid.UUID) -> PurchaseOrder | None:
    return db.scalar(
        select(PurchaseOrder).where(
            PurchaseOrder.id == po_id, PurchaseOrder.tenant_id == tenant_id
        )
    )


def get_po_line(db: Session, order_id: uuid.UUID, line_id: uuid.UUID) -> POLine | None:
    return db.scalar(
        select(POLine).where(POLine.id == line_id, POLine.order_id == order_id)
    )


def list_pos(db: Session, tenant_id: uuid.UUID, status: str | None, limit: int, offset: int):
    conds = [PurchaseOrder.tenant_id == tenant_id]
    if status:
        conds.append(PurchaseOrder.status == status)
    stmt = select(PurchaseOrder).where(*conds).order_by(PurchaseOrder.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(PurchaseOrder).where(*conds))
    return items, total or 0


def next_po_number(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count()).select_from(PurchaseOrder).where(PurchaseOrder.tenant_id == tenant_id)
    )
    return f"PO-{year}-{(count or 0) + 1:04d}"


# --- Aggregates ---
def count_items(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count()).select_from(InventoryItem).where(
                InventoryItem.tenant_id == tenant_id
            )
        )
        or 0
    )


def count_low_stock(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(InventoryItem)
            .where(
                InventoryItem.tenant_id == tenant_id,
                InventoryItem.quantity_on_hand <= InventoryItem.reorder_level,
            )
        )
        or 0
    )


def total_stock_value(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(
            func.coalesce(
                func.sum(InventoryItem.quantity_on_hand * InventoryItem.unit_cost), 0
            )
        ).where(InventoryItem.tenant_id == tenant_id)
    )
    return float(val or 0)


def count_open_pos(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(PurchaseOrder)
            .where(
                PurchaseOrder.tenant_id == tenant_id,
                PurchaseOrder.status.in_(["ordered", "partially_received"]),
            )
        )
        or 0
    )
