"""Inventory & procurement schemas."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Items ---
class ItemCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=255)
    category: str | None = None
    unit: str = Field(default="pcs")
    reorder_level: float = Field(ge=0, default=0)
    unit_cost: float = Field(ge=0, default=0)


class ItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    sku: str
    name: str
    category: str | None
    unit: str
    quantity_on_hand: float
    reorder_level: float
    unit_cost: float


class ItemUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    category: str | None = None
    unit: str | None = None
    reorder_level: float | None = Field(default=None, ge=0)
    unit_cost: float | None = Field(default=None, ge=0)


# --- Stock movements ---
class MovementCreate(BaseModel):
    movement_type: str = Field(pattern="^(in|out|adjustment)$")
    quantity: float = Field(gt=0)
    reason: str | None = None


class MovementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    item_id: uuid.UUID
    movement_type: str
    quantity: float
    reason: str | None
    moved_at: datetime


# --- Suppliers ---
class SupplierCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    contact_person: str | None = None
    phone: str | None = None
    email: str | None = None


class SupplierOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    contact_person: str | None
    phone: str | None
    email: str | None


# --- Purchase orders ---
class POLineCreate(BaseModel):
    item_id: uuid.UUID
    quantity: float = Field(gt=0)
    unit_price: float = Field(ge=0, default=0)


class POLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    item_id: uuid.UUID
    quantity: float
    received_qty: float
    unit_price: float
    line_total: float


class PurchaseOrderCreate(BaseModel):
    supplier_id: uuid.UUID
    order_date: date | None = None
    notes: str | None = None
    lines: list[POLineCreate] = Field(min_length=1)


class PurchaseOrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    supplier_id: uuid.UUID
    order_date: date
    status: str
    total: float
    notes: str | None
    lines: list[POLineOut]


class ReceiveLine(BaseModel):
    line_id: uuid.UUID
    received_qty: float = Field(gt=0)


# --- Reports ---
class InventorySummary(BaseModel):
    total_items: int
    low_stock_items: int
    total_stock_value: float
    open_purchase_orders: int
