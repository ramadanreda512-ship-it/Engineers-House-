"""Inventory & procurement HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.inventory import service
from app.modules.inventory.schemas import (
    InventorySummary,
    ItemCreate,
    ItemOut,
    ItemUpdate,
    MovementCreate,
    MovementOut,
    PurchaseOrderCreate,
    PurchaseOrderOut,
    ReceiveLine,
    SupplierCreate,
    SupplierOut,
)
from app.shared.pagination import Page

router = APIRouter(prefix="/inventory", tags=["inventory"])


# --- Items ---
@router.post("/items", response_model=ItemOut, status_code=201)
def create_item(
    body: ItemCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.manage")),
):
    return service.create_item(db, user.tenant_id, body)


@router.get("/items", response_model=Page[ItemOut])
def list_items(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    items, total = service.list_items(db, user.tenant_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/items/{item_id}", response_model=ItemOut)
def get_item(
    item_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    return service.get_item(db, user.tenant_id, item_id)


@router.patch("/items/{item_id}", response_model=ItemOut)
def update_item(
    item_id: uuid.UUID,
    body: ItemUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.manage")),
):
    return service.update_item(db, user.tenant_id, item_id, body)


@router.delete("/items/{item_id}", status_code=204)
def delete_item(
    item_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.manage")),
):
    service.delete_item(db, user.tenant_id, item_id)


# --- Stock movements ---
@router.post("/items/{item_id}/movements", response_model=MovementOut, status_code=201)
def record_movement(
    item_id: uuid.UUID,
    body: MovementCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.movement.record")),
):
    return service.record_movement(db, user.tenant_id, item_id, body)


@router.get("/items/{item_id}/movements", response_model=list[MovementOut])
def list_movements(
    item_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    return service.list_movements(db, user.tenant_id, item_id)


# --- Suppliers ---
@router.post("/suppliers", response_model=SupplierOut, status_code=201)
def create_supplier(
    body: SupplierCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.manage")),
):
    return service.create_supplier(db, user.tenant_id, body)


@router.get("/suppliers", response_model=list[SupplierOut])
def list_suppliers(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    return service.list_suppliers(db, user.tenant_id)


# --- Purchase orders ---
@router.post("/purchase-orders", response_model=PurchaseOrderOut, status_code=201)
def create_po(
    body: PurchaseOrderCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.po.manage")),
):
    return service.create_po(db, user.tenant_id, body)


@router.get("/purchase-orders", response_model=Page[PurchaseOrderOut])
def list_pos(
    status: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    items, total = service.list_pos(db, user.tenant_id, status, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/purchase-orders/{po_id}", response_model=PurchaseOrderOut)
def get_po(
    po_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    return service.get_po(db, user.tenant_id, po_id)


@router.post("/purchase-orders/{po_id}/receive", response_model=PurchaseOrderOut)
def receive_po_line(
    po_id: uuid.UUID,
    body: ReceiveLine,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.po.manage")),
):
    return service.receive_po_line(db, user.tenant_id, po_id, body)


# --- Reports ---
@router.get("/summary", response_model=InventorySummary)
def inventory_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("inventory.item.view")),
):
    return service.inventory_summary(db, user.tenant_id)
