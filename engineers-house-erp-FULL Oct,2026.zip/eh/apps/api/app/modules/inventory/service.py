"""Inventory & procurement business logic.

Key rules enforced here:
- Item SKUs are unique per tenant.
- quantity_on_hand is never set directly: it is recomputed from stock
  movements. An 'out' movement that would drive stock negative is rejected.
- Purchase order totals are computed server-side from the lines.
- Receiving a PO line creates an 'in' movement (raising stock) and advances
  the PO status to partially_received / received based on all its lines.
"""
from __future__ import annotations

import uuid
from datetime import UTC, date, datetime

from sqlalchemy.orm import Session

from app.modules.inventory import repository as repo
from app.modules.inventory.models import (
    InventoryItem,
    POLine,
    PurchaseOrder,
    StockMovement,
    Supplier,
)
from app.modules.inventory.schemas import (
    InventorySummary,
    ItemCreate,
    ItemUpdate,
    MovementCreate,
    PurchaseOrderCreate,
    ReceiveLine,
    SupplierCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


# --- Items ---
def create_item(db: Session, tenant_id: uuid.UUID, body: ItemCreate) -> InventoryItem:
    if repo.sku_exists(db, tenant_id, body.sku):
        raise Conflict(f"SKU '{body.sku}' already exists")
    item = InventoryItem(tenant_id=tenant_id, quantity_on_hand=0, **body.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def list_items(db: Session, tenant_id: uuid.UUID, page: int, size: int):
    return repo.list_items(db, tenant_id, size, (page - 1) * size)


def get_item(db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID) -> InventoryItem:
    item = repo.get_item(db, tenant_id, item_id)
    if not item:
        raise NotFound("Item")
    return item


def update_item(
    db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID, body: ItemUpdate
) -> InventoryItem:
    item = get_item(db, tenant_id, item_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return item


def delete_item(db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID) -> None:
    item = get_item(db, tenant_id, item_id)
    if repo.item_has_movements(db, item_id) or repo.item_in_purchase_orders(db, item_id):
        raise Conflict(
            "Cannot delete an item that has stock movements or appears on a "
            "purchase order, to preserve inventory history."
        )
    db.delete(item)
    db.commit()


def _apply_movement(
    db: Session,
    tenant_id: uuid.UUID,
    item: InventoryItem,
    movement_type: str,
    quantity: float,
    reason: str | None,
) -> StockMovement:
    """Adjust on-hand quantity and record the movement. Rejects going negative."""
    qty = _round(quantity)
    current = float(item.quantity_on_hand)
    if movement_type == "in":
        item.quantity_on_hand = _round(current + qty)
    elif movement_type == "out":
        if qty > current:
            raise BadRequest(
                f"Cannot remove {qty}; only {current} {item.unit} in stock"
            )
        item.quantity_on_hand = _round(current - qty)
    else:  # adjustment sets the delta directly (can be +/-, but qty>0 here means add)
        item.quantity_on_hand = _round(current + qty)

    movement = StockMovement(
        tenant_id=tenant_id,
        item_id=item.id,
        movement_type=movement_type,
        quantity=qty,
        reason=reason,
        moved_at=datetime.now(UTC),
    )
    db.add(movement)
    return movement


def record_movement(
    db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID, body: MovementCreate
) -> StockMovement:
    item = get_item(db, tenant_id, item_id)
    movement = _apply_movement(db, tenant_id, item, body.movement_type, body.quantity, body.reason)
    db.commit()
    db.refresh(movement)
    return movement


def list_movements(db: Session, tenant_id: uuid.UUID, item_id: uuid.UUID):
    get_item(db, tenant_id, item_id)
    return repo.list_movements(db, item_id)


# --- Suppliers ---
def create_supplier(db: Session, tenant_id: uuid.UUID, body: SupplierCreate) -> Supplier:
    supplier = Supplier(tenant_id=tenant_id, **body.model_dump())
    db.add(supplier)
    db.commit()
    db.refresh(supplier)
    return supplier


def list_suppliers(db: Session, tenant_id: uuid.UUID):
    return repo.list_suppliers(db, tenant_id)


# --- Purchase orders ---
def create_po(db: Session, tenant_id: uuid.UUID, body: PurchaseOrderCreate) -> PurchaseOrder:
    if not repo.get_supplier(db, tenant_id, body.supplier_id):
        raise NotFound("Supplier")
    for line in body.lines:
        if not repo.get_item(db, tenant_id, line.item_id):
            raise NotFound(f"Item {line.item_id}")

    total = _round(sum(line.quantity * line.unit_price for line in body.lines))
    year = (body.order_date or date.today()).year
    po = PurchaseOrder(
        tenant_id=tenant_id,
        number=repo.next_po_number(db, tenant_id, year),
        supplier_id=body.supplier_id,
        order_date=body.order_date or date.today(),
        status="ordered",
        total=total,
        notes=body.notes,
    )
    db.add(po)
    db.flush()
    for line in body.lines:
        db.add(
            POLine(
                order_id=po.id,
                item_id=line.item_id,
                quantity=line.quantity,
                received_qty=0,
                unit_price=line.unit_price,
                line_total=_round(line.quantity * line.unit_price),
            )
        )
    db.commit()
    db.refresh(po)
    return po


def list_pos(db: Session, tenant_id: uuid.UUID, status: str | None, page: int, size: int):
    return repo.list_pos(db, tenant_id, status, size, (page - 1) * size)


def get_po(db: Session, tenant_id: uuid.UUID, po_id: uuid.UUID) -> PurchaseOrder:
    po = repo.get_po(db, tenant_id, po_id)
    if not po:
        raise NotFound("Purchase order")
    return po


def receive_po_line(
    db: Session, tenant_id: uuid.UUID, po_id: uuid.UUID, body: ReceiveLine
) -> PurchaseOrder:
    po = get_po(db, tenant_id, po_id)
    if po.status in ("received", "cancelled"):
        raise Conflict(f"Purchase order is already {po.status}")
    line = repo.get_po_line(db, po_id, body.line_id)
    if not line:
        raise NotFound("PO line")

    outstanding = _round(float(line.quantity) - float(line.received_qty))
    if body.received_qty - 0.01 > outstanding:
        raise BadRequest(
            f"Receiving {body.received_qty} exceeds outstanding {outstanding}"
        )

    line.received_qty = _round(float(line.received_qty) + body.received_qty)
    item = repo.get_item(db, tenant_id, line.item_id)
    if item:
        _apply_movement(
            db, tenant_id, item, "in", body.received_qty, f"PO {po.number} receipt"
        )

    # Recompute PO status from all lines.
    db.flush()
    db.refresh(po)
    fully = all(float(ln.received_qty) >= float(ln.quantity) for ln in po.lines)
    any_received = any(float(ln.received_qty) > 0 for ln in po.lines)
    po.status = "received" if fully else ("partially_received" if any_received else "ordered")
    db.commit()
    db.refresh(po)
    return po


# --- Reports ---
def inventory_summary(db: Session, tenant_id: uuid.UUID) -> InventorySummary:
    return InventorySummary(
        total_items=repo.count_items(db, tenant_id),
        low_stock_items=repo.count_low_stock(db, tenant_id),
        total_stock_value=_round(repo.total_stock_value(db, tenant_id)),
        open_purchase_orders=repo.count_open_pos(db, tenant_id),
    )
