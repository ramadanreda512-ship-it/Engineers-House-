"""Governance business logic: approval workflow + budget variance.

Approvals give a maker/checker control: a request is created (pending), then a
different action approves or rejects it. Budget variance compares the planned
budget per account against the actual posted balance for a fiscal year.
"""
from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.modules.accounting import repository as acc_repo
from app.modules.accounting.models import DEBIT_NORMAL
from app.modules.governance import repository as repo
from app.modules.governance.models import Approval, Budget
from app.modules.governance.schemas import (
    ApprovalCreate,
    ApprovalDecision,
    BudgetCreate,
    BudgetUpdate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x) -> float:
    return round(float(x or 0), 2)


# --- Approvals ---
def create_approval(
    db: Session, tenant_id: uuid.UUID, user_id: uuid.UUID, body: ApprovalCreate
) -> Approval:
    approval = Approval(
        tenant_id=tenant_id,
        entity_type=body.entity_type,
        entity_id=body.entity_id,
        title=body.title,
        amount=_round(body.amount),
        requested_by=user_id,
        status="pending",
    )
    db.add(approval)
    db.commit()
    db.refresh(approval)
    return approval


def list_approvals(db: Session, tenant_id: uuid.UUID, status: str | None):
    return repo.list_approvals(db, tenant_id, status)


def _decide(
    db: Session, tenant_id: uuid.UUID, user_id: uuid.UUID, approval_id: uuid.UUID,
    new_status: str, comments: str | None,
) -> Approval:
    approval = repo.get_approval(db, tenant_id, approval_id)
    if not approval:
        raise NotFound("Approval")
    if approval.status != "pending":
        raise Conflict(f"Approval is already {approval.status}")
    approval.status = new_status
    approval.approved_by = user_id
    approval.comments = comments
    approval.decided_at = datetime.now(UTC)
    db.commit()
    db.refresh(approval)
    return approval


def approve(db, tenant_id, user_id, approval_id, body: ApprovalDecision):
    return _decide(db, tenant_id, user_id, approval_id, "approved", body.comments)


def reject(db, tenant_id, user_id, approval_id, body: ApprovalDecision):
    return _decide(db, tenant_id, user_id, approval_id, "rejected", body.comments)


# --- Budgets ---
def create_budget(db: Session, tenant_id: uuid.UUID, body: BudgetCreate) -> Budget:
    if not acc_repo.get_account(db, tenant_id, body.account_id):
        raise NotFound("Account")
    if repo.budget_exists(db, tenant_id, body.account_id, body.fiscal_year, body.fiscal_month):
        raise Conflict("A budget for this account and period already exists")
    budget = Budget(tenant_id=tenant_id, **body.model_dump())
    db.add(budget)
    db.commit()
    db.refresh(budget)
    return budget


def list_budgets(db: Session, tenant_id: uuid.UUID, fiscal_year: int | None):
    return repo.list_budgets(db, tenant_id, fiscal_year)


def update_budget(
    db: Session, tenant_id: uuid.UUID, budget_id: uuid.UUID, body: BudgetUpdate
) -> Budget:
    budget = repo.get_budget(db, tenant_id, budget_id)
    if not budget:
        raise NotFound("Budget")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(budget, field, value)
    db.commit()
    db.refresh(budget)
    return budget


def delete_budget(db: Session, tenant_id: uuid.UUID, budget_id: uuid.UUID) -> None:
    budget = repo.get_budget(db, tenant_id, budget_id)
    if not budget:
        raise NotFound("Budget")
    db.delete(budget)
    db.commit()


def budget_variance(db: Session, tenant_id: uuid.UUID, fiscal_year: int) -> dict:
    """Compare annual budgets to actual posted balances for the fiscal year."""
    if not fiscal_year:
        raise BadRequest("fiscal_year is required")
    accounts = {a.id: a for a in acc_repo.list_accounts(db, tenant_id)}
    totals = acc_repo.account_totals(db, tenant_id)
    budgets = [
        b for b in repo.list_budgets(db, tenant_id, fiscal_year) if b.fiscal_month is None
    ]
    rows = []
    total_budget = total_actual = 0.0
    for b in budgets:
        acc = accounts.get(b.account_id)
        if not acc:
            continue
        debit, credit = totals.get(acc.id, (0.0, 0.0))
        actual = (debit - credit) if acc.account_type in DEBIT_NORMAL else (credit - debit)
        actual = _round(actual)
        budget_amt = _round(b.amount)
        variance = _round(budget_amt - actual)
        total_budget += budget_amt
        total_actual += actual
        rows.append(
            {
                "account_id": acc.id,
                "account_code": acc.code,
                "account_name": acc.name,
                "budget": budget_amt,
                "actual": actual,
                "variance": variance,
                "variance_pct": _round(variance / budget_amt * 100) if budget_amt else 0.0,
            }
        )
    rows.sort(key=lambda r: r["account_code"])
    return {
        "fiscal_year": fiscal_year,
        "rows": rows,
        "total_budget": _round(total_budget),
        "total_actual": _round(total_actual),
        "total_variance": _round(total_budget - total_actual),
    }
