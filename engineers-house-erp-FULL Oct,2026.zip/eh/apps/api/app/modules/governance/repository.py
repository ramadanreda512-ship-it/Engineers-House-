"""Tenant-scoped data access for governance (approvals + budgets)."""
from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.governance.models import Approval, Budget


def get_approval(db: Session, tenant_id: uuid.UUID, approval_id: uuid.UUID) -> Approval | None:
    return db.scalar(
        select(Approval).where(Approval.id == approval_id, Approval.tenant_id == tenant_id)
    )


def list_approvals(db: Session, tenant_id: uuid.UUID, status: str | None):
    conds = [Approval.tenant_id == tenant_id]
    if status:
        conds.append(Approval.status == status)
    return db.scalars(
        select(Approval).where(*conds).order_by(Approval.created_at.desc())
    ).all()


def get_budget(db: Session, tenant_id: uuid.UUID, budget_id: uuid.UUID) -> Budget | None:
    return db.scalar(
        select(Budget).where(Budget.id == budget_id, Budget.tenant_id == tenant_id)
    )


def list_budgets(db: Session, tenant_id: uuid.UUID, fiscal_year: int | None):
    conds = [Budget.tenant_id == tenant_id]
    if fiscal_year:
        conds.append(Budget.fiscal_year == fiscal_year)
    return db.scalars(
        select(Budget).where(*conds).order_by(Budget.fiscal_year.desc())
    ).all()


def budget_exists(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID, year: int, month: int | None
) -> bool:
    return (
        db.scalar(
            select(Budget).where(
                Budget.tenant_id == tenant_id,
                Budget.account_id == account_id,
                Budget.fiscal_year == year,
                Budget.fiscal_month.is_(month) if month is None else Budget.fiscal_month == month,
            )
        )
        is not None
    )
