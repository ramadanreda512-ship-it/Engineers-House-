"""Governance schemas (approvals + budgets)."""
from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Approvals ---
class ApprovalCreate(BaseModel):
    entity_type: str = Field(
        pattern="^(journal_entry|voucher|payment|partner_transaction)$"
    )
    entity_id: uuid.UUID
    title: str = Field(min_length=2, max_length=255)
    amount: float = Field(ge=0, default=0)


class ApprovalDecision(BaseModel):
    comments: str | None = None


class ApprovalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    entity_type: str
    entity_id: uuid.UUID
    title: str
    amount: float
    requested_by: uuid.UUID
    approved_by: uuid.UUID | None
    status: str
    comments: str | None
    decided_at: datetime | None


# --- Budgets ---
class BudgetCreate(BaseModel):
    account_id: uuid.UUID
    fiscal_year: int = Field(ge=2000, le=2100)
    fiscal_month: int | None = Field(default=None, ge=1, le=12)
    amount: float = Field(ge=0)
    description: str | None = None


class BudgetUpdate(BaseModel):
    amount: float | None = Field(default=None, ge=0)
    description: str | None = None


class BudgetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    fiscal_year: int
    fiscal_month: int | None
    amount: float
    description: str | None


class BudgetVarianceRow(BaseModel):
    account_id: uuid.UUID
    account_code: str
    account_name: str
    budget: float
    actual: float
    variance: float
    variance_pct: float


class BudgetVarianceReport(BaseModel):
    fiscal_year: int
    rows: list[BudgetVarianceRow]
    total_budget: float
    total_actual: float
    total_variance: float
