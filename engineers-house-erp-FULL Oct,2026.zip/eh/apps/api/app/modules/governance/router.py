"""Governance HTTP endpoints (approvals + budgets)."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.governance import service
from app.modules.governance.schemas import (
    ApprovalCreate,
    ApprovalDecision,
    ApprovalOut,
    BudgetCreate,
    BudgetOut,
    BudgetUpdate,
    BudgetVarianceReport,
)
from app.modules.identity.models import User

router = APIRouter(prefix="/governance", tags=["governance"])

VIEW = "governance.view"
MANAGE = "governance.manage"
APPROVE = "governance.approve"


# --- Approvals ---
@router.post("/approvals", response_model=ApprovalOut, status_code=201)
def create_approval(
    body: ApprovalCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_approval(db, user.tenant_id, user.id, body)


@router.get("/approvals", response_model=list[ApprovalOut])
def list_approvals(
    status: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_approvals(db, user.tenant_id, status)


@router.post("/approvals/{approval_id}/approve", response_model=ApprovalOut)
def approve(
    approval_id: uuid.UUID,
    body: ApprovalDecision,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(APPROVE)),
):
    return service.approve(db, user.tenant_id, user.id, approval_id, body)


@router.post("/approvals/{approval_id}/reject", response_model=ApprovalOut)
def reject(
    approval_id: uuid.UUID,
    body: ApprovalDecision,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(APPROVE)),
):
    return service.reject(db, user.tenant_id, user.id, approval_id, body)


# --- Budgets ---
@router.post("/budgets", response_model=BudgetOut, status_code=201)
def create_budget(
    body: BudgetCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_budget(db, user.tenant_id, body)


@router.get("/budgets", response_model=list[BudgetOut])
def list_budgets(
    fiscal_year: int | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_budgets(db, user.tenant_id, fiscal_year)


@router.patch("/budgets/{budget_id}", response_model=BudgetOut)
def update_budget(
    budget_id: uuid.UUID,
    body: BudgetUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_budget(db, user.tenant_id, budget_id, body)


@router.delete("/budgets/{budget_id}", status_code=204)
def delete_budget(
    budget_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_budget(db, user.tenant_id, budget_id)


@router.get("/budgets/variance", response_model=BudgetVarianceReport)
def budget_variance(
    fiscal_year: int = Query(...),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.budget_variance(db, user.tenant_id, fiscal_year)
