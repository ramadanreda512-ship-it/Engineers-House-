"""Governance: approval workflow + annual/monthly budgets.

Approval: a generic request-and-approve record for sensitive entities
(journal entries, vouchers, payments). It lets a maker submit and a checker
approve/reject, giving a basic segregation-of-duties control.

Budget: a planned amount per accounting account per fiscal year (and optional
month). Budget-vs-actual at the account level powers variance reports that
complement the project-level budget feature.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.shared.base_model import GUID, Base, TimestampMixin

APPROVAL_ENTITY_TYPES = ("journal_entry", "voucher", "payment", "partner_transaction")
APPROVAL_STATUSES = ("pending", "approved", "rejected")


class Approval(Base, TimestampMixin):
    __tablename__ = "approvals"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    entity_type: Mapped[str] = mapped_column(String(30))
    entity_id: Mapped[uuid.UUID] = mapped_column(GUID())
    title: Mapped[str] = mapped_column(String(255))
    amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    requested_by: Mapped[uuid.UUID] = mapped_column(GUID())
    approved_by: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    status: Mapped[str] = mapped_column(String(12), default="pending")
    comments: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Budget(Base, TimestampMixin):
    __tablename__ = "budgets"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "account_id", "fiscal_year", "fiscal_month",
            name="uq_budget_account_period",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("gl_accounts.id"))
    fiscal_year: Mapped[int] = mapped_column()
    # null = annual budget; 1-12 = a specific month
    fiscal_month: Mapped[int | None] = mapped_column(nullable=True)
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
