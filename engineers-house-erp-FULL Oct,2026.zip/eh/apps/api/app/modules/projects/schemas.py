"""Pydantic schemas for the Projects (construction/EPC) module."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Project ---
class ProjectCreate(BaseModel):
    account_id: uuid.UUID | None = None
    code: str = Field(min_length=2, max_length=40)
    name: str = Field(min_length=2, max_length=255)
    contract_value: float = Field(ge=0)
    retention_pct: float = Field(ge=0, le=100, default=10)
    start_date: date | None = None
    expected_end_date: date | None = None
    budget_materials: float = Field(ge=0, default=0)
    budget_labor: float = Field(ge=0, default=0)
    budget_other: float = Field(ge=0, default=0)
    cost_center_id: uuid.UUID | None = None


class ProjectUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    contract_value: float | None = Field(default=None, ge=0)
    retention_pct: float | None = Field(default=None, ge=0, le=100)
    start_date: date | None = None
    expected_end_date: date | None = None
    status: str | None = None
    budget_materials: float | None = Field(default=None, ge=0)
    budget_labor: float | None = Field(default=None, ge=0)
    budget_other: float | None = Field(default=None, ge=0)
    cost_center_id: uuid.UUID | None = None


class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID | None = None
    code: str
    name: str
    contract_value: float
    retention_pct: float
    start_date: date | None = None
    expected_end_date: date | None = None
    status: str
    budget_materials: float = 0
    budget_labor: float = 0
    budget_other: float = 0
    cost_center_id: uuid.UUID | None = None


class BudgetVsActualRow(BaseModel):
    category: str
    budget: float
    actual: float
    variance: float
    variance_pct: float


class ProjectBudgetReport(BaseModel):
    project_id: uuid.UUID
    project_code: str
    project_name: str
    contract_value: float
    rows: list[BudgetVsActualRow]
    total_budget: float
    total_actual: float
    total_variance: float
    invoiced_amount: float
    received_amount: float
    projected_margin: float


# --- BOQ ---
class BOQItemCreate(BaseModel):
    item_code: str = Field(min_length=1, max_length=40)
    description: str = Field(min_length=2, max_length=500)
    unit: str = Field(min_length=1, max_length=20)
    planned_qty: float = Field(gt=0)
    unit_rate: float = Field(ge=0)


class BOQItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    item_code: str
    description: str
    unit: str
    planned_qty: float
    unit_rate: float
    executed_qty: float


class BOQProgressUpdate(BaseModel):
    executed_qty: float = Field(ge=0)


# --- Variation Order ---
class VariationOrderCreate(BaseModel):
    number: str = Field(min_length=1, max_length=40)
    description: str = Field(min_length=2, max_length=500)
    amount: float  # can be negative


class VariationOrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    number: str
    description: str
    amount: float
    status: str
    requested_at: datetime
    approved_at: datetime | None = None


# --- Progress Billing (IPC) ---
class ProgressBillingCreate(BaseModel):
    number: str = Field(min_length=1, max_length=40)
    billing_date: date
    cumulative_pct: float = Field(ge=0, le=100)


class ProgressBillingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    number: str
    billing_date: date
    cumulative_pct: float
    cumulative_gross: float
    previous_gross: float
    period_gross: float
    retention_amount: float
    net_payable: float
    status: str


# --- Retention Release ---
class RetentionReleaseCreate(BaseModel):
    amount: float = Field(gt=0)
    note: str | None = None


class RetentionReleaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    amount: float
    released_at: datetime
    note: str | None = None


# --- Subcontractor / Subcontract ---
class SubcontractorCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    trade: str | None = None
    contact_phone: str | None = None


class SubcontractorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    trade: str | None = None
    contact_phone: str | None = None


class SubcontractCreate(BaseModel):
    subcontractor_id: uuid.UUID
    scope: str = Field(min_length=2, max_length=500)
    contract_value: float = Field(ge=0)
    retention_pct: float = Field(ge=0, le=100, default=10)


class SubcontractOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    subcontractor_id: uuid.UUID
    scope: str
    contract_value: float
    retention_pct: float
    status: str


class SubcontractPaymentCreate(BaseModel):
    cumulative_pct: float = Field(ge=0, le=100)


class SubcontractPaymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    subcontract_id: uuid.UUID
    cumulative_pct: float
    period_gross: float
    retention_amount: float
    net_payable: float
    status: str


# --- Milestones ---
class MilestoneCreate(BaseModel):
    title: str = Field(min_length=2, max_length=255)
    description: str | None = None
    target_date: date | None = None
    weight: float = Field(gt=0, default=1)
    sort_order: int = 0


class MilestoneUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=255)
    description: str | None = None
    target_date: date | None = None
    weight: float | None = Field(default=None, gt=0)
    progress_pct: float | None = Field(default=None, ge=0, le=100)
    status: str | None = Field(default=None, pattern="^(pending|in_progress|completed|delayed)$")
    sort_order: int | None = None


class MilestoneOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    title: str
    description: str | None = None
    target_date: date | None = None
    weight: float = 1
    progress_pct: float = 0
    status: str = "pending"
    sort_order: int = 0


class ProjectProgress(BaseModel):
    project_id: uuid.UUID
    milestone_progress_pct: float
    boq_progress_pct: float
    overall_progress_pct: float


class ProjectsSummary(BaseModel):
    total_projects: int
    by_status: dict[str, int]
    total_contract_value: float
    total_invoiced: float
    total_received: float
    total_actual_cost: float
