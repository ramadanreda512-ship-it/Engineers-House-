"""Construction project business logic.

The core financial rule implemented here, matching standard construction
ERP practice (Interim Payment Certificates / progress billing):

    effective_contract_value = contract_value + sum(approved variation orders)
    cumulative_gross          = effective_contract_value * (cumulative_pct / 100)
    period_gross              = cumulative_gross - previous_cumulative_gross
    retention_amount          = period_gross * (retention_pct / 100)
    net_payable               = period_gross - retention_amount

This calculation is done server-side and only server-side — the client
supplies the measured cumulative completion percentage, nothing else, so the
money math can never be entered or overridden by hand.

Other rules enforced here:
- A variation order's value only affects billing once it is APPROVED.
- A new progress billing's cumulative_pct must be >= the previous billing's
  (completion cannot regress on paper).
- Subcontract payments follow the identical percentage-of-completion logic,
  independently from the main contract billing (back-to-back, not coupled).
"""
from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.modules.projects import repository as repo
from app.modules.projects.models import (
    BOQItem,
    ProgressBilling,
    Project,
    RetentionRelease,
    Subcontract,
    Subcontractor,
    SubcontractPayment,
    VariationOrder,
)
from app.modules.projects.schemas import (
    BOQItemCreate,
    BOQProgressUpdate,
    ProgressBillingCreate,
    ProjectCreate,
    ProjectUpdate,
    RetentionReleaseCreate,
    SubcontractCreate,
    SubcontractorCreate,
    SubcontractPaymentCreate,
    VariationOrderCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


# --- Project ---
def create_project(db: Session, tenant_id: uuid.UUID, body: ProjectCreate) -> Project:
    project = Project(tenant_id=tenant_id, **body.model_dump())
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


def list_projects(
    db: Session, tenant_id: uuid.UUID, page: int, size: int,
    search: str | None = None, status: str | None = None,
):
    return repo.list_projects(db, tenant_id, size, (page - 1) * size, search=search, status=status)


def get_project(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> Project:
    return _ensure_project(db, tenant_id, project_id)


def _ensure_project(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> Project:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    return project


def update_project(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: ProjectUpdate
) -> Project:
    project = _ensure_project(db, tenant_id, project_id)
    data = body.model_dump(exclude_unset=True)
    # Contract value is locked once billings exist (it changes IPC math).
    if "contract_value" in data and repo.project_has_billings(db, project_id):
        raise Conflict(
            "Cannot change the contract value after progress billings exist. "
            "Use a variation order instead."
        )
    for field, value in data.items():
        setattr(project, field, value)
    db.commit()
    db.refresh(project)
    return project


def cancel_project(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> Project:
    project = _ensure_project(db, tenant_id, project_id)
    project.status = "cancelled"
    db.commit()
    db.refresh(project)
    return project


def delete_project(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> None:
    project = _ensure_project(db, tenant_id, project_id)
    if repo.project_has_billings(db, project_id):
        raise Conflict(
            "Cannot delete a project that has progress billings. Cancel it "
            "instead to keep its financial history."
        )
    db.delete(project)
    db.commit()


def list_boq_items(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    _ensure_project(db, tenant_id, project_id)
    return repo.list_boq_items(db, project_id)


def list_variation_orders(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    _ensure_project(db, tenant_id, project_id)
    return repo.list_variation_orders(db, project_id)


def list_billings(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    _ensure_project(db, tenant_id, project_id)
    return repo.list_billings(db, project_id)


def list_subcontracts(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    _ensure_project(db, tenant_id, project_id)
    return repo.list_subcontracts(db, project_id)


def list_subcontractors(db: Session, tenant_id: uuid.UUID):
    return repo.list_subcontractors(db, tenant_id)


# --- BOQ ---
def add_boq_item(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: BOQItemCreate
) -> BOQItem:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    item = BOQItem(project_id=project_id, **body.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def update_boq_progress(
    db: Session,
    tenant_id: uuid.UUID,
    project_id: uuid.UUID,
    item_id: uuid.UUID,
    body: BOQProgressUpdate,
) -> BOQItem:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    item = repo.get_boq_item(db, project_id, item_id)
    if not item:
        raise NotFound("BOQ item")
    if body.executed_qty > item.planned_qty:
        raise BadRequest(
            f"Executed quantity ({body.executed_qty}) cannot exceed planned quantity "
            f"({item.planned_qty}) for item {item.item_code}"
        )
    item.executed_qty = body.executed_qty
    db.commit()
    db.refresh(item)
    return item


# --- Variation Orders ---
def request_variation_order(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: VariationOrderCreate
) -> VariationOrder:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    vo = VariationOrder(
        project_id=project_id,
        status="pending",
        requested_at=datetime.now(UTC),
        **body.model_dump(),
    )
    db.add(vo)
    db.commit()
    db.refresh(vo)
    return vo


def approve_variation_order(
    db: Session,
    tenant_id: uuid.UUID,
    project_id: uuid.UUID,
    vo_id: uuid.UUID,
    approver_id: uuid.UUID,
) -> VariationOrder:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    vo = repo.get_variation_order(db, project_id, vo_id)
    if not vo:
        raise NotFound("Variation order")
    if vo.status != "pending":
        raise Conflict(f"Variation order is already {vo.status}")
    vo.status = "approved"
    vo.approved_at = datetime.now(UTC)
    vo.approved_by = approver_id
    db.commit()
    db.refresh(vo)
    return vo


# --- Progress Billing (IPC) ---
def create_progress_billing(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: ProgressBillingCreate
) -> ProgressBilling:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")

    previous = repo.last_billing(db, project_id)
    previous_pct = float(previous.cumulative_pct) if previous else 0.0
    if body.cumulative_pct < previous_pct:
        raise BadRequest(
            f"Cumulative completion ({body.cumulative_pct}%) cannot be lower than the "
            f"previous billing's ({previous_pct}%)"
        )

    effective_contract_value = float(project.contract_value) + repo.approved_variation_total(
        db, project_id
    )
    cumulative_gross = round(effective_contract_value * (body.cumulative_pct / 100), 2)
    previous_gross = round(float(previous.cumulative_gross), 2) if previous else 0.0
    period_gross = round(cumulative_gross - previous_gross, 2)
    if period_gross < 0:
        raise BadRequest("Computed period billing is negative; check cumulative percentage")

    retention_amount = round(period_gross * (float(project.retention_pct) / 100), 2)
    net_payable = round(period_gross - retention_amount, 2)

    billing = ProgressBilling(
        project_id=project_id,
        number=body.number,
        billing_date=body.billing_date,
        cumulative_pct=body.cumulative_pct,
        cumulative_gross=cumulative_gross,
        previous_gross=previous_gross,
        period_gross=period_gross,
        retention_amount=retention_amount,
        net_payable=net_payable,
        status="draft",
    )
    db.add(billing)
    db.commit()
    db.refresh(billing)
    return billing


# --- Retention release ---
def release_retention(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: RetentionReleaseCreate
) -> RetentionRelease:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    release = RetentionRelease(
        project_id=project_id, released_at=datetime.now(UTC), **body.model_dump()
    )
    db.add(release)
    db.commit()
    db.refresh(release)
    return release


# --- Subcontractors / Subcontracts ---
def create_subcontractor(
    db: Session, tenant_id: uuid.UUID, body: SubcontractorCreate
) -> Subcontractor:
    subcontractor = Subcontractor(tenant_id=tenant_id, **body.model_dump())
    db.add(subcontractor)
    db.commit()
    db.refresh(subcontractor)
    return subcontractor


def award_subcontract(
    db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body: SubcontractCreate
) -> Subcontract:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    if not repo.get_subcontractor(db, tenant_id, body.subcontractor_id):
        raise NotFound("Subcontractor")
    subcontract = Subcontract(project_id=project_id, status="active", **body.model_dump())
    db.add(subcontract)
    db.commit()
    db.refresh(subcontract)
    return subcontract


def _last_subcontract_payment(db: Session, subcontract_id: uuid.UUID) -> SubcontractPayment | None:
    from sqlalchemy import select

    return db.scalar(
        select(SubcontractPayment)
        .where(SubcontractPayment.subcontract_id == subcontract_id)
        .order_by(SubcontractPayment.created_at.desc())
        .limit(1)
    )


def record_subcontract_payment(
    db: Session,
    tenant_id: uuid.UUID,
    project_id: uuid.UUID,
    subcontract_id: uuid.UUID,
    body: SubcontractPaymentCreate,
) -> SubcontractPayment:
    project = repo.get_project(db, tenant_id, project_id)
    if not project:
        raise NotFound("Project")
    subcontract = repo.get_subcontract(db, project_id, subcontract_id)
    if not subcontract:
        raise NotFound("Subcontract")

    previous = _last_subcontract_payment(db, subcontract_id)
    previous_pct = float(previous.cumulative_pct) if previous else 0.0
    if body.cumulative_pct < previous_pct:
        raise BadRequest("Cumulative completion cannot be lower than the previous payment's")

    cumulative_gross = round(float(subcontract.contract_value) * (body.cumulative_pct / 100), 2)
    previous_gross = (
        round(float(previous.cumulative_pct) / 100 * float(subcontract.contract_value), 2)
        if previous
        else 0.0
    )
    period_gross = round(cumulative_gross - previous_gross, 2)
    retention_amount = round(period_gross * (float(subcontract.retention_pct) / 100), 2)
    net_payable = round(period_gross - retention_amount, 2)

    payment = SubcontractPayment(
        subcontract_id=subcontract_id,
        cumulative_pct=body.cumulative_pct,
        period_gross=period_gross,
        retention_amount=retention_amount,
        net_payable=net_payable,
        status="pending",
    )
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment


# --- Budget vs Actual report ---
# Maps accounting expense account codes to budget categories. Material/labor
# codes mirror the legacy chart (510101 material, 510102 wages); everything
# else falls under "other".
_MATERIAL_CODES = ("510101",)
_LABOR_CODES = ("510102", "5202")


def _project_actuals(db: Session, tenant_id: uuid.UUID, project: Project):
    """Compute actual cost per category for a project from the accounting
    cost-center postings (if a cost center is linked) plus linked finance
    expenses. Returns (materials, labor, other)."""
    from sqlalchemy import func, select

    from app.modules.accounting.models import GLAccount, JournalEntry, JournalLine
    from app.modules.finance.models import Expense

    materials = labor = other = 0.0

    # 1) From accounting cost-center postings (debits to expense accounts).
    if project.cost_center_id:
        rows = db.execute(
            select(GLAccount.code, JournalLine.debit, JournalLine.credit)
            .join(JournalLine, JournalLine.account_id == GLAccount.id)
            .join(JournalEntry, JournalLine.entry_id == JournalEntry.id)
            .where(
                JournalLine.tenant_id == tenant_id,
                JournalLine.cost_center_id == project.cost_center_id,
                JournalEntry.status == "posted",
                GLAccount.account_type == "expense",
            )
        ).all()
        for code, debit, credit in rows:
            amt = float(debit) - float(credit)
            if code in _MATERIAL_CODES:
                materials += amt
            elif code in _LABOR_CODES:
                labor += amt
            else:
                other += amt

    # 2) From finance expenses tagged to this project (counted as "other"
    #    unless already captured via the ledger).
    exp_total = db.scalar(
        select(func.coalesce(func.sum(Expense.amount), 0)).where(
            Expense.tenant_id == tenant_id, Expense.project_id == project.id
        )
    )
    if exp_total and not project.cost_center_id:
        other += float(exp_total)

    return round(materials, 2), round(labor, 2), round(other, 2)


def project_budget_report(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> dict:
    from sqlalchemy import func, select

    project = get_project(db, tenant_id, project_id)
    mat_actual, lab_actual, oth_actual = _project_actuals(db, tenant_id, project)

    def _row(category, budget, actual):
        variance = round(budget - actual, 2)
        variance_pct = round((variance / budget * 100), 2) if budget else 0.0
        return {
            "category": category,
            "budget": round(float(budget), 2),
            "actual": round(float(actual), 2),
            "variance": variance,
            "variance_pct": variance_pct,
        }

    rows = [
        _row("materials", float(project.budget_materials), mat_actual),
        _row("labor", float(project.budget_labor), lab_actual),
        _row("other", float(project.budget_other), oth_actual),
    ]
    total_budget = round(sum(r["budget"] for r in rows), 2)
    total_actual = round(sum(r["actual"] for r in rows), 2)

    # Invoiced / received from finance invoices linked to this project.
    from app.modules.finance.models import Invoice, Payment

    invoiced = float(
        db.scalar(
            select(func.coalesce(func.sum(Invoice.total), 0)).where(
                Invoice.tenant_id == tenant_id, Invoice.project_id == project_id
            )
        )
        or 0
    )
    received = float(
        db.scalar(
            select(func.coalesce(func.sum(Payment.amount), 0))
            .select_from(Payment)
            .join(Invoice, Payment.invoice_id == Invoice.id)
            .where(Invoice.tenant_id == tenant_id, Invoice.project_id == project_id)
        )
        or 0
    )

    return {
        "project_id": project.id,
        "project_code": project.code,
        "project_name": project.name,
        "contract_value": round(float(project.contract_value), 2),
        "rows": rows,
        "total_budget": total_budget,
        "total_actual": total_actual,
        "total_variance": round(total_budget - total_actual, 2),
        "invoiced_amount": round(invoiced, 2),
        "received_amount": round(received, 2),
        "projected_margin": round(float(project.contract_value) - total_actual, 2),
    }


# --- Milestones ---
def add_milestone(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID, body) -> object:
    from app.modules.projects.models import ProjectMilestone

    get_project(db, tenant_id, project_id)
    ms = ProjectMilestone(
        tenant_id=tenant_id, project_id=project_id, progress_pct=0, status="pending",
        **body.model_dump(),
    )
    db.add(ms)
    db.commit()
    db.refresh(ms)
    return ms


def list_milestones(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    get_project(db, tenant_id, project_id)
    return repo.list_milestones(db, tenant_id, project_id)


def update_milestone(db: Session, tenant_id: uuid.UUID, milestone_id: uuid.UUID, body) -> object:
    ms = repo.get_milestone(db, tenant_id, milestone_id)
    if not ms:
        raise NotFound("Milestone")
    data = body.model_dump(exclude_unset=True)
    # Completing sets progress to 100; 100% progress marks completed.
    if data.get("status") == "completed":
        data.setdefault("progress_pct", 100)
    if data.get("progress_pct") == 100:
        data.setdefault("status", "completed")
    for field, value in data.items():
        setattr(ms, field, value)
    db.commit()
    db.refresh(ms)
    return ms


def delete_milestone(db: Session, tenant_id: uuid.UUID, milestone_id: uuid.UUID) -> None:
    ms = repo.get_milestone(db, tenant_id, milestone_id)
    if not ms:
        raise NotFound("Milestone")
    db.delete(ms)
    db.commit()


def project_progress(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> dict:
    """Weighted progress roll-up from milestones and BOQ quantities."""
    project = get_project(db, tenant_id, project_id)
    # Milestones: weight-averaged progress.
    milestones = repo.list_milestones(db, tenant_id, project_id)
    total_w = sum(float(m.weight) for m in milestones)
    ms_pct = (
        round(sum(float(m.weight) * float(m.progress_pct) for m in milestones) / total_w, 1)
        if total_w
        else 0.0
    )
    # BOQ: value-weighted executed percentage.
    boq = repo.list_boq_items(db, project_id)
    total_value = sum(float(i.planned_qty) * float(i.unit_rate) for i in boq)
    boq_pct = (
        round(
            sum(float(i.executed_qty) * float(i.unit_rate) for i in boq) / total_value * 100, 1
        )
        if total_value
        else 0.0
    )
    # Overall: prefer BOQ if it exists (contract-based), else milestones.
    overall = boq_pct if total_value else ms_pct
    if total_value and total_w:
        overall = round((boq_pct + ms_pct) / 2, 1)
    return {
        "project_id": project.id,
        "milestone_progress_pct": ms_pct,
        "boq_progress_pct": boq_pct,
        "overall_progress_pct": overall,
    }


def projects_summary(db: Session, tenant_id: uuid.UUID) -> dict:
    """Portfolio KPIs: counts, contract value, invoiced/received, actual cost."""
    from sqlalchemy import func, select

    from app.modules.finance.models import Invoice, Payment

    projects, _ = repo.list_projects(db, tenant_id, 100000, 0)
    by_status: dict[str, int] = {}
    total_contract = 0.0
    total_actual = 0.0
    for p in projects:
        by_status[p.status] = by_status.get(p.status, 0) + 1
        total_contract += float(p.contract_value)
        mat, lab, oth = _project_actuals(db, tenant_id, p)
        total_actual += mat + lab + oth
    invoiced = float(db.scalar(
        select(func.coalesce(func.sum(Invoice.total), 0)).where(
            Invoice.tenant_id == tenant_id, Invoice.project_id.is_not(None)
        )
    ) or 0)
    received = float(db.scalar(
        select(func.coalesce(func.sum(Payment.amount), 0))
        .select_from(Payment)
        .join(Invoice, Payment.invoice_id == Invoice.id)
        .where(Invoice.tenant_id == tenant_id, Invoice.project_id.is_not(None))
    ) or 0)
    return {
        "total_projects": len(projects),
        "by_status": by_status,
        "total_contract_value": round(total_contract, 2),
        "total_invoiced": round(invoiced, 2),
        "total_received": round(received, 2),
        "total_actual_cost": round(total_actual, 2),
    }


# --- CSV import / export ---
def export_projects_csv(db: Session, tenant_id: uuid.UUID) -> dict:
    import csv
    import io
    from datetime import date as _date

    items, _ = repo.list_projects(db, tenant_id, 100000, 0)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Code", "Name", "Contract Value", "Status", "Retention %"])
    for p in items:
        w.writerow([
            p.code, p.name, float(p.contract_value), p.status,
            float(p.retention_pct) if p.retention_pct is not None else 0,
        ])
    return {
        "filename": f"projects-{_date.today().isoformat()}.csv",
        "content": "\ufeff" + buf.getvalue(),
    }


def import_projects_csv(db: Session, tenant_id: uuid.UUID, content: str) -> dict:
    from sqlalchemy import select

    from app.modules.projects.models import Project
    from app.shared.csv_io import parse_csv_rows, pick, to_float

    rows = parse_csv_rows(content)
    created, skipped, errors = 0, 0, []
    for idx, row in enumerate(rows, start=2):
        code = pick(row, "code", "الكود")
        name = pick(row, "name", "الاسم", "اسم المشروع")
        if not code or not name:
            errors.append({"row": idx, "reason": "missing code or name"})
            continue
        existing = db.scalar(
            select(Project).where(Project.tenant_id == tenant_id, Project.code == code)
        )
        if existing:
            skipped += 1
            errors.append({"row": idx, "reason": f"project code '{code}' already exists"})
            continue
        status = pick(row, "status", "الحالة") or "planned"
        if status not in ("planned", "active", "on_hold", "completed", "cancelled"):
            status = "planned"
        db.add(Project(
            tenant_id=tenant_id,
            code=code,
            name=name,
            contract_value=to_float(pick(row, "contract value", "قيمة العقد")),
            status=status,
            retention_pct=to_float(pick(row, "retention %", "نسبة الاحتجاز"), 0),
        ))
        db.flush()
        created += 1
    db.commit()
    return {"created": created, "skipped": skipped, "errors": errors}
