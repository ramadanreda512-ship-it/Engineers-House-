"""Construction / industrial project models.

This module deliberately does NOT reuse the CRM Quotation/Invoice shape.
Construction-style project billing is percentage-of-completion against a
contract value, not a flat line-item invoice — see the eponymous service
layer for the IPC (Interim Payment Certificate) calculation that is the
financial heart of this module.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Project(Base, TimestampMixin):
    __tablename__ = "projects"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_project_tenant_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    # CRM account (client)
    account_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    code: Mapped[str] = mapped_column(String(40))  # e.g. PRJ-2026-001
    name: Mapped[str] = mapped_column(String(255))
    contract_value: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    # % held back per billing
    retention_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=10)
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    expected_end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="planned")
    # planned/active/on_hold/completed/cancelled

    # --- Budget (planned cost), split by category. Actuals are computed from
    # the accounting cost-center postings and finance expenses at report time. ---
    budget_materials: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    budget_labor: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    budget_other: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    # Optional link to the accounting cost center that tracks this project's costs.
    cost_center_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    boq_items: Mapped[list[BOQItem]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )
    variation_orders: Mapped[list[VariationOrder]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )
    billings: Mapped[list[ProgressBilling]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )
    subcontracts: Mapped[list[Subcontract]] = relationship(
        back_populates="project", cascade="all, delete-orphan", lazy="selectin"
    )


class BOQItem(Base, TimestampMixin):
    """Bill of Quantities line: planned quantity x unit rate, with cumulative
    executed quantity tracked separately so progress is auditable per item."""

    __tablename__ = "boq_items"
    __table_args__ = (UniqueConstraint("project_id", "item_code", name="uq_boq_project_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    item_code: Mapped[str] = mapped_column(String(40))  # e.g. "2.1"
    description: Mapped[str] = mapped_column(String(500))
    unit: Mapped[str] = mapped_column(String(20))  # e.g. "m", "no", "kg", "lump sum"
    planned_qty: Mapped[float] = mapped_column(Numeric(14, 3))
    unit_rate: Mapped[float] = mapped_column(Numeric(14, 2))
    executed_qty: Mapped[float] = mapped_column(Numeric(14, 3), default=0)

    project: Mapped[Project] = relationship(back_populates="boq_items")


class VariationOrder(Base, TimestampMixin):
    """Change to contracted scope after award. Must be approved before its
    value is included in any progress billing calculation."""

    __tablename__ = "variation_orders"
    __table_args__ = (UniqueConstraint("project_id", "number", name="uq_vo_project_number"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    number: Mapped[str] = mapped_column(String(40))  # e.g. VO-001
    description: Mapped[str] = mapped_column(String(500))
    amount: Mapped[float] = mapped_column(Numeric(16, 2))  # can be negative (scope reduction)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    # pending/approved/rejected
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    approved_by: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    project: Mapped[Project] = relationship(back_populates="variation_orders")


class ProgressBilling(Base, TimestampMixin):
    """An Interim Payment Certificate (IPC): a percentage-of-completion
    billing event. cumulative_pct is the running completion percentage as of
    this billing; the service layer derives gross/retention/net amounts from
    it so the math is never duplicated or entered by hand."""

    __tablename__ = "progress_billings"
    __table_args__ = (UniqueConstraint("project_id", "number", name="uq_billing_project_number"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    number: Mapped[str] = mapped_column(String(40))  # e.g. IPC-01
    billing_date: Mapped[date] = mapped_column(Date)
    # 0-100, cumulative to date
    cumulative_pct: Mapped[float] = mapped_column(Numeric(5, 2))
    cumulative_gross: Mapped[float] = mapped_column(Numeric(16, 2))  # contract+VO value * pct
    previous_gross: Mapped[float] = mapped_column(Numeric(16, 2))  # gross as of prior IPC
    period_gross: Mapped[float] = mapped_column(Numeric(16, 2))  # this period's gross billing
    retention_amount: Mapped[float] = mapped_column(Numeric(16, 2))  # retained from this period
    net_payable: Mapped[float] = mapped_column(Numeric(16, 2))  # period_gross - retention
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # draft/certified/paid

    project: Mapped[Project] = relationship(back_populates="billings")


class RetentionRelease(Base, TimestampMixin):
    """Release of previously withheld retention money, typically at handover
    or after the defects-liability period."""

    __tablename__ = "retention_releases"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    released_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    note: Mapped[str | None] = mapped_column(String(255), nullable=True)


class Subcontractor(Base, TimestampMixin):
    __tablename__ = "subcontractors"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    name: Mapped[str] = mapped_column(String(255))
    trade: Mapped[str | None] = mapped_column(String(120), nullable=True)  # e.g. "Electrical"
    contact_phone: Mapped[str | None] = mapped_column(String(40), nullable=True)


class Subcontract(Base, TimestampMixin):
    """A subcontract package awarded against a project, billed independently
    from the main contract's progress billing (back-to-back terms)."""

    __tablename__ = "subcontracts"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    subcontractor_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("subcontractors.id")
    )
    scope: Mapped[str] = mapped_column(String(500))
    contract_value: Mapped[float] = mapped_column(Numeric(16, 2))
    retention_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=10)
    status: Mapped[str] = mapped_column(String(20), default="active")

    project: Mapped[Project] = relationship(back_populates="subcontracts")
    payments: Mapped[list[SubcontractPayment]] = relationship(
        back_populates="subcontract", cascade="all, delete-orphan", lazy="selectin"
    )


class SubcontractPayment(Base, TimestampMixin):
    __tablename__ = "subcontract_payments"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    subcontract_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("subcontracts.id", ondelete="CASCADE")
    )
    cumulative_pct: Mapped[float] = mapped_column(Numeric(5, 2))
    period_gross: Mapped[float] = mapped_column(Numeric(16, 2))
    retention_amount: Mapped[float] = mapped_column(Numeric(16, 2))
    net_payable: Mapped[float] = mapped_column(Numeric(16, 2))
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending")

    subcontract: Mapped[Subcontract] = relationship(back_populates="payments")


class ProjectMilestone(Base, TimestampMixin):
    """A named project phase/milestone with target date, weight and progress.
    Mirrors the competitor app's ProjectMilestone, improved with a weight so
    the project-level progress can be computed as a weighted roll-up."""

    __tablename__ = "project_milestones"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    project_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("projects.id", ondelete="CASCADE")
    )
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    target_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    weight: Mapped[float] = mapped_column(Numeric(5, 2), default=1)  # relative weight
    progress_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)  # 0-100
    status: Mapped[str] = mapped_column(String(20), default="pending")
    # pending / in_progress / completed / delayed
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
