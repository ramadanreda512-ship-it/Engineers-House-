"""Construction Projects HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.projects import service
from app.modules.projects.schemas import (
    BOQItemCreate,
    BOQItemOut,
    BOQProgressUpdate,
    MilestoneCreate,
    MilestoneOut,
    MilestoneUpdate,
    ProgressBillingCreate,
    ProgressBillingOut,
    ProjectBudgetReport,
    ProjectCreate,
    ProjectOut,
    ProjectProgress,
    ProjectsSummary,
    ProjectUpdate,
    RetentionReleaseCreate,
    RetentionReleaseOut,
    SubcontractCreate,
    SubcontractorCreate,
    SubcontractorOut,
    SubcontractOut,
    SubcontractPaymentCreate,
    SubcontractPaymentOut,
    VariationOrderCreate,
    VariationOrderOut,
)
from app.shared.csv_io import CsvExportOut, CsvImportBody
from app.shared.pagination import Page

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=ProjectOut, status_code=201)
def create_project(
    body: ProjectCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.create")),
):
    return service.create_project(db, user.tenant_id, body)


@router.get("", response_model=Page[ProjectOut])
def list_projects(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    status: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    items, total = service.list_projects(
        db, user.tenant_id, page, size, search=search, status=status
    )
    return Page(items=items, total=total, page=page, size=size)


@router.get("/summary", response_model=ProjectsSummary)
def projects_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.projects_summary(db, user.tenant_id)


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.get_project(db, user.tenant_id, project_id)


@router.get("/{project_id}/budget-report", response_model=ProjectBudgetReport)
def project_budget_report(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.project_budget_report(db, user.tenant_id, project_id)


@router.patch("/{project_id}", response_model=ProjectOut)
def update_project(
    project_id: uuid.UUID,
    body: ProjectUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.create")),
):
    return service.update_project(db, user.tenant_id, project_id, body)


@router.post("/{project_id}/cancel", response_model=ProjectOut)
def cancel_project(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.create")),
):
    return service.cancel_project(db, user.tenant_id, project_id)


@router.delete("/{project_id}", status_code=204)
def delete_project(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.delete")),
):
    service.delete_project(db, user.tenant_id, project_id)


@router.post("/{project_id}/boq", response_model=BOQItemOut, status_code=201)
def add_boq_item(
    project_id: uuid.UUID,
    body: BOQItemCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.boq.manage")),
):
    return service.add_boq_item(db, user.tenant_id, project_id, body)


@router.get("/{project_id}/boq", response_model=list[BOQItemOut])
def list_boq_items(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_boq_items(db, user.tenant_id, project_id)


@router.patch("/{project_id}/boq/{item_id}/progress", response_model=BOQItemOut)
def update_boq_progress(
    project_id: uuid.UUID,
    item_id: uuid.UUID,
    body: BOQProgressUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.boq.manage")),
):
    return service.update_boq_progress(db, user.tenant_id, project_id, item_id, body)


@router.post("/{project_id}/variation-orders", response_model=VariationOrderOut, status_code=201)
def request_variation_order(
    project_id: uuid.UUID,
    body: VariationOrderCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.variation.request")),
):
    return service.request_variation_order(db, user.tenant_id, project_id, body)


@router.get("/{project_id}/variation-orders", response_model=list[VariationOrderOut])
def list_variation_orders(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_variation_orders(db, user.tenant_id, project_id)


@router.post(
    "/{project_id}/variation-orders/{vo_id}/approve", response_model=VariationOrderOut
)
def approve_variation_order(
    project_id: uuid.UUID,
    vo_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.variation.approve")),
):
    return service.approve_variation_order(db, user.tenant_id, project_id, vo_id, user.id)


@router.post(
    "/{project_id}/billings", response_model=ProgressBillingOut, status_code=201
)
def create_progress_billing(
    project_id: uuid.UUID,
    body: ProgressBillingCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.billing.create")),
):
    return service.create_progress_billing(db, user.tenant_id, project_id, body)


@router.get("/{project_id}/billings", response_model=list[ProgressBillingOut])
def list_billings(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_billings(db, user.tenant_id, project_id)


@router.post(
    "/{project_id}/retention-releases", response_model=RetentionReleaseOut, status_code=201
)
def release_retention(
    project_id: uuid.UUID,
    body: RetentionReleaseCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.retention.release")),
):
    return service.release_retention(db, user.tenant_id, project_id, body)


@router.post("/subcontractors", response_model=SubcontractorOut, status_code=201)
def create_subcontractor(
    body: SubcontractorCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.subcontractor.create")),
):
    return service.create_subcontractor(db, user.tenant_id, body)


@router.get("/subcontractors", response_model=list[SubcontractorOut])
def list_subcontractors(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_subcontractors(db, user.tenant_id)


@router.post("/{project_id}/subcontracts", response_model=SubcontractOut, status_code=201)
def award_subcontract(
    project_id: uuid.UUID,
    body: SubcontractCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.subcontract.award")),
):
    return service.award_subcontract(db, user.tenant_id, project_id, body)


@router.get("/{project_id}/subcontracts", response_model=list[SubcontractOut])
def list_subcontracts(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_subcontracts(db, user.tenant_id, project_id)


@router.post(
    "/{project_id}/subcontracts/{subcontract_id}/payments",
    response_model=SubcontractPaymentOut,
    status_code=201,
)
def record_subcontract_payment(
    project_id: uuid.UUID,
    subcontract_id: uuid.UUID,
    body: SubcontractPaymentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.subcontract.payment")),
):
    return service.record_subcontract_payment(
        db, user.tenant_id, project_id, subcontract_id, body
    )


# --- Milestones & progress ---
@router.post("/{project_id}/milestones", response_model=MilestoneOut, status_code=201)
def add_milestone(
    project_id: uuid.UUID,
    body: MilestoneCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.manage")),
):
    return service.add_milestone(db, user.tenant_id, project_id, body)


@router.get("/{project_id}/milestones", response_model=list[MilestoneOut])
def list_milestones(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.list_milestones(db, user.tenant_id, project_id)


@router.patch("/milestones/{milestone_id}", response_model=MilestoneOut)
def update_milestone(
    milestone_id: uuid.UUID,
    body: MilestoneUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.manage")),
):
    return service.update_milestone(db, user.tenant_id, milestone_id, body)


@router.delete("/milestones/{milestone_id}", status_code=204)
def delete_milestone(
    milestone_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.delete")),
):
    service.delete_milestone(db, user.tenant_id, milestone_id)


@router.get("/{project_id}/progress", response_model=ProjectProgress)
def project_progress(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.project_progress(db, user.tenant_id, project_id)


# --- CSV import / export ---
@router.get("/export/csv", response_model=CsvExportOut)
def export_projects(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.view")),
):
    return service.export_projects_csv(db, user.tenant_id)


@router.post("/import/csv", response_model=None)
def import_projects(
    body: CsvImportBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("project.manage")),
):
    return service.import_projects_csv(db, user.tenant_id, body.content)
