"""Tenant-scoped data access for the Projects module."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.projects.models import (
    BOQItem,
    ProgressBilling,
    Project,
    Subcontract,
    Subcontractor,
    VariationOrder,
)


def get_project(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID) -> Project | None:
    return db.scalar(
        select(Project).where(Project.id == project_id, Project.tenant_id == tenant_id)
    )


def get_boq_item(db: Session, project_id: uuid.UUID, item_id: uuid.UUID) -> BOQItem | None:
    return db.scalar(
        select(BOQItem).where(BOQItem.id == item_id, BOQItem.project_id == project_id)
    )


def get_variation_order(
    db: Session, project_id: uuid.UUID, vo_id: uuid.UUID
) -> VariationOrder | None:
    return db.scalar(
        select(VariationOrder).where(
            VariationOrder.id == vo_id, VariationOrder.project_id == project_id
        )
    )


def get_subcontractor(
    db: Session, tenant_id: uuid.UUID, subcontractor_id: uuid.UUID
) -> Subcontractor | None:
    return db.scalar(
        select(Subcontractor).where(
            Subcontractor.id == subcontractor_id, Subcontractor.tenant_id == tenant_id
        )
    )


def get_subcontract(
    db: Session, project_id: uuid.UUID, subcontract_id: uuid.UUID
) -> Subcontract | None:
    return db.scalar(
        select(Subcontract).where(
            Subcontract.id == subcontract_id, Subcontract.project_id == project_id
        )
    )


def approved_variation_total(db: Session, project_id: uuid.UUID) -> float:
    total = db.scalar(
        select(func.coalesce(func.sum(VariationOrder.amount), 0)).where(
            VariationOrder.project_id == project_id, VariationOrder.status == "approved"
        )
    )
    return float(total or 0)


def last_billing(db: Session, project_id: uuid.UUID) -> ProgressBilling | None:
    return db.scalar(
        select(ProgressBilling)
        .where(ProgressBilling.project_id == project_id)
        .order_by(ProgressBilling.billing_date.desc(), ProgressBilling.created_at.desc())
        .limit(1)
    )


def list_projects(
    db: Session, tenant_id: uuid.UUID, limit: int, offset: int,
    search: str | None = None, status: str | None = None,
):
    conds = [Project.tenant_id == tenant_id]
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(Project.name).like(like) | func.lower(Project.code).like(like)
        )
    if status:
        conds.append(Project.status == status)
    stmt = select(Project).where(*conds).order_by(Project.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Project).where(*conds))
    return items, total or 0


def list_milestones(db: Session, tenant_id: uuid.UUID, project_id: uuid.UUID):
    from app.modules.projects.models import ProjectMilestone

    return db.scalars(
        select(ProjectMilestone)
        .where(
            ProjectMilestone.tenant_id == tenant_id,
            ProjectMilestone.project_id == project_id,
        )
        .order_by(ProjectMilestone.sort_order.asc(), ProjectMilestone.created_at.asc())
    ).all()


def get_milestone(db: Session, tenant_id: uuid.UUID, milestone_id: uuid.UUID):
    from app.modules.projects.models import ProjectMilestone

    return db.scalar(
        select(ProjectMilestone).where(
            ProjectMilestone.id == milestone_id, ProjectMilestone.tenant_id == tenant_id
        )
    )


def list_boq_items(db: Session, project_id: uuid.UUID):
    stmt = (
        select(BOQItem).where(BOQItem.project_id == project_id).order_by(BOQItem.item_code.asc())
    )
    return db.scalars(stmt).all()


def list_variation_orders(db: Session, project_id: uuid.UUID):
    stmt = (
        select(VariationOrder)
        .where(VariationOrder.project_id == project_id)
        .order_by(VariationOrder.requested_at.asc())
    )
    return db.scalars(stmt).all()


def project_has_billings(db: Session, project_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(ProgressBilling)
            .where(ProgressBilling.project_id == project_id)
        )
        or 0
    ) > 0


def list_billings(db: Session, project_id: uuid.UUID):
    stmt = (
        select(ProgressBilling)
        .where(ProgressBilling.project_id == project_id)
        .order_by(ProgressBilling.billing_date.asc())
    )
    return db.scalars(stmt).all()


def list_subcontracts(db: Session, project_id: uuid.UUID):
    stmt = (
        select(Subcontract)
        .where(Subcontract.project_id == project_id)
        .order_by(Subcontract.created_at.asc())
    )
    return db.scalars(stmt).all()


def list_subcontractors(db: Session, tenant_id: uuid.UUID):
    stmt = (
        select(Subcontractor)
        .where(Subcontractor.tenant_id == tenant_id)
        .order_by(Subcontractor.name.asc())
    )
    return db.scalars(stmt).all()
