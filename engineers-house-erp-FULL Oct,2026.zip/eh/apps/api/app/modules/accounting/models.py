"""Double-entry accounting (General Ledger) models.

This is the financial core that turns the system from an operational ERP into
an accounting-grade one. It deliberately sits alongside the existing `finance`
module (invoices/payments/expenses) without modifying it; finance documents can
later post journal entries into this ledger.

Concepts (standard double-entry bookkeeping):
  GLAccount        - a line in the chart of accounts (hierarchical). Every account
                   has a type that fixes its "normal" side (debit or credit).
  CostCenter     - a dimension to tag entries by (typically a project), so the
                   system can produce a project cost report like the legacy app.
  JournalEntry   - one balanced accounting transaction (sum of debits == credits).
  JournalLine    - one debit-or-credit posting to an account within an entry.
  Voucher        - a receipt (قبض) or payment (صرف) document that, when posted,
                   creates a balanced two-line journal entry (cash vs account).
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin

# GLAccount types and their normal balance side.
# asset/expense are debit-normal; liability/equity/revenue are credit-normal.
ACCOUNT_TYPES = ("asset", "liability", "equity", "revenue", "expense")
DEBIT_NORMAL = ("asset", "expense")


class GLAccount(Base, TimestampMixin):
    __tablename__ = "gl_accounts"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_gl_account_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(20))  # e.g. "510101"
    name: Mapped[str] = mapped_column(String(255))
    account_type: Mapped[str] = mapped_column(String(12))  # asset/liability/equity/revenue/expense
    parent_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("gl_accounts.id", ondelete="SET NULL"), nullable=True
    )
    # A "group" account is a non-postable header; only leaf accounts take entries.
    is_group: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # Opening balance for this account (entered at setup), debit-positive.
    opening_balance: Mapped[float] = mapped_column(Numeric(16, 2), default=0)


class CostCenter(Base, TimestampMixin):
    __tablename__ = "gl_cost_centers"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_gl_cc_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(20))
    name: Mapped[str] = mapped_column(String(255))
    # Optional link to a project, so project cost reports roll up automatically.
    project_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class JournalEntry(Base, TimestampMixin):
    __tablename__ = "gl_journal_entries"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    number: Mapped[str] = mapped_column(String(40))  # auto: JV-YYYY-NNNN
    entry_date: Mapped[date] = mapped_column(Date)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    # draft / posted / cancelled. Only posted entries affect the ledger.
    status: Mapped[str] = mapped_column(String(12), default="posted")
    # Where this entry came from: manual / voucher / invoice / expense ...
    source: Mapped[str] = mapped_column(String(20), default="manual")
    total_debit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    total_credit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)

    lines: Mapped[list[JournalLine]] = relationship(
        back_populates="entry", cascade="all, delete-orphan", lazy="selectin"
    )


class JournalLine(Base, TimestampMixin):
    __tablename__ = "gl_journal_lines"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    entry_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("gl_journal_entries.id", ondelete="CASCADE")
    )
    account_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("gl_accounts.id"))
    cost_center_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    debit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    credit: Mapped[float] = mapped_column(Numeric(16, 2), default=0)

    entry: Mapped[JournalEntry] = relationship(back_populates="lines")


class Voucher(Base, TimestampMixin):
    """A receipt (قبض) or payment (صرف) voucher. Posting it creates a balanced
    journal entry moving money between a cash/bank account and a counter account."""

    __tablename__ = "gl_vouchers"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    number: Mapped[str] = mapped_column(String(40))  # RV-YYYY-NNNN / PV-YYYY-NNNN
    voucher_type: Mapped[str] = mapped_column(String(10))  # receipt / payment
    voucher_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    # The cash/bank account money moves to (receipt) or from (payment).
    cash_account_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("gl_accounts.id"))
    # The counter account (e.g. a customer for receipt, a supplier/expense for payment).
    counter_account_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("gl_accounts.id"))
    cost_center_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    payee: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(12), default="posted")  # posted / cancelled
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
