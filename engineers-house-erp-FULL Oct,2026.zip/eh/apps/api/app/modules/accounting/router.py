"""Accounting HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.accounting import service
from app.modules.accounting.schemas import (
    AccountCreate,
    AccountLedger,
    AccountOut,
    AccountUpdate,
    BalanceSheet,
    CostCenterCreate,
    CostCenterOut,
    CostCenterUpdate,
    IncomeStatement,
    JournalEntryCreate,
    JournalEntryOut,
    ProjectCostReport,
    TrialBalance,
    VoucherCreate,
    VoucherOut,
)
from app.modules.identity.models import User
from app.shared.pagination import Page

router = APIRouter(prefix="/accounting", tags=["accounting"])

VIEW = "accounting.view"
MANAGE = "accounting.manage"


# --- Chart of accounts ---
@router.post("/accounts", response_model=AccountOut, status_code=201)
def create_account(
    body: AccountCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_account(db, user.tenant_id, body)


@router.get("/accounts", response_model=list[AccountOut])
def list_accounts(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_accounts(db, user.tenant_id)


@router.patch("/accounts/{account_id}", response_model=AccountOut)
def update_account(
    account_id: uuid.UUID,
    body: AccountUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_account(db, user.tenant_id, account_id, body)


@router.delete("/accounts/{account_id}", status_code=204)
def delete_account(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_account(db, user.tenant_id, account_id)


@router.get("/accounts/{account_id}/ledger", response_model=AccountLedger)
def account_ledger(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.account_ledger(db, user.tenant_id, account_id)


# --- Cost centers ---
@router.post("/cost-centers", response_model=CostCenterOut, status_code=201)
def create_cost_center(
    body: CostCenterCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_cost_center(db, user.tenant_id, body)


@router.get("/cost-centers", response_model=list[CostCenterOut])
def list_cost_centers(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_cost_centers(db, user.tenant_id)


@router.patch("/cost-centers/{cc_id}", response_model=CostCenterOut)
def update_cost_center(
    cc_id: uuid.UUID,
    body: CostCenterUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_cost_center(db, user.tenant_id, cc_id, body)


@router.delete("/cost-centers/{cc_id}", status_code=204)
def delete_cost_center(
    cc_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_cost_center(db, user.tenant_id, cc_id)


# --- Journal entries ---
@router.post("/journal-entries", response_model=JournalEntryOut, status_code=201)
def create_entry(
    body: JournalEntryCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_entry(db, user.tenant_id, body)


@router.get("/journal-entries", response_model=Page[JournalEntryOut])
def list_entries(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    items, total = service.list_entries(db, user.tenant_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/journal-entries/{entry_id}", response_model=JournalEntryOut)
def get_entry(
    entry_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.get_entry(db, user.tenant_id, entry_id)


@router.post("/journal-entries/{entry_id}/cancel", response_model=JournalEntryOut)
def cancel_entry(
    entry_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.cancel_entry(db, user.tenant_id, entry_id)


# --- Vouchers ---
@router.post("/vouchers", response_model=VoucherOut, status_code=201)
def create_voucher(
    body: VoucherCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_voucher(db, user.tenant_id, body)


@router.get("/vouchers", response_model=Page[VoucherOut])
def list_vouchers(
    voucher_type: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    items, total = service.list_vouchers(db, user.tenant_id, voucher_type, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/vouchers/{voucher_id}/cancel", response_model=VoucherOut)
def cancel_voucher(
    voucher_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.cancel_voucher(db, user.tenant_id, voucher_id)


# --- Financial reports ---
@router.get("/reports/trial-balance", response_model=TrialBalance)
def trial_balance(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.trial_balance(db, user.tenant_id)


@router.get("/reports/income-statement", response_model=IncomeStatement)
def income_statement(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.income_statement(db, user.tenant_id)


@router.get("/reports/balance-sheet", response_model=BalanceSheet)
def balance_sheet(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.balance_sheet(db, user.tenant_id)


@router.get("/reports/project-costs", response_model=ProjectCostReport)
def project_cost_report(
    cost_center_id: uuid.UUID | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.project_cost_report(db, user.tenant_id, cost_center_id)
