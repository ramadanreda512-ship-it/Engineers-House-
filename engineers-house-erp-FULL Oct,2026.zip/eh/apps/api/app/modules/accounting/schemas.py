"""Accounting request/response schemas. Ledger amounts are server-computed."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field, model_validator


# --- Chart of accounts ---
class AccountCreate(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=255)
    account_type: str = Field(pattern="^(asset|liability|equity|revenue|expense)$")
    parent_id: uuid.UUID | None = None
    is_group: bool = False
    opening_balance: float = 0


class AccountUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    parent_id: uuid.UUID | None = None
    is_active: bool | None = None
    opening_balance: float | None = None


class AccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    account_type: str
    parent_id: uuid.UUID | None
    is_group: bool
    is_active: bool
    opening_balance: float


# --- Cost centers ---
class CostCenterCreate(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=255)
    project_id: uuid.UUID | None = None


class CostCenterUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    project_id: uuid.UUID | None = None
    is_active: bool | None = None


class CostCenterOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    project_id: uuid.UUID | None
    is_active: bool


# --- Journal entries ---
class JournalLineCreate(BaseModel):
    account_id: uuid.UUID
    cost_center_id: uuid.UUID | None = None
    description: str | None = None
    debit: float = Field(ge=0, default=0)
    credit: float = Field(ge=0, default=0)

    @model_validator(mode="after")
    def _one_side_only(self):
        if self.debit > 0 and self.credit > 0:
            raise ValueError("A line cannot have both debit and credit")
        if self.debit == 0 and self.credit == 0:
            raise ValueError("A line must have either a debit or a credit")
        return self


class JournalLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    cost_center_id: uuid.UUID | None
    description: str | None
    debit: float
    credit: float


class JournalEntryCreate(BaseModel):
    entry_date: date | None = None
    description: str | None = None
    reference: str | None = None
    lines: list[JournalLineCreate] = Field(min_length=2)

    @model_validator(mode="after")
    def _balanced(self):
        total_debit = round(sum(line_.debit for line_ in self.lines), 2)
        total_credit = round(sum(line_.credit for line_ in self.lines), 2)
        if total_debit != total_credit:
            raise ValueError(
                f"Entry is not balanced: debit {total_debit} != credit {total_credit}"
            )
        if total_debit == 0:
            raise ValueError("Entry total cannot be zero")
        return self


class JournalEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    entry_date: date
    description: str | None
    reference: str | None
    status: str
    source: str
    total_debit: float
    total_credit: float
    lines: list[JournalLineOut]


# --- Vouchers ---
class VoucherCreate(BaseModel):
    voucher_type: str = Field(pattern="^(receipt|payment)$")
    voucher_date: date | None = None
    amount: float = Field(gt=0)
    cash_account_id: uuid.UUID
    counter_account_id: uuid.UUID
    cost_center_id: uuid.UUID | None = None
    description: str | None = None
    payee: str | None = None


class VoucherOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    voucher_type: str
    voucher_date: date
    amount: float
    cash_account_id: uuid.UUID
    counter_account_id: uuid.UUID
    cost_center_id: uuid.UUID | None
    description: str | None
    payee: str | None
    status: str
    journal_entry_id: uuid.UUID | None


# --- Reports ---
class LedgerLine(BaseModel):
    entry_id: uuid.UUID
    entry_number: str
    entry_date: date
    description: str | None
    debit: float
    credit: float
    running_balance: float


class AccountLedger(BaseModel):
    account_id: uuid.UUID
    account_code: str
    account_name: str
    opening_balance: float
    lines: list[LedgerLine]
    closing_balance: float


class TrialBalanceRow(BaseModel):
    account_id: uuid.UUID
    account_code: str
    account_name: str
    account_type: str
    debit: float
    credit: float


class TrialBalance(BaseModel):
    rows: list[TrialBalanceRow]
    total_debit: float
    total_credit: float
    is_balanced: bool


class IncomeStatement(BaseModel):
    total_revenue: float
    total_expense: float
    net_profit: float
    revenue_lines: list[TrialBalanceRow]
    expense_lines: list[TrialBalanceRow]


class BalanceSheet(BaseModel):
    total_assets: float
    total_liabilities: float
    total_equity: float
    retained_earnings: float
    is_balanced: bool
    asset_lines: list[TrialBalanceRow]
    liability_lines: list[TrialBalanceRow]
    equity_lines: list[TrialBalanceRow]


class ProjectCostRow(BaseModel):
    cost_center_id: uuid.UUID
    cost_center_code: str
    cost_center_name: str
    account_code: str
    account_name: str
    debit: float
    credit: float
    balance: float


class ProjectCostReport(BaseModel):
    rows: list[ProjectCostRow]
    total_debit: float
    total_credit: float
    total_balance: float
