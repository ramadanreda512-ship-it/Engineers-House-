"""Tenant-scoped data access for the accounting module."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.accounting.models import (
    CostCenter,
    GLAccount,
    JournalEntry,
    JournalLine,
    Voucher,
)


# --- Accounts ---
def get_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> GLAccount | None:
    return db.scalar(
        select(GLAccount).where(GLAccount.id == account_id, GLAccount.tenant_id == tenant_id)
    )


def code_exists(db: Session, tenant_id: uuid.UUID, code: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(GLAccount)
            .where(GLAccount.tenant_id == tenant_id, GLAccount.code == code)
        )
        or 0
    ) > 0


def list_accounts(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(GLAccount).where(GLAccount.tenant_id == tenant_id).order_by(GLAccount.code.asc())
    ).all()


def account_has_lines(db: Session, account_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(JournalLine)
            .where(JournalLine.account_id == account_id)
        )
        or 0
    ) > 0


def account_has_children(db: Session, account_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count()).select_from(GLAccount).where(GLAccount.parent_id == account_id)
        )
        or 0
    ) > 0


# --- Cost centers ---
def get_cost_center(db: Session, tenant_id: uuid.UUID, cc_id: uuid.UUID) -> CostCenter | None:
    return db.scalar(
        select(CostCenter).where(CostCenter.id == cc_id, CostCenter.tenant_id == tenant_id)
    )


def cc_code_exists(db: Session, tenant_id: uuid.UUID, code: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(CostCenter)
            .where(CostCenter.tenant_id == tenant_id, CostCenter.code == code)
        )
        or 0
    ) > 0


def list_cost_centers(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(CostCenter)
        .where(CostCenter.tenant_id == tenant_id)
        .order_by(CostCenter.code.asc())
    ).all()


def cc_has_lines(db: Session, cc_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(JournalLine)
            .where(JournalLine.cost_center_id == cc_id)
        )
        or 0
    ) > 0


# --- Journal entries ---
def get_entry(db: Session, tenant_id: uuid.UUID, entry_id: uuid.UUID) -> JournalEntry | None:
    return db.scalar(
        select(JournalEntry).where(
            JournalEntry.id == entry_id, JournalEntry.tenant_id == tenant_id
        )
    )


def list_entries(db: Session, tenant_id: uuid.UUID, limit: int, offset: int):
    stmt = (
        select(JournalEntry)
        .where(JournalEntry.tenant_id == tenant_id)
        .order_by(JournalEntry.entry_date.desc(), JournalEntry.created_at.desc())
    )
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(
        select(func.count()).select_from(JournalEntry).where(JournalEntry.tenant_id == tenant_id)
    )
    return items, total or 0


def next_entry_number(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count())
        .select_from(JournalEntry)
        .where(JournalEntry.tenant_id == tenant_id)
    )
    return f"JV-{year}-{(count or 0) + 1:04d}"


# --- Vouchers ---
def get_voucher(db: Session, tenant_id: uuid.UUID, voucher_id: uuid.UUID) -> Voucher | None:
    return db.scalar(
        select(Voucher).where(Voucher.id == voucher_id, Voucher.tenant_id == tenant_id)
    )


def list_vouchers(db: Session, tenant_id: uuid.UUID, vtype: str | None, limit: int, offset: int):
    conds = [Voucher.tenant_id == tenant_id]
    if vtype:
        conds.append(Voucher.voucher_type == vtype)
    stmt = select(Voucher).where(*conds).order_by(Voucher.voucher_date.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Voucher).where(*conds))
    return items, total or 0


def next_voucher_number(db: Session, tenant_id: uuid.UUID, vtype: str, year: int) -> str:
    prefix = "RV" if vtype == "receipt" else "PV"
    count = db.scalar(
        select(func.count())
        .select_from(Voucher)
        .where(Voucher.tenant_id == tenant_id, Voucher.voucher_type == vtype)
    )
    return f"{prefix}-{year}-{(count or 0) + 1:04d}"


# --- Ledger aggregates (only posted entries count) ---
def posted_lines_for_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID):
    """Return (entry, line) pairs for an account, oldest first."""
    return db.execute(
        select(JournalEntry, JournalLine)
        .join(JournalLine, JournalLine.entry_id == JournalEntry.id)
        .where(
            JournalLine.tenant_id == tenant_id,
            JournalLine.account_id == account_id,
            JournalEntry.status == "posted",
        )
        .order_by(JournalEntry.entry_date.asc(), JournalEntry.created_at.asc())
    ).all()


def account_totals(db: Session, tenant_id: uuid.UUID):
    """Sum of debits and credits per account across posted entries.
    Returns dict: account_id -> (debit, credit)."""
    rows = db.execute(
        select(
            JournalLine.account_id,
            func.coalesce(func.sum(JournalLine.debit), 0),
            func.coalesce(func.sum(JournalLine.credit), 0),
        )
        .join(JournalEntry, JournalLine.entry_id == JournalEntry.id)
        .where(JournalLine.tenant_id == tenant_id, JournalEntry.status == "posted")
        .group_by(JournalLine.account_id)
    ).all()
    return {r[0]: (float(r[1]), float(r[2])) for r in rows}


def cost_center_totals(db: Session, tenant_id: uuid.UUID, cc_id: uuid.UUID | None):
    """Per (cost_center, account) debit/credit totals across posted entries."""
    conds = [JournalLine.tenant_id == tenant_id, JournalEntry.status == "posted"]
    if cc_id:
        conds.append(JournalLine.cost_center_id == cc_id)
    else:
        conds.append(JournalLine.cost_center_id.is_not(None))
    return db.execute(
        select(
            JournalLine.cost_center_id,
            JournalLine.account_id,
            func.coalesce(func.sum(JournalLine.debit), 0),
            func.coalesce(func.sum(JournalLine.credit), 0),
        )
        .join(JournalEntry, JournalLine.entry_id == JournalEntry.id)
        .where(*conds)
        .group_by(JournalLine.cost_center_id, JournalLine.account_id)
    ).all()
