"""Accounting business logic: double-entry posting, ledger, and statements.

Key rules enforced here:
- Account codes are unique per tenant; a group (header) account cannot take
  journal lines; only leaf accounts can.
- Every journal entry must balance (sum debits == sum credits) and have >= 2
  lines; this is validated in the schema and re-checked here.
- Posting a voucher creates a balanced 2-line journal entry:
    receipt: debit cash, credit counter account
    payment: debit counter account, credit cash
- The ledger, trial balance, income statement, balance sheet and project cost
  report are all derived from posted journal lines (single source of truth).
- An account/cost-centre that has postings cannot be deleted (history is kept).
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.modules.accounting import repository as repo
from app.modules.accounting.models import (
    DEBIT_NORMAL,
    CostCenter,
    GLAccount,
    JournalEntry,
    JournalLine,
    Voucher,
)
from app.modules.accounting.schemas import (
    AccountCreate,
    AccountUpdate,
    CostCenterCreate,
    CostCenterUpdate,
    JournalEntryCreate,
    VoucherCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


# --- Chart of accounts ---
def create_account(db: Session, tenant_id: uuid.UUID, body: AccountCreate) -> GLAccount:
    if repo.code_exists(db, tenant_id, body.code):
        raise Conflict(f"Account code '{body.code}' already exists")
    if body.parent_id and not repo.get_account(db, tenant_id, body.parent_id):
        raise NotFound("Parent account")
    account = GLAccount(tenant_id=tenant_id, is_active=True, **body.model_dump())
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


def list_accounts(db: Session, tenant_id: uuid.UUID):
    return repo.list_accounts(db, tenant_id)


def get_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> GLAccount:
    account = repo.get_account(db, tenant_id, account_id)
    if not account:
        raise NotFound("Account")
    return account


def update_account(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID, body: AccountUpdate
) -> GLAccount:
    account = get_account(db, tenant_id, account_id)
    data = body.model_dump(exclude_unset=True)
    # Opening balance can only change before the account has postings.
    if "opening_balance" in data and repo.account_has_lines(db, account_id):
        raise Conflict("Cannot change opening balance after the account has entries")
    for field, value in data.items():
        setattr(account, field, value)
    db.commit()
    db.refresh(account)
    return account


def delete_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> None:
    get_account(db, tenant_id, account_id)
    if repo.account_has_lines(db, account_id):
        raise Conflict(
            "Cannot delete an account that has journal entries. Deactivate it instead."
        )
    if repo.account_has_children(db, account_id):
        raise Conflict("Cannot delete an account that has sub-accounts")
    db.delete(get_account(db, tenant_id, account_id))
    db.commit()


# --- Cost centers ---
def create_cost_center(db: Session, tenant_id: uuid.UUID, body: CostCenterCreate) -> CostCenter:
    if repo.cc_code_exists(db, tenant_id, body.code):
        raise Conflict(f"Cost center code '{body.code}' already exists")
    cc = CostCenter(tenant_id=tenant_id, is_active=True, **body.model_dump())
    db.add(cc)
    db.commit()
    db.refresh(cc)
    return cc


def list_cost_centers(db: Session, tenant_id: uuid.UUID):
    return repo.list_cost_centers(db, tenant_id)


def update_cost_center(
    db: Session, tenant_id: uuid.UUID, cc_id: uuid.UUID, body: CostCenterUpdate
) -> CostCenter:
    cc = repo.get_cost_center(db, tenant_id, cc_id)
    if not cc:
        raise NotFound("Cost center")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(cc, field, value)
    db.commit()
    db.refresh(cc)
    return cc


def delete_cost_center(db: Session, tenant_id: uuid.UUID, cc_id: uuid.UUID) -> None:
    cc = repo.get_cost_center(db, tenant_id, cc_id)
    if not cc:
        raise NotFound("Cost center")
    if repo.cc_has_lines(db, cc_id):
        raise Conflict("Cannot delete a cost center that has entries. Deactivate it instead.")
    db.delete(cc)
    db.commit()


# --- Journal entries ---
def _validate_postable(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> GLAccount:
    account = repo.get_account(db, tenant_id, account_id)
    if not account:
        raise NotFound(f"Account {account_id}")
    if account.is_group:
        raise BadRequest(
            f"Account '{account.code}' is a group account and cannot take entries"
        )
    if not account.is_active:
        raise BadRequest(f"Account '{account.code}' is inactive")
    return account


def create_entry(db: Session, tenant_id: uuid.UUID, body: JournalEntryCreate) -> JournalEntry:
    # Validate every referenced account is postable.
    for line_ in body.lines:
        _validate_postable(db, tenant_id, line_.account_id)
        if line_.cost_center_id and not repo.get_cost_center(db, tenant_id, line_.cost_center_id):
            raise NotFound("Cost center")

    total_debit = _round(sum(line_.debit for line_ in body.lines))
    total_credit = _round(sum(line_.credit for line_ in body.lines))
    year = (body.entry_date or date.today()).year
    entry = JournalEntry(
        tenant_id=tenant_id,
        number=repo.next_entry_number(db, tenant_id, year),
        entry_date=body.entry_date or date.today(),
        description=body.description,
        reference=body.reference,
        status="posted",
        source="manual",
        total_debit=total_debit,
        total_credit=total_credit,
    )
    db.add(entry)
    db.flush()
    for line_ in body.lines:
        db.add(
            JournalLine(
                tenant_id=tenant_id,
                entry_id=entry.id,
                account_id=line_.account_id,
                cost_center_id=line_.cost_center_id,
                description=line_.description,
                debit=_round(line_.debit),
                credit=_round(line_.credit),
            )
        )
    db.commit()
    db.refresh(entry)
    return entry


def list_entries(db: Session, tenant_id: uuid.UUID, page: int, size: int):
    return repo.list_entries(db, tenant_id, size, (page - 1) * size)


def get_entry(db: Session, tenant_id: uuid.UUID, entry_id: uuid.UUID) -> JournalEntry:
    entry = repo.get_entry(db, tenant_id, entry_id)
    if not entry:
        raise NotFound("Journal entry")
    return entry


def cancel_entry(db: Session, tenant_id: uuid.UUID, entry_id: uuid.UUID) -> JournalEntry:
    entry = get_entry(db, tenant_id, entry_id)
    if entry.status == "cancelled":
        raise Conflict("Entry is already cancelled")
    entry.status = "cancelled"
    db.commit()
    db.refresh(entry)
    return entry


# --- Vouchers ---
def create_voucher(db: Session, tenant_id: uuid.UUID, body: VoucherCreate) -> Voucher:
    cash = _validate_postable(db, tenant_id, body.cash_account_id)
    counter = _validate_postable(db, tenant_id, body.counter_account_id)
    if body.cost_center_id and not repo.get_cost_center(db, tenant_id, body.cost_center_id):
        raise NotFound("Cost center")
    if cash.id == counter.id:
        raise BadRequest("Cash and counter accounts must be different")

    year = (body.voucher_date or date.today()).year
    amount = _round(body.amount)

    # Build the balanced journal entry for the voucher.
    if body.voucher_type == "receipt":
        # Money in: debit cash, credit the counter account.
        debit_acc, credit_acc = cash.id, counter.id
    else:
        # Money out: debit the counter account, credit cash.
        debit_acc, credit_acc = counter.id, cash.id

    entry = JournalEntry(
        tenant_id=tenant_id,
        number=repo.next_entry_number(db, tenant_id, year),
        entry_date=body.voucher_date or date.today(),
        description=body.description or f"{body.voucher_type} voucher",
        status="posted",
        source="voucher",
        total_debit=amount,
        total_credit=amount,
    )
    db.add(entry)
    db.flush()
    db.add(
        JournalLine(
            tenant_id=tenant_id, entry_id=entry.id, account_id=debit_acc,
            cost_center_id=body.cost_center_id, description=body.description,
            debit=amount, credit=0,
        )
    )
    db.add(
        JournalLine(
            tenant_id=tenant_id, entry_id=entry.id, account_id=credit_acc,
            cost_center_id=body.cost_center_id, description=body.description,
            debit=0, credit=amount,
        )
    )

    voucher = Voucher(
        tenant_id=tenant_id,
        number=repo.next_voucher_number(db, tenant_id, body.voucher_type, year),
        voucher_type=body.voucher_type,
        voucher_date=body.voucher_date or date.today(),
        amount=amount,
        cash_account_id=body.cash_account_id,
        counter_account_id=body.counter_account_id,
        cost_center_id=body.cost_center_id,
        description=body.description,
        payee=body.payee,
        status="posted",
        journal_entry_id=entry.id,
    )
    db.add(voucher)
    db.commit()
    db.refresh(voucher)
    return voucher


def list_vouchers(db: Session, tenant_id: uuid.UUID, vtype: str | None, page: int, size: int):
    return repo.list_vouchers(db, tenant_id, vtype, size, (page - 1) * size)


def get_voucher(db: Session, tenant_id: uuid.UUID, voucher_id: uuid.UUID) -> Voucher:
    voucher = repo.get_voucher(db, tenant_id, voucher_id)
    if not voucher:
        raise NotFound("Voucher")
    return voucher


def cancel_voucher(db: Session, tenant_id: uuid.UUID, voucher_id: uuid.UUID) -> Voucher:
    voucher = get_voucher(db, tenant_id, voucher_id)
    if voucher.status == "cancelled":
        raise Conflict("Voucher is already cancelled")
    voucher.status = "cancelled"
    # Cancel the linked journal entry too, so the ledger stays consistent.
    if voucher.journal_entry_id:
        entry = repo.get_entry(db, tenant_id, voucher.journal_entry_id)
        if entry:
            entry.status = "cancelled"
    db.commit()
    db.refresh(voucher)
    return voucher


# --- Reports ---
def _signed_balance(account_type: str, debit: float, credit: float) -> float:
    """Return the account balance with its natural sign for its type."""
    if account_type in DEBIT_NORMAL:
        return _round(debit - credit)
    return _round(credit - debit)


def account_ledger(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> dict:
    account = get_account(db, tenant_id, account_id)
    rows = repo.posted_lines_for_account(db, tenant_id, account_id)
    debit_normal = account.account_type in DEBIT_NORMAL
    out_lines = []
    bal = float(account.opening_balance)
    for entry, line_ in rows:
        d, c = float(line_.debit), float(line_.credit)
        bal = bal + d - c if debit_normal else bal - d + c
        out_lines.append(
            {
                "entry_id": entry.id,
                "entry_number": entry.number,
                "entry_date": entry.entry_date,
                "description": line_.description or entry.description,
                "debit": _round(d),
                "credit": _round(c),
                "running_balance": _round(bal),
            }
        )
    return {
        "account_id": account.id,
        "account_code": account.code,
        "account_name": account.name,
        "opening_balance": _round(float(account.opening_balance)),
        "lines": out_lines,
        "closing_balance": _round(bal),
    }


def trial_balance(db: Session, tenant_id: uuid.UUID) -> dict:
    accounts = {a.id: a for a in repo.list_accounts(db, tenant_id)}
    totals = repo.account_totals(db, tenant_id)
    rows = []
    total_debit = 0.0
    total_credit = 0.0
    for acc_id, (debit, credit) in totals.items():
        account = accounts.get(acc_id)
        if not account:
            continue
        net = debit - credit
        d = _round(net) if net > 0 else 0.0
        c = _round(-net) if net < 0 else 0.0
        total_debit += d
        total_credit += c
        rows.append(
            {
                "account_id": account.id,
                "account_code": account.code,
                "account_name": account.name,
                "account_type": account.account_type,
                "debit": d,
                "credit": c,
            }
        )
    rows.sort(key=lambda r: r["account_code"])
    return {
        "rows": rows,
        "total_debit": _round(total_debit),
        "total_credit": _round(total_credit),
        "is_balanced": _round(total_debit) == _round(total_credit),
    }


def income_statement(db: Session, tenant_id: uuid.UUID) -> dict:
    accounts = {a.id: a for a in repo.list_accounts(db, tenant_id)}
    totals = repo.account_totals(db, tenant_id)
    revenue_lines, expense_lines = [], []
    total_rev = 0.0
    total_exp = 0.0
    for acc_id, (debit, credit) in totals.items():
        account = accounts.get(acc_id)
        if not account:
            continue
        if account.account_type == "revenue":
            bal = _round(credit - debit)
            total_rev += bal
            revenue_lines.append(_tb_row(account, 0.0, bal))
        elif account.account_type == "expense":
            bal = _round(debit - credit)
            total_exp += bal
            expense_lines.append(_tb_row(account, bal, 0.0))
    revenue_lines.sort(key=lambda r: r["account_code"])
    expense_lines.sort(key=lambda r: r["account_code"])
    return {
        "total_revenue": _round(total_rev),
        "total_expense": _round(total_exp),
        "net_profit": _round(total_rev - total_exp),
        "revenue_lines": revenue_lines,
        "expense_lines": expense_lines,
    }


def _tb_row(account, debit, credit):
    return {
        "account_id": account.id,
        "account_code": account.code,
        "account_name": account.name,
        "account_type": account.account_type,
        "debit": _round(debit),
        "credit": _round(credit),
    }


def balance_sheet(db: Session, tenant_id: uuid.UUID) -> dict:
    accounts = {a.id: a for a in repo.list_accounts(db, tenant_id)}
    totals = repo.account_totals(db, tenant_id)
    asset_lines, liability_lines, equity_lines = [], [], []
    total_assets = total_liabilities = total_equity = 0.0
    total_rev = total_exp = 0.0
    for acc_id, (debit, credit) in totals.items():
        account = accounts.get(acc_id)
        if not account:
            continue
        t = account.account_type
        if t == "asset":
            bal = _round(debit - credit)
            total_assets += bal
            asset_lines.append(_tb_row(account, bal, 0.0))
        elif t == "liability":
            bal = _round(credit - debit)
            total_liabilities += bal
            liability_lines.append(_tb_row(account, 0.0, bal))
        elif t == "equity":
            bal = _round(credit - debit)
            total_equity += bal
            equity_lines.append(_tb_row(account, 0.0, bal))
        elif t == "revenue":
            total_rev += _round(credit - debit)
        elif t == "expense":
            total_exp += _round(debit - credit)
    retained = _round(total_rev - total_exp)  # net profit flows to equity
    for lines in (asset_lines, liability_lines, equity_lines):
        lines.sort(key=lambda r: r["account_code"])
    equity_plus_retained = _round(total_equity + retained)
    return {
        "total_assets": _round(total_assets),
        "total_liabilities": _round(total_liabilities),
        "total_equity": equity_plus_retained,
        "retained_earnings": retained,
        "is_balanced": _round(total_assets) == _round(total_liabilities + equity_plus_retained),
        "asset_lines": asset_lines,
        "liability_lines": liability_lines,
        "equity_lines": equity_lines,
    }


def project_cost_report(db: Session, tenant_id: uuid.UUID, cc_id: uuid.UUID | None) -> dict:
    accounts = {a.id: a for a in repo.list_accounts(db, tenant_id)}
    ccs = {c.id: c for c in repo.list_cost_centers(db, tenant_id)}
    raw = repo.cost_center_totals(db, tenant_id, cc_id)
    rows = []
    total_debit = total_credit = total_balance = 0.0
    for cc_id_row, acc_id, debit, credit in raw:
        account = accounts.get(acc_id)
        cc = ccs.get(cc_id_row)
        if not account or not cc:
            continue
        d, c = float(debit), float(credit)
        bal = _round(d - c)
        total_debit += d
        total_credit += c
        total_balance += bal
        rows.append(
            {
                "cost_center_id": cc.id,
                "cost_center_code": cc.code,
                "cost_center_name": cc.name,
                "account_code": account.code,
                "account_name": account.name,
                "debit": _round(d),
                "credit": _round(c),
                "balance": bal,
            }
        )
    rows.sort(key=lambda r: (r["cost_center_code"], r["account_code"]))
    return {
        "rows": rows,
        "total_debit": _round(total_debit),
        "total_credit": _round(total_credit),
        "total_balance": _round(total_balance),
    }
