from __future__ import annotations

import json

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.backup import service
from app.modules.identity.models import User

router = APIRouter(prefix="/backup", tags=["backup"])

# Backup/restore is a sensitive, admin-level operation.
MANAGE = "backup.manage"


class BackupFileOut(BaseModel):
    filename: str
    content: str  # JSON string the browser saves as a .json file


class RestoreBody(BaseModel):
    content: str  # JSON string uploaded from a backup file


class RestoreResult(BaseModel):
    restored_rows: int
    table_count: int


class BackupStats(BaseModel):
    total_rows: int
    highlights: dict


@router.get("/stats", response_model=BackupStats)
def stats(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.backup_stats(db)


@router.get("/export", response_model=BackupFileOut)
def export_backup(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    import datetime

    data = service.export_all(db)
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    return {
        "filename": f"engineers-house-backup-{stamp}.json",
        "content": json.dumps(data, ensure_ascii=False),
    }


@router.post("/restore", response_model=RestoreResult)
def restore_backup(
    body: RestoreBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    try:
        payload = json.loads(body.content)
    except json.JSONDecodeError as exc:
        from fastapi import HTTPException

        raise HTTPException(
            status_code=400, detail="Invalid backup file (not valid JSON)."
        ) from exc
    try:
        return service.restore_all(db, payload)
    except ValueError as exc:
        from fastapi import HTTPException

        raise HTTPException(status_code=400, detail=str(exc)) from exc
