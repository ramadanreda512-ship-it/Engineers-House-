"""Full-database backup & restore.

Backup walks every table registered on the SQLAlchemy metadata and dumps all
rows into a single JSON document — so it automatically covers every module
(CRM, training, projects, finance, ...) with no per-table code, and keeps
covering new modules added later. Restore wipes the current data and loads
the document back in dependency order (parents before children) inside one
transaction, so a failed restore rolls back and leaves data untouched.

Values are encoded to be JSON-safe: UUIDs and Decimals become strings,
datetimes/dates become ISO strings. On restore the SQLAlchemy column types
convert them back automatically.
"""
from __future__ import annotations

import datetime
import decimal
import uuid
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.shared.base_model import Base

BACKUP_FORMAT_VERSION = 2


def _encode(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _decode(value: Any, python_type: Any) -> Any:
    """Convert a JSON-encoded value back into the Python object the column's
    type expects (datetime/date/time), so SQLite accepts it on insert.
    UUIDs, Decimals, ints, bools are handled by SQLAlchemy column types from
    their string/number form, so they pass through untouched."""
    if value is None or not isinstance(value, str):
        return value
    try:
        if python_type is datetime.datetime:
            return datetime.datetime.fromisoformat(value)
        if python_type is datetime.date:
            return datetime.date.fromisoformat(value)
        if python_type is datetime.time:
            return datetime.time.fromisoformat(value)
    except (ValueError, TypeError):
        return value
    return value


def export_all(db: Session) -> dict:
    """Serialize every table into a JSON-safe dict."""
    tables = Base.metadata.sorted_tables  # dependency order (parents first)
    data: dict[str, list[dict]] = {}
    total_rows = 0
    for table in tables:
        rows = []
        for row in db.execute(select(table)).mappings():
            rows.append({k: _encode(v) for k, v in row.items()})
        data[table.name] = rows
        total_rows += len(rows)
    return {
        "format_version": BACKUP_FORMAT_VERSION,
        "created_at": datetime.datetime.utcnow().isoformat(),
        "table_count": len(tables),
        "row_count": total_rows,
        "tables": data,
    }


def backup_stats(db: Session) -> dict:
    """Lightweight counts per meaningful table for the UI (no full dump)."""
    from sqlalchemy import func

    interesting = {
        "accounts": "customers",
        "students": "students",
        "courses": "courses",
        "cohorts": "cohorts",
        "projects": "projects",
        "invoices": "invoices",
        "journal_entries": "journal_entries",
        "training_leads": "training_leads",
    }
    counts = {}
    for table in Base.metadata.sorted_tables:
        if table.name in interesting:
            n = db.scalar(select(func.count()).select_from(table)) or 0
            counts[interesting[table.name]] = int(n)
    total = 0
    for table in Base.metadata.sorted_tables:
        total += int(db.scalar(select(func.count()).select_from(table)) or 0)
    return {"total_rows": total, "highlights": counts}


def restore_all(db: Session, payload: dict) -> dict:
    """Replace ALL data with the backup's contents, in one transaction.

    Deletes existing rows in reverse dependency order (children first), then
    inserts the backup rows in forward order (parents first). If anything
    fails, the whole thing rolls back.
    """
    if not isinstance(payload, dict) or "tables" not in payload:
        raise ValueError("Invalid backup file: missing 'tables'.")
    tables_data = payload["tables"]
    sorted_tables = Base.metadata.sorted_tables
    known = {t.name for t in sorted_tables}
    unknown = set(tables_data.keys()) - known
    if unknown:
        # Ignore unknown tables rather than fail — keeps forward compatibility.
        for name in unknown:
            tables_data.pop(name, None)

    inserted = 0
    try:
        # Pre-compute each table's column python types for decoding.
        col_types = {
            table.name: {c.name: _col_python_type(c) for c in table.columns}
            for table in sorted_tables
        }
        # 1) Wipe existing data, children first.
        for table in reversed(sorted_tables):
            db.execute(delete(table))
        # 2) Insert backup data, parents first, decoding dates/times.
        for table in sorted_tables:
            rows = tables_data.get(table.name) or []
            if rows:
                types = col_types[table.name]
                decoded = [
                    {k: _decode(v, types.get(k)) for k, v in row.items()}
                    for row in rows
                ]
                db.execute(table.insert(), decoded)
                inserted += len(decoded)
        db.commit()
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        raise ValueError(f"Restore failed and was rolled back: {exc}") from exc
    return {"restored_rows": inserted, "table_count": len(sorted_tables)}


def _col_python_type(column: Any) -> Any:
    """Best-effort python_type for a column; None if it can't be determined."""
    try:
        return column.type.python_type
    except (NotImplementedError, AttributeError):
        return None
