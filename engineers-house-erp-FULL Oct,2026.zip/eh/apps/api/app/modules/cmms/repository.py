"""Tenant-scoped data access for CMMS entities."""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.cmms.models import Asset, MaintenanceSchedule, WorkOrder


def get_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> Asset | None:
    return db.scalar(select(Asset).where(Asset.id == asset_id, Asset.tenant_id == tenant_id))


def asset_code_exists(db: Session, tenant_id: uuid.UUID, code: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(Asset)
            .where(Asset.tenant_id == tenant_id, Asset.code == code)
        )
        or 0
    ) > 0


def list_assets(db: Session, tenant_id: uuid.UUID, limit: int, offset: int):
    stmt = select(Asset).where(Asset.tenant_id == tenant_id).order_by(Asset.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Asset).where(Asset.tenant_id == tenant_id))
    return items, total or 0


def asset_has_work_orders(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(WorkOrder)
            .where(WorkOrder.tenant_id == tenant_id, WorkOrder.asset_id == asset_id)
        )
        or 0
    ) > 0


def get_work_order(db: Session, tenant_id: uuid.UUID, wo_id: uuid.UUID) -> WorkOrder | None:
    return db.scalar(
        select(WorkOrder).where(WorkOrder.id == wo_id, WorkOrder.tenant_id == tenant_id)
    )


def list_work_orders(
    db: Session,
    tenant_id: uuid.UUID,
    asset_id: uuid.UUID | None,
    status: str | None,
    limit: int,
    offset: int,
):
    conds = [WorkOrder.tenant_id == tenant_id]
    if asset_id:
        conds.append(WorkOrder.asset_id == asset_id)
    if status:
        conds.append(WorkOrder.status == status)
    stmt = select(WorkOrder).where(*conds).order_by(WorkOrder.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(WorkOrder).where(*conds))
    return items, total or 0


def next_wo_number(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count()).select_from(WorkOrder).where(WorkOrder.tenant_id == tenant_id)
    )
    return f"WO-{year}-{(count or 0) + 1:04d}"


def list_schedules(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID | None):
    conds = [MaintenanceSchedule.tenant_id == tenant_id]
    if asset_id:
        conds.append(MaintenanceSchedule.asset_id == asset_id)
    stmt = select(MaintenanceSchedule).where(*conds).order_by(MaintenanceSchedule.next_due_on.asc())
    return db.scalars(stmt).all()


def get_schedule(
    db: Session, tenant_id: uuid.UUID, schedule_id: uuid.UUID
) -> MaintenanceSchedule | None:
    return db.scalar(
        select(MaintenanceSchedule).where(
            MaintenanceSchedule.id == schedule_id, MaintenanceSchedule.tenant_id == tenant_id
        )
    )


# --- Aggregates for the summary ---
def count_assets(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> int:
    conds = [Asset.tenant_id == tenant_id]
    if status:
        conds.append(Asset.status == status)
    return int(db.scalar(select(func.count()).select_from(Asset).where(*conds)) or 0)


def count_work_orders(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> int:
    conds = [WorkOrder.tenant_id == tenant_id]
    if status:
        conds.append(WorkOrder.status == status)
    return int(db.scalar(select(func.count()).select_from(WorkOrder).where(*conds)) or 0)


def count_overdue_schedules(db: Session, tenant_id: uuid.UUID, today: date) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(MaintenanceSchedule)
            .where(
                MaintenanceSchedule.tenant_id == tenant_id,
                MaintenanceSchedule.is_active.is_(True),
                MaintenanceSchedule.next_due_on < today,
            )
        )
        or 0
    )


def sum_maintenance_cost(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(
            func.coalesce(func.sum(WorkOrder.labor_cost + WorkOrder.parts_cost), 0)
        ).where(WorkOrder.tenant_id == tenant_id)
    )
    return float(val or 0)
