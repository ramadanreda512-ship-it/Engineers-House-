"""CMMS (maintenance) models: assets, work orders, and PM schedules.

Design notes:
- An Asset is a piece of equipment/machine the company maintains (its own or
  a client's). It carries a unique asset code per tenant.
- A WorkOrder is a maintenance job against an asset: corrective (breakdown) or
  preventive (planned). It moves open -> in_progress -> completed, and records
  labor/parts cost and downtime for reliability reporting.
- A MaintenanceSchedule defines recurring preventive maintenance (every N days)
  for an asset; a background job (or manual action) generates the due WorkOrder.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Asset(Base, TimestampMixin):
    __tablename__ = "assets"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(40))  # unique per tenant
    name: Mapped[str] = mapped_column(String(255))
    category: Mapped[str | None] = mapped_column(String(60), nullable=True)
    location: Mapped[str | None] = mapped_column(String(120), nullable=True)
    manufacturer: Mapped[str | None] = mapped_column(String(120), nullable=True)
    model_number: Mapped[str | None] = mapped_column(String(120), nullable=True)
    # operational / under_maintenance / out_of_service / retired
    status: Mapped[str] = mapped_column(String(20), default="operational")
    criticality: Mapped[str] = mapped_column(String(10), default="medium")  # low/medium/high
    commissioned_on: Mapped[date | None] = mapped_column(Date, nullable=True)

    work_orders: Mapped[list[WorkOrder]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    schedules: Mapped[list[MaintenanceSchedule]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )


class WorkOrder(Base, TimestampMixin):
    __tablename__ = "work_orders"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    number: Mapped[str] = mapped_column(String(40))  # auto: WO-YYYY-NNNN
    asset_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("assets.id", ondelete="CASCADE"))

    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    wo_type: Mapped[str] = mapped_column(String(20), default="corrective")  # corrective/preventive
    priority: Mapped[str] = mapped_column(String(10), default="medium")  # low/medium/high/critical
    # open / in_progress / completed / cancelled
    status: Mapped[str] = mapped_column(String(20), default="open")

    assigned_to: Mapped[str | None] = mapped_column(String(120), nullable=True)
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    labor_cost: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    parts_cost: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    downtime_hours: Mapped[float] = mapped_column(Numeric(8, 2), default=0)

    asset: Mapped[Asset] = relationship(back_populates="work_orders")


class MaintenanceSchedule(Base, TimestampMixin):
    __tablename__ = "maintenance_schedules"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    asset_id: Mapped[uuid.UUID] = mapped_column(GUID(), ForeignKey("assets.id", ondelete="CASCADE"))

    title: Mapped[str] = mapped_column(String(255))
    interval_days: Mapped[int] = mapped_column(Integer)  # every N days
    last_done_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    next_due_on: Mapped[date] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(default=True)

    asset: Mapped[Asset] = relationship(back_populates="schedules")
