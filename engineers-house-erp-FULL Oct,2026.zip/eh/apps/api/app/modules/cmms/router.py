"""CMMS HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.cmms import service
from app.modules.cmms.schemas import (
    AssetCreate,
    AssetOut,
    AssetUpdate,
    CmmsSummary,
    ScheduleCreate,
    ScheduleOut,
    WorkOrderComplete,
    WorkOrderCreate,
    WorkOrderOut,
)
from app.modules.identity.models import User
from app.shared.pagination import Page

router = APIRouter(prefix="/cmms", tags=["cmms"])


# --- Assets ---
@router.post("/assets", response_model=AssetOut, status_code=201)
def create_asset(
    body: AssetCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.manage")),
):
    return service.create_asset(db, user.tenant_id, body)


@router.get("/assets", response_model=Page[AssetOut])
def list_assets(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.view")),
):
    items, total = service.list_assets(db, user.tenant_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/assets/{asset_id}", response_model=AssetOut)
def get_asset(
    asset_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.view")),
):
    return service.get_asset(db, user.tenant_id, asset_id)


@router.patch("/assets/{asset_id}", response_model=AssetOut)
def update_asset(
    asset_id: uuid.UUID,
    body: AssetUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.manage")),
):
    return service.update_asset(db, user.tenant_id, asset_id, body)


@router.delete("/assets/{asset_id}", status_code=204)
def delete_asset(
    asset_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.manage")),
):
    service.delete_asset(db, user.tenant_id, asset_id)


# --- Work orders ---
@router.post("/work-orders", response_model=WorkOrderOut, status_code=201)
def create_work_order(
    body: WorkOrderCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.workorder.manage")),
):
    return service.create_work_order(db, user.tenant_id, body)


@router.get("/work-orders", response_model=Page[WorkOrderOut])
def list_work_orders(
    asset_id: uuid.UUID | None = Query(None),
    status: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.view")),
):
    items, total = service.list_work_orders(db, user.tenant_id, asset_id, status, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/work-orders/{wo_id}/start", response_model=WorkOrderOut)
def start_work_order(
    wo_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.workorder.manage")),
):
    return service.start_work_order(db, user.tenant_id, wo_id)


@router.post("/work-orders/{wo_id}/complete", response_model=WorkOrderOut)
def complete_work_order(
    wo_id: uuid.UUID,
    body: WorkOrderComplete,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.workorder.manage")),
):
    return service.complete_work_order(db, user.tenant_id, wo_id, body)


# --- Maintenance schedules ---
@router.post("/schedules", response_model=ScheduleOut, status_code=201)
def create_schedule(
    body: ScheduleCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.workorder.manage")),
):
    return service.create_schedule(db, user.tenant_id, body)


@router.get("/schedules", response_model=list[ScheduleOut])
def list_schedules(
    asset_id: uuid.UUID | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.view")),
):
    return service.list_schedules(db, user.tenant_id, asset_id)


@router.post("/schedules/{schedule_id}/generate", response_model=WorkOrderOut, status_code=201)
def generate_from_schedule(
    schedule_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.workorder.manage")),
):
    return service.generate_work_order_from_schedule(db, user.tenant_id, schedule_id)


# --- Reports ---
@router.get("/summary", response_model=CmmsSummary)
def cmms_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("cmms.asset.view")),
):
    return service.cmms_summary(db, user.tenant_id)
