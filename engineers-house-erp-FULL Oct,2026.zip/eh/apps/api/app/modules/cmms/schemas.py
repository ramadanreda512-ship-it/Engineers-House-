"""CMMS request/response schemas."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Assets ---
class AssetCreate(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=255)
    category: str | None = None
    location: str | None = None
    manufacturer: str | None = None
    model_number: str | None = None
    criticality: str = Field(default="medium")
    commissioned_on: date | None = None


class AssetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    category: str | None
    location: str | None
    manufacturer: str | None
    model_number: str | None
    status: str
    criticality: str
    commissioned_on: date | None


class AssetUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    category: str | None = None
    location: str | None = None
    manufacturer: str | None = None
    model_number: str | None = None
    criticality: str | None = None
    status: str | None = None


# --- Work orders ---
class WorkOrderCreate(BaseModel):
    asset_id: uuid.UUID
    title: str = Field(min_length=1, max_length=255)
    description: str | None = None
    wo_type: str = Field(default="corrective")
    priority: str = Field(default="medium")
    assigned_to: str | None = None
    due_date: date | None = None


class WorkOrderComplete(BaseModel):
    labor_cost: float = Field(ge=0, default=0)
    parts_cost: float = Field(ge=0, default=0)
    downtime_hours: float = Field(ge=0, default=0)


class WorkOrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    asset_id: uuid.UUID
    title: str
    description: str | None
    wo_type: str
    priority: str
    status: str
    assigned_to: str | None
    due_date: date | None
    completed_at: datetime | None
    labor_cost: float
    parts_cost: float
    downtime_hours: float


# --- Maintenance schedules ---
class ScheduleCreate(BaseModel):
    asset_id: uuid.UUID
    title: str = Field(min_length=1, max_length=255)
    interval_days: int = Field(gt=0)
    next_due_on: date | None = None


class ScheduleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    asset_id: uuid.UUID
    title: str
    interval_days: int
    last_done_on: date | None
    next_due_on: date
    is_active: bool


# --- Reports ---
class CmmsSummary(BaseModel):
    total_assets: int
    operational_assets: int
    open_work_orders: int
    completed_work_orders: int
    overdue_schedules: int
    total_maintenance_cost: float
