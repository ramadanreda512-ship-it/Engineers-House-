"""CMMS business logic.

Key rules enforced here:
- Asset codes are unique per tenant.
- Completing a work order stamps completed_at, records labor/parts/downtime,
  and (if the work order came from a PM schedule) is the moment a schedule's
  next due date should roll forward — handled by complete_schedule_cycle.
- Generating a work order from a schedule advances the schedule so the same
  visit is not generated twice.
"""
from __future__ import annotations

import uuid
from datetime import UTC, date, datetime, timedelta

from sqlalchemy.orm import Session

from app.modules.cmms import repository as repo
from app.modules.cmms.models import Asset, MaintenanceSchedule, WorkOrder
from app.modules.cmms.schemas import (
    AssetCreate,
    AssetUpdate,
    CmmsSummary,
    ScheduleCreate,
    WorkOrderComplete,
    WorkOrderCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


# --- Assets ---
def create_asset(db: Session, tenant_id: uuid.UUID, body: AssetCreate) -> Asset:
    if repo.asset_code_exists(db, tenant_id, body.code):
        raise Conflict(f"Asset code '{body.code}' already exists")
    asset = Asset(tenant_id=tenant_id, **body.model_dump())
    db.add(asset)
    db.commit()
    db.refresh(asset)
    return asset


def list_assets(db: Session, tenant_id: uuid.UUID, page: int, size: int):
    return repo.list_assets(db, tenant_id, size, (page - 1) * size)


def get_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> Asset:
    asset = repo.get_asset(db, tenant_id, asset_id)
    if not asset:
        raise NotFound("Asset")
    return asset


def update_asset(
    db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID, body: AssetUpdate
) -> Asset:
    asset = get_asset(db, tenant_id, asset_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(asset, field, value)
    db.commit()
    db.refresh(asset)
    return asset


def delete_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> None:
    asset = get_asset(db, tenant_id, asset_id)
    if repo.asset_has_work_orders(db, tenant_id, asset_id):
        raise Conflict(
            "Cannot delete an asset that has work orders. Mark it 'retired' "
            "via update instead to keep its maintenance history."
        )
    db.delete(asset)
    db.commit()


# --- Work orders ---
def create_work_order(db: Session, tenant_id: uuid.UUID, body: WorkOrderCreate) -> WorkOrder:
    if not repo.get_asset(db, tenant_id, body.asset_id):
        raise NotFound("Asset")
    year = date.today().year
    wo = WorkOrder(
        tenant_id=tenant_id,
        number=repo.next_wo_number(db, tenant_id, year),
        asset_id=body.asset_id,
        title=body.title,
        description=body.description,
        wo_type=body.wo_type,
        priority=body.priority,
        assigned_to=body.assigned_to,
        due_date=body.due_date,
        status="open",
    )
    db.add(wo)
    db.commit()
    db.refresh(wo)
    return wo


def list_work_orders(
    db: Session,
    tenant_id: uuid.UUID,
    asset_id: uuid.UUID | None,
    status: str | None,
    page: int,
    size: int,
):
    return repo.list_work_orders(db, tenant_id, asset_id, status, size, (page - 1) * size)


def start_work_order(db: Session, tenant_id: uuid.UUID, wo_id: uuid.UUID) -> WorkOrder:
    wo = repo.get_work_order(db, tenant_id, wo_id)
    if not wo:
        raise NotFound("Work order")
    if wo.status in ("completed", "cancelled"):
        raise Conflict(f"Work order is already {wo.status}")
    wo.status = "in_progress"
    # Reflect that the asset is being worked on.
    asset = repo.get_asset(db, tenant_id, wo.asset_id)
    if asset and asset.status == "operational":
        asset.status = "under_maintenance"
    db.commit()
    db.refresh(wo)
    return wo


def complete_work_order(
    db: Session, tenant_id: uuid.UUID, wo_id: uuid.UUID, body: WorkOrderComplete
) -> WorkOrder:
    wo = repo.get_work_order(db, tenant_id, wo_id)
    if not wo:
        raise NotFound("Work order")
    if wo.status == "completed":
        raise Conflict("Work order is already completed")
    if wo.status == "cancelled":
        raise BadRequest("Cannot complete a cancelled work order")
    wo.status = "completed"
    wo.completed_at = datetime.now(UTC)
    wo.labor_cost = body.labor_cost
    wo.parts_cost = body.parts_cost
    wo.downtime_hours = body.downtime_hours
    # Return the asset to operational once maintenance is done.
    asset = repo.get_asset(db, tenant_id, wo.asset_id)
    if asset and asset.status == "under_maintenance":
        asset.status = "operational"
    db.commit()
    db.refresh(wo)
    return wo


# --- Maintenance schedules ---
def create_schedule(db: Session, tenant_id: uuid.UUID, body: ScheduleCreate) -> MaintenanceSchedule:
    if not repo.get_asset(db, tenant_id, body.asset_id):
        raise NotFound("Asset")
    next_due = body.next_due_on or (date.today() + timedelta(days=body.interval_days))
    schedule = MaintenanceSchedule(
        tenant_id=tenant_id,
        asset_id=body.asset_id,
        title=body.title,
        interval_days=body.interval_days,
        next_due_on=next_due,
        is_active=True,
    )
    db.add(schedule)
    db.commit()
    db.refresh(schedule)
    return schedule


def list_schedules(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID | None):
    return repo.list_schedules(db, tenant_id, asset_id)


def generate_work_order_from_schedule(
    db: Session, tenant_id: uuid.UUID, schedule_id: uuid.UUID
) -> WorkOrder:
    """Create a preventive work order for a due schedule and roll the schedule
    forward by its interval so the same visit is not generated twice."""
    schedule = repo.get_schedule(db, tenant_id, schedule_id)
    if not schedule:
        raise NotFound("Maintenance schedule")
    if not schedule.is_active:
        raise BadRequest("Schedule is not active")

    year = date.today().year
    wo = WorkOrder(
        tenant_id=tenant_id,
        number=repo.next_wo_number(db, tenant_id, year),
        asset_id=schedule.asset_id,
        title=f"PM: {schedule.title}",
        wo_type="preventive",
        priority="medium",
        status="open",
        due_date=schedule.next_due_on,
    )
    db.add(wo)
    schedule.last_done_on = date.today()
    schedule.next_due_on = date.today() + timedelta(days=schedule.interval_days)
    db.commit()
    db.refresh(wo)
    return wo


# --- Reports ---
def cmms_summary(db: Session, tenant_id: uuid.UUID) -> CmmsSummary:
    return CmmsSummary(
        total_assets=repo.count_assets(db, tenant_id),
        operational_assets=repo.count_assets(db, tenant_id, "operational"),
        open_work_orders=repo.count_work_orders(db, tenant_id, "open"),
        completed_work_orders=repo.count_work_orders(db, tenant_id, "completed"),
        overdue_schedules=repo.count_overdue_schedules(db, tenant_id, date.today()),
        total_maintenance_cost=round(repo.sum_maintenance_cost(db, tenant_id), 2),
    )
