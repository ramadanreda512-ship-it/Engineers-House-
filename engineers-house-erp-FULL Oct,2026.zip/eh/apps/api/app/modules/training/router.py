"""Training / LMS HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.training import service
from app.modules.training.schemas import (
    AssessmentCreate,
    AssessmentOut,
    AttendanceMark,
    AttendanceOut,
    CertificateOut,
    CohortCostCreate,
    CohortCostOut,
    CohortCreate,
    CohortFinanceRow,
    CohortOut,
    CohortPnl,
    CourseCreate,
    CourseOut,
    CourseUpdate,
    EnrollmentCreate,
    EnrollmentFinance,
    EnrollmentOut,
    InstallmentCreate,
    InstallmentOut,
    InstructorCreate,
    InstructorOut,
    InstructorOutFull,
    LeadConvert,
    LeadCreate,
    LeadLogContact,
    LeadLogOut,
    LeadLose,
    LeadOut,
    LeadsSummary,
    LeadUpdate,
    SessionCreate,
    SessionOut,
    StudentCreate,
    StudentOut,
    StudentUpdate,
    TrainingSummary,
)
from app.shared.csv_io import CsvExportOut, CsvImportBody
from app.shared.pagination import Page

router = APIRouter(prefix="/training", tags=["training"])


@router.post("/courses", response_model=CourseOut, status_code=201)
def create_course(
    body: CourseCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.create")),
):
    return service.create_course(db, user.tenant_id, body)


@router.get("/courses", response_model=Page[CourseOut])
def list_courses(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    category: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    items, total = service.list_courses(
        db, user.tenant_id, page, size, search=search, category=category
    )
    return Page(items=items, total=total, page=page, size=size)


@router.patch("/courses/{course_id}", response_model=CourseOut)
def update_course(
    course_id: uuid.UUID,
    body: CourseUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.create")),
):
    return service.update_course(db, user.tenant_id, course_id, body)


@router.delete("/courses/{course_id}", status_code=204)
def delete_course(
    course_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.delete")),
):
    service.delete_course(db, user.tenant_id, course_id)


@router.post("/instructors", response_model=InstructorOut, status_code=201)
def create_instructor(
    body: InstructorCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.instructor.create")),
):
    return service.create_instructor(db, user.tenant_id, body)


@router.get("/instructors", response_model=list[InstructorOutFull])
def list_instructors(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.list_instructors(db, user.tenant_id)


@router.get("/summary", response_model=TrainingSummary)
def training_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.training_summary(db, user.tenant_id)


@router.get("/reports/cohort-finance", response_model=list[CohortFinanceRow])
def cohort_finance_report(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.cohort_finance_report(db, user.tenant_id)


@router.post("/cohorts", response_model=CohortOut, status_code=201)
def create_cohort(
    body: CohortCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.cohort.create")),
):
    return service.create_cohort(db, user.tenant_id, body)


@router.get("/cohorts", response_model=Page[CohortOut])
def list_cohorts(
    course_id: uuid.UUID | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    items, total = service.list_cohorts(db, user.tenant_id, course_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/cohorts/{cohort_id}/sessions", response_model=SessionOut, status_code=201)
def add_session(
    cohort_id: uuid.UUID,
    body: SessionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.session.create")),
):
    return service.add_session(db, user.tenant_id, cohort_id, body)


@router.get("/cohorts/{cohort_id}/sessions", response_model=list[SessionOut])
def list_sessions(
    cohort_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.list_sessions(db, user.tenant_id, cohort_id)


@router.get("/cohorts/{cohort_id}/enrollments", response_model=Page[EnrollmentOut])
def list_cohort_enrollments(
    cohort_id: uuid.UUID,
    page: int = Query(1, ge=1),
    size: int = Query(100, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    items, total = service.list_enrollments(db, user.tenant_id, cohort_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/students", response_model=StudentOut, status_code=201)
def create_student(
    body: StudentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.create_student(db, user.tenant_id, body)


@router.get("/students", response_model=Page[StudentOut])
def list_students(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    items, total = service.list_students(db, user.tenant_id, page, size, search=search)
    return Page(items=items, total=total, page=page, size=size)


@router.patch("/students/{student_id}", response_model=StudentOut)
def update_student(
    student_id: uuid.UUID,
    body: StudentUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.update_student(db, user.tenant_id, student_id, body)


@router.delete("/students/{student_id}", status_code=204)
def delete_student(
    student_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.delete")),
):
    service.delete_student(db, user.tenant_id, student_id)


@router.post("/enrollments", response_model=EnrollmentOut, status_code=201)
def enroll_student(
    body: EnrollmentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.create")),
):
    return service.enroll_student(db, user.tenant_id, body)


@router.get("/enrollments/{enrollment_id}", response_model=EnrollmentOut)
def get_enrollment(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.create")),
):
    return service.get_enrollment(db, user.tenant_id, enrollment_id)


@router.get("/enrollments/{enrollment_id}/installments", response_model=list[InstallmentOut])
def list_installments(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.create")),
):
    return service.list_installments(db, user.tenant_id, enrollment_id)


@router.get("/enrollments/{enrollment_id}/finance", response_model=EnrollmentFinance)
def enrollment_finance(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.create")),
):
    return service.enrollment_finance(db, user.tenant_id, enrollment_id)


@router.post("/enrollments/{enrollment_id}/installments", response_model=InstallmentOut,
             status_code=201)
def add_installment(
    enrollment_id: uuid.UUID,
    body: InstallmentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.edit")),
):
    return service.add_installment(db, user.tenant_id, enrollment_id, body)


@router.post("/installments/{installment_id}/pay", response_model=InstallmentOut)
def pay_installment(
    installment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.edit")),
):
    return service.pay_installment(db, installment_id)


@router.post("/installments/{installment_id}/unpay", response_model=InstallmentOut)
def unpay_installment(
    installment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.edit")),
):
    return service.unpay_installment(db, installment_id)


@router.delete("/installments/{installment_id}", status_code=204)
def delete_installment(
    installment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.delete")),
):
    service.delete_installment(db, user.tenant_id, installment_id)


@router.delete("/enrollments/{enrollment_id}", status_code=204)
def delete_enrollment(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.delete")),
):
    service.delete_enrollment(db, user.tenant_id, enrollment_id)


@router.post("/enrollments/{enrollment_id}/complete", response_model=EnrollmentOut)
def complete_enrollment(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.edit")),
):
    return service.complete_enrollment(db, user.tenant_id, enrollment_id)


@router.post("/enrollments/{enrollment_id}/withdraw", response_model=EnrollmentOut)
def withdraw_enrollment(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.enrollment.edit")),
):
    return service.withdraw_enrollment(db, user.tenant_id, enrollment_id)


@router.post("/sessions/{session_id}/attendance", response_model=AttendanceOut, status_code=201)
def mark_attendance(
    session_id: uuid.UUID,
    body: AttendanceMark,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.attendance.mark")),
):
    return service.mark_attendance(db, user.tenant_id, session_id, body)


@router.post(
    "/enrollments/{enrollment_id}/assessments",
    response_model=AssessmentOut,
    status_code=201,
)
def record_assessment(
    enrollment_id: uuid.UUID,
    body: AssessmentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.assessment.record")),
):
    return service.record_assessment(db, user.tenant_id, enrollment_id, body)


@router.post(
    "/enrollments/{enrollment_id}/certificate",
    response_model=CertificateOut,
    status_code=201,
)
def issue_certificate(
    enrollment_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.certificate.issue")),
):
    return service.issue_certificate(db, user.tenant_id, enrollment_id)


# --- CSV import / export ---
@router.get("/students-export", response_model=CsvExportOut)
def export_students(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.export_students_csv(db, user.tenant_id)


@router.post("/students-import", response_model=None)
def import_students(
    body: CsvImportBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.create")),
):
    return service.import_students_csv(db, user.tenant_id, body.content)


@router.get("/courses-export", response_model=CsvExportOut)
def export_courses(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.export_courses_csv(db, user.tenant_id)


@router.post("/courses-import", response_model=None)
def import_courses(
    body: CsvImportBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.create")),
):
    return service.import_courses_csv(db, user.tenant_id, body.content)


# --- Public certificate verification (no auth: for employers/clients) ---
@router.get("/certificates/verify/{verification_code}", response_model=None)
def verify_certificate(
    verification_code: str,
    db: Session = Depends(get_db),
):
    return service.verify_certificate(db, verification_code)


# ==================== Training leads (B2C funnel) ====================
@router.post("/leads", response_model=LeadOut, status_code=201)
def create_lead(
    body: LeadCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.create_lead(db, user.tenant_id, body)


@router.get("/leads", response_model=Page[LeadOut])
def list_leads(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    status: str | None = Query(None),
    source: str | None = Query(None),
    search: str | None = Query(None),
    due: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    items, total = service.list_leads(
        db, user.tenant_id, page, size,
        status=status, source=source, search=search, due=due,
    )
    return Page(items=items, total=total, page=page, size=size)


@router.get("/leads/summary", response_model=LeadsSummary)
def leads_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.leads_summary(db, user.tenant_id)


@router.patch("/leads/{lead_id}", response_model=LeadOut)
def update_lead(
    lead_id: uuid.UUID,
    body: LeadUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.update_lead(db, user.tenant_id, lead_id, body)


@router.post("/leads/{lead_id}/log-contact", response_model=LeadOut)
def log_lead_contact(
    lead_id: uuid.UUID,
    body: LeadLogContact,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.log_lead_contact(db, user.tenant_id, lead_id, body)


@router.get("/leads/{lead_id}/logs", response_model=list[LeadLogOut])
def lead_logs(
    lead_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.lead_logs(db, user.tenant_id, lead_id)


@router.post("/leads/{lead_id}/lose", response_model=LeadOut)
def lose_lead(
    lead_id: uuid.UUID,
    body: LeadLose,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.lose_lead(db, user.tenant_id, lead_id, body)


@router.post("/leads/{lead_id}/convert", response_model=None)
def convert_lead(
    lead_id: uuid.UUID,
    body: LeadConvert,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.student.create")),
):
    return service.convert_lead(db, user.tenant_id, lead_id, body)


# ==================== Cohort profitability ====================
@router.post("/cohorts/{cohort_id}/costs", response_model=CohortCostOut, status_code=201)
def add_cohort_cost(
    cohort_id: uuid.UUID,
    body: CohortCostCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.cohort.create")),
):
    return service.add_cohort_cost(db, user.tenant_id, cohort_id, body)


@router.get("/cohorts/{cohort_id}/costs", response_model=list[CohortCostOut])
def list_cohort_costs(
    cohort_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.list_cohort_costs(db, user.tenant_id, cohort_id)


@router.delete("/costs/{cost_id}", status_code=204)
def delete_cohort_cost(
    cost_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.cohort.delete")),
):
    service.delete_cohort_cost(db, user.tenant_id, cost_id)


@router.get("/cohorts/{cohort_id}/pnl", response_model=CohortPnl)
def cohort_pnl(
    cohort_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.cohort_pnl(db, user.tenant_id, cohort_id)


@router.get("/reports/profitability", response_model=list[CohortPnl])
def profitability_report(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("training.course.view")),
):
    return service.profitability_report(db, user.tenant_id)
