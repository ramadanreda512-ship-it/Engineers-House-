"""Training / LMS models: courses, cohorts, sessions, students, enrollments,
attendance, certificates.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Course(Base, TimestampMixin):
    __tablename__ = "courses"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_course_tenant_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(255))
    category: Mapped[str] = mapped_column(String(60))  # PLC, SCADA, HMI, Instrumentation, ...
    duration_hours: Mapped[int] = mapped_column(Integer, default=0)
    price: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    mode: Mapped[str] = mapped_column(String(20), default="onsite")  # onsite/online/hybrid
    # beginner / intermediate / advanced (engineering-track levels)
    level: Mapped[str] = mapped_column(String(20), default="beginner")
    description: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    prerequisites: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True)
    # Minimum assessment score (0-100) required before a certificate can be
    # issued. Null means the course has no score requirement (attendance/
    # completion alone is sufficient, the Phase-1 default).
    passing_score: Mapped[float | None] = mapped_column(Numeric(5, 2), nullable=True)

    cohorts: Mapped[list[Cohort]] = relationship(
        back_populates="course", cascade="all, delete-orphan", lazy="selectin"
    )


class Instructor(Base, TimestampMixin):
    __tablename__ = "instructors"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    user_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    name: Mapped[str] = mapped_column(String(255))
    specialization: Mapped[str | None] = mapped_column(String(120), nullable=True)
    revenue_share_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)


class Cohort(Base, TimestampMixin):
    __tablename__ = "cohorts"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    course_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("courses.id", ondelete="CASCADE")
    )
    instructor_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("instructors.id"), nullable=True
    )
    code: Mapped[str] = mapped_column(String(40))  # e.g. PLC-2026-01
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    capacity: Mapped[int] = mapped_column(Integer, default=20)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # planned/ongoing/completed/cancelled
    status: Mapped[str] = mapped_column(String(20), default="planned")

    course: Mapped[Course] = relationship(back_populates="cohorts")
    sessions: Mapped[list[Session]] = relationship(
        back_populates="cohort", cascade="all, delete-orphan", lazy="selectin"
    )
    enrollments: Mapped[list[Enrollment]] = relationship(
        back_populates="cohort", cascade="all, delete-orphan", lazy="selectin"
    )
    instructor: Mapped[Instructor | None] = relationship(lazy="selectin")


class Session(Base, TimestampMixin):
    __tablename__ = "training_sessions"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    cohort_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("cohorts.id", ondelete="CASCADE")
    )
    title: Mapped[str] = mapped_column(String(255))
    scheduled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    duration_min: Mapped[int] = mapped_column(Integer, default=120)
    mode: Mapped[str] = mapped_column(String(20), default="onsite")

    cohort: Mapped[Cohort] = relationship(back_populates="sessions")
    attendances: Mapped[list[Attendance]] = relationship(
        back_populates="session", cascade="all, delete-orphan", lazy="selectin"
    )


class Student(Base, TimestampMixin):
    __tablename__ = "students"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    full_name: Mapped[str] = mapped_column(String(255))
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    # Professional profile (for corporate training and certificates)
    company: Mapped[str | None] = mapped_column(String(255), nullable=True)
    job_title: Mapped[str | None] = mapped_column(String(120), nullable=True)
    national_id: Mapped[str | None] = mapped_column(String(30), nullable=True)
    source: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    # Optional link to a CRM account (corporate training client)
    account_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    enrollments: Mapped[list[Enrollment]] = relationship(
        back_populates="student", cascade="all, delete-orphan", lazy="selectin"
    )


class Enrollment(Base, TimestampMixin):
    __tablename__ = "enrollments"
    __table_args__ = (
        UniqueConstraint("student_id", "cohort_id", name="uq_enrollment_student_cohort"),
    )
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    student_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("students.id", ondelete="CASCADE")
    )
    cohort_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("cohorts.id", ondelete="CASCADE")
    )
    # active/waitlisted/completed/withdrawn
    status: Mapped[str] = mapped_column(String(20), default="active")
    # null unless status == waitlisted; lower = earlier in line
    waitlist_position: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_fee: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    discount: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    # Booking deposit paid up front; the remainder is split into installments.
    down_payment: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    enrolled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    student: Mapped[Student] = relationship(back_populates="enrollments")
    cohort: Mapped[Cohort] = relationship(back_populates="enrollments")
    attendances: Mapped[list[Attendance]] = relationship(
        back_populates="enrollment", cascade="all, delete-orphan", lazy="selectin"
    )
    installments: Mapped[list[Installment]] = relationship(
        back_populates="enrollment", cascade="all, delete-orphan", lazy="selectin"
    )
    assessments: Mapped[list[Assessment]] = relationship(
        back_populates="enrollment", cascade="all, delete-orphan", lazy="selectin"
    )
    certificate: Mapped[Certificate | None] = relationship(
        back_populates="enrollment", cascade="all, delete-orphan", uselist=False
    )


class Attendance(Base, TimestampMixin):
    __tablename__ = "attendances"
    __table_args__ = (
        UniqueConstraint("session_id", "enrollment_id", name="uq_attendance_session_enrollment"),
    )
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("training_sessions.id", ondelete="CASCADE")
    )
    enrollment_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("enrollments.id", ondelete="CASCADE")
    )
    status: Mapped[str] = mapped_column(String(20), default="present")  # present/absent/late
    marked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    session: Mapped[Session] = relationship(back_populates="attendances")
    enrollment: Mapped[Enrollment] = relationship(back_populates="attendances")


class Installment(Base, TimestampMixin):
    __tablename__ = "installments"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    enrollment_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("enrollments.id", ondelete="CASCADE")
    )
    sequence: Mapped[int] = mapped_column(Integer)
    amount: Mapped[float] = mapped_column(Numeric(14, 2))
    due_date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending/paid/overdue
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    enrollment: Mapped[Enrollment] = relationship(back_populates="installments")


class Assessment(Base, TimestampMixin):
    """A graded exam/test recorded against an enrollment. A course may define
    a passing_score; if it does, certificate issuance checks the enrollment's
    best assessment score against it (see training/service.py)."""

    __tablename__ = "assessments"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    enrollment_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("enrollments.id", ondelete="CASCADE")
    )
    title: Mapped[str] = mapped_column(String(255))  # e.g. "Final Exam"
    score: Mapped[float] = mapped_column(Numeric(5, 2))  # 0-100
    taken_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    enrollment: Mapped[Enrollment] = relationship(back_populates="assessments")


class Certificate(Base, TimestampMixin):
    __tablename__ = "certificates"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    enrollment_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("enrollments.id", ondelete="CASCADE"), unique=True
    )
    serial: Mapped[str] = mapped_column(String(60), unique=True)
    verification_code: Mapped[str] = mapped_column(String(40), unique=True)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    enrollment: Mapped[Enrollment] = relationship(back_populates="certificate")


# --- B2C inquiry funnel (training leads) ---
LEAD_SOURCES = (
    "whatsapp", "phone_call", "facebook", "instagram",
    "walk_in", "referral", "website", "other",
)
LEAD_STATUSES = ("new", "contacted", "follow_up", "interested", "registered", "lost")
LOST_REASONS = ("price", "timing", "location", "competitor", "no_response", "other")


class TrainingLead(Base, TimestampMixin):
    """A B2C training inquiry: someone who asked about a course. The whole
    point is never losing them: every lead carries a next_follow_up date so
    the front-desk sees exactly whom to contact today, and every lost lead
    records why (price/timing/competitor...) for marketing analysis."""

    __tablename__ = "training_leads"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    name: Mapped[str] = mapped_column(String(255))
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    whatsapp: Mapped[str | None] = mapped_column(String(40), nullable=True)
    source: Mapped[str] = mapped_column(String(20), default="whatsapp")
    interested_course_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("courses.id"), nullable=True
    )
    status: Mapped[str] = mapped_column(String(20), default="new")
    next_follow_up: Mapped[date | None] = mapped_column(Date, nullable=True)
    lost_reason: Mapped[str | None] = mapped_column(String(20), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    contact_count: Mapped[int] = mapped_column(Integer, default=0)
    # Set when the lead converts into an actual student.
    student_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("students.id"), nullable=True
    )
    interested_course: Mapped[Course | None] = relationship()
    logs: Mapped[list[TrainingLeadLog]] = relationship(
        back_populates="lead", cascade="all, delete-orphan", lazy="selectin",
        order_by="TrainingLeadLog.created_at.desc()",
    )


class TrainingLeadLog(Base, TimestampMixin):
    """One follow-up touch on a lead (call/whatsapp note)."""

    __tablename__ = "training_lead_logs"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    lead_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("training_leads.id", ondelete="CASCADE")
    )
    note: Mapped[str] = mapped_column(String(500))
    lead: Mapped[TrainingLead] = relationship(back_populates="logs")


# --- Cohort profitability ---
COHORT_COST_TYPES = ("hall", "materials", "marketing", "other")


class CohortCost(Base, TimestampMixin):
    """A manual cost line on a cohort (hall rent, materials, marketing...).
    The instructor's share is NOT entered here: it is computed automatically
    from the instructor's revenue_share_pct in the P&L."""

    __tablename__ = "cohort_costs"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    cohort_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("cohorts.id", ondelete="CASCADE")
    )
    cost_type: Mapped[str] = mapped_column(String(20), default="other")
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    amount: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    cost_date: Mapped[date | None] = mapped_column(Date, nullable=True)
