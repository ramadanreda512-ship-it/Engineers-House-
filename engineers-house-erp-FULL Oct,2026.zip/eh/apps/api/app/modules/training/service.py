"""Training / LMS business logic.

Key rules enforced here (not just in the DB):
- A cohort enrolling beyond capacity waitlists the student (status=
  'waitlisted') instead of rejecting them; installments are deferred until
  the enrollment becomes active.
- Withdrawing an active enrollment automatically promotes the first
  waitlisted enrollment (if any) to active and generates its installment
  schedule, in the same transaction.
- Attendance marking is idempotent: marking the same session+enrollment again
  updates the existing record instead of creating a duplicate.
- A certificate can only be issued once, only after the enrollment is marked
  completed, and — if the course defines a passing_score — only once an
  assessment meeting that score has been recorded for the enrollment.
"""
from __future__ import annotations

import secrets
import uuid
from datetime import UTC, date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.training import repository as repo
from app.modules.training.models import (
    Assessment,
    Attendance,
    Certificate,
    Cohort,
    Course,
    Enrollment,
    Installment,
    Instructor,
    Student,
)
from app.modules.training.models import (
    Session as TrainingSession,
)
from app.modules.training.schemas import (
    AssessmentCreate,
    AttendanceMark,
    CohortCreate,
    CourseCreate,
    CourseUpdate,
    EnrollmentCreate,
    InstructorCreate,
    SessionCreate,
    StudentCreate,
    StudentUpdate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


# --- Courses ---
def create_course(db: Session, tenant_id: uuid.UUID, body: CourseCreate) -> Course:
    existing = db.scalar(
        select(Course).where(Course.tenant_id == tenant_id, Course.code == body.code)
    )
    if existing:
        raise Conflict(f"Course code '{body.code}' already exists")
    course = Course(tenant_id=tenant_id, **body.model_dump())
    db.add(course)
    db.commit()
    db.refresh(course)
    return course


def list_courses(
    db: Session, tenant_id: uuid.UUID, page: int, size: int,
    search: str | None = None, category: str | None = None,
):
    return repo.list_courses(
        db, tenant_id, size, (page - 1) * size, search=search, category=category
    )


def get_course(db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID) -> Course:
    course = repo.get_course(db, tenant_id, course_id)
    if not course:
        raise NotFound("Course")
    return course


def update_course(
    db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID, body: CourseUpdate
) -> Course:
    course = get_course(db, tenant_id, course_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(course, field, value)
    db.commit()
    db.refresh(course)
    return course


def delete_course(db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID) -> None:
    course = get_course(db, tenant_id, course_id)
    if repo.course_has_cohorts(db, tenant_id, course_id):
        raise Conflict(
            "Cannot delete a course that has cohorts. Delete its cohorts first, "
            "or deactivate the course instead."
        )
    db.delete(course)
    db.commit()


def list_cohorts(
    db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID | None, page: int, size: int
):
    return repo.list_cohorts(db, tenant_id, course_id, size, (page - 1) * size)


def list_students(
    db: Session, tenant_id: uuid.UUID, page: int, size: int, search: str | None = None
):
    return repo.list_students(db, tenant_id, size, (page - 1) * size, search=search)


def list_sessions(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID):
    if not repo.get_cohort(db, tenant_id, cohort_id):
        raise NotFound("Cohort")
    return repo.list_sessions(db, tenant_id, cohort_id)


def list_enrollments(
    db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID | None, page: int, size: int
):
    return repo.list_enrollments(db, tenant_id, cohort_id, size, (page - 1) * size)


def list_installments(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID):
    if not repo.get_enrollment(db, tenant_id, enrollment_id):
        raise NotFound("Enrollment")
    return repo.list_installments(db, enrollment_id)


# --- Instructors ---
def create_instructor(db: Session, tenant_id: uuid.UUID, body: InstructorCreate) -> Instructor:
    instructor = Instructor(tenant_id=tenant_id, **body.model_dump())
    db.add(instructor)
    db.commit()
    db.refresh(instructor)
    return instructor


# --- Cohorts ---
def create_cohort(db: Session, tenant_id: uuid.UUID, body: CohortCreate) -> Cohort:
    if not repo.get_course(db, tenant_id, body.course_id):
        raise NotFound("Course")
    if body.instructor_id:
        instructor = db.scalar(
            select(Instructor).where(
                Instructor.id == body.instructor_id, Instructor.tenant_id == tenant_id
            )
        )
        if not instructor:
            raise NotFound("Instructor")
    cohort = Cohort(tenant_id=tenant_id, **body.model_dump())
    db.add(cohort)
    db.commit()
    db.refresh(cohort)
    return cohort


# --- Sessions ---
def add_session(
    db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID, body: SessionCreate
) -> TrainingSession:
    if not repo.get_cohort(db, tenant_id, cohort_id):
        raise NotFound("Cohort")
    session = TrainingSession(tenant_id=tenant_id, cohort_id=cohort_id, **body.model_dump())
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


# --- Students ---
def create_student(db: Session, tenant_id: uuid.UUID, body: StudentCreate) -> Student:
    student = Student(tenant_id=tenant_id, **body.model_dump())
    db.add(student)
    db.commit()
    db.refresh(student)
    return student


def get_student(db: Session, tenant_id: uuid.UUID, student_id: uuid.UUID) -> Student:
    student = repo.get_student(db, tenant_id, student_id)
    if not student:
        raise NotFound("Student")
    return student


def update_student(
    db: Session, tenant_id: uuid.UUID, student_id: uuid.UUID, body: StudentUpdate
) -> Student:
    student = get_student(db, tenant_id, student_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(student, field, value)
    db.commit()
    db.refresh(student)
    return student


def delete_student(db: Session, tenant_id: uuid.UUID, student_id: uuid.UUID) -> None:
    student = get_student(db, tenant_id, student_id)
    if repo.student_has_enrollments(db, tenant_id, student_id):
        raise Conflict(
            "Cannot delete a student who has enrollments. Withdraw the student "
            "from their cohorts first."
        )
    db.delete(student)
    db.commit()


# --- Enrollments ---
def _generate_installments(db: Session, enrollment: Enrollment, body: EnrollmentCreate) -> None:
    """Create the installment schedule for a now-active enrollment.

    The booking deposit (down_payment) is deducted first — only the REMAINING
    balance is split across installment_count. The last installment absorbs
    any rounding difference so the parts always sum exactly to the balance.
    Example: total 2000, deposit 500, 3 installments -> 1500 split as
    500 / 500 / 500.
    """
    net_fee = round(body.total_fee - body.discount, 2)
    deposit = round(min(body.down_payment, net_fee), 2)
    balance = round(net_fee - deposit, 2)
    n = body.installment_count
    if balance <= 0 or n <= 0:
        return  # fully covered by the deposit; no installments needed
    base_amount = round(balance / n, 2)
    first_due = body.first_due_date or date.today()
    running_total = 0.0
    for i in range(1, n + 1):
        amount = base_amount
        if i == n:
            amount = round(balance - running_total, 2)
        running_total = round(running_total + amount, 2)
        db.add(
            Installment(
                enrollment_id=enrollment.id,
                sequence=i,
                amount=amount,
                due_date=first_due + timedelta(days=30 * (i - 1)),
                status="pending",
            )
        )


def enroll_student(db: Session, tenant_id: uuid.UUID, body: EnrollmentCreate) -> Enrollment:
    """Enroll a student into a cohort. If the cohort is at capacity, the
    student is placed on the waitlist (status='waitlisted') instead of being
    rejected outright — matching standard TMS behavior. Installments are only
    generated once an enrollment is active; a waitlisted enrollment has none
    until it is promoted (see withdraw_enrollment)."""
    if not repo.get_student(db, tenant_id, body.student_id):
        raise NotFound("Student")
    cohort = repo.get_cohort(db, tenant_id, body.cohort_id)
    if not cohort:
        raise NotFound("Cohort")

    existing = db.scalar(
        select(Enrollment).where(
            Enrollment.student_id == body.student_id, Enrollment.cohort_id == body.cohort_id
        )
    )
    if existing:
        raise Conflict("Student is already enrolled in this cohort")

    net_fee = round(body.total_fee - body.discount, 2)
    if net_fee < 0:
        raise BadRequest("Discount cannot exceed total fee")

    is_full = repo.count_active_enrollments(db, cohort.id) >= cohort.capacity
    enrollment = Enrollment(
        tenant_id=tenant_id,
        student_id=body.student_id,
        cohort_id=body.cohort_id,
        status="waitlisted" if is_full else "active",
        waitlist_position=repo.next_waitlist_position(db, cohort.id) if is_full else None,
        total_fee=body.total_fee,
        discount=body.discount,
        down_payment=body.down_payment,
        enrolled_at=datetime.now(UTC),
    )
    db.add(enrollment)
    db.flush()

    if not is_full:
        _generate_installments(db, enrollment, body)

    db.commit()
    db.refresh(enrollment)
    return enrollment


def get_enrollment(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> Enrollment:
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    return enrollment


def withdraw_enrollment(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> Enrollment:
    """Withdraw a student from a cohort. If the enrollment being withdrawn
    was active, the first waitlisted enrollment (if any) is automatically
    promoted to active and given its installment schedule, all within the
    same transaction — no manual intervention needed."""
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    if enrollment.status == "withdrawn":
        raise Conflict("Enrollment is already withdrawn")

    was_active = enrollment.status == "active"
    enrollment.status = "withdrawn"
    enrollment.waitlist_position = None
    db.flush()

    if was_active:
        promoted = repo.first_waitlisted(db, enrollment.cohort_id)
        if promoted is not None:
            promoted.status = "active"
            promoted.waitlist_position = None
            db.flush()
            promo_body = EnrollmentCreate(
                student_id=promoted.student_id,
                cohort_id=promoted.cohort_id,
                total_fee=float(promoted.total_fee),
                discount=float(promoted.discount),
                installment_count=1,
            )
            _generate_installments(db, promoted, promo_body)

    db.commit()
    db.refresh(enrollment)
    return enrollment


def complete_enrollment(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> Enrollment:
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    enrollment.status = "completed"
    db.commit()
    db.refresh(enrollment)
    return enrollment


# --- Attendance ---
def mark_attendance(
    db: Session, tenant_id: uuid.UUID, session_id: uuid.UUID, body: AttendanceMark
) -> Attendance:
    session = repo.get_session(db, tenant_id, session_id)
    if not session:
        raise NotFound("Session")
    enrollment = repo.get_enrollment(db, tenant_id, body.enrollment_id)
    if not enrollment or enrollment.cohort_id != session.cohort_id:
        raise BadRequest("Enrollment does not belong to this session's cohort")

    existing = db.scalar(
        select(Attendance).where(
            Attendance.session_id == session_id, Attendance.enrollment_id == body.enrollment_id
        )
    )
    now = datetime.now(UTC)
    if existing:
        existing.status = body.status
        existing.marked_at = now
        db.commit()
        db.refresh(existing)
        return existing

    attendance = Attendance(
        session_id=session_id, enrollment_id=body.enrollment_id, status=body.status, marked_at=now
    )
    db.add(attendance)
    db.commit()
    db.refresh(attendance)
    return attendance


# --- Installments ---
def process_installment_reminders(db: Session, reminder_window_days: int = 3) -> dict:
    """Scan installments and return a summary of work to be done:
    - 'due_soon': pending installments due within the reminder window (these
      would trigger a notification to the student).
    - 'overdue': pending installments past their due date; these are flipped
      to status='overdue' as a side effect so dashboards reflect reality.

    Returns counts plus the affected installment ids, so a Celery task (or a
    test) can act on the result. Kept free of any I/O beyond the DB so it is
    fully unit-testable without a broker or mail server.
    """
    today = date.today()
    window_end = today + timedelta(days=reminder_window_days)

    due_soon = repo.installments_due_between(db, today, window_end)
    overdue = repo.overdue_pending_installments(db, today)

    overdue_ids = []
    for inst in overdue:
        inst.status = "overdue"
        overdue_ids.append(str(inst.id))
    if overdue_ids:
        db.commit()

    return {
        "reminder_window_days": reminder_window_days,
        "due_soon_count": len(due_soon),
        "due_soon_ids": [str(i.id) for i in due_soon],
        "overdue_count": len(overdue_ids),
        "overdue_ids": overdue_ids,
    }


def pay_installment(db: Session, installment_id: uuid.UUID) -> Installment:
    installment = db.get(Installment, installment_id)
    if not installment:
        raise NotFound("Installment")
    if installment.status == "paid":
        raise Conflict("Installment already paid")
    installment.status = "paid"
    installment.paid_at = datetime.now(UTC)
    db.commit()
    db.refresh(installment)
    return installment


def unpay_installment(db: Session, installment_id: uuid.UUID) -> Installment:
    """Reverse a payment recorded by mistake."""
    installment = db.get(Installment, installment_id)
    if not installment:
        raise NotFound("Installment")
    installment.status = "pending"
    installment.paid_at = None
    db.commit()
    db.refresh(installment)
    return installment


def add_installment(
    db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID, body
) -> Installment:
    """Manually add one installment to an enrollment (e.g. to reschedule a
    remaining balance the owner wants split differently)."""
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    seq = body.sequence
    if seq is None:
        existing = [i.sequence for i in enrollment.installments]
        seq = (max(existing) + 1) if existing else 1
    installment = Installment(
        enrollment_id=enrollment.id,
        sequence=seq,
        amount=body.amount,
        due_date=body.due_date,
        status="pending",
    )
    db.add(installment)
    db.commit()
    db.refresh(installment)
    return installment


def delete_installment(db: Session, tenant_id: uuid.UUID, installment_id: uuid.UUID) -> None:
    """Delete a single installment — used to correct data-entry mistakes."""
    installment = db.get(Installment, installment_id)
    if not installment:
        raise NotFound("Installment")
    # Ensure it belongs to this tenant via its enrollment.
    enrollment = repo.get_enrollment(db, tenant_id, installment.enrollment_id)
    if not enrollment:
        raise NotFound("Installment")
    db.delete(installment)
    db.commit()


def delete_enrollment(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> None:
    """Hard-delete an enrollment and its installments. Meant for fixing a
    wrong entry (unlike 'withdraw', which keeps a record). Certificates block
    deletion so issued credentials are never orphaned."""
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    from app.modules.training.models import Certificate

    has_cert = db.scalar(
        select(Certificate).where(Certificate.enrollment_id == enrollment_id)
    )
    if has_cert:
        raise Conflict(
            "Cannot delete an enrollment that has a certificate. Withdraw it instead."
        )
    # Installments cascade via FK ondelete, but delete explicitly to be safe.
    for inst in list(enrollment.installments):
        db.delete(inst)
    db.delete(enrollment)
    db.commit()


def enrollment_finance(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> dict:
    """The full money picture for one enrollment: fees, deposit, what's paid,
    and what's still outstanding — the numbers the front desk needs daily."""
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    net_fee = round(float(enrollment.total_fee) - float(enrollment.discount), 2)
    deposit = float(enrollment.down_payment or 0)
    installments = sorted(enrollment.installments, key=lambda i: i.sequence)
    inst_total = round(sum(float(i.amount) for i in installments), 2)
    paid_installments = round(
        sum(float(i.amount) for i in installments if i.status == "paid"), 2
    )
    paid_total = round(deposit + paid_installments, 2)
    return {
        "enrollment_id": enrollment.id,
        "total_fee": float(enrollment.total_fee),
        "discount": float(enrollment.discount),
        "down_payment": deposit,
        "net_fee": net_fee,
        "installments_total": inst_total,
        "paid_total": paid_total,
        "outstanding": round(net_fee - paid_total, 2),
        "installments": installments,
    }
def record_assessment(
    db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID, body: AssessmentCreate
) -> Assessment:
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    assessment = Assessment(
        enrollment_id=enrollment_id,
        title=body.title,
        score=body.score,
        taken_at=body.taken_at or datetime.now(UTC),
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)
    return assessment


# --- Certificates ---
def issue_certificate(db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID) -> Certificate:
    enrollment = repo.get_enrollment(db, tenant_id, enrollment_id)
    if not enrollment:
        raise NotFound("Enrollment")
    if enrollment.status != "completed":
        raise BadRequest("Enrollment must be marked completed before issuing a certificate")
    if enrollment.certificate:
        raise Conflict("Certificate already issued for this enrollment")

    course = repo.get_course_for_cohort(db, enrollment.cohort_id)
    if course is not None and course.passing_score is not None:
        best_score = max((float(a.score) for a in enrollment.assessments), default=None)
        if best_score is None:
            raise BadRequest(
                f"Course requires a minimum score of {course.passing_score}; "
                "no assessment has been recorded for this enrollment"
            )
        if best_score < float(course.passing_score):
            raise BadRequest(
                f"Best recorded score ({best_score}) is below the course's passing "
                f"score ({course.passing_score})"
            )

    year = datetime.now(UTC).year
    certificate = Certificate(
        enrollment_id=enrollment.id,
        serial=repo.next_certificate_serial(db, tenant_id, year),
        verification_code=secrets.token_hex(8),
        issued_at=datetime.now(UTC),
    )
    db.add(certificate)
    db.commit()
    db.refresh(certificate)
    return certificate


def list_instructors(db: Session, tenant_id: uuid.UUID):
    return repo.list_instructors(db, tenant_id)


def training_summary(db: Session, tenant_id: uuid.UUID) -> dict:
    """KPI summary: courses, cohorts, students, revenue and collection."""
    from sqlalchemy import func, select

    from app.modules.training.models import (
        Cohort,
        Course,
        Enrollment,
        Installment,
        Student,
    )

    def _count(model, *conds):
        return int(
            db.scalar(
                select(func.count()).select_from(model).where(model.tenant_id == tenant_id, *conds)
            )
            or 0
        )

    total_courses = _count(Course)
    active_cohorts = _count(Cohort, Cohort.status.in_(("planned", "running")))
    total_students = _count(Student)
    active_enr = _count(Enrollment, Enrollment.status == "active")
    completed = _count(Enrollment, Enrollment.status == "completed")
    total_enr = _count(Enrollment)
    total_fees = float(
        db.scalar(
            select(func.coalesce(func.sum(Enrollment.total_fee - Enrollment.discount), 0)).where(
                Enrollment.tenant_id == tenant_id, Enrollment.status != "withdrawn"
            )
        )
        or 0
    )
    collected = float(
        db.scalar(
            select(func.coalesce(func.sum(Installment.amount), 0))
            .select_from(Installment)
            .join(Enrollment, Installment.enrollment_id == Enrollment.id)
            .where(Enrollment.tenant_id == tenant_id, Installment.status == "paid")
        )
        or 0
    )
    return {
        "total_courses": total_courses,
        "active_cohorts": active_cohorts,
        "total_students": total_students,
        "active_enrollments": active_enr,
        "total_fees": round(total_fees, 2),
        "total_collected": round(collected, 2),
        "total_outstanding": round(total_fees - collected, 2),
        "completion_rate_pct": round(completed / total_enr * 100, 1) if total_enr else 0.0,
    }


def cohort_finance_report(db: Session, tenant_id: uuid.UUID) -> list[dict]:
    """Per-cohort financials: fees, collected, outstanding, fill and attendance."""
    from sqlalchemy import func, select

    from app.modules.training.models import Attendance, Installment

    rows = []
    cohorts, _ = repo.list_cohorts(db, tenant_id, None, 1000, 0)
    for c in cohorts:
        active = [e for e in c.enrollments if e.status != "withdrawn"]
        enr_ids = [e.id for e in active]
        fees = sum(float(e.total_fee) - float(e.discount) for e in active)
        collected = 0.0
        if enr_ids:
            collected = float(
                db.scalar(
                    select(func.coalesce(func.sum(Installment.amount), 0)).where(
                        Installment.enrollment_id.in_(enr_ids),
                        Installment.status == "paid",
                    )
                )
                or 0
            )
        session_ids = [s_.id for s_ in c.sessions]
        att_rate = 0.0
        if session_ids:
            total_marks = int(
                db.scalar(
                    select(func.count())
                    .select_from(Attendance)
                    .where(Attendance.session_id.in_(session_ids))
                )
                or 0
            )
            present = int(
                db.scalar(
                    select(func.count())
                    .select_from(Attendance)
                    .where(
                        Attendance.session_id.in_(session_ids),
                        Attendance.status == "present",
                    )
                )
                or 0
            )
            att_rate = round(present / total_marks * 100, 1) if total_marks else 0.0
        rows.append({
            "cohort_id": c.id,
            "cohort_code": c.code,
            "course_title": c.course.title if c.course else "",
            "status": c.status,
            "enrolled": len(active),
            "capacity": c.capacity,
            "total_fees": round(fees, 2),
            "collected": round(collected, 2),
            "outstanding": round(fees - collected, 2),
            "attendance_rate_pct": att_rate,
        })
    return rows


# --- CSV import / export ---
def export_students_csv(db: Session, tenant_id: uuid.UUID) -> dict:
    import csv
    import io
    from datetime import date as _date

    items, _ = repo.list_students(db, tenant_id, 100000, 0)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([
        "Full Name", "Email", "Phone", "Company", "Job Title",
        "National ID", "Source", "Notes",
    ])
    for st in items:
        w.writerow([
            st.full_name, st.email or "", st.phone or "", st.company or "",
            st.job_title or "", st.national_id or "", st.source or "",
            st.notes or "",
        ])
    return {
        "filename": f"students-{_date.today().isoformat()}.csv",
        "content": "\ufeff" + buf.getvalue(),
    }


def import_students_csv(db: Session, tenant_id: uuid.UUID, content: str) -> dict:
    from app.shared.csv_io import parse_csv_rows, pick

    rows = parse_csv_rows(content)
    created, errors = 0, []
    for idx, row in enumerate(rows, start=2):
        name = pick(row, "full name", "name", "الاسم", "اسم الطالب")
        if not name:
            errors.append({"row": idx, "reason": "missing full name"})
            continue
        db.add(Student(
            tenant_id=tenant_id,
            full_name=name,
            email=pick(row, "email", "البريد") or None,
            phone=pick(row, "phone", "الهاتف") or None,
            company=pick(row, "company", "الشركة") or None,
            job_title=pick(row, "job title", "المسمى الوظيفي") or None,
            national_id=pick(row, "national id", "الرقم القومي") or None,
            source=pick(row, "source", "المصدر") or None,
            notes=pick(row, "notes", "ملاحظات") or None,
        ))
        db.flush()
        created += 1
    db.commit()
    return {"created": created, "skipped": 0, "errors": errors}


def export_courses_csv(db: Session, tenant_id: uuid.UUID) -> dict:
    import csv
    import io
    from datetime import date as _date

    items, _ = repo.list_courses(db, tenant_id, 100000, 0)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([
        "Code", "Title", "Category", "Level", "Duration Hours", "Price",
        "Mode", "Description", "Prerequisites", "Passing Score", "Active",
    ])
    for c in items:
        w.writerow([
            c.code, c.title, c.category, c.level, c.duration_hours,
            float(c.price), c.mode, c.description or "", c.prerequisites or "",
            float(c.passing_score) if c.passing_score is not None else "",
            "yes" if c.is_active else "no",
        ])
    return {
        "filename": f"courses-{_date.today().isoformat()}.csv",
        "content": "\ufeff" + buf.getvalue(),
    }


def import_courses_csv(db: Session, tenant_id: uuid.UUID, content: str) -> dict:
    from app.shared.csv_io import parse_csv_rows, pick, to_float, to_int

    rows = parse_csv_rows(content)
    created, skipped, errors = 0, 0, []
    for idx, row in enumerate(rows, start=2):
        code = pick(row, "code", "الكود")
        title = pick(row, "title", "العنوان", "اسم الكورس")
        if not code or not title:
            errors.append({"row": idx, "reason": "missing code or title"})
            continue
        existing = db.scalar(
            select(Course).where(Course.tenant_id == tenant_id, Course.code == code)
        )
        if existing:
            skipped += 1
            errors.append({"row": idx, "reason": f"course code '{code}' already exists"})
            continue
        level = pick(row, "level", "المستوى") or "beginner"
        if level not in ("beginner", "intermediate", "advanced"):
            level = "beginner"
        mode = pick(row, "mode", "النمط") or "onsite"
        if mode not in ("onsite", "online", "hybrid"):
            mode = "onsite"
        passing = pick(row, "passing score", "درجة النجاح")
        db.add(Course(
            tenant_id=tenant_id,
            code=code,
            title=title,
            category=pick(row, "category", "الفئة") or "General",
            level=level,
            duration_hours=to_int(pick(row, "duration hours", "المدة")),
            price=to_float(pick(row, "price", "السعر")),
            mode=mode,
            description=pick(row, "description", "الوصف") or None,
            prerequisites=pick(row, "prerequisites", "المتطلبات") or None,
            passing_score=to_float(passing) if passing else None,
            is_active=pick(row, "active", "نشط").lower() not in ("no", "لا", "false", "0"),
        ))
        db.flush()
        created += 1
    db.commit()
    return {"created": created, "skipped": skipped, "errors": errors}


def verify_certificate(db: Session, verification_code: str) -> dict:
    """Public certificate verification: given the code printed on the
    certificate, return the trainee, course, cohort and issue date so any
    employer or client can confirm authenticity. No authentication needed
    and no sensitive data (phone/ID) is exposed."""
    from sqlalchemy import select

    cert = db.scalar(
        select(Certificate).where(Certificate.verification_code == verification_code)
    )
    if not cert:
        return {"valid": False}
    enrollment = cert.enrollment
    student = enrollment.student if enrollment else None
    cohort = enrollment.cohort if enrollment else None
    course = cohort.course if cohort else None
    return {
        "valid": True,
        "serial": cert.serial,
        "student_name": student.full_name if student else "",
        "course_title": course.title if course else "",
        "course_category": course.category if course else "",
        "cohort_code": cohort.code if cohort else "",
        "issued_at": str(cert.issued_at.date()) if cert.issued_at else "",
    }


# ==================== Training leads (B2C funnel) ====================
def create_lead(db: Session, tenant_id: uuid.UUID, body) -> object:
    from app.modules.training.models import TrainingLead

    lead = TrainingLead(tenant_id=tenant_id, status="new", contact_count=0, **body.model_dump())
    db.add(lead)
    db.commit()
    db.refresh(lead)
    return lead


def list_leads(
    db: Session, tenant_id: uuid.UUID, page: int, size: int,
    status: str | None = None, source: str | None = None,
    search: str | None = None, due: str | None = None,
):
    from datetime import date as _date

    from sqlalchemy import func, select

    from app.modules.training.models import TrainingLead

    conds = [TrainingLead.tenant_id == tenant_id]
    if status:
        conds.append(TrainingLead.status == status)
    if source:
        conds.append(TrainingLead.source == source)
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(TrainingLead.name).like(like)
            | func.lower(func.coalesce(TrainingLead.phone, "")).like(like)
        )
    today = _date.today()
    if due == "today":
        conds.append(TrainingLead.next_follow_up == today)
        conds.append(TrainingLead.status.notin_(("registered", "lost")))
    elif due == "overdue":
        conds.append(TrainingLead.next_follow_up < today)
        conds.append(TrainingLead.status.notin_(("registered", "lost")))
    stmt = (
        select(TrainingLead).where(*conds)
        .order_by(TrainingLead.next_follow_up.asc().nulls_last(), TrainingLead.created_at.desc())
    )
    items = db.scalars(stmt.limit(size).offset((page - 1) * size)).all()
    total = db.scalar(select(func.count()).select_from(TrainingLead).where(*conds))
    return items, total or 0


def _get_lead(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID):
    from sqlalchemy import select

    from app.modules.training.models import TrainingLead

    lead = db.scalar(
        select(TrainingLead).where(
            TrainingLead.id == lead_id, TrainingLead.tenant_id == tenant_id
        )
    )
    if not lead:
        raise NotFound("Lead")
    return lead


def update_lead(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID, body) -> object:
    lead = _get_lead(db, tenant_id, lead_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(lead, field, value)
    db.commit()
    db.refresh(lead)
    return lead


def log_lead_contact(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID, body) -> object:
    from app.modules.training.models import TrainingLeadLog

    lead = _get_lead(db, tenant_id, lead_id)
    db.add(TrainingLeadLog(tenant_id=tenant_id, lead_id=lead.id, note=body.note))
    lead.contact_count = (lead.contact_count or 0) + 1
    if body.next_follow_up is not None:
        lead.next_follow_up = body.next_follow_up
    if body.status:
        lead.status = body.status
    elif lead.status == "new":
        lead.status = "contacted"
    db.commit()
    db.refresh(lead)
    return lead


def lead_logs(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID):
    return _get_lead(db, tenant_id, lead_id).logs


def lose_lead(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID, body) -> object:
    from app.modules.training.models import TrainingLeadLog

    lead = _get_lead(db, tenant_id, lead_id)
    lead.status = "lost"
    lead.lost_reason = body.lost_reason
    if body.note:
        db.add(TrainingLeadLog(tenant_id=tenant_id, lead_id=lead.id, note=body.note))
    db.commit()
    db.refresh(lead)
    return lead


def convert_lead(db: Session, tenant_id: uuid.UUID, lead_id: uuid.UUID, body) -> dict:
    """Turn a lead into a real student (one click at the front desk). If a
    cohort is given, an enrollment with installments is created too."""
    lead = _get_lead(db, tenant_id, lead_id)
    if lead.status == "registered":
        raise Conflict("Lead already converted")
    student = Student(
        tenant_id=tenant_id,
        full_name=lead.name,
        phone=lead.phone,
        source=lead.source,
        notes=lead.notes,
    )
    db.add(student)
    db.flush()
    enrollment_id = None
    if body.cohort_id:
        from app.modules.training.schemas import EnrollmentCreate

        enrollment = enroll_student(
            db, tenant_id,
            EnrollmentCreate(
                student_id=student.id, cohort_id=body.cohort_id,
                total_fee=body.total_fee, discount=body.discount,
                installments_count=body.installments_count,
            ),
        )
        enrollment_id = enrollment.id
    lead.status = "registered"
    lead.student_id = student.id
    db.commit()
    return {
        "student_id": str(student.id),
        "enrollment_id": str(enrollment_id) if enrollment_id else None,
    }


def leads_summary(db: Session, tenant_id: uuid.UUID) -> dict:
    from datetime import date as _date

    from sqlalchemy import select

    from app.modules.training.models import TrainingLead

    leads = db.scalars(
        select(TrainingLead).where(TrainingLead.tenant_id == tenant_id)
    ).all()
    today = _date.today()
    by_status: dict[str, int] = {}
    by_source: dict[str, dict] = {}
    lost_reasons: dict[str, int] = {}
    due_today = overdue = 0
    open_statuses = ("new", "contacted", "follow_up", "interested")
    for lead in leads:
        by_status[lead.status] = by_status.get(lead.status, 0) + 1
        src = by_source.setdefault(lead.source, {"total": 0, "registered": 0})
        src["total"] += 1
        if lead.status == "registered":
            src["registered"] += 1
        if lead.status == "lost" and lead.lost_reason:
            lost_reasons[lead.lost_reason] = lost_reasons.get(lead.lost_reason, 0) + 1
        if lead.status in open_statuses and lead.next_follow_up:
            if lead.next_follow_up == today:
                due_today += 1
            elif lead.next_follow_up < today:
                overdue += 1
    for src in by_source.values():
        src["rate_pct"] = round(src["registered"] / src["total"] * 100, 1) if src["total"] else 0.0
    registered = by_status.get("registered", 0)
    return {
        "total": len(leads),
        "by_status": by_status,
        "due_today": due_today,
        "overdue": overdue,
        "conversion_by_source": by_source,
        "lost_reasons": lost_reasons,
        "conversion_rate_pct": round(registered / len(leads) * 100, 1) if leads else 0.0,
    }


# ==================== Cohort profitability ====================
def add_cohort_cost(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID, body) -> object:
    from app.modules.training.models import CohortCost

    cohort = repo.get_cohort(db, tenant_id, cohort_id)
    if not cohort:
        raise NotFound("Cohort")
    cost = CohortCost(tenant_id=tenant_id, cohort_id=cohort_id, **body.model_dump())
    db.add(cost)
    db.commit()
    db.refresh(cost)
    return cost


def list_cohort_costs(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID):
    from sqlalchemy import select

    from app.modules.training.models import CohortCost

    return db.scalars(
        select(CohortCost).where(
            CohortCost.tenant_id == tenant_id, CohortCost.cohort_id == cohort_id
        ).order_by(CohortCost.created_at.desc())
    ).all()


def delete_cohort_cost(db: Session, tenant_id: uuid.UUID, cost_id: uuid.UUID) -> None:
    from sqlalchemy import select

    from app.modules.training.models import CohortCost

    cost = db.scalar(
        select(CohortCost).where(CohortCost.id == cost_id, CohortCost.tenant_id == tenant_id)
    )
    if not cost:
        raise NotFound("Cost")
    db.delete(cost)
    db.commit()


def cohort_pnl(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID) -> dict:
    """Cohort profit & loss. Revenue = net fees of non-withdrawn enrollments.
    Instructor share is automatic: revenue x instructor.revenue_share_pct.
    Manual costs (hall/materials/marketing/other) come from cohort_costs."""
    from sqlalchemy import func, select

    from app.modules.training.models import CohortCost, Installment

    cohort = repo.get_cohort(db, tenant_id, cohort_id)
    if not cohort:
        raise NotFound("Cohort")
    active = [e for e in cohort.enrollments if e.status != "withdrawn"]
    revenue = sum(float(e.total_fee) - float(e.discount) for e in active)
    enr_ids = [e.id for e in active]
    collected = 0.0
    if enr_ids:
        collected = float(db.scalar(
            select(func.coalesce(func.sum(Installment.amount), 0)).where(
                Installment.enrollment_id.in_(enr_ids), Installment.status == "paid"
            )
        ) or 0)
    share_pct = float(cohort.instructor.revenue_share_pct) if cohort.instructor else 0.0
    instructor_share = round(revenue * share_pct / 100, 2)
    manual = float(db.scalar(
        select(func.coalesce(func.sum(CohortCost.amount), 0)).where(
            CohortCost.tenant_id == tenant_id, CohortCost.cohort_id == cohort_id
        )
    ) or 0)
    total_costs = round(instructor_share + manual, 2)
    profit = round(revenue - total_costs, 2)
    return {
        "cohort_id": cohort.id,
        "cohort_code": cohort.code,
        "revenue": round(revenue, 2),
        "collected": round(collected, 2),
        "instructor_name": cohort.instructor.name if cohort.instructor else None,
        "instructor_share_pct": share_pct,
        "instructor_share": instructor_share,
        "manual_costs": round(manual, 2),
        "total_costs": total_costs,
        "profit": profit,
        "margin_pct": round(profit / revenue * 100, 1) if revenue else 0.0,
    }


def profitability_report(db: Session, tenant_id: uuid.UUID) -> list[dict]:
    """All cohorts ranked by profit — tells the owner which courses make
    money and which quietly lose it."""
    cohorts, _ = repo.list_cohorts(db, tenant_id, None, 1000, 0)
    rows = [cohort_pnl(db, tenant_id, c.id) for c in cohorts]
    rows.sort(key=lambda r: r["profit"], reverse=True)
    return rows
