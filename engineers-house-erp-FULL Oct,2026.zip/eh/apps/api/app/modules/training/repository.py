"""Tenant-scoped data access for Training / LMS entities."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.training.models import Cohort, Course, Enrollment, Instructor, Student
from app.modules.training.models import Session as TrainingSession


def get_course(db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID) -> Course | None:
    return db.scalar(select(Course).where(Course.id == course_id, Course.tenant_id == tenant_id))


def course_has_cohorts(db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(Cohort)
            .where(Cohort.tenant_id == tenant_id, Cohort.course_id == course_id)
        )
        or 0
    ) > 0


def student_has_enrollments(db: Session, tenant_id: uuid.UUID, student_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(Enrollment)
            .where(Enrollment.tenant_id == tenant_id, Enrollment.student_id == student_id)
        )
        or 0
    ) > 0


def get_cohort(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID) -> Cohort | None:
    return db.scalar(select(Cohort).where(Cohort.id == cohort_id, Cohort.tenant_id == tenant_id))


def get_course_for_cohort(db: Session, cohort_id: uuid.UUID) -> Course | None:
    """Fetch the Course that a cohort belongs to, regardless of tenant scope
    on the caller's side (the cohort itself was already tenant-checked)."""
    cohort = db.get(Cohort, cohort_id)
    if cohort is None:
        return None
    return db.get(Course, cohort.course_id)


def get_session(
    db: Session, tenant_id: uuid.UUID, session_id: uuid.UUID
) -> TrainingSession | None:
    return db.scalar(
        select(TrainingSession).where(
            TrainingSession.id == session_id, TrainingSession.tenant_id == tenant_id
        )
    )


def get_student(db: Session, tenant_id: uuid.UUID, student_id: uuid.UUID) -> Student | None:
    return db.scalar(
        select(Student).where(Student.id == student_id, Student.tenant_id == tenant_id)
    )


def get_enrollment(
    db: Session, tenant_id: uuid.UUID, enrollment_id: uuid.UUID
) -> Enrollment | None:
    return db.scalar(
        select(Enrollment).where(Enrollment.id == enrollment_id, Enrollment.tenant_id == tenant_id)
    )


def count_active_enrollments(db: Session, cohort_id: uuid.UUID) -> int:
    return (
        db.scalar(
            select(func.count())
            .select_from(Enrollment)
            .where(Enrollment.cohort_id == cohort_id, Enrollment.status == "active")
        )
        or 0
    )


def next_waitlist_position(db: Session, cohort_id: uuid.UUID) -> int:
    """Next position number for the back of the waitlist (1-indexed)."""
    max_pos = db.scalar(
        select(func.max(Enrollment.waitlist_position)).where(
            Enrollment.cohort_id == cohort_id, Enrollment.status == "waitlisted"
        )
    )
    return (max_pos or 0) + 1


def first_waitlisted(db: Session, cohort_id: uuid.UUID) -> Enrollment | None:
    """The enrollment at the front of the waitlist (lowest position), if any."""
    return db.scalar(
        select(Enrollment)
        .where(Enrollment.cohort_id == cohort_id, Enrollment.status == "waitlisted")
        .order_by(Enrollment.waitlist_position.asc())
        .limit(1)
    )


def list_courses(
    db: Session, tenant_id: uuid.UUID, limit: int, offset: int,
    search: str | None = None, category: str | None = None,
):
    conds = [Course.tenant_id == tenant_id]
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(Course.title).like(like) | func.lower(Course.code).like(like)
        )
    if category:
        conds.append(Course.category == category)
    stmt = select(Course).where(*conds).order_by(Course.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Course).where(*conds))
    return items, total or 0


def list_instructors(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(Instructor).where(Instructor.tenant_id == tenant_id).order_by(Instructor.name.asc())
    ).all()


def list_cohorts(
    db: Session, tenant_id: uuid.UUID, course_id: uuid.UUID | None, limit: int, offset: int
):
    conds = [Cohort.tenant_id == tenant_id]
    if course_id:
        conds.append(Cohort.course_id == course_id)
    stmt = select(Cohort).where(*conds).order_by(Cohort.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Cohort).where(*conds))
    return items, total or 0


def list_students(
    db: Session, tenant_id: uuid.UUID, limit: int, offset: int, search: str | None = None
):
    conds = [Student.tenant_id == tenant_id]
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(Student.full_name).like(like)
            | func.lower(func.coalesce(Student.email, "")).like(like)
            | func.lower(func.coalesce(Student.phone, "")).like(like)
            | func.lower(func.coalesce(Student.company, "")).like(like)
        )
    stmt = select(Student).where(*conds).order_by(Student.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Student).where(*conds))
    return items, total or 0


def list_sessions(db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID):
    from app.modules.training.models import Session as TrainingSession

    stmt = (
        select(TrainingSession)
        .where(TrainingSession.tenant_id == tenant_id, TrainingSession.cohort_id == cohort_id)
        .order_by(TrainingSession.scheduled_at.asc())
    )
    return db.scalars(stmt).all()


def list_enrollments(
    db: Session, tenant_id: uuid.UUID, cohort_id: uuid.UUID | None, limit: int, offset: int
):
    conds = [Enrollment.tenant_id == tenant_id]
    if cohort_id:
        conds.append(Enrollment.cohort_id == cohort_id)
    stmt = select(Enrollment).where(*conds).order_by(Enrollment.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Enrollment).where(*conds))
    return items, total or 0


def list_installments(db: Session, enrollment_id: uuid.UUID):
    from app.modules.training.models import Installment

    stmt = (
        select(Installment)
        .where(Installment.enrollment_id == enrollment_id)
        .order_by(Installment.sequence.asc())
    )
    return db.scalars(stmt).all()


def next_certificate_serial(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    from app.modules.training.models import Certificate

    count = db.scalar(select(func.count()).select_from(Certificate))
    return f"EH-CERT-{year}-{(count or 0) + 1:05d}"


def installments_due_between(db: Session, start, end):
    """Pending installments with a due date in [start, end] (inclusive).
    Used to find upcoming installments that need a reminder."""
    from app.modules.training.models import Installment

    return db.scalars(
        select(Installment).where(
            Installment.status == "pending",
            Installment.due_date >= start,
            Installment.due_date <= end,
        )
    ).all()


def overdue_pending_installments(db: Session, today):
    """Pending installments whose due date has passed."""
    from app.modules.training.models import Installment

    return db.scalars(
        select(Installment).where(
            Installment.status == "pending", Installment.due_date < today
        )
    ).all()
