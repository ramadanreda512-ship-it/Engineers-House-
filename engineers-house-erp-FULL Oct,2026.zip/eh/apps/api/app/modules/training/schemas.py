"""Pydantic schemas for the Training / LMS module."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Course ---
class CourseCreate(BaseModel):
    code: str = Field(min_length=2, max_length=40)
    title: str = Field(min_length=2, max_length=255)
    category: str = Field(min_length=2, max_length=60)
    duration_hours: int = Field(ge=0, default=0)
    price: float = Field(ge=0, default=0)
    mode: str = Field(default="onsite")  # onsite/online/hybrid
    level: str = Field(default="beginner")  # beginner/intermediate/advanced
    description: str | None = None
    prerequisites: str | None = None
    passing_score: float | None = Field(ge=0, le=100, default=None)


class CourseUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=255)
    category: str | None = Field(default=None, min_length=2, max_length=60)
    duration_hours: int | None = Field(default=None, ge=0)
    price: float | None = Field(default=None, ge=0)
    mode: str | None = None
    level: str | None = None
    description: str | None = None
    prerequisites: str | None = None
    passing_score: float | None = Field(default=None, ge=0, le=100)
    is_active: bool | None = None


class CourseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    title: str
    category: str
    duration_hours: int
    price: float
    mode: str
    level: str = "beginner"
    description: str | None = None
    prerequisites: str | None = None
    is_active: bool
    passing_score: float | None = None


# --- Instructor ---
class InstructorCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    specialization: str | None = None
    revenue_share_pct: float = Field(ge=0, le=100, default=0)


class InstructorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    specialization: str | None = None
    revenue_share_pct: float


# --- Cohort ---
class CohortCreate(BaseModel):
    course_id: uuid.UUID
    instructor_id: uuid.UUID | None = None
    code: str = Field(min_length=2, max_length=40)
    start_date: date | None = None
    end_date: date | None = None
    capacity: int = Field(gt=0, default=20)
    location: str | None = None


class CohortOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    course_id: uuid.UUID
    instructor_id: uuid.UUID | None = None
    code: str
    start_date: date | None = None
    end_date: date | None = None
    capacity: int
    location: str | None = None
    status: str


# --- Session ---
class SessionCreate(BaseModel):
    title: str = Field(min_length=2, max_length=255)
    scheduled_at: datetime
    duration_min: int = Field(gt=0, default=120)
    mode: str = Field(default="onsite")


class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    cohort_id: uuid.UUID
    title: str
    scheduled_at: datetime
    duration_min: int
    mode: str


# --- Student ---
class StudentCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=255)
    email: str | None = None
    phone: str | None = None
    company: str | None = None
    job_title: str | None = None
    national_id: str | None = None
    source: str | None = None
    notes: str | None = None
    account_id: uuid.UUID | None = None


class StudentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    full_name: str
    email: str | None = None
    phone: str | None = None
    company: str | None = None
    job_title: str | None = None
    national_id: str | None = None
    source: str | None = None
    notes: str | None = None
    account_id: uuid.UUID | None = None


class StudentUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=255)
    email: str | None = None
    phone: str | None = None
    company: str | None = None
    job_title: str | None = None
    national_id: str | None = None
    source: str | None = None
    notes: str | None = None
    account_id: uuid.UUID | None = None


# --- Enrollment ---
class EnrollmentCreate(BaseModel):
    student_id: uuid.UUID
    cohort_id: uuid.UUID
    total_fee: float = Field(ge=0)
    discount: float = Field(ge=0, default=0)
    # Booking deposit paid immediately; deducted before splitting the rest.
    down_payment: float = Field(ge=0, default=0)
    installment_count: int = Field(ge=1, le=12, default=1)
    first_due_date: date | None = None


class EnrollmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    student_id: uuid.UUID
    cohort_id: uuid.UUID
    status: str
    waitlist_position: int | None = None
    total_fee: float
    discount: float
    down_payment: float = 0
    enrolled_at: datetime


# --- Attendance ---
class AttendanceMark(BaseModel):
    enrollment_id: uuid.UUID
    status: str = Field(pattern="^(present|absent|late)$")


class AttendanceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    session_id: uuid.UUID
    enrollment_id: uuid.UUID
    status: str
    marked_at: datetime


# --- Installment ---
class InstallmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    sequence: int
    amount: float
    due_date: date
    status: str
    paid_at: datetime | None = None


class InstallmentPay(BaseModel):
    paid_at: datetime | None = None


# --- Assessment ---
class AssessmentCreate(BaseModel):
    title: str = Field(min_length=2, max_length=255)
    score: float = Field(ge=0, le=100)
    taken_at: datetime | None = None


class AssessmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    enrollment_id: uuid.UUID
    title: str
    score: float
    taken_at: datetime


# --- Certificate ---
class CertificateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    enrollment_id: uuid.UUID
    serial: str
    verification_code: str
    issued_at: datetime


# --- Training analytics ---
class TrainingSummary(BaseModel):
    total_courses: int
    active_cohorts: int
    total_students: int
    active_enrollments: int
    total_fees: float
    total_collected: float
    total_outstanding: float
    completion_rate_pct: float


class CohortFinanceRow(BaseModel):
    cohort_id: uuid.UUID
    cohort_code: str
    course_title: str
    status: str
    enrolled: int
    capacity: int
    total_fees: float
    collected: float
    outstanding: float
    attendance_rate_pct: float


class InstructorOutFull(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    specialization: str | None = None
    revenue_share_pct: float = 0


# --- Training leads (B2C inquiry funnel) ---
class LeadCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    phone: str | None = None
    whatsapp: str | None = None
    source: str = Field(
        default="whatsapp",
        pattern="^(whatsapp|phone_call|facebook|instagram|walk_in|referral|website|other)$",
    )
    interested_course_id: uuid.UUID | None = None
    next_follow_up: date | None = None
    notes: str | None = None


class LeadUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    phone: str | None = None
    whatsapp: str | None = None
    source: str | None = Field(
        default=None,
        pattern="^(whatsapp|phone_call|facebook|instagram|walk_in|referral|website|other)$",
    )
    interested_course_id: uuid.UUID | None = None
    status: str | None = Field(
        default=None, pattern="^(new|contacted|follow_up|interested)$"
    )
    next_follow_up: date | None = None
    notes: str | None = None


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    phone: str | None = None
    whatsapp: str | None = None
    source: str
    interested_course_id: uuid.UUID | None = None
    status: str
    next_follow_up: date | None = None
    lost_reason: str | None = None
    notes: str | None = None
    contact_count: int = 0
    student_id: uuid.UUID | None = None


class LeadLogContact(BaseModel):
    note: str = Field(min_length=1, max_length=500)
    next_follow_up: date | None = None
    status: str | None = Field(
        default=None, pattern="^(contacted|follow_up|interested)$"
    )


class LeadLose(BaseModel):
    lost_reason: str = Field(
        pattern="^(price|timing|location|competitor|no_response|other)$"
    )
    note: str | None = None


class LeadConvert(BaseModel):
    cohort_id: uuid.UUID | None = None
    total_fee: float = Field(ge=0, default=0)
    discount: float = Field(ge=0, default=0)
    installments_count: int = Field(ge=1, default=1)


class LeadLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    note: str
    created_at: datetime


class LeadsSummary(BaseModel):
    total: int
    by_status: dict[str, int]
    due_today: int
    overdue: int
    conversion_by_source: dict[str, dict]
    lost_reasons: dict[str, int]
    conversion_rate_pct: float


# --- Cohort profitability ---
class CohortCostCreate(BaseModel):
    cost_type: str = Field(default="other", pattern="^(hall|materials|marketing|other)$")
    description: str | None = None
    amount: float = Field(gt=0)
    cost_date: date | None = None


class CohortCostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    cohort_id: uuid.UUID
    cost_type: str
    description: str | None = None
    amount: float
    cost_date: date | None = None


class CohortPnl(BaseModel):
    cohort_id: uuid.UUID
    cohort_code: str
    revenue: float
    collected: float
    instructor_name: str | None = None
    instructor_share_pct: float
    instructor_share: float
    manual_costs: float
    total_costs: float
    profit: float
    margin_pct: float


# --- Installment management ---
class InstallmentCreate(BaseModel):
    amount: float = Field(gt=0)
    due_date: date
    sequence: int | None = None  # auto-assigned if omitted


class EnrollmentFinance(BaseModel):
    """Full money picture for one enrollment (what the front desk needs)."""
    enrollment_id: uuid.UUID
    total_fee: float
    discount: float
    down_payment: float
    net_fee: float           # total - discount
    installments_total: float
    paid_total: float        # down payment + paid installments
    outstanding: float       # net_fee - paid_total
    installments: list[InstallmentOut] = []
