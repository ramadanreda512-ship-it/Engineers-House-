"""Partner (shareholder) management with equity tracking.

Models the partners/shareholders of the company: their capital contributions,
ownership percentages, withdrawals, loans, and profit distributions. Every
financial transaction optionally posts a balanced journal entry into the
accounting general ledger, so the books stay consistent.

Mirrors (and improves on) the legacy app's Partner / PartnerTransaction design:
- adds tenant scoping
- adds a partner "current account" balance derived from transactions
- links each transaction to the journal entry it posted
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin

# Transaction types and whether they CREDIT the partner's current account
# (increase what the company owes the partner) or DEBIT it (reduce it).
# credit-normal for the partner: contributions and loan repayments by company.
PARTNER_TX_TYPES = (
    "capital_contribution",   # شريك يضخ رأس مال -> credit partner
    "additional_investment",  # استثمار إضافي -> credit partner
    "withdrawal",             # سحب شخصي -> debit partner
    "loan_disbursed",         # الشركة تقرض الشريك -> debit partner
    "loan_repaid",            # الشريك يسدد قرضه -> credit partner
    "profit_distribution",    # توزيع أرباح -> debit partner
    "expense_charged",        # مصروف محمّل على الشريك -> debit partner
)
# Types that increase the partner's credit balance (company owes partner more).
PARTNER_CREDIT_TYPES = ("capital_contribution", "additional_investment", "loan_repaid")


class Partner(Base, TimestampMixin):
    __tablename__ = "partners"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_partner_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(20))  # PRT-001
    name: Mapped[str] = mapped_column(String(255))
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    # Total capital the partner has put in (running, from contributions).
    capital_contribution: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    # Ownership percentage (0-100), used to split profit distributions.
    equity_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    transactions: Mapped[list[PartnerTransaction]] = relationship(
        back_populates="partner", cascade="all, delete-orphan", lazy="selectin"
    )


class PartnerTransaction(Base, TimestampMixin):
    __tablename__ = "partner_transactions"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    partner_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("partners.id", ondelete="CASCADE")
    )
    tx_date: Mapped[date] = mapped_column(Date)
    tx_type: Mapped[str] = mapped_column(String(30))
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # The cash/bank account the money moved through (optional).
    cash_account_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    # The journal entry this transaction posted (if any).
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    status: Mapped[str] = mapped_column(String(12), default="posted")  # posted/cancelled

    partner: Mapped[Partner] = relationship(back_populates="transactions")
