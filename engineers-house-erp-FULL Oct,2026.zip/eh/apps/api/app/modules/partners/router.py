"""Partner (shareholder) HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.partners import service
from app.modules.partners.schemas import (
    PartnerCreate,
    PartnerOut,
    PartnerStatement,
    PartnerSummary,
    PartnerTxCreate,
    PartnerTxOut,
    PartnerUpdate,
    PartnerWithBalance,
    ProfitDistributionPreview,
    ProfitDistributionRequest,
)

router = APIRouter(prefix="/partners", tags=["partners"])

VIEW = "partners.view"
MANAGE = "partners.manage"


@router.post("", response_model=PartnerOut, status_code=201)
def create_partner(
    body: PartnerCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_partner(db, user.tenant_id, body)


@router.get("", response_model=list[PartnerWithBalance])
def list_partners(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    out = []
    for p, bal, contrib, withdr in service.list_partners_with_balance(db, user.tenant_id):
        out.append(
            PartnerWithBalance(
                id=p.id, code=p.code, name=p.name, email=p.email, phone=p.phone,
                capital_contribution=float(p.capital_contribution),
                equity_percent=float(p.equity_percent), is_active=p.is_active, notes=p.notes,
                current_balance=bal, total_contributions=contrib, total_withdrawals=withdr,
            )
        )
    return out


@router.get("/summary", response_model=PartnerSummary)
def summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.summary(db, user.tenant_id)


@router.get("/{partner_id}", response_model=PartnerOut)
def get_partner(
    partner_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.get_partner(db, user.tenant_id, partner_id)


@router.patch("/{partner_id}", response_model=PartnerOut)
def update_partner(
    partner_id: uuid.UUID,
    body: PartnerUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_partner(db, user.tenant_id, partner_id, body)


@router.delete("/{partner_id}", status_code=204)
def delete_partner(
    partner_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_partner(db, user.tenant_id, partner_id)


# --- Transactions ---
@router.post("/{partner_id}/transactions", response_model=PartnerTxOut, status_code=201)
def add_transaction(
    partner_id: uuid.UUID,
    body: PartnerTxCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.add_transaction(db, user.tenant_id, partner_id, body)


@router.get("/{partner_id}/transactions", response_model=list[PartnerTxOut])
def list_transactions(
    partner_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_transactions(db, user.tenant_id, partner_id)


@router.post(
    "/{partner_id}/transactions/{tx_id}/cancel", response_model=PartnerTxOut
)
def cancel_transaction(
    partner_id: uuid.UUID,
    tx_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.cancel_transaction(db, user.tenant_id, partner_id, tx_id)


@router.get("/{partner_id}/statement", response_model=PartnerStatement)
def partner_statement(
    partner_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.partner_statement(db, user.tenant_id, partner_id)


# --- Profit distribution ---
@router.post("/profit-distribution/preview", response_model=ProfitDistributionPreview)
def preview_distribution(
    body: ProfitDistributionRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.preview_distribution(db, user.tenant_id, body.total_profit)


@router.post("/profit-distribution", response_model=ProfitDistributionPreview, status_code=201)
def distribute_profit(
    body: ProfitDistributionRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.distribute_profit(db, user.tenant_id, body)
