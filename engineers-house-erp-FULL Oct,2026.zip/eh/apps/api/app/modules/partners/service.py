"""Partner business logic, integrated with the accounting general ledger.

Each partner transaction can post a balanced journal entry. The partner's
"current account" is tracked as a liability/equity-style balance:
  - contributions / additional investment / loan repaid  -> CREDIT partner
  - withdrawal / loan disbursed / profit distribution / expense charged -> DEBIT

When a cash account is supplied, the matching ledger entry is:
  contribution (money in):   debit cash,            credit partner capital
  withdrawal   (money out):  debit partner current, credit cash
This keeps the books balanced automatically.

Profit distribution splits a total profit across active partners by their
equity percentage, posting one transaction per partner.
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.modules.accounting import repository as acc_repo
from app.modules.accounting.models import JournalEntry, JournalLine
from app.modules.partners import repository as repo
from app.modules.partners.models import (
    PARTNER_CREDIT_TYPES,
    Partner,
    PartnerTransaction,
)
from app.modules.partners.schemas import (
    PartnerCreate,
    PartnerTxCreate,
    PartnerUpdate,
    ProfitDistributionRequest,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


def _next_code(db: Session, tenant_id: uuid.UUID) -> str:
    return f"PRT-{repo.partner_count(db, tenant_id) + 1:03d}"


# --- Partner CRUD ---
def create_partner(db: Session, tenant_id: uuid.UUID, body: PartnerCreate) -> Partner:
    # Guard: total equity across partners must not exceed 100%.
    existing = sum(float(p.equity_percent) for p in repo.list_partners(db, tenant_id))
    if existing + body.equity_percent > 100.0001:
        raise BadRequest(
            f"Total equity would exceed 100% (currently {existing:.2f}%)"
        )
    partner = Partner(
        tenant_id=tenant_id,
        code=_next_code(db, tenant_id),
        capital_contribution=0,
        is_active=True,
        **body.model_dump(),
    )
    db.add(partner)
    db.commit()
    db.refresh(partner)
    return partner


def list_partners_with_balance(db: Session, tenant_id: uuid.UUID):
    out = []
    for p in repo.list_partners(db, tenant_id):
        bal, contrib, withdr = _partner_balance(db, tenant_id, p)
        out.append((p, bal, contrib, withdr))
    return out


def get_partner(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID) -> Partner:
    partner = repo.get_partner(db, tenant_id, partner_id)
    if not partner:
        raise NotFound("Partner")
    return partner


def update_partner(
    db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID, body: PartnerUpdate
) -> Partner:
    partner = get_partner(db, tenant_id, partner_id)
    data = body.model_dump(exclude_unset=True)
    if "equity_percent" in data:
        others = sum(
            float(p.equity_percent)
            for p in repo.list_partners(db, tenant_id)
            if p.id != partner_id
        )
        if others + data["equity_percent"] > 100.0001:
            raise BadRequest(f"Total equity would exceed 100% (others have {others:.2f}%)")
    for field, value in data.items():
        setattr(partner, field, value)
    db.commit()
    db.refresh(partner)
    return partner


def delete_partner(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID) -> None:
    partner = get_partner(db, tenant_id, partner_id)
    if repo.list_transactions(db, tenant_id, partner_id):
        raise Conflict(
            "Cannot delete a partner who has transactions. Deactivate the partner instead."
        )
    db.delete(partner)
    db.commit()


# --- Balance computation ---
def _partner_balance(db: Session, tenant_id: uuid.UUID, partner: Partner):
    """Return (current_balance, total_contributions, total_withdrawals).
    current_balance > 0 means the company owes the partner."""
    contrib = 0.0
    withdr = 0.0
    balance = 0.0
    for tx in repo.list_transactions(db, tenant_id, partner.id):
        amt = float(tx.amount)
        if tx.tx_type in PARTNER_CREDIT_TYPES:
            balance += amt
            if tx.tx_type in ("capital_contribution", "additional_investment"):
                contrib += amt
        else:
            balance -= amt
            if tx.tx_type == "withdrawal":
                withdr += amt
    return _round(balance), _round(contrib), _round(withdr)


# --- Transactions (post to ledger) ---
def _acc_by_code(db: Session, tenant_id: uuid.UUID, code: str):
    for a in acc_repo.list_accounts(db, tenant_id):
        if a.code == code:
            return a
    return None


def _post_partner_journal(
    db: Session,
    tenant_id: uuid.UUID,
    partner: Partner,
    tx_type: str,
    amount: float,
    tx_date: date,
    cash_account_id: uuid.UUID | None,
    description: str | None,
) -> uuid.UUID | None:
    """Post a balanced journal entry for the transaction, if a cash account is
    available. The partner side uses the equity 'Capital' account (3101) or the
    partners' current-account liability if present. Returns the entry id."""
    cash = None
    if cash_account_id:
        cash = acc_repo.get_account(db, tenant_id, cash_account_id)
    if not cash:
        cash = _acc_by_code(db, tenant_id, "1101") or _acc_by_code(db, tenant_id, "1102")
    # Partner equity account: prefer a dedicated partners account, else Capital.
    partner_acc = (
        _acc_by_code(db, tenant_id, "3102")  # partners' current accounts (optional)
        or _acc_by_code(db, tenant_id, "3101")  # capital
    )
    if not cash or not partner_acc:
        return None  # ledger not set up; skip posting gracefully

    amount = _round(amount)
    credits_partner = tx_type in PARTNER_CREDIT_TYPES
    if credits_partner:
        # money in: debit cash, credit partner equity
        debit_acc, credit_acc = cash.id, partner_acc.id
    else:
        # money out: debit partner equity, credit cash
        debit_acc, credit_acc = partner_acc.id, cash.id

    year = tx_date.year
    entry = JournalEntry(
        tenant_id=tenant_id,
        number=acc_repo.next_entry_number(db, tenant_id, year),
        entry_date=tx_date,
        description=description or f"Partner {partner.name}: {tx_type}",
        status="posted",
        source="partner",
        total_debit=amount,
        total_credit=amount,
    )
    db.add(entry)
    db.flush()
    db.add(JournalLine(tenant_id=tenant_id, entry_id=entry.id, account_id=debit_acc,
                       debit=amount, credit=0, description=description))
    db.add(JournalLine(tenant_id=tenant_id, entry_id=entry.id, account_id=credit_acc,
                       debit=0, credit=amount, description=description))
    return entry.id


def add_transaction(
    db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID, body: PartnerTxCreate
) -> PartnerTransaction:
    partner = get_partner(db, tenant_id, partner_id)
    tx_date = body.tx_date or date.today()
    entry_id = _post_partner_journal(
        db, tenant_id, partner, body.tx_type, body.amount, tx_date,
        body.cash_account_id, body.description,
    )
    tx = PartnerTransaction(
        tenant_id=tenant_id,
        partner_id=partner_id,
        tx_date=tx_date,
        tx_type=body.tx_type,
        amount=_round(body.amount),
        description=body.description,
        cash_account_id=body.cash_account_id,
        journal_entry_id=entry_id,
        status="posted",
    )
    db.add(tx)
    # Keep the partner's running capital_contribution in sync.
    if body.tx_type in ("capital_contribution", "additional_investment"):
        partner.capital_contribution = _round(
            float(partner.capital_contribution) + float(body.amount)
        )
    db.commit()
    db.refresh(tx)
    return tx


def list_transactions(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID):
    get_partner(db, tenant_id, partner_id)
    return repo.list_transactions(db, tenant_id, partner_id)


def cancel_transaction(
    db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID, tx_id: uuid.UUID
) -> PartnerTransaction:
    partner = get_partner(db, tenant_id, partner_id)
    tx = next(
        (t for t in repo.list_transactions(db, tenant_id, partner_id) if t.id == tx_id), None
    )
    if not tx:
        raise NotFound("Transaction")
    tx.status = "cancelled"
    if tx.journal_entry_id:
        entry = acc_repo.get_entry(db, tenant_id, tx.journal_entry_id)
        if entry:
            entry.status = "cancelled"
    if tx.tx_type in ("capital_contribution", "additional_investment"):
        partner.capital_contribution = _round(
            float(partner.capital_contribution) - float(tx.amount)
        )
    db.commit()
    db.refresh(tx)
    return tx


# --- Profit distribution ---
def preview_distribution(
    db: Session, tenant_id: uuid.UUID, total_profit: float
) -> dict:
    partners = repo.all_active_partners(db, tenant_id)
    total_equity = sum(float(p.equity_percent) for p in partners)
    lines = []
    distributed = 0.0
    for p in partners:
        if p.equity_percent <= 0:
            continue
        share = _round(total_profit * float(p.equity_percent) / 100.0)
        distributed += share
        lines.append(
            {
                "partner_id": p.id,
                "partner_name": p.name,
                "equity_percent": float(p.equity_percent),
                "amount": share,
            }
        )
    return {
        "total_profit": _round(total_profit),
        "distributed": _round(distributed),
        "lines": lines,
        "_total_equity": total_equity,
    }


def distribute_profit(
    db: Session, tenant_id: uuid.UUID, body: ProfitDistributionRequest
) -> dict:
    preview = preview_distribution(db, tenant_id, body.total_profit)
    if not preview["lines"]:
        raise BadRequest("No active partners with an equity percentage to distribute to")
    tx_date = body.tx_date or date.today()
    for line_ in preview["lines"]:
        partner = get_partner(db, tenant_id, line_["partner_id"])
        entry_id = _post_partner_journal(
            db, tenant_id, partner, "profit_distribution", line_["amount"], tx_date,
            body.cash_account_id, f"Profit distribution {tx_date.year}",
        )
        db.add(
            PartnerTransaction(
                tenant_id=tenant_id,
                partner_id=partner.id,
                tx_date=tx_date,
                tx_type="profit_distribution",
                amount=line_["amount"],
                description=f"Profit distribution {tx_date.year}",
                cash_account_id=body.cash_account_id,
                journal_entry_id=entry_id,
                status="posted",
            )
        )
    db.commit()
    return preview


# --- Statement & summary ---
def partner_statement(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID) -> dict:
    partner = get_partner(db, tenant_id, partner_id)
    lines = []
    bal = 0.0
    for tx in repo.list_transactions(db, tenant_id, partner_id):
        amt = float(tx.amount)
        credit = amt if tx.tx_type in PARTNER_CREDIT_TYPES else 0.0
        debit = 0.0 if tx.tx_type in PARTNER_CREDIT_TYPES else amt
        bal += credit - debit
        lines.append(
            {
                "tx_date": tx.tx_date,
                "tx_type": tx.tx_type,
                "description": tx.description,
                "debit": _round(debit),
                "credit": _round(credit),
                "running_balance": _round(bal),
            }
        )
    return {
        "partner_id": partner.id,
        "partner_code": partner.code,
        "partner_name": partner.name,
        "lines": lines,
        "closing_balance": _round(bal),
    }


def summary(db: Session, tenant_id: uuid.UUID) -> dict:
    partners = repo.list_partners(db, tenant_id)
    total_capital = 0.0
    total_equity = 0.0
    total_owed = 0.0
    for p in partners:
        bal, _, _ = _partner_balance(db, tenant_id, p)
        total_capital += float(p.capital_contribution)
        total_equity += float(p.equity_percent)
        total_owed += bal
    return {
        "total_partners": len(partners),
        "total_capital": _round(total_capital),
        "total_equity_percent": _round(total_equity),
        "total_owed_to_partners": _round(total_owed),
    }
