"""Tenant-scoped data access for partners."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.partners.models import Partner, PartnerTransaction


def get_partner(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID) -> Partner | None:
    return db.scalar(
        select(Partner).where(Partner.id == partner_id, Partner.tenant_id == tenant_id)
    )


def list_partners(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(Partner).where(Partner.tenant_id == tenant_id).order_by(Partner.code.asc())
    ).all()


def code_exists(db: Session, tenant_id: uuid.UUID, code: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(Partner)
            .where(Partner.tenant_id == tenant_id, Partner.code == code)
        )
        or 0
    ) > 0


def partner_count(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(select(func.count()).select_from(Partner).where(Partner.tenant_id == tenant_id))
        or 0
    )


def list_transactions(db: Session, tenant_id: uuid.UUID, partner_id: uuid.UUID):
    return db.scalars(
        select(PartnerTransaction)
        .where(
            PartnerTransaction.tenant_id == tenant_id,
            PartnerTransaction.partner_id == partner_id,
            PartnerTransaction.status == "posted",
        )
        .order_by(PartnerTransaction.tx_date.asc(), PartnerTransaction.created_at.asc())
    ).all()


def all_active_partners(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(Partner).where(Partner.tenant_id == tenant_id, Partner.is_active.is_(True))
    ).all()
