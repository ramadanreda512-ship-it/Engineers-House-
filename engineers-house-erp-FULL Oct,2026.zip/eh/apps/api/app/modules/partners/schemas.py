"""Partner schemas. Balances are server-computed from transactions."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


class PartnerCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    email: str | None = None
    phone: str | None = None
    equity_percent: float = Field(ge=0, le=100, default=0)
    notes: str | None = None


class PartnerUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    email: str | None = None
    phone: str | None = None
    equity_percent: float | None = Field(default=None, ge=0, le=100)
    is_active: bool | None = None
    notes: str | None = None


class PartnerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    email: str | None
    phone: str | None
    capital_contribution: float
    equity_percent: float
    is_active: bool
    notes: str | None


class PartnerWithBalance(PartnerOut):
    # Current account balance: positive = company owes the partner.
    current_balance: float
    total_contributions: float
    total_withdrawals: float


class PartnerTxCreate(BaseModel):
    tx_type: str = Field(
        pattern="^(capital_contribution|additional_investment|withdrawal|"
        "loan_disbursed|loan_repaid|profit_distribution|expense_charged)$"
    )
    amount: float = Field(gt=0)
    tx_date: date | None = None
    description: str | None = None
    # Optional cash/bank account to post the journal entry against.
    cash_account_id: uuid.UUID | None = None


class PartnerTxOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    partner_id: uuid.UUID
    tx_date: date
    tx_type: str
    amount: float
    description: str | None
    cash_account_id: uuid.UUID | None
    journal_entry_id: uuid.UUID | None
    status: str


class ProfitDistributionLine(BaseModel):
    partner_id: uuid.UUID
    partner_name: str
    equity_percent: float
    amount: float


class ProfitDistributionPreview(BaseModel):
    total_profit: float
    distributed: float
    lines: list[ProfitDistributionLine]


class ProfitDistributionRequest(BaseModel):
    total_profit: float = Field(gt=0)
    tx_date: date | None = None
    cash_account_id: uuid.UUID | None = None


class PartnerStatementLine(BaseModel):
    tx_date: date
    tx_type: str
    description: str | None
    debit: float
    credit: float
    running_balance: float


class PartnerStatement(BaseModel):
    partner_id: uuid.UUID
    partner_code: str
    partner_name: str
    lines: list[PartnerStatementLine]
    closing_balance: float


class PartnerSummary(BaseModel):
    total_partners: int
    total_capital: float
    total_equity_percent: float
    total_owed_to_partners: float
