from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.settings import service
from app.modules.settings.schemas import (
    CategoryCounts,
    CategoryCreate,
    CategoryOut,
    CategoryUpdate,
)

router = APIRouter(prefix="/settings", tags=["settings"])

# Reading categories is needed by anyone creating a course/project/customer,
# so it uses the broad view permission; writing uses a management permission.
VIEW = "settings.category.view"
MANAGE = "settings.category.manage"


@router.get("/categories", response_model=list[CategoryOut])
def list_categories(
    kind: str = Query(..., pattern="^(course|project|customer)$"),
    active_only: bool = Query(False),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_categories(db, user.tenant_id, kind, active_only=active_only)


@router.get("/categories/counts", response_model=CategoryCounts)
def category_counts(
    kind: str = Query(..., pattern="^(course|project|customer)$"),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.category_counts(db, user.tenant_id, kind)


@router.post("/categories", response_model=CategoryOut, status_code=201)
def create_category(
    body: CategoryCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_category(db, user.tenant_id, body)


@router.patch("/categories/{category_id}", response_model=CategoryOut)
def update_category(
    category_id: uuid.UUID,
    body: CategoryUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_category(db, user.tenant_id, category_id, body)


@router.delete("/categories/{category_id}", status_code=204)
def delete_category(
    category_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_category(db, user.tenant_id, category_id)
