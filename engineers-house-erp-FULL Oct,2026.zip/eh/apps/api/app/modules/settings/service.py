from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.settings.models import Category
from app.modules.settings.schemas import CategoryCreate, CategoryUpdate
from app.shared.exceptions import Conflict, NotFound


def list_categories(db: Session, tenant_id: uuid.UUID, kind: str, active_only: bool = False):
    conds = [Category.tenant_id == tenant_id, Category.kind == kind]
    if active_only:
        conds.append(Category.is_active.is_(True))
    return db.scalars(
        select(Category).where(*conds).order_by(Category.sort_order, Category.name_ar)
    ).all()


def category_counts(db: Session, tenant_id: uuid.UUID, kind: str) -> dict:
    rows = list_categories(db, tenant_id, kind)
    return {
        "total": len(rows),
        "active": sum(1 for r in rows if r.is_active),
        "system": sum(1 for r in rows if r.is_system),
    }


def create_category(db: Session, tenant_id: uuid.UUID, body: CategoryCreate) -> Category:
    existing = db.scalar(
        select(Category).where(
            Category.tenant_id == tenant_id,
            Category.kind == body.kind,
            func.lower(Category.code) == body.code.lower(),
        )
    )
    if existing:
        raise Conflict(f"Category code '{body.code}' already exists for {body.kind}")
    cat = Category(tenant_id=tenant_id, is_active=True, is_system=False, **body.model_dump())
    db.add(cat)
    db.commit()
    db.refresh(cat)
    return cat


def _get(db: Session, tenant_id: uuid.UUID, category_id: uuid.UUID) -> Category:
    cat = db.scalar(
        select(Category).where(Category.id == category_id, Category.tenant_id == tenant_id)
    )
    if not cat:
        raise NotFound("Category")
    return cat


def update_category(
    db: Session, tenant_id: uuid.UUID, category_id: uuid.UUID, body: CategoryUpdate
) -> Category:
    cat = _get(db, tenant_id, category_id)
    data = body.model_dump(exclude_unset=True)
    # If renaming the code, guard uniqueness within the same kind.
    new_code = data.get("code")
    if new_code and new_code.lower() != cat.code.lower():
        clash = db.scalar(
            select(Category).where(
                Category.tenant_id == tenant_id,
                Category.kind == cat.kind,
                func.lower(Category.code) == new_code.lower(),
                Category.id != cat.id,
            )
        )
        if clash:
            raise Conflict(f"Category code '{new_code}' already exists for {cat.kind}")
    for field, value in data.items():
        setattr(cat, field, value)
    db.commit()
    db.refresh(cat)
    return cat


def delete_category(db: Session, tenant_id: uuid.UUID, category_id: uuid.UUID) -> None:
    cat = _get(db, tenant_id, category_id)
    if cat.is_system:
        raise Conflict(
            "System categories cannot be deleted. Deactivate it instead if unused."
        )
    db.delete(cat)
    db.commit()
