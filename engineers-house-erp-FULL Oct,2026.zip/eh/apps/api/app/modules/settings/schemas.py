from __future__ import annotations

import uuid

from pydantic import BaseModel, ConfigDict, Field


class CategoryCreate(BaseModel):
    kind: str = Field(pattern="^(course|project|customer)$")
    code: str = Field(min_length=1, max_length=40)
    name_ar: str = Field(min_length=1, max_length=255)
    name_en: str | None = None
    sort_order: int = 0


class CategoryUpdate(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=40)
    name_ar: str | None = Field(default=None, min_length=1, max_length=255)
    name_en: str | None = None
    is_active: bool | None = None
    sort_order: int | None = None


class CategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    kind: str
    code: str
    name_ar: str
    name_en: str | None = None
    is_active: bool
    is_system: bool
    sort_order: int


class CategoryCounts(BaseModel):
    total: int
    active: int
    system: int
