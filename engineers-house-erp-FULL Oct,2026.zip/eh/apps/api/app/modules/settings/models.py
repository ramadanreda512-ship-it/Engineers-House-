"""System settings: user-managed category lists (lookups).

A single generic Category table backs several dropdown lists in the system —
course categories, project categories, and customer classifications — each
distinguished by `kind`. Seeded rows (PLC, SCADA, ...) are marked
is_system=True so the UI can show a "system" badge; they can be deactivated
but the app protects a few from deletion if referenced. Keeping all lookups
in one table means one screen manages them all.
"""
from __future__ import annotations

import uuid

from sqlalchemy import Boolean, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.shared.base_model import GUID, Base, TimestampMixin

# The lookup lists this module manages. Extendable later (asset categories,
# payment methods, statuses, ...) without schema changes — just new `kind`s.
CATEGORY_KINDS = ("course", "project", "customer")


class Category(Base, TimestampMixin):
    __tablename__ = "categories"
    __table_args__ = (
        UniqueConstraint("tenant_id", "kind", "code", name="uq_category_kind_code"),
    )

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    kind: Mapped[str] = mapped_column(String(20), index=True)  # course/project/customer
    code: Mapped[str] = mapped_column(String(40))
    name_ar: Mapped[str] = mapped_column(String(255))
    name_en: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_system: Mapped[bool] = mapped_column(Boolean, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
