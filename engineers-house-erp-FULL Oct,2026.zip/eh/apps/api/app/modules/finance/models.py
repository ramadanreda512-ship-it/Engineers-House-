"""Finance models: invoices, invoice lines, and payments.

Design notes:
- An Invoice is issued to a customer (by name; optionally linked to a CRM
  account, a project, or a training enrollment as the revenue source).
- Invoice monetary totals (subtotal, tax, total) are always computed
  server-side from the line items, never trusted from the client.
- Payments are recorded against an invoice. The invoice's paid_amount and
  status are recomputed from its payments on every change, so they can never
  drift out of sync with reality.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Invoice(Base, TimestampMixin):
    __tablename__ = "invoices"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    number: Mapped[str] = mapped_column(String(40))  # auto: INV-YYYY-NNNN

    customer_name: Mapped[str] = mapped_column(String(255))
    # Optional links to the revenue source (any may be null).
    account_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    project_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    enrollment_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    issue_date: Mapped[date] = mapped_column(Date)
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # draft / issued / partially_paid / paid / cancelled
    status: Mapped[str] = mapped_column(String(20), default="draft")
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)  # percent

    # All server-computed.
    subtotal: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    paid_amount: Mapped[float] = mapped_column(Numeric(14, 2), default=0)

    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    lines: Mapped[list[InvoiceLine]] = relationship(
        back_populates="invoice", cascade="all, delete-orphan", lazy="selectin"
    )
    payments: Mapped[list[Payment]] = relationship(
        back_populates="invoice", cascade="all, delete-orphan", lazy="selectin"
    )


class InvoiceLine(Base, TimestampMixin):
    __tablename__ = "invoice_lines"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    invoice_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("invoices.id", ondelete="CASCADE")
    )
    description: Mapped[str] = mapped_column(String(255))
    quantity: Mapped[float] = mapped_column(Numeric(14, 2), default=1)
    unit_price: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    line_total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)  # computed

    invoice: Mapped[Invoice] = relationship(back_populates="lines")


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    invoice_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("invoices.id", ondelete="CASCADE")
    )
    amount: Mapped[float] = mapped_column(Numeric(14, 2))
    method: Mapped[str] = mapped_column(String(30), default="cash")  # cash/bank/cheque/other
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    paid_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    invoice: Mapped[Invoice] = relationship(back_populates="payments")


class Expense(Base, TimestampMixin):
    """A simple expense record for cash-flow and profitability reporting."""

    __tablename__ = "expenses"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    category: Mapped[str] = mapped_column(String(60))  # salaries/rent/materials/...
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    amount: Mapped[float] = mapped_column(Numeric(14, 2))
    project_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    spent_at: Mapped[date] = mapped_column(Date)
