"""Finance business logic.

Key rules enforced here (not just in the DB):
- Invoice subtotal/tax/total are recomputed from the line items on creation;
  client-supplied totals are ignored entirely.
- Recording a payment recomputes the invoice's paid_amount and status from the
  full set of payments, so they can never drift. Overpayment is rejected.
- A cancelled or fully paid invoice cannot receive further payments.
"""
from __future__ import annotations

import uuid
from datetime import UTC, date, datetime

from sqlalchemy.orm import Session

from app.modules.finance import repository as repo
from app.modules.finance.models import Expense, Invoice, InvoiceLine, Payment
from app.modules.finance.schemas import (
    ExpenseCreate,
    ExpenseUpdate,
    FinanceSummary,
    InvoiceCreate,
    PaymentCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


def _recompute_invoice_status(invoice: Invoice) -> None:
    """Set paid_amount and status from the invoice's payments + total."""
    paid = _round(sum(float(p.amount) for p in invoice.payments))
    invoice.paid_amount = paid
    total = float(invoice.total)
    if invoice.status == "cancelled":
        return
    if paid <= 0:
        invoice.status = "issued"
    elif paid + 0.01 < total:
        invoice.status = "partially_paid"
    else:
        invoice.status = "paid"


def create_invoice(db: Session, tenant_id: uuid.UUID, body: InvoiceCreate) -> Invoice:
    subtotal = _round(sum(line.quantity * line.unit_price for line in body.lines))
    tax_amount = _round(subtotal * (body.tax_rate / 100.0))
    total = _round(subtotal + tax_amount)

    year = (body.issue_date or date.today()).year
    invoice = Invoice(
        tenant_id=tenant_id,
        number=repo.next_invoice_number(db, tenant_id, year),
        customer_name=body.customer_name,
        account_id=body.account_id,
        project_id=body.project_id,
        enrollment_id=body.enrollment_id,
        issue_date=body.issue_date or date.today(),
        due_date=body.due_date,
        status="issued",
        tax_rate=body.tax_rate,
        subtotal=subtotal,
        tax_amount=tax_amount,
        total=total,
        paid_amount=0,
        notes=body.notes,
    )
    db.add(invoice)
    db.flush()

    for line in body.lines:
        db.add(
            InvoiceLine(
                invoice_id=invoice.id,
                description=line.description,
                quantity=line.quantity,
                unit_price=line.unit_price,
                line_total=_round(line.quantity * line.unit_price),
            )
        )

    db.commit()
    db.refresh(invoice)
    return invoice


def get_invoice(db: Session, tenant_id: uuid.UUID, invoice_id: uuid.UUID) -> Invoice:
    invoice = repo.get_invoice(db, tenant_id, invoice_id)
    if not invoice:
        raise NotFound("Invoice")
    return invoice


def list_invoices(
    db: Session, tenant_id: uuid.UUID, status: str | None, page: int, size: int
):
    return repo.list_invoices(db, tenant_id, status, size, (page - 1) * size)


def cancel_invoice(db: Session, tenant_id: uuid.UUID, invoice_id: uuid.UUID) -> Invoice:
    invoice = get_invoice(db, tenant_id, invoice_id)
    if invoice.payments:
        raise Conflict("Cannot cancel an invoice that already has payments")
    invoice.status = "cancelled"
    db.commit()
    db.refresh(invoice)
    return invoice


def record_payment(
    db: Session, tenant_id: uuid.UUID, invoice_id: uuid.UUID, body: PaymentCreate
) -> Payment:
    invoice = get_invoice(db, tenant_id, invoice_id)
    if invoice.status == "cancelled":
        raise Conflict("Cannot record a payment against a cancelled invoice")
    if invoice.status == "paid":
        raise Conflict("Invoice is already fully paid")

    already_paid = _round(sum(float(p.amount) for p in invoice.payments))
    remaining = _round(float(invoice.total) - already_paid)
    if body.amount - 0.01 > remaining:
        raise BadRequest(
            f"Payment ({body.amount}) exceeds the outstanding balance ({remaining})"
        )

    payment = Payment(
        tenant_id=tenant_id,
        invoice_id=invoice.id,
        amount=body.amount,
        method=body.method,
        reference=body.reference,
        paid_at=body.paid_at or datetime.now(UTC),
    )
    db.add(payment)
    db.flush()
    db.refresh(invoice)
    _recompute_invoice_status(invoice)
    db.commit()
    db.refresh(payment)
    return payment


def list_payments(db: Session, tenant_id: uuid.UUID, invoice_id: uuid.UUID):
    get_invoice(db, tenant_id, invoice_id)
    return repo.list_payments(db, invoice_id)


# --- Expenses ---
def create_expense(db: Session, tenant_id: uuid.UUID, body: ExpenseCreate) -> Expense:
    expense = Expense(
        tenant_id=tenant_id,
        category=body.category,
        description=body.description,
        amount=body.amount,
        project_id=body.project_id,
        spent_at=body.spent_at or date.today(),
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense


def list_expenses(db: Session, tenant_id: uuid.UUID, page: int, size: int):
    return repo.list_expenses(db, tenant_id, size, (page - 1) * size)


def update_expense(
    db: Session, tenant_id: uuid.UUID, expense_id: uuid.UUID, body: ExpenseUpdate
) -> Expense:
    expense = repo.get_expense(db, tenant_id, expense_id)
    if not expense:
        raise NotFound("Expense")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(expense, field, value)
    db.commit()
    db.refresh(expense)
    return expense


def delete_expense(db: Session, tenant_id: uuid.UUID, expense_id: uuid.UUID) -> None:
    expense = repo.get_expense(db, tenant_id, expense_id)
    if not expense:
        raise NotFound("Expense")
    db.delete(expense)
    db.commit()


# --- Reports ---
def finance_summary(db: Session, tenant_id: uuid.UUID) -> FinanceSummary:
    invoiced = repo.sum_invoiced(db, tenant_id)
    collected = repo.sum_collected(db, tenant_id)
    expenses = repo.sum_expenses(db, tenant_id)
    return FinanceSummary(
        total_invoiced=_round(invoiced),
        total_collected=_round(collected),
        total_outstanding=_round(invoiced - collected),
        total_expenses=_round(expenses),
        net_cash=_round(collected - expenses),
        invoice_count=repo.count_invoices(db, tenant_id),
        paid_invoice_count=repo.count_invoices(db, tenant_id, "paid"),
        overdue_invoice_count=repo.count_overdue(db, tenant_id, date.today()),
    )
