"""Tenant-scoped data access for Finance entities."""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.finance.models import Expense, Invoice, Payment


def get_invoice(db: Session, tenant_id: uuid.UUID, invoice_id: uuid.UUID) -> Invoice | None:
    return db.scalar(
        select(Invoice).where(Invoice.id == invoice_id, Invoice.tenant_id == tenant_id)
    )


def list_invoices(
    db: Session, tenant_id: uuid.UUID, status: str | None, limit: int, offset: int
):
    conds = [Invoice.tenant_id == tenant_id]
    if status:
        conds.append(Invoice.status == status)
    stmt = select(Invoice).where(*conds).order_by(Invoice.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Invoice).where(*conds))
    return items, total or 0


def list_payments(db: Session, invoice_id: uuid.UUID):
    stmt = (
        select(Payment)
        .where(Payment.invoice_id == invoice_id)
        .order_by(Payment.paid_at.asc())
    )
    return db.scalars(stmt).all()


def next_invoice_number(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count()).select_from(Invoice).where(Invoice.tenant_id == tenant_id)
    )
    return f"INV-{year}-{(count or 0) + 1:04d}"


def get_expense(db: Session, tenant_id: uuid.UUID, expense_id: uuid.UUID):
    from app.modules.finance.models import Expense
    return db.scalar(
        select(Expense).where(Expense.id == expense_id, Expense.tenant_id == tenant_id)
    )


def list_expenses(db: Session, tenant_id: uuid.UUID, limit: int, offset: int):
    stmt = (
        select(Expense).where(Expense.tenant_id == tenant_id).order_by(Expense.spent_at.desc())
    )
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(
        select(func.count()).select_from(Expense).where(Expense.tenant_id == tenant_id)
    )
    return items, total or 0


# --- Aggregates for the finance summary report ---
def sum_invoiced(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(func.coalesce(func.sum(Invoice.total), 0)).where(
            Invoice.tenant_id == tenant_id, Invoice.status != "cancelled"
        )
    )
    return float(val or 0)


def sum_collected(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(func.coalesce(func.sum(Invoice.paid_amount), 0)).where(
            Invoice.tenant_id == tenant_id, Invoice.status != "cancelled"
        )
    )
    return float(val or 0)


def sum_expenses(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(func.coalesce(func.sum(Expense.amount), 0)).where(Expense.tenant_id == tenant_id)
    )
    return float(val or 0)


def count_invoices(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> int:
    conds = [Invoice.tenant_id == tenant_id]
    if status:
        conds.append(Invoice.status == status)
    return int(db.scalar(select(func.count()).select_from(Invoice).where(*conds)) or 0)


def count_overdue(db: Session, tenant_id: uuid.UUID, today: date) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(Invoice)
            .where(
                Invoice.tenant_id == tenant_id,
                Invoice.status.in_(["issued", "partially_paid"]),
                Invoice.due_date.is_not(None),
                Invoice.due_date < today,
            )
        )
        or 0
    )
