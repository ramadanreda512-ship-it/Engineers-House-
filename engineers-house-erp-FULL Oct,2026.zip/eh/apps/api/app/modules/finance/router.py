"""Finance HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.finance import service
from app.modules.finance.schemas import (
    ExpenseCreate,
    ExpenseOut,
    ExpenseUpdate,
    FinanceSummary,
    InvoiceCreate,
    InvoiceOut,
    PaymentCreate,
    PaymentOut,
)
from app.modules.identity.models import User
from app.shared.pagination import Page

router = APIRouter(prefix="/finance", tags=["finance"])


# --- Invoices ---
@router.post("/invoices", response_model=InvoiceOut, status_code=201)
def create_invoice(
    body: InvoiceCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.create")),
):
    return service.create_invoice(db, user.tenant_id, body)


@router.get("/invoices", response_model=Page[InvoiceOut])
def list_invoices(
    status: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.view")),
):
    items, total = service.list_invoices(db, user.tenant_id, status, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/invoices/{invoice_id}", response_model=InvoiceOut)
def get_invoice(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.view")),
):
    return service.get_invoice(db, user.tenant_id, invoice_id)


@router.post("/invoices/{invoice_id}/cancel", response_model=InvoiceOut)
def cancel_invoice(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.create")),
):
    return service.cancel_invoice(db, user.tenant_id, invoice_id)


# --- Payments ---
@router.post("/invoices/{invoice_id}/payments", response_model=PaymentOut, status_code=201)
def record_payment(
    invoice_id: uuid.UUID,
    body: PaymentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.payment.record")),
):
    return service.record_payment(db, user.tenant_id, invoice_id, body)


@router.get("/invoices/{invoice_id}/payments", response_model=list[PaymentOut])
def list_payments(
    invoice_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.view")),
):
    return service.list_payments(db, user.tenant_id, invoice_id)


# --- Expenses ---
@router.post("/expenses", response_model=ExpenseOut, status_code=201)
def create_expense(
    body: ExpenseCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.expense.create")),
):
    return service.create_expense(db, user.tenant_id, body)


@router.get("/expenses", response_model=Page[ExpenseOut])
def list_expenses(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.view")),
):
    items, total = service.list_expenses(db, user.tenant_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.patch("/expenses/{expense_id}", response_model=ExpenseOut)
def update_expense(
    expense_id: uuid.UUID,
    body: ExpenseUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.expense.create")),
):
    return service.update_expense(db, user.tenant_id, expense_id, body)


@router.delete("/expenses/{expense_id}", status_code=204)
def delete_expense(
    expense_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.expense.delete")),
):
    service.delete_expense(db, user.tenant_id, expense_id)


# --- Reports ---
@router.get("/summary", response_model=FinanceSummary)
def finance_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("finance.invoice.view")),
):
    return service.finance_summary(db, user.tenant_id)
