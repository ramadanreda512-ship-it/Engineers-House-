"""Finance request/response schemas. Money totals are output-only (server-computed)."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- Invoice lines ---
class InvoiceLineCreate(BaseModel):
    description: str = Field(min_length=1, max_length=255)
    quantity: float = Field(gt=0, default=1)
    unit_price: float = Field(ge=0, default=0)


class InvoiceLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    description: str
    quantity: float
    unit_price: float
    line_total: float


# --- Invoices ---
class InvoiceCreate(BaseModel):
    customer_name: str = Field(min_length=1, max_length=255)
    account_id: uuid.UUID | None = None
    project_id: uuid.UUID | None = None
    enrollment_id: uuid.UUID | None = None
    issue_date: date | None = None
    due_date: date | None = None
    tax_rate: float = Field(ge=0, le=100, default=0)
    notes: str | None = None
    lines: list[InvoiceLineCreate] = Field(min_length=1)


class InvoiceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    customer_name: str
    account_id: uuid.UUID | None
    project_id: uuid.UUID | None
    enrollment_id: uuid.UUID | None
    issue_date: date
    due_date: date | None
    status: str
    tax_rate: float
    subtotal: float
    tax_amount: float
    total: float
    paid_amount: float
    notes: str | None
    lines: list[InvoiceLineOut]


# --- Payments ---
class PaymentCreate(BaseModel):
    amount: float = Field(gt=0)
    method: str = Field(default="cash")
    reference: str | None = None
    paid_at: datetime | None = None


class PaymentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    invoice_id: uuid.UUID
    amount: float
    method: str
    reference: str | None
    paid_at: datetime


# --- Expenses ---
class ExpenseCreate(BaseModel):
    category: str = Field(min_length=1, max_length=60)
    description: str | None = None
    amount: float = Field(gt=0)
    project_id: uuid.UUID | None = None
    spent_at: date | None = None


class ExpenseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    category: str
    description: str | None
    amount: float
    project_id: uuid.UUID | None
    spent_at: date


class ExpenseUpdate(BaseModel):
    category: str | None = Field(default=None, min_length=1, max_length=60)
    description: str | None = None
    amount: float | None = Field(default=None, gt=0)
    project_id: uuid.UUID | None = None
    spent_at: date | None = None


# --- Reports ---
class FinanceSummary(BaseModel):
    total_invoiced: float
    total_collected: float
    total_outstanding: float
    total_expenses: float
    net_cash: float
    invoice_count: int
    paid_invoice_count: int
    overdue_invoice_count: int
