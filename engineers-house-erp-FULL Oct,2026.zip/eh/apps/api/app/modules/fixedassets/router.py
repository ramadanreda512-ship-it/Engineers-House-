"""Fixed asset HTTP endpoints."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.fixedassets import service
from app.modules.fixedassets.schemas import (
    AssetCreate,
    AssetOut,
    AssetSummary,
    AssetUpdate,
    AssetWithSchedule,
    DepreciationEntryOut,
    DepreciationRunRequest,
    DepreciationRunResult,
)
from app.modules.identity.models import User

router = APIRouter(prefix="/fixed-assets", tags=["fixed-assets"])

VIEW = "fixedassets.view"
MANAGE = "fixedassets.manage"


@router.post("", response_model=AssetOut, status_code=201)
def create_asset(
    body: AssetCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_asset(db, user.tenant_id, body)


@router.get("", response_model=list[AssetWithSchedule])
def list_assets(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    out = []
    for a in service.list_assets(db, user.tenant_id):
        fields = service.asset_schedule_fields(a)
        out.append(
            AssetWithSchedule(
                id=a.id, code=a.code, name=a.name, category=a.category,
                purchase_date=a.purchase_date, purchase_value=float(a.purchase_value),
                salvage_value=float(a.salvage_value), useful_life_months=a.useful_life_months,
                depreciation_method=a.depreciation_method,
                accumulated_depreciation=float(a.accumulated_depreciation),
                current_value=float(a.current_value), location=a.location,
                serial_number=a.serial_number, status=a.status, is_active=a.is_active,
                **fields,
            )
        )
    return out


@router.get("/summary", response_model=AssetSummary)
def summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.summary(db, user.tenant_id)


@router.get("/{asset_id}", response_model=AssetOut)
def get_asset(
    asset_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.get_asset(db, user.tenant_id, asset_id)


@router.patch("/{asset_id}", response_model=AssetOut)
def update_asset(
    asset_id: uuid.UUID,
    body: AssetUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_asset(db, user.tenant_id, asset_id, body)


@router.delete("/{asset_id}", status_code=204)
def delete_asset(
    asset_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_asset(db, user.tenant_id, asset_id)


@router.post("/{asset_id}/depreciate", response_model=DepreciationRunResult, status_code=201)
def run_depreciation(
    asset_id: uuid.UUID,
    body: DepreciationRunRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.run_depreciation(db, user.tenant_id, asset_id, body)


@router.get("/{asset_id}/depreciation", response_model=list[DepreciationEntryOut])
def list_depreciation(
    asset_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_depreciation(db, user.tenant_id, asset_id)
