"""Fixed assets with depreciation (financial asset register).

Distinct from the CMMS asset module (which tracks maintenance/work orders):
this tracks the *financial* life of an asset - its purchase value, salvage
value, useful life, and accumulated depreciation - so the balance sheet shows
the correct net book value, and depreciation expense hits the income statement.

Depreciation method supported: straight-line.
  monthly_depreciation = (purchase_value - salvage_value) / useful_life_months
Each depreciation run posts a journal entry:
  debit  depreciation expense
  credit accumulated depreciation
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin

ASSET_CATEGORIES = (
    "computer", "plc_equipment", "instrument", "training_kit",
    "vehicle", "office_furniture", "building", "other",
)
ASSET_STATUSES = ("in_use", "in_storage", "under_maintenance", "disposed")


class FixedAsset(Base, TimestampMixin):
    __tablename__ = "fixed_assets"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_fixed_asset_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(20))  # AST-001
    name: Mapped[str] = mapped_column(String(255))
    category: Mapped[str] = mapped_column(String(30), default="other")
    purchase_date: Mapped[date] = mapped_column(Date)
    purchase_value: Mapped[float] = mapped_column(Numeric(16, 2))
    salvage_value: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    useful_life_months: Mapped[int] = mapped_column(default=60)
    depreciation_method: Mapped[str] = mapped_column(String(20), default="straight_line")
    accumulated_depreciation: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    # current_value (net book value) = purchase_value - accumulated_depreciation
    current_value: Mapped[float] = mapped_column(Numeric(16, 2))
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    serial_number: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="in_use")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    depreciation_entries: Mapped[list[DepreciationEntry]] = relationship(
        back_populates="asset", cascade="all, delete-orphan", lazy="selectin"
    )


class DepreciationEntry(Base, TimestampMixin):
    """One posted depreciation run for an asset (usually monthly)."""

    __tablename__ = "fixed_asset_depreciation"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    asset_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("fixed_assets.id", ondelete="CASCADE")
    )
    period_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[float] = mapped_column(Numeric(16, 2))
    book_value_after: Mapped[float] = mapped_column(Numeric(16, 2))
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    asset: Mapped[FixedAsset] = relationship(back_populates="depreciation_entries")
