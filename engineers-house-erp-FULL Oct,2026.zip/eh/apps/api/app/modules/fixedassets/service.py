"""Fixed asset business logic with straight-line depreciation.

Creating an asset sets current_value = purchase_value. Running depreciation
for a period posts one month of straight-line depreciation and a balanced
journal entry (debit depreciation expense, credit accumulated depreciation),
then reduces the asset's book value. Depreciation stops once the asset reaches
its salvage value.
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.modules.accounting import repository as acc_repo
from app.modules.accounting.models import JournalEntry, JournalLine
from app.modules.fixedassets import repository as repo
from app.modules.fixedassets.models import DepreciationEntry, FixedAsset
from app.modules.fixedassets.schemas import (
    AssetCreate,
    AssetUpdate,
    DepreciationRunRequest,
)
from app.shared.exceptions import Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


def _next_code(db: Session, tenant_id: uuid.UUID) -> str:
    return f"AST-{repo.asset_count(db, tenant_id) + 1:03d}"


def _monthly_depreciation(asset: FixedAsset) -> float:
    depreciable = float(asset.purchase_value) - float(asset.salvage_value)
    if asset.useful_life_months <= 0:
        return 0.0
    return _round(depreciable / asset.useful_life_months)


# --- CRUD ---
def create_asset(db: Session, tenant_id: uuid.UUID, body: AssetCreate) -> FixedAsset:
    asset = FixedAsset(
        tenant_id=tenant_id,
        code=_next_code(db, tenant_id),
        depreciation_method="straight_line",
        accumulated_depreciation=0,
        current_value=_round(body.purchase_value),
        status="in_use",
        is_active=True,
        **body.model_dump(),
    )
    db.add(asset)
    db.commit()
    db.refresh(asset)
    return asset


def list_assets(db: Session, tenant_id: uuid.UUID):
    return repo.list_assets(db, tenant_id)


def get_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> FixedAsset:
    asset = repo.get_asset(db, tenant_id, asset_id)
    if not asset:
        raise NotFound("Fixed asset")
    return asset


def asset_schedule_fields(asset: FixedAsset) -> dict:
    monthly = _monthly_depreciation(asset)
    months_done = (
        int((float(asset.purchase_value) - float(asset.current_value)) / monthly)
        if monthly > 0
        else 0
    )
    fully = float(asset.current_value) <= float(asset.salvage_value) + 0.01
    return {
        "monthly_depreciation": monthly,
        "months_depreciated": months_done,
        "is_fully_depreciated": fully,
    }


def update_asset(
    db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID, body: AssetUpdate
) -> FixedAsset:
    asset = get_asset(db, tenant_id, asset_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(asset, field, value)
    db.commit()
    db.refresh(asset)
    return asset


def delete_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> None:
    asset = get_asset(db, tenant_id, asset_id)
    if repo.depreciation_count(db, asset_id) > 0:
        raise Conflict(
            "Cannot delete an asset that has depreciation history. "
            "Set its status to 'disposed' instead."
        )
    db.delete(asset)
    db.commit()


# --- Depreciation ---
def _acc_by_code(db: Session, tenant_id: uuid.UUID, code: str):
    for a in acc_repo.list_accounts(db, tenant_id):
        if a.code == code:
            return a
    return None


def run_depreciation(
    db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID, body: DepreciationRunRequest
) -> dict:
    asset = get_asset(db, tenant_id, asset_id)
    monthly = _monthly_depreciation(asset)
    remaining = _round(float(asset.current_value) - float(asset.salvage_value))
    if remaining <= 0 or monthly <= 0:
        raise Conflict("Asset is already fully depreciated")
    amount = min(monthly, remaining)

    period = body.period_date or date.today()

    # Post the depreciation journal entry if the accounts are available.
    expense_acc = (
        acc_repo.get_account(db, tenant_id, body.expense_account_id)
        if body.expense_account_id
        else _acc_by_code(db, tenant_id, "5203") or _acc_by_code(db, tenant_id, "5201")
    )
    accum_acc = (
        acc_repo.get_account(db, tenant_id, body.accumulated_account_id)
        if body.accumulated_account_id
        else _acc_by_code(db, tenant_id, "1202") or _acc_by_code(db, tenant_id, "1201")
    )
    entry_id = None
    if expense_acc and accum_acc:
        entry = JournalEntry(
            tenant_id=tenant_id,
            number=acc_repo.next_entry_number(db, tenant_id, period.year),
            entry_date=period,
            description=f"Depreciation: {asset.name}",
            status="posted",
            source="depreciation",
            total_debit=amount,
            total_credit=amount,
        )
        db.add(entry)
        db.flush()
        db.add(JournalLine(tenant_id=tenant_id, entry_id=entry.id, account_id=expense_acc.id,
                           debit=amount, credit=0, description=f"Depreciation {asset.code}"))
        db.add(JournalLine(tenant_id=tenant_id, entry_id=entry.id, account_id=accum_acc.id,
                           debit=0, credit=amount, description=f"Depreciation {asset.code}"))
        entry_id = entry.id

    asset.accumulated_depreciation = _round(float(asset.accumulated_depreciation) + amount)
    asset.current_value = _round(float(asset.current_value) - amount)
    db.add(
        DepreciationEntry(
            tenant_id=tenant_id,
            asset_id=asset.id,
            period_date=period,
            amount=amount,
            book_value_after=asset.current_value,
            journal_entry_id=entry_id,
        )
    )
    db.commit()
    db.refresh(asset)
    return {
        "asset_id": asset.id,
        "asset_code": asset.code,
        "amount": amount,
        "accumulated_depreciation": _round(float(asset.accumulated_depreciation)),
        "current_value": _round(float(asset.current_value)),
        "is_fully_depreciated": float(asset.current_value) <= float(asset.salvage_value) + 0.01,
    }


def list_depreciation(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID):
    get_asset(db, tenant_id, asset_id)
    return repo.list_depreciation(db, tenant_id, asset_id)


def summary(db: Session, tenant_id: uuid.UUID) -> dict:
    assets = repo.list_assets(db, tenant_id)
    total_purchase = sum(float(a.purchase_value) for a in assets)
    total_accum = sum(float(a.accumulated_depreciation) for a in assets)
    total_book = sum(float(a.current_value) for a in assets)
    return {
        "total_assets": len(assets),
        "total_purchase_value": _round(total_purchase),
        "total_accumulated_depreciation": _round(total_accum),
        "total_book_value": _round(total_book),
    }
