"""Tenant-scoped data access for fixed assets."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.fixedassets.models import DepreciationEntry, FixedAsset


def get_asset(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID) -> FixedAsset | None:
    return db.scalar(
        select(FixedAsset).where(FixedAsset.id == asset_id, FixedAsset.tenant_id == tenant_id)
    )


def list_assets(db: Session, tenant_id: uuid.UUID):
    return db.scalars(
        select(FixedAsset)
        .where(FixedAsset.tenant_id == tenant_id)
        .order_by(FixedAsset.code.asc())
    ).all()


def asset_count(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count()).select_from(FixedAsset).where(FixedAsset.tenant_id == tenant_id)
        )
        or 0
    )


def list_depreciation(db: Session, tenant_id: uuid.UUID, asset_id: uuid.UUID):
    return db.scalars(
        select(DepreciationEntry)
        .where(
            DepreciationEntry.tenant_id == tenant_id,
            DepreciationEntry.asset_id == asset_id,
        )
        .order_by(DepreciationEntry.period_date.asc())
    ).all()


def depreciation_count(db: Session, asset_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(DepreciationEntry)
            .where(DepreciationEntry.asset_id == asset_id)
        )
        or 0
    )
