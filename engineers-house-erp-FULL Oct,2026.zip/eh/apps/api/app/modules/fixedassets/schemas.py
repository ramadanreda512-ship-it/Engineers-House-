"""Fixed asset schemas. Depreciation amounts are server-computed."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


class AssetCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    category: str = Field(
        pattern="^(computer|plc_equipment|instrument|training_kit|"
        "vehicle|office_furniture|building|other)$",
        default="other",
    )
    purchase_date: date
    purchase_value: float = Field(gt=0)
    salvage_value: float = Field(ge=0, default=0)
    useful_life_months: int = Field(gt=0, default=60)
    location: str | None = None
    serial_number: str | None = None


class AssetUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    category: str | None = None
    location: str | None = None
    serial_number: str | None = None
    status: str | None = None
    salvage_value: float | None = Field(default=None, ge=0)
    useful_life_months: int | None = Field(default=None, gt=0)


class AssetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    category: str
    purchase_date: date
    purchase_value: float
    salvage_value: float
    useful_life_months: int
    depreciation_method: str
    accumulated_depreciation: float
    current_value: float
    location: str | None
    serial_number: str | None
    status: str
    is_active: bool


class AssetWithSchedule(AssetOut):
    monthly_depreciation: float
    months_depreciated: int
    is_fully_depreciated: bool


class DepreciationRunRequest(BaseModel):
    period_date: date | None = None
    # Optional cash/expense account overrides; defaults pulled from chart.
    expense_account_id: uuid.UUID | None = None
    accumulated_account_id: uuid.UUID | None = None


class DepreciationEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    asset_id: uuid.UUID
    period_date: date
    amount: float
    book_value_after: float
    journal_entry_id: uuid.UUID | None


class DepreciationRunResult(BaseModel):
    asset_id: uuid.UUID
    asset_code: str
    amount: float
    accumulated_depreciation: float
    current_value: float
    is_fully_depreciated: bool


class AssetSummary(BaseModel):
    total_assets: int
    total_purchase_value: float
    total_accumulated_depreciation: float
    total_book_value: float
