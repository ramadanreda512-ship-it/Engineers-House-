"""In-app help assistant.

Answers a user's free-text question about how to use a given module. It is a
thin, safe wrapper around the Anthropic API: it only ever receives the module
context and the question (never the customer's data), and if no API key is
configured it returns a clear message so the static help still stands on its
own.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.core.config import get_settings
from app.core.deps import get_current_user
from app.modules.identity.models import User

router = APIRouter(prefix="/help", tags=["help"])
settings = get_settings()

# Short Arabic descriptions of each module, so the assistant answers in the
# right context without needing access to any real data.
MODULE_CONTEXT = {
    "dashboard": "لوحة التحكم: نظرة سريعة على أرقام الشركة (عملاء، فرص، إيرادات، مهام).",
    "crm": (
        "إدارة العملاء CRM: العملاء، الفرص البيعية، عروض الأسعار (بخصم وضريبة "
        "وطباعة PDF)، كتالوج الخدمات، متابعات اليوم، وتحليل أسباب خسارة الصفقات."
    ),
    "training": (
        "التدريب: الكورسات، الدفعات، الطلاب، الاستفسارات B2C، الأقساط (مع مقدم "
        "حجز)، وربحية كل دفعة بعد نصيب المدرب والتكاليف."
    ),
    "projects": (
        "المقاولات والمشاريع: المراحل، نسبة الإنجاز الموزونة، جداول الكميات، "
        "المقاولون من الباطن."
    ),
    "tendering": "المناقصات: تتبّع المناقصات ومستنداتها ومواعيدها النهائية وحالتها.",
    "accounting": "المحاسبة: دليل الحسابات والقيود المزدوجة (مدين/دائن).",
    "finance": "المالية: الفواتير، المدفوعات، المصروفات، وتتبّع المستحقات والنقدية.",
    "cmms": "الصيانة CMMS: الأصول وأوامر الشغل (وقائية وتصحيحية).",
    "inventory": "المخازن: الأصناف وحركات الوارد والمنصرف والأرصدة.",
    "hr": "الموارد البشرية: بيانات الموظفين وطلبات الإجازات.",
    "partners": "الشركاء: الموردون والشركاء التجاريون.",
    "fixed-assets": "الأصول الثابتة: تسجيل الأصول وإهلاكها.",
    "analyst": "المحلل الذكي: تحليلات ورؤى ذكية عبر بيانات النظام.",
    "governance": "الموافقات والموازنات: سلاسل الاعتماد والموازنات المالية.",
    "settings": "الإعدادات: الفئات، النسخ الاحتياطي، وإدارة المستخدمين والصلاحيات.",
}


class HelpAsk(BaseModel):
    module: str = Field(max_length=40)
    question: str = Field(min_length=1, max_length=1000)


class HelpAnswer(BaseModel):
    answer: str
    ai_enabled: bool


@router.post("/ask", response_model=HelpAnswer)
def ask_help(
    body: HelpAsk,
    user: User = Depends(get_current_user),
):
    context = MODULE_CONTEXT.get(body.module, "نظام ERP لشركة هندسية مصرية (إنجينيرز هاوس).")

    if not settings.anthropic_api_key:
        return {
            "answer": (
                "المساعد الذكي غير مُفعّل بعد. لتفعيله، أضف مفتاح Anthropic API على "
                "الخادم (ANTHROPIC_API_KEY) ثم أعد التشغيل. في هذه الأثناء، يظهر لك "
                "«دليل الاستخدام» الثابت أعلى النافذة ويغطي معظم ما تحتاجه."
            ),
            "ai_enabled": False,
        }

    try:
        import httpx
    except ModuleNotFoundError:
        return {
            "answer": (
                "مكتبة httpx غير مثبّتة على الخادم. ثبّتها بالأمر: pip install httpx "
                "ثم أعد التشغيل. حتى ذلك الحين، استخدم «دليل الاستخدام» الثابت."
            ),
            "ai_enabled": False,
        }

    system = (
        "أنت مساعد استخدام ودود داخل برنامج ERP باسم «إنجينيرز هاوس» لشركة هندسية "
        "مصرية (أتمتة صناعية وتدريب ومقاولات). تشرح للمستخدم كيف يستخدم البرنامج "
        "بالعربية الواضحة والمختصرة، خطوة بخطوة. لا تخترع ميزات غير موجودة؛ إذا لم "
        "تكن متأكدًا اقترح مراجعة دليل الاستخدام أو مدير النظام. ركّز على الموديول "
        f"الحالي: {context}"
    )
    try:
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.anthropic_api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": settings.anthropic_model,
                "max_tokens": 1000,
                "system": system,
                "messages": [{"role": "user", "content": body.question}],
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        answer = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        ) or "لا يوجد رد."
    except Exception as e:  # noqa: BLE001
        return {
            "answer": (
                f"تعذّر الاتصال بالمساعد الذكي حاليًا ({e}). استخدم «دليل الاستخدام» "
                "الثابت أعلى النافذة."
            ),
            "ai_enabled": False,
        }

    return {"answer": answer, "ai_enabled": True}
