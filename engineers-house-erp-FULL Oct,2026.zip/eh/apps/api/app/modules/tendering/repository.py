"""Tenant-scoped data access for the tendering module."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.modules.tendering.models import (
    BOQDivision,
    BOQElement,
    BOQSection,
    CostEstimate,
    Tender,
    TenderCompetitor,
)


# --- Tender ---
def get_tender(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID) -> Tender | None:
    return db.scalar(select(Tender).where(Tender.id == tender_id, Tender.tenant_id == tenant_id))


def list_tenders(
    db: Session, tenant_id: uuid.UUID, status: str | None, bu: str | None, limit: int, offset: int
):
    conds = [Tender.tenant_id == tenant_id]
    if status:
        conds.append(Tender.status == status)
    if bu:
        conds.append(Tender.business_unit == bu)
    stmt = select(Tender).where(*conds).order_by(Tender.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Tender).where(*conds))
    return items, total or 0


def next_tender_code(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count()).select_from(Tender).where(Tender.tenant_id == tenant_id)
    )
    return f"TND-{year}-{(count or 0) + 1:04d}"


# --- Competitors ---
def list_competitors(db: Session, tender_id: uuid.UUID):
    return db.scalars(
        select(TenderCompetitor)
        .where(TenderCompetitor.tender_id == tender_id)
        .order_by(TenderCompetitor.created_at.asc())
    ).all()


def get_competitor(
    db: Session, tenant_id: uuid.UUID, competitor_id: uuid.UUID
) -> TenderCompetitor | None:
    return db.scalar(
        select(TenderCompetitor).where(
            TenderCompetitor.id == competitor_id, TenderCompetitor.tenant_id == tenant_id
        )
    )


# --- BOQ tree ---
def get_section(db: Session, tenant_id: uuid.UUID, section_id: uuid.UUID) -> BOQSection | None:
    return db.scalar(
        select(BOQSection).where(BOQSection.id == section_id, BOQSection.tenant_id == tenant_id)
    )


def get_division(db: Session, tenant_id: uuid.UUID, division_id: uuid.UUID) -> BOQDivision | None:
    return db.scalar(
        select(BOQDivision).where(
            BOQDivision.id == division_id, BOQDivision.tenant_id == tenant_id
        )
    )


def get_element(db: Session, tenant_id: uuid.UUID, element_id: uuid.UUID) -> BOQElement | None:
    return db.scalar(
        select(BOQElement).where(BOQElement.id == element_id, BOQElement.tenant_id == tenant_id)
    )


def full_boq_tree(db: Session, tender_id: uuid.UUID):
    """Load all sections -> divisions -> elements for a tender, eagerly."""
    return db.scalars(
        select(BOQSection)
        .where(BOQSection.tender_id == tender_id)
        .options(selectinload(BOQSection.divisions).selectinload(BOQDivision.elements))
        .order_by(BOQSection.sort_order, BOQSection.code)
    ).all()


def all_elements_for_tender(db: Session, tender_id: uuid.UUID):
    """Flat list of every priced element under a tender (for conversion/totals)."""
    return db.scalars(
        select(BOQElement)
        .join(BOQDivision, BOQElement.division_id == BOQDivision.id)
        .join(BOQSection, BOQDivision.section_id == BOQSection.id)
        .where(BOQSection.tender_id == tender_id)
    ).all()


# --- Estimates ---
def get_estimate(db: Session, tenant_id: uuid.UUID, estimate_id: uuid.UUID) -> CostEstimate | None:
    return db.scalar(
        select(CostEstimate).where(
            CostEstimate.id == estimate_id, CostEstimate.tenant_id == tenant_id
        )
    )


def list_estimates(db: Session, tender_id: uuid.UUID):
    return db.scalars(
        select(CostEstimate)
        .where(CostEstimate.tender_id == tender_id)
        .order_by(CostEstimate.version.asc())
    ).all()


def next_estimate_version(db: Session, tender_id: uuid.UUID) -> int:
    count = db.scalar(
        select(func.count()).select_from(CostEstimate).where(CostEstimate.tender_id == tender_id)
    )
    return (count or 0) + 1


# --- Aggregates for summary ---
def count_tenders(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> int:
    conds = [Tender.tenant_id == tenant_id]
    if status:
        conds.append(Tender.status == status)
    return int(db.scalar(select(func.count()).select_from(Tender).where(*conds)) or 0)


def sum_tender_value(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> float:
    conds = [Tender.tenant_id == tenant_id]
    if status:
        conds.append(Tender.status == status)
    val = db.scalar(
        select(func.coalesce(func.sum(Tender.estimated_value), 0)).where(*conds)
    )
    return float(val or 0)
