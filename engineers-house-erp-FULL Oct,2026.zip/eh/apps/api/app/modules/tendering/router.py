"""Tendering HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.identity.models import User
from app.modules.tendering import service
from app.modules.tendering.schemas import (
    BOQTree,
    CategoryBreakdown,
    CompetitorCreate,
    CompetitorOut,
    ConvertResult,
    DivisionCreate,
    DivisionOut,
    DivisionUpdate,
    ElementCreate,
    ElementOut,
    ElementUpdate,
    EstimateCreate,
    EstimateOut,
    SectionCreate,
    SectionOut,
    SectionUpdate,
    TenderCreate,
    TenderOut,
    TenderSummary,
    TenderUpdate,
)
from app.shared.pagination import Page

router = APIRouter(prefix="/tendering", tags=["tendering"])

VIEW = "tender.view"
MANAGE = "tender.manage"


# --- Tenders ---
@router.post("/tenders", response_model=TenderOut, status_code=201)
def create_tender(
    body: TenderCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_tender(db, user.tenant_id, body)


@router.get("/tenders", response_model=Page[TenderOut])
def list_tenders(
    status: str | None = Query(None),
    business_unit: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    items, total = service.list_tenders(
        db, user.tenant_id, status, business_unit, page, size
    )
    return Page(items=items, total=total, page=page, size=size)


@router.get("/tenders/{tender_id}", response_model=TenderOut)
def get_tender(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.get_tender(db, user.tenant_id, tender_id)


@router.patch("/tenders/{tender_id}", response_model=TenderOut)
def update_tender(
    tender_id: uuid.UUID,
    body: TenderUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_tender(db, user.tenant_id, tender_id, body)


@router.post("/tenders/{tender_id}/status", response_model=TenderOut)
def set_status(
    tender_id: uuid.UUID,
    status: str = Query(...),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.set_status(db, user.tenant_id, tender_id, status)


@router.delete("/tenders/{tender_id}", status_code=204)
def delete_tender(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_tender(db, user.tenant_id, tender_id)


@router.post("/tenders/{tender_id}/convert", response_model=ConvertResult, status_code=201)
def convert_to_project(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.convert_to_project(db, user.tenant_id, tender_id)


# --- Competitors ---
@router.post("/tenders/{tender_id}/competitors", response_model=CompetitorOut, status_code=201)
def add_competitor(
    tender_id: uuid.UUID,
    body: CompetitorCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.add_competitor(db, user.tenant_id, tender_id, body)


@router.get("/tenders/{tender_id}/competitors", response_model=list[CompetitorOut])
def list_competitors(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_competitors(db, user.tenant_id, tender_id)


@router.delete("/competitors/{competitor_id}", status_code=204)
def delete_competitor(
    competitor_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_competitor(db, user.tenant_id, competitor_id)


# --- BOQ tree ---
@router.get("/tenders/{tender_id}/boq", response_model=BOQTree)
def get_boq(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.boq_tree(db, user.tenant_id, tender_id)


@router.post("/tenders/{tender_id}/sections", response_model=SectionOut, status_code=201)
def add_section(
    tender_id: uuid.UUID,
    body: SectionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.add_section(db, user.tenant_id, tender_id, body)


@router.patch("/sections/{section_id}", response_model=SectionOut)
def update_section(
    section_id: uuid.UUID,
    body: SectionUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_section(db, user.tenant_id, section_id, body)


@router.delete("/sections/{section_id}", status_code=204)
def delete_section(
    section_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_section(db, user.tenant_id, section_id)


@router.post("/sections/{section_id}/divisions", response_model=DivisionOut, status_code=201)
def add_division(
    section_id: uuid.UUID,
    body: DivisionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.add_division(db, user.tenant_id, section_id, body)


@router.patch("/divisions/{division_id}", response_model=DivisionOut)
def update_division(
    division_id: uuid.UUID,
    body: DivisionUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_division(db, user.tenant_id, division_id, body)


@router.delete("/divisions/{division_id}", status_code=204)
def delete_division(
    division_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_division(db, user.tenant_id, division_id)


@router.post("/divisions/{division_id}/elements", response_model=ElementOut, status_code=201)
def add_element(
    division_id: uuid.UUID,
    body: ElementCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.add_element(db, user.tenant_id, division_id, body)


@router.patch("/elements/{element_id}", response_model=ElementOut)
def update_element(
    element_id: uuid.UUID,
    body: ElementUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.update_element(db, user.tenant_id, element_id, body)


@router.delete("/elements/{element_id}", status_code=204)
def delete_element(
    element_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_element(db, user.tenant_id, element_id)


# --- Cost estimates ---
@router.post("/tenders/{tender_id}/estimates", response_model=EstimateOut, status_code=201)
def create_estimate(
    tender_id: uuid.UUID,
    body: EstimateCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    return service.create_estimate(db, user.tenant_id, tender_id, body)


@router.get("/tenders/{tender_id}/estimates", response_model=list[EstimateOut])
def list_estimates(
    tender_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.list_estimates(db, user.tenant_id, tender_id)


@router.get("/estimates/{estimate_id}", response_model=EstimateOut)
def get_estimate(
    estimate_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.get_estimate(db, user.tenant_id, estimate_id)


@router.get("/estimates/{estimate_id}/breakdown", response_model=CategoryBreakdown)
def estimate_breakdown(
    estimate_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.estimate_breakdown(db, user.tenant_id, estimate_id)


@router.delete("/estimates/{estimate_id}", status_code=204)
def delete_estimate(
    estimate_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(MANAGE)),
):
    service.delete_estimate(db, user.tenant_id, estimate_id)


# --- Reports ---
@router.get("/summary", response_model=TenderSummary)
def tender_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission(VIEW)),
):
    return service.tender_summary(db, user.tenant_id)
