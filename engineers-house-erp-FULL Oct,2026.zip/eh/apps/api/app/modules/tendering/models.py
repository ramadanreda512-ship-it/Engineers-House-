"""Tendering, cost estimation, and multi-level BOQ models.

This module is the pre-award core of a construction ERP. It deliberately sits
*alongside* the existing `projects` module (which handles post-award execution
and IPC billing) without modifying it. The integration point is one-directional:
a won Tender can be converted into a Project, copying its multi-level BOQ down
into the project's flat execution BOQ.

Structure of the multi-level BOQ (matching professional practice):
    Tender
      └── BOQSection      (e.g. "Civil Works")
            └── BOQDivision   (e.g. "Concrete")
                  └── BOQElement  (the priced leaf item: qty x unit_rate)

Cost estimation is kept separate from the BOQ: the BOQ is what the client sees
(selling price), while the CostEstimate is the internal build-up of cost
(direct/indirect/labour/material/equipment/subcontractor) used to decide margin.
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Tender(Base, TimestampMixin):
    __tablename__ = "tenders"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_tender_tenant_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(40))  # auto: TND-YYYY-NNNN
    title: Mapped[str] = mapped_column(String(255))
    # CRM account (the client issuing the tender), optional.
    client_account_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    client_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Which Engineers House business unit this belongs to.
    business_unit: Mapped[str] = mapped_column(String(40), default="construction")
    # industrial_automation/electrical/plc_scada/construction/maintenance/consulting

    reference_no: Mapped[str | None] = mapped_column(String(120), nullable=True)
    submission_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    estimated_value: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    bid_bond_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)

    # draft / submitted / under_evaluation / won / lost / cancelled
    status: Mapped[str] = mapped_column(String(20), default="draft")
    # Our submitted bid total (filled from BOQ once priced).
    bid_value: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    win_probability: Mapped[float] = mapped_column(Numeric(5, 2), default=0)  # 0-100
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Set when a won tender is converted into an execution project.
    converted_project_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)

    sections: Mapped[list[BOQSection]] = relationship(
        back_populates="tender", cascade="all, delete-orphan"
    )
    competitors: Mapped[list[TenderCompetitor]] = relationship(
        back_populates="tender", cascade="all, delete-orphan"
    )
    estimates: Mapped[list[CostEstimate]] = relationship(
        back_populates="tender", cascade="all, delete-orphan"
    )


class TenderCompetitor(Base, TimestampMixin):
    """A competitor bidding on the same tender (for bid/competitor analysis)."""

    __tablename__ = "tender_competitors"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    tender_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("tenders.id", ondelete="CASCADE")
    )
    name: Mapped[str] = mapped_column(String(255))
    bid_amount: Mapped[float | None] = mapped_column(Numeric(16, 2), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(255), nullable=True)

    tender: Mapped[Tender] = relationship(back_populates="competitors")


# --- Multi-level BOQ ---
class BOQSection(Base, TimestampMixin):
    __tablename__ = "boq_sections"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    tender_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("tenders.id", ondelete="CASCADE")
    )
    code: Mapped[str] = mapped_column(String(20))  # e.g. "1"
    name: Mapped[str] = mapped_column(String(255))
    sort_order: Mapped[int] = mapped_column(default=0)

    tender: Mapped[Tender] = relationship(back_populates="sections")
    divisions: Mapped[list[BOQDivision]] = relationship(
        back_populates="section", cascade="all, delete-orphan"
    )


class BOQDivision(Base, TimestampMixin):
    __tablename__ = "boq_divisions"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    section_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("boq_sections.id", ondelete="CASCADE")
    )
    code: Mapped[str] = mapped_column(String(20))  # e.g. "1.1"
    name: Mapped[str] = mapped_column(String(255))
    sort_order: Mapped[int] = mapped_column(default=0)

    section: Mapped[BOQSection] = relationship(back_populates="divisions")
    elements: Mapped[list[BOQElement]] = relationship(
        back_populates="division", cascade="all, delete-orphan"
    )


class BOQElement(Base, TimestampMixin):
    """The priced leaf item of the BOQ. amount = quantity * unit_rate (computed)."""

    __tablename__ = "boq_elements"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    division_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("boq_divisions.id", ondelete="CASCADE")
    )
    item_code: Mapped[str] = mapped_column(String(30))  # e.g. "1.1.1"
    description: Mapped[str] = mapped_column(Text)
    unit: Mapped[str] = mapped_column(String(20))  # m3, m2, no, ls...
    quantity: Mapped[float] = mapped_column(Numeric(16, 3), default=0)
    unit_rate: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)  # computed
    sort_order: Mapped[int] = mapped_column(default=0)

    division: Mapped[BOQDivision] = relationship(back_populates="elements")


# --- Cost estimation ---
class CostEstimate(Base, TimestampMixin):
    """An internal cost build-up for a tender. A tender may have several
    estimate versions; the lines categorise cost into the standard buckets."""

    __tablename__ = "cost_estimates"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    tender_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("tenders.id", ondelete="CASCADE")
    )
    version: Mapped[int] = mapped_column(default=1)
    title: Mapped[str] = mapped_column(String(255), default="Preliminary estimate")
    estimate_type: Mapped[str] = mapped_column(String(20), default="preliminary")
    # preliminary / detailed
    overhead_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    margin_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)

    # All computed from lines + the pcts above.
    direct_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    overhead_amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    total_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    margin_amount: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    selling_price: Mapped[float] = mapped_column(Numeric(16, 2), default=0)

    tender: Mapped[Tender] = relationship(back_populates="estimates")
    lines: Mapped[list[CostEstimateLine]] = relationship(
        back_populates="estimate", cascade="all, delete-orphan", lazy="selectin"
    )


class CostEstimateLine(Base, TimestampMixin):
    __tablename__ = "cost_estimate_lines"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    estimate_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("cost_estimates.id", ondelete="CASCADE")
    )
    # labour / material / equipment / subcontractor / other (the cost categories)
    category: Mapped[str] = mapped_column(String(20))
    cost_code: Mapped[str | None] = mapped_column(String(30), nullable=True)
    description: Mapped[str] = mapped_column(String(255))
    quantity: Mapped[float] = mapped_column(Numeric(16, 3), default=1)
    unit_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)
    line_cost: Mapped[float] = mapped_column(Numeric(16, 2), default=0)  # computed

    estimate: Mapped[CostEstimate] = relationship(back_populates="lines")
