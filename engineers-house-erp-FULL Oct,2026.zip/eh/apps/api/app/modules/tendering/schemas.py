"""Tendering request/response schemas. Monetary totals are server-computed (output-only)."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


# --- Tender ---
class TenderCreate(BaseModel):
    title: str = Field(min_length=2, max_length=255)
    client_account_id: uuid.UUID | None = None
    client_name: str | None = None
    business_unit: str = Field(default="construction")
    reference_no: str | None = None
    submission_date: date | None = None
    estimated_value: float = Field(ge=0, default=0)
    bid_bond_pct: float = Field(ge=0, le=100, default=0)
    win_probability: float = Field(ge=0, le=100, default=0)
    notes: str | None = None


class TenderUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=255)
    client_name: str | None = None
    business_unit: str | None = None
    reference_no: str | None = None
    submission_date: date | None = None
    estimated_value: float | None = Field(default=None, ge=0)
    bid_bond_pct: float | None = Field(default=None, ge=0, le=100)
    win_probability: float | None = Field(default=None, ge=0, le=100)
    notes: str | None = None


class TenderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    title: str
    client_account_id: uuid.UUID | None
    client_name: str | None
    business_unit: str
    reference_no: str | None
    submission_date: date | None
    estimated_value: float
    bid_bond_pct: float
    status: str
    bid_value: float
    win_probability: float
    notes: str | None
    converted_project_id: uuid.UUID | None


# --- Competitors ---
class CompetitorCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    bid_amount: float | None = Field(default=None, ge=0)
    notes: str | None = None


class CompetitorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    bid_amount: float | None
    notes: str | None


# --- Multi-level BOQ ---
class SectionCreate(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=255)
    sort_order: int = 0


class SectionUpdate(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=20)
    name: str | None = Field(default=None, min_length=1, max_length=255)
    sort_order: int | None = None


class DivisionCreate(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=255)
    sort_order: int = 0


class DivisionUpdate(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=20)
    name: str | None = Field(default=None, min_length=1, max_length=255)
    sort_order: int | None = None


class ElementCreate(BaseModel):
    item_code: str = Field(min_length=1, max_length=30)
    description: str = Field(min_length=1)
    unit: str = Field(min_length=1, max_length=20)
    quantity: float = Field(ge=0, default=0)
    unit_rate: float = Field(ge=0, default=0)
    sort_order: int = 0


class ElementUpdate(BaseModel):
    item_code: str | None = Field(default=None, min_length=1, max_length=30)
    description: str | None = None
    unit: str | None = None
    quantity: float | None = Field(default=None, ge=0)
    unit_rate: float | None = Field(default=None, ge=0)
    sort_order: int | None = None


class ElementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    division_id: uuid.UUID
    item_code: str
    description: str
    unit: str
    quantity: float
    unit_rate: float
    amount: float
    sort_order: int


class DivisionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    section_id: uuid.UUID
    code: str
    name: str
    sort_order: int
    elements: list[ElementOut] = []
    subtotal: float = 0


class SectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    tender_id: uuid.UUID
    code: str
    name: str
    sort_order: int
    divisions: list[DivisionOut] = []
    subtotal: float = 0


class BOQTree(BaseModel):
    tender_id: uuid.UUID
    sections: list[SectionOut]
    grand_total: float


# --- Cost estimation ---
class EstimateLineCreate(BaseModel):
    category: str = Field(pattern="^(labour|material|equipment|subcontractor|other)$")
    cost_code: str | None = None
    description: str = Field(min_length=1, max_length=255)
    quantity: float = Field(gt=0, default=1)
    unit_cost: float = Field(ge=0, default=0)


class EstimateLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    category: str
    cost_code: str | None
    description: str
    quantity: float
    unit_cost: float
    line_cost: float


class EstimateCreate(BaseModel):
    title: str = Field(default="Preliminary estimate", max_length=255)
    estimate_type: str = Field(default="preliminary")
    overhead_pct: float = Field(ge=0, le=100, default=0)
    margin_pct: float = Field(ge=0, le=100, default=0)
    lines: list[EstimateLineCreate] = Field(default_factory=list)


class EstimateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    tender_id: uuid.UUID
    version: int
    title: str
    estimate_type: str
    overhead_pct: float
    margin_pct: float
    direct_cost: float
    overhead_amount: float
    total_cost: float
    margin_amount: float
    selling_price: float
    lines: list[EstimateLineOut]


class CategoryBreakdown(BaseModel):
    labour: float
    material: float
    equipment: float
    subcontractor: float
    other: float


# --- Conversion ---
class ConvertResult(BaseModel):
    project_id: uuid.UUID
    project_code: str
    boq_items_created: int


# --- Reports ---
class TenderSummary(BaseModel):
    total_tenders: int
    won_tenders: int
    lost_tenders: int
    pending_tenders: int
    total_pipeline_value: float
    won_value: float
    win_rate: float
