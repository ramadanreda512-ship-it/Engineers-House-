"""Tendering business logic.

Key rules enforced here:
- BOQ element amount = quantity * unit_rate, computed server-side. Section and
  division subtotals and the tender bid_value roll up from the elements.
- Cost estimate build-up is computed server-side:
    direct_cost   = sum of all line costs
    overhead      = direct_cost * overhead_pct
    total_cost    = direct_cost + overhead
    margin        = total_cost * margin_pct
    selling_price = total_cost + margin
- A tender can be marked won/lost; only a 'won' tender can be converted into an
  execution Project, and only once. Conversion copies the multi-level BOQ down
  into the project's flat execution BOQ (one row per priced element).
- Historical/contractual integrity: a converted tender cannot be converted again.
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.modules.tendering import repository as repo
from app.modules.tendering.models import (
    BOQDivision,
    BOQElement,
    BOQSection,
    CostEstimate,
    CostEstimateLine,
    Tender,
    TenderCompetitor,
)
from app.modules.tendering.schemas import (
    CategoryBreakdown,
    CompetitorCreate,
    ConvertResult,
    DivisionCreate,
    DivisionUpdate,
    ElementCreate,
    ElementUpdate,
    EstimateCreate,
    SectionCreate,
    SectionUpdate,
    TenderCreate,
    TenderSummary,
    TenderUpdate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


# --- Tender ---
def create_tender(db: Session, tenant_id: uuid.UUID, body: TenderCreate) -> Tender:
    year = (body.submission_date or date.today()).year
    tender = Tender(
        tenant_id=tenant_id,
        code=repo.next_tender_code(db, tenant_id, year),
        status="draft",
        bid_value=0,
        **body.model_dump(),
    )
    db.add(tender)
    db.commit()
    db.refresh(tender)
    return tender


def get_tender(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID) -> Tender:
    tender = repo.get_tender(db, tenant_id, tender_id)
    if not tender:
        raise NotFound("Tender")
    return tender


def list_tenders(
    db: Session, tenant_id: uuid.UUID, status: str | None, bu: str | None, page: int, size: int
):
    return repo.list_tenders(db, tenant_id, status, bu, size, (page - 1) * size)


def update_tender(
    db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID, body: TenderUpdate
) -> Tender:
    tender = get_tender(db, tenant_id, tender_id)
    if tender.status in ("won", "lost") and tender.converted_project_id:
        raise Conflict("Cannot edit a tender that has been converted to a project")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(tender, field, value)
    db.commit()
    db.refresh(tender)
    return tender


def set_status(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID, status: str) -> Tender:
    valid = {"draft", "submitted", "under_evaluation", "won", "lost", "cancelled"}
    if status not in valid:
        raise BadRequest(f"Invalid status '{status}'")
    tender = get_tender(db, tenant_id, tender_id)
    tender.status = status
    db.commit()
    db.refresh(tender)
    return tender


def delete_tender(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID) -> None:
    tender = get_tender(db, tenant_id, tender_id)
    if tender.converted_project_id:
        raise Conflict(
            "Cannot delete a tender that has been converted to a project. "
            "Cancel it instead to keep the history."
        )
    db.delete(tender)
    db.commit()


# --- Competitors ---
def add_competitor(
    db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID, body: CompetitorCreate
) -> TenderCompetitor:
    get_tender(db, tenant_id, tender_id)
    comp = TenderCompetitor(tenant_id=tenant_id, tender_id=tender_id, **body.model_dump())
    db.add(comp)
    db.commit()
    db.refresh(comp)
    return comp


def list_competitors(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID):
    get_tender(db, tenant_id, tender_id)
    return repo.list_competitors(db, tender_id)


def delete_competitor(db: Session, tenant_id: uuid.UUID, competitor_id: uuid.UUID) -> None:
    comp = repo.get_competitor(db, tenant_id, competitor_id)
    if not comp:
        raise NotFound("Competitor")
    db.delete(comp)
    db.commit()


# --- BOQ tree ---
def _recompute_bid_value(db: Session, tender: Tender) -> None:
    """Roll the sum of all element amounts up into the tender bid_value."""
    elements = repo.all_elements_for_tender(db, tender.id)
    tender.bid_value = _round(sum(float(e.amount) for e in elements))


def add_section(
    db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID, body: SectionCreate
) -> BOQSection:
    get_tender(db, tenant_id, tender_id)
    section = BOQSection(tenant_id=tenant_id, tender_id=tender_id, **body.model_dump())
    db.add(section)
    db.commit()
    db.refresh(section)
    return section


def update_section(
    db: Session, tenant_id: uuid.UUID, section_id: uuid.UUID, body: SectionUpdate
) -> BOQSection:
    section = repo.get_section(db, tenant_id, section_id)
    if not section:
        raise NotFound("Section")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(section, field, value)
    db.commit()
    db.refresh(section)
    return section


def delete_section(db: Session, tenant_id: uuid.UUID, section_id: uuid.UUID) -> None:
    section = repo.get_section(db, tenant_id, section_id)
    if not section:
        raise NotFound("Section")
    tender = repo.get_tender(db, tenant_id, section.tender_id)
    db.delete(section)
    db.flush()
    if tender:
        _recompute_bid_value(db, tender)
    db.commit()


def add_division(
    db: Session, tenant_id: uuid.UUID, section_id: uuid.UUID, body: DivisionCreate
) -> BOQDivision:
    if not repo.get_section(db, tenant_id, section_id):
        raise NotFound("Section")
    div = BOQDivision(tenant_id=tenant_id, section_id=section_id, **body.model_dump())
    db.add(div)
    db.commit()
    db.refresh(div)
    return div


def update_division(
    db: Session, tenant_id: uuid.UUID, division_id: uuid.UUID, body: DivisionUpdate
) -> BOQDivision:
    div = repo.get_division(db, tenant_id, division_id)
    if not div:
        raise NotFound("Division")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(div, field, value)
    db.commit()
    db.refresh(div)
    return div


def delete_division(db: Session, tenant_id: uuid.UUID, division_id: uuid.UUID) -> None:
    div = repo.get_division(db, tenant_id, division_id)
    if not div:
        raise NotFound("Division")
    section = repo.get_section(db, tenant_id, div.section_id)
    tender = repo.get_tender(db, tenant_id, section.tender_id) if section else None
    db.delete(div)
    db.flush()
    if tender:
        _recompute_bid_value(db, tender)
    db.commit()


def add_element(
    db: Session, tenant_id: uuid.UUID, division_id: uuid.UUID, body: ElementCreate
) -> BOQElement:
    div = repo.get_division(db, tenant_id, division_id)
    if not div:
        raise NotFound("Division")
    amount = _round(body.quantity * body.unit_rate)
    element = BOQElement(
        tenant_id=tenant_id, division_id=division_id, amount=amount, **body.model_dump()
    )
    db.add(element)
    db.flush()
    section = repo.get_section(db, tenant_id, div.section_id)
    tender = repo.get_tender(db, tenant_id, section.tender_id) if section else None
    if tender:
        _recompute_bid_value(db, tender)
    db.commit()
    db.refresh(element)
    return element


def update_element(
    db: Session, tenant_id: uuid.UUID, element_id: uuid.UUID, body: ElementUpdate
) -> BOQElement:
    element = repo.get_element(db, tenant_id, element_id)
    if not element:
        raise NotFound("Element")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(element, field, value)
    element.amount = _round(float(element.quantity) * float(element.unit_rate))
    db.flush()
    div = repo.get_division(db, tenant_id, element.division_id)
    section = repo.get_section(db, tenant_id, div.section_id) if div else None
    tender = repo.get_tender(db, tenant_id, section.tender_id) if section else None
    if tender:
        _recompute_bid_value(db, tender)
    db.commit()
    db.refresh(element)
    return element


def delete_element(db: Session, tenant_id: uuid.UUID, element_id: uuid.UUID) -> None:
    element = repo.get_element(db, tenant_id, element_id)
    if not element:
        raise NotFound("Element")
    div = repo.get_division(db, tenant_id, element.division_id)
    section = repo.get_section(db, tenant_id, div.section_id) if div else None
    tender = repo.get_tender(db, tenant_id, section.tender_id) if section else None
    db.delete(element)
    db.flush()
    if tender:
        _recompute_bid_value(db, tender)
    db.commit()


def boq_tree(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID) -> dict:
    get_tender(db, tenant_id, tender_id)
    sections = repo.full_boq_tree(db, tender_id)
    out_sections = []
    grand_total = 0.0
    for s in sorted(sections, key=lambda x: (x.sort_order, x.code)):
        sec_total = 0.0
        out_divs = []
        for d in sorted(s.divisions, key=lambda x: (x.sort_order, x.code)):
            div_total = _round(sum(float(e.amount) for e in d.elements))
            sec_total += div_total
            out_divs.append(
                {
                    "id": d.id,
                    "section_id": d.section_id,
                    "code": d.code,
                    "name": d.name,
                    "sort_order": d.sort_order,
                    "elements": sorted(
                        [
                            {
                                "id": e.id,
                                "division_id": e.division_id,
                                "item_code": e.item_code,
                                "description": e.description,
                                "unit": e.unit,
                                "quantity": float(e.quantity),
                                "unit_rate": float(e.unit_rate),
                                "amount": float(e.amount),
                                "sort_order": e.sort_order,
                            }
                            for e in d.elements
                        ],
                        key=lambda x: (x["sort_order"], x["item_code"]),
                    ),
                    "subtotal": div_total,
                }
            )
        grand_total += sec_total
        out_sections.append(
            {
                "id": s.id,
                "tender_id": s.tender_id,
                "code": s.code,
                "name": s.name,
                "sort_order": s.sort_order,
                "divisions": out_divs,
                "subtotal": _round(sec_total),
            }
        )
    return {
        "tender_id": tender_id,
        "sections": out_sections,
        "grand_total": _round(grand_total),
    }


# --- Cost estimation ---
def _compute_estimate(estimate: CostEstimate, lines: list[CostEstimateLine]) -> None:
    direct = _round(sum(float(line_.line_cost) for line_ in lines))
    overhead = _round(direct * (float(estimate.overhead_pct) / 100.0))
    total = _round(direct + overhead)
    margin = _round(total * (float(estimate.margin_pct) / 100.0))
    estimate.direct_cost = direct
    estimate.overhead_amount = overhead
    estimate.total_cost = total
    estimate.margin_amount = margin
    estimate.selling_price = _round(total + margin)


def create_estimate(
    db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID, body: EstimateCreate
) -> CostEstimate:
    get_tender(db, tenant_id, tender_id)
    estimate = CostEstimate(
        tenant_id=tenant_id,
        tender_id=tender_id,
        version=repo.next_estimate_version(db, tender_id),
        title=body.title,
        estimate_type=body.estimate_type,
        overhead_pct=body.overhead_pct,
        margin_pct=body.margin_pct,
    )
    db.add(estimate)
    db.flush()
    line_objs = []
    for line_ in body.lines:
        obj = CostEstimateLine(
            estimate_id=estimate.id,
            category=line_.category,
            cost_code=line_.cost_code,
            description=line_.description,
            quantity=line_.quantity,
            unit_cost=line_.unit_cost,
            line_cost=_round(line_.quantity * line_.unit_cost),
        )
        db.add(obj)
        line_objs.append(obj)
    _compute_estimate(estimate, line_objs)
    db.commit()
    db.refresh(estimate)
    return estimate


def list_estimates(db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID):
    get_tender(db, tenant_id, tender_id)
    return repo.list_estimates(db, tender_id)


def get_estimate(db: Session, tenant_id: uuid.UUID, estimate_id: uuid.UUID) -> CostEstimate:
    estimate = repo.get_estimate(db, tenant_id, estimate_id)
    if not estimate:
        raise NotFound("Estimate")
    return estimate


def estimate_breakdown(
    db: Session, tenant_id: uuid.UUID, estimate_id: uuid.UUID
) -> CategoryBreakdown:
    estimate = get_estimate(db, tenant_id, estimate_id)
    totals = {"labour": 0.0, "material": 0.0, "equipment": 0.0, "subcontractor": 0.0, "other": 0.0}
    for line_ in estimate.lines:
        totals[line_.category] = totals.get(line_.category, 0.0) + float(line_.line_cost)
    return CategoryBreakdown(**{k: _round(v) for k, v in totals.items()})


def delete_estimate(db: Session, tenant_id: uuid.UUID, estimate_id: uuid.UUID) -> None:
    estimate = get_estimate(db, tenant_id, estimate_id)
    db.delete(estimate)
    db.commit()


# --- Conversion to project ---
def convert_to_project(
    db: Session, tenant_id: uuid.UUID, tender_id: uuid.UUID
) -> ConvertResult:
    """Convert a won tender into an execution Project, copying the multi-level
    BOQ down into the project's flat execution BOQ. Idempotent guard: a tender
    can only be converted once."""
    from app.modules.projects.models import BOQItem, Project
    from app.modules.projects.repository import get_project  # noqa: F401

    tender = get_tender(db, tenant_id, tender_id)
    if tender.status != "won":
        raise Conflict("Only a tender marked 'won' can be converted to a project")
    if tender.converted_project_id:
        raise Conflict("This tender has already been converted to a project")

    # Generate a project code based on the tender code.
    project_code = tender.code.replace("TND-", "PRJ-")
    project = Project(
        tenant_id=tenant_id,
        account_id=tender.client_account_id,
        code=project_code,
        name=tender.title,
        contract_value=_round(float(tender.bid_value)),
        retention_pct=10,
        status="planned",
    )
    db.add(project)
    db.flush()

    # Copy every priced BOQ element into a flat project BOQ item.
    # Project BOQ items are unique per (project, item_code), so de-duplicate
    # by suffixing any repeated codes.
    elements = repo.all_elements_for_tender(db, tender_id)
    created = 0
    seen_codes: set[str] = set()
    for e in elements:
        code = e.item_code
        if code in seen_codes:
            suffix = 2
            while f"{code}-{suffix}" in seen_codes:
                suffix += 1
            code = f"{code}-{suffix}"
        seen_codes.add(code)
        db.add(
            BOQItem(
                project_id=project.id,
                item_code=code,
                description=e.description[:500] if e.description else code,
                unit=e.unit,
                planned_qty=float(e.quantity),
                unit_rate=float(e.unit_rate),
                executed_qty=0,
            )
        )
        created += 1

    tender.converted_project_id = project.id
    db.commit()
    db.refresh(project)
    return ConvertResult(
        project_id=project.id, project_code=project.code, boq_items_created=created
    )


# --- Reports ---
def tender_summary(db: Session, tenant_id: uuid.UUID) -> TenderSummary:
    total = repo.count_tenders(db, tenant_id)
    won = repo.count_tenders(db, tenant_id, "won")
    lost = repo.count_tenders(db, tenant_id, "lost")
    pending = total - won - lost
    win_rate = _round(won / (won + lost) * 100.0) if (won + lost) > 0 else 0.0
    return TenderSummary(
        total_tenders=total,
        won_tenders=won,
        lost_tenders=lost,
        pending_tenders=pending,
        total_pipeline_value=_round(repo.sum_tender_value(db, tenant_id)),
        won_value=_round(repo.sum_tender_value(db, tenant_id, "won")),
        win_rate=win_rate,
    )
