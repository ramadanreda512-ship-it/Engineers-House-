"""HR models: employees, leave requests, and payroll entries.

Design notes:
- An Employee has a unique employee code per tenant, a department/title, a
  hire date, and a base salary.
- A LeaveRequest is approval-gated: it starts 'pending' and an HR manager
  approves or rejects it. Approved annual-leave days decrement the employee's
  remaining balance in the same transaction.
- A PayrollEntry is a monthly salary record (base + allowances - deductions =
  net), computed server-side.
"""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Employee(Base, TimestampMixin):
    __tablename__ = "employees"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_employee_tenant_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(40))
    full_name: Mapped[str] = mapped_column(String(255))
    department: Mapped[str | None] = mapped_column(String(80), nullable=True)
    job_title: Mapped[str | None] = mapped_column(String(120), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    hire_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    base_salary: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    annual_leave_balance: Mapped[int] = mapped_column(Integer, default=21)
    # active / on_leave / terminated
    status: Mapped[str] = mapped_column(String(20), default="active")

    leave_requests: Mapped[list[LeaveRequest]] = relationship(
        back_populates="employee", cascade="all, delete-orphan"
    )
    payroll_entries: Mapped[list[PayrollEntry]] = relationship(
        back_populates="employee", cascade="all, delete-orphan"
    )


class LeaveRequest(Base, TimestampMixin):
    __tablename__ = "leave_requests"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    employee_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("employees.id", ondelete="CASCADE")
    )
    leave_type: Mapped[str] = mapped_column(String(20), default="annual")  # annual/sick/unpaid
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    days: Mapped[int] = mapped_column(Integer)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    # pending / approved / rejected
    status: Mapped[str] = mapped_column(String(20), default="pending")

    employee: Mapped[Employee] = relationship(back_populates="leave_requests")


class PayrollEntry(Base, TimestampMixin):
    __tablename__ = "payroll_entries"

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    employee_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("employees.id", ondelete="CASCADE")
    )
    period: Mapped[str] = mapped_column(String(7))  # YYYY-MM
    base_salary: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    allowances: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    deductions: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    net_pay: Mapped[float] = mapped_column(Numeric(14, 2), default=0)  # computed

    employee: Mapped[Employee] = relationship(back_populates="payroll_entries")
