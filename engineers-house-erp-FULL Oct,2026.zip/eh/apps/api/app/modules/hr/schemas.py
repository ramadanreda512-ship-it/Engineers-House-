"""HR request/response schemas."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


# --- Employees ---
class EmployeeCreate(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    full_name: str = Field(min_length=1, max_length=255)
    department: str | None = None
    job_title: str | None = None
    email: str | None = None
    phone: str | None = None
    hire_date: date | None = None
    base_salary: float = Field(ge=0, default=0)
    annual_leave_balance: int = Field(ge=0, default=21)


class EmployeeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    full_name: str
    department: str | None
    job_title: str | None
    email: str | None
    phone: str | None
    hire_date: date | None
    base_salary: float
    annual_leave_balance: int
    status: str


class EmployeeUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    department: str | None = None
    job_title: str | None = None
    email: str | None = None
    phone: str | None = None
    base_salary: float | None = Field(default=None, ge=0)
    annual_leave_balance: int | None = Field(default=None, ge=0)
    status: str | None = None


# --- Leave requests ---
class LeaveCreate(BaseModel):
    employee_id: uuid.UUID
    leave_type: str = Field(default="annual")
    start_date: date
    end_date: date
    reason: str | None = None


class LeaveOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    employee_id: uuid.UUID
    leave_type: str
    start_date: date
    end_date: date
    days: int
    reason: str | None
    status: str


# --- Payroll ---
class PayrollCreate(BaseModel):
    employee_id: uuid.UUID
    period: str = Field(pattern=r"^\d{4}-\d{2}$")  # YYYY-MM
    allowances: float = Field(ge=0, default=0)
    deductions: float = Field(ge=0, default=0)


class PayrollOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    employee_id: uuid.UUID
    period: str
    base_salary: float
    allowances: float
    deductions: float
    net_pay: float


# --- Reports ---
class HrSummary(BaseModel):
    total_employees: int
    active_employees: int
    pending_leave_requests: int
    total_monthly_payroll: float
