"""Tenant-scoped data access for HR entities."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.hr.models import Employee, LeaveRequest, PayrollEntry


def get_employee(db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID) -> Employee | None:
    return db.scalar(
        select(Employee).where(Employee.id == employee_id, Employee.tenant_id == tenant_id)
    )


def code_exists(db: Session, tenant_id: uuid.UUID, code: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(Employee)
            .where(Employee.tenant_id == tenant_id, Employee.code == code)
        )
        or 0
    ) > 0


def list_employees(db: Session, tenant_id: uuid.UUID, limit: int, offset: int):
    stmt = (
        select(Employee).where(Employee.tenant_id == tenant_id).order_by(Employee.full_name.asc())
    )
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(
        select(func.count()).select_from(Employee).where(Employee.tenant_id == tenant_id)
    )
    return items, total or 0


def employee_has_payroll(db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(PayrollEntry)
            .where(
                PayrollEntry.tenant_id == tenant_id,
                PayrollEntry.employee_id == employee_id,
            )
        )
        or 0
    ) > 0


def get_leave(db: Session, tenant_id: uuid.UUID, leave_id: uuid.UUID) -> LeaveRequest | None:
    return db.scalar(
        select(LeaveRequest).where(
            LeaveRequest.id == leave_id, LeaveRequest.tenant_id == tenant_id
        )
    )


def list_leaves(
    db: Session, tenant_id: uuid.UUID, status: str | None, limit: int, offset: int
):
    conds = [LeaveRequest.tenant_id == tenant_id]
    if status:
        conds.append(LeaveRequest.status == status)
    stmt = select(LeaveRequest).where(*conds).order_by(LeaveRequest.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(LeaveRequest).where(*conds))
    return items, total or 0


def list_payroll(db: Session, tenant_id: uuid.UUID, period: str | None, limit: int, offset: int):
    conds = [PayrollEntry.tenant_id == tenant_id]
    if period:
        conds.append(PayrollEntry.period == period)
    stmt = select(PayrollEntry).where(*conds).order_by(PayrollEntry.period.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(PayrollEntry).where(*conds))
    return items, total or 0


def payroll_exists(db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID, period: str) -> bool:
    return (
        db.scalar(
            select(func.count())
            .select_from(PayrollEntry)
            .where(
                PayrollEntry.tenant_id == tenant_id,
                PayrollEntry.employee_id == employee_id,
                PayrollEntry.period == period,
            )
        )
        or 0
    ) > 0


# --- Aggregates ---
def count_employees(db: Session, tenant_id: uuid.UUID, status: str | None = None) -> int:
    conds = [Employee.tenant_id == tenant_id]
    if status:
        conds.append(Employee.status == status)
    return int(db.scalar(select(func.count()).select_from(Employee).where(*conds)) or 0)


def count_pending_leaves(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(
            select(func.count())
            .select_from(LeaveRequest)
            .where(LeaveRequest.tenant_id == tenant_id, LeaveRequest.status == "pending")
        )
        or 0
    )


def sum_monthly_payroll(db: Session, tenant_id: uuid.UUID) -> float:
    val = db.scalar(
        select(func.coalesce(func.sum(Employee.base_salary), 0)).where(
            Employee.tenant_id == tenant_id, Employee.status == "active"
        )
    )
    return float(val or 0)
