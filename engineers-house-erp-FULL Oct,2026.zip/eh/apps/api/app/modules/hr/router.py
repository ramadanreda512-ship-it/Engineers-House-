"""HR HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.hr import service
from app.modules.hr.schemas import (
    EmployeeCreate,
    EmployeeOut,
    EmployeeUpdate,
    HrSummary,
    LeaveCreate,
    LeaveOut,
    PayrollCreate,
    PayrollOut,
)
from app.modules.identity.models import User
from app.shared.pagination import Page

router = APIRouter(prefix="/hr", tags=["hr"])


# --- Employees ---
@router.post("/employees", response_model=EmployeeOut, status_code=201)
def create_employee(
    body: EmployeeCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.manage")),
):
    return service.create_employee(db, user.tenant_id, body)


@router.get("/employees", response_model=Page[EmployeeOut])
def list_employees(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.view")),
):
    items, total = service.list_employees(db, user.tenant_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.get("/employees/{employee_id}", response_model=EmployeeOut)
def get_employee(
    employee_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.view")),
):
    return service.get_employee(db, user.tenant_id, employee_id)


@router.patch("/employees/{employee_id}", response_model=EmployeeOut)
def update_employee(
    employee_id: uuid.UUID,
    body: EmployeeUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.manage")),
):
    return service.update_employee(db, user.tenant_id, employee_id, body)


@router.delete("/employees/{employee_id}", status_code=204)
def delete_employee(
    employee_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.manage")),
):
    service.delete_employee(db, user.tenant_id, employee_id)


# --- Leave requests ---
@router.post("/leaves", response_model=LeaveOut, status_code=201)
def request_leave(
    body: LeaveCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.leave.request")),
):
    return service.request_leave(db, user.tenant_id, body)


@router.get("/leaves", response_model=Page[LeaveOut])
def list_leaves(
    status: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.view")),
):
    items, total = service.list_leaves(db, user.tenant_id, status, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/leaves/{leave_id}/approve", response_model=LeaveOut)
def approve_leave(
    leave_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.leave.approve")),
):
    return service.decide_leave(db, user.tenant_id, leave_id, approve=True)


@router.post("/leaves/{leave_id}/reject", response_model=LeaveOut)
def reject_leave(
    leave_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.leave.approve")),
):
    return service.decide_leave(db, user.tenant_id, leave_id, approve=False)


# --- Payroll ---
@router.post("/payroll", response_model=PayrollOut, status_code=201)
def create_payroll(
    body: PayrollCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.payroll.manage")),
):
    return service.create_payroll(db, user.tenant_id, body)


@router.get("/payroll", response_model=Page[PayrollOut])
def list_payroll(
    period: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.payroll.manage")),
):
    items, total = service.list_payroll(db, user.tenant_id, period, page, size)
    return Page(items=items, total=total, page=page, size=size)


# --- Reports ---
@router.get("/summary", response_model=HrSummary)
def hr_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("hr.employee.view")),
):
    return service.hr_summary(db, user.tenant_id)
