"""HR business logic.

Key rules enforced here:
- Employee codes are unique per tenant.
- Leave duration (days) is computed server-side from start/end dates, and an
  annual-leave request cannot exceed the employee's remaining balance.
- Approving an annual-leave request decrements the balance in the same
  transaction; a request can only be acted on once (no double approve/reject).
- Payroll net pay is computed server-side (base + allowances - deductions) and
  is unique per employee per period.
"""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.modules.hr import repository as repo
from app.modules.hr.models import Employee, LeaveRequest, PayrollEntry
from app.modules.hr.schemas import (
    EmployeeCreate,
    EmployeeUpdate,
    HrSummary,
    LeaveCreate,
    PayrollCreate,
)
from app.shared.exceptions import BadRequest, Conflict, NotFound


def _round(x: float) -> float:
    return round(float(x), 2)


# --- Employees ---
def create_employee(db: Session, tenant_id: uuid.UUID, body: EmployeeCreate) -> Employee:
    if repo.code_exists(db, tenant_id, body.code):
        raise Conflict(f"Employee code '{body.code}' already exists")
    employee = Employee(tenant_id=tenant_id, status="active", **body.model_dump())
    db.add(employee)
    db.commit()
    db.refresh(employee)
    return employee


def list_employees(db: Session, tenant_id: uuid.UUID, page: int, size: int):
    return repo.list_employees(db, tenant_id, size, (page - 1) * size)


def get_employee(db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID) -> Employee:
    employee = repo.get_employee(db, tenant_id, employee_id)
    if not employee:
        raise NotFound("Employee")
    return employee


def update_employee(
    db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID, body: EmployeeUpdate
) -> Employee:
    employee = get_employee(db, tenant_id, employee_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(employee, field, value)
    db.commit()
    db.refresh(employee)
    return employee


def delete_employee(db: Session, tenant_id: uuid.UUID, employee_id: uuid.UUID) -> None:
    employee = get_employee(db, tenant_id, employee_id)
    if repo.employee_has_payroll(db, tenant_id, employee_id):
        raise Conflict(
            "Cannot delete an employee who has payroll records. Set their status "
            "to 'terminated' via update instead to keep payroll history."
        )
    db.delete(employee)
    db.commit()


# --- Leave requests ---
def request_leave(db: Session, tenant_id: uuid.UUID, body: LeaveCreate) -> LeaveRequest:
    employee = repo.get_employee(db, tenant_id, body.employee_id)
    if not employee:
        raise NotFound("Employee")
    if body.end_date < body.start_date:
        raise BadRequest("End date cannot be before start date")
    days = (body.end_date - body.start_date).days + 1
    if body.leave_type == "annual" and days > employee.annual_leave_balance:
        raise BadRequest(
            f"Requested {days} days exceeds remaining balance "
            f"({employee.annual_leave_balance})"
        )
    leave = LeaveRequest(
        tenant_id=tenant_id,
        employee_id=body.employee_id,
        leave_type=body.leave_type,
        start_date=body.start_date,
        end_date=body.end_date,
        days=days,
        reason=body.reason,
        status="pending",
    )
    db.add(leave)
    db.commit()
    db.refresh(leave)
    return leave


def list_leaves(db: Session, tenant_id: uuid.UUID, status: str | None, page: int, size: int):
    return repo.list_leaves(db, tenant_id, status, size, (page - 1) * size)


def decide_leave(
    db: Session, tenant_id: uuid.UUID, leave_id: uuid.UUID, approve: bool
) -> LeaveRequest:
    leave = repo.get_leave(db, tenant_id, leave_id)
    if not leave:
        raise NotFound("Leave request")
    if leave.status != "pending":
        raise Conflict(f"Leave request is already {leave.status}")

    if approve:
        leave.status = "approved"
        if leave.leave_type == "annual":
            employee = repo.get_employee(db, tenant_id, leave.employee_id)
            if employee:
                if leave.days > employee.annual_leave_balance:
                    raise BadRequest("Insufficient leave balance to approve")
                employee.annual_leave_balance -= leave.days
    else:
        leave.status = "rejected"

    db.commit()
    db.refresh(leave)
    return leave


# --- Payroll ---
def create_payroll(db: Session, tenant_id: uuid.UUID, body: PayrollCreate) -> PayrollEntry:
    employee = repo.get_employee(db, tenant_id, body.employee_id)
    if not employee:
        raise NotFound("Employee")
    if repo.payroll_exists(db, tenant_id, body.employee_id, body.period):
        raise Conflict(
            f"Payroll for {employee.full_name} in {body.period} already exists"
        )
    base = float(employee.base_salary)
    net = _round(base + body.allowances - body.deductions)
    if net < 0:
        raise BadRequest("Deductions cannot exceed base salary plus allowances")
    entry = PayrollEntry(
        tenant_id=tenant_id,
        employee_id=body.employee_id,
        period=body.period,
        base_salary=base,
        allowances=body.allowances,
        deductions=body.deductions,
        net_pay=net,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def list_payroll(db: Session, tenant_id: uuid.UUID, period: str | None, page: int, size: int):
    return repo.list_payroll(db, tenant_id, period, size, (page - 1) * size)


# --- Reports ---
def hr_summary(db: Session, tenant_id: uuid.UUID) -> HrSummary:
    return HrSummary(
        total_employees=repo.count_employees(db, tenant_id),
        active_employees=repo.count_employees(db, tenant_id, "active"),
        pending_leave_requests=repo.count_pending_leaves(db, tenant_id),
        total_monthly_payroll=_round(repo.sum_monthly_payroll(db, tenant_id)),
    )
