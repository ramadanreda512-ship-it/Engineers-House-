"""CRM Pydantic schemas."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field

from app.shared.enums import AccountType, OpportunityStage, QuotationStatus

# Customer classification options (business category).
CLASSIFICATIONS = (
    "lead", "prospect", "client", "supplier", "partner", "contractor",
    "consultant", "factory", "government", "training_client",
    "maintenance_client", "automation_client",
)


# --- Accounts ---
class AccountCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    name_en: str | None = None
    company_name: str | None = None
    type: AccountType = AccountType.LEAD
    classification: str | None = None
    industry: str | None = None
    activity: str | None = None
    source: str | None = None
    country: str | None = None
    governorate: str | None = None
    city: str | None = None
    address: str | None = None
    gps: str | None = None
    phone: str | None = None
    email: str | None = None
    whatsapp: str | None = None
    website: str | None = None
    linkedin: str | None = None
    tax_number: str | None = None
    commercial_reg: str | None = None
    credit_limit: float = Field(default=0, ge=0)
    payment_terms_days: int = Field(default=0, ge=0)
    currency: str = "EGP"
    sales_engineer: str | None = None
    score: int = Field(default=0, ge=0, le=100)
    health: str | None = None
    notes: str | None = None


class AccountUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    name_en: str | None = None
    company_name: str | None = None
    type: AccountType | None = None
    classification: str | None = None
    industry: str | None = None
    activity: str | None = None
    source: str | None = None
    country: str | None = None
    governorate: str | None = None
    city: str | None = None
    address: str | None = None
    gps: str | None = None
    phone: str | None = None
    email: str | None = None
    whatsapp: str | None = None
    website: str | None = None
    linkedin: str | None = None
    tax_number: str | None = None
    commercial_reg: str | None = None
    credit_limit: float | None = Field(default=None, ge=0)
    payment_terms_days: int | None = Field(default=None, ge=0)
    currency: str | None = None
    sales_engineer: str | None = None
    score: int | None = Field(default=None, ge=0, le=100)
    health: str | None = None
    is_active: bool | None = None
    notes: str | None = None


class AccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str | None = None
    name: str
    name_en: str | None = None
    company_name: str | None = None
    type: AccountType
    classification: str | None = None
    industry: str | None = None
    activity: str | None = None
    source: str | None = None
    country: str | None = None
    governorate: str | None = None
    city: str | None = None
    address: str | None = None
    gps: str | None = None
    phone: str | None = None
    email: str | None = None
    whatsapp: str | None = None
    website: str | None = None
    linkedin: str | None = None
    tax_number: str | None = None
    commercial_reg: str | None = None
    credit_limit: float = 0
    payment_terms_days: int = 0
    currency: str = "EGP"
    sales_engineer: str | None = None
    score: int = 0
    health: str | None = None
    is_active: bool = True
    notes: str | None = None


# --- Contacts ---
class ContactCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    email: str | None = None
    phone: str | None = None
    whatsapp: str | None = None
    position: str | None = None
    department: str | None = None
    is_decision_maker: bool = False
    is_primary: bool = False


class ContactOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    name: str
    email: str | None = None
    phone: str | None = None
    whatsapp: str | None = None
    position: str | None = None
    department: str | None = None
    is_decision_maker: bool = False
    is_primary: bool = False


# --- Activities (timeline) ---
class ActivityCreate(BaseModel):
    activity_type: str = Field(
        pattern="^(call|meeting|site_visit|task|note|email)$", default="note"
    )
    subject: str = Field(min_length=1, max_length=255)
    body: str | None = None
    activity_date: datetime | None = None
    due_date: date | None = None


class ActivityUpdate(BaseModel):
    subject: str | None = Field(default=None, min_length=1, max_length=255)
    body: str | None = None
    due_date: date | None = None
    is_done: bool | None = None


class ActivityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    activity_type: str
    subject: str
    body: str | None = None
    activity_date: datetime
    due_date: date | None = None
    is_done: bool = False


# --- Opportunities ---
class OpportunityCreate(BaseModel):
    account_id: uuid.UUID
    title: str = Field(min_length=2, max_length=255)
    stage: OpportunityStage = OpportunityStage.NEW
    value: float = 0
    currency: str = "USD"
    probability: int = Field(default=0, ge=0, le=100)
    expected_close: date | None = None


class OpportunityUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=255)
    stage: OpportunityStage | None = None
    value: float | None = Field(default=None, ge=0)
    probability: int | None = Field(default=None, ge=0, le=100)
    expected_close: date | None = None
    loss_reason: str | None = None
    competitor: str | None = None


class OpportunityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    title: str
    stage: OpportunityStage
    value: float
    currency: str
    probability: int
    expected_close: date | None = None
    loss_reason: str | None = None
    competitor: str | None = None


# --- Quotations ---
class QuotationLineIn(BaseModel):
    product_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=255)
    unit: str | None = None
    qty: float = Field(gt=0)
    unit_price: float = Field(ge=0)
    discount_pct: float = Field(default=0, ge=0, le=100)


class QuotationLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    product_id: uuid.UUID | None = None
    description: str
    unit: str | None = None
    qty: float
    unit_price: float
    discount_pct: float = 0
    line_total: float


class QuotationCreate(BaseModel):
    account_id: uuid.UUID
    opportunity_id: uuid.UUID | None = None
    title: str | None = None
    valid_until: date | None = None
    currency: str = Field(default="EGP", max_length=3)
    discount_amount: float = Field(default=0, ge=0)
    tax_rate: float = Field(default=0.0, ge=0, le=1)
    payment_terms: str | None = None
    delivery_period: str | None = None
    terms: str | None = None
    notes: str | None = None
    prepared_by: str | None = None
    lines: list[QuotationLineIn] = Field(min_length=1)


class QuotationUpdate(BaseModel):
    title: str | None = None
    valid_until: date | None = None
    discount_amount: float | None = Field(default=None, ge=0)
    tax_rate: float | None = Field(default=None, ge=0, le=1)
    payment_terms: str | None = None
    delivery_period: str | None = None
    terms: str | None = None
    notes: str | None = None
    prepared_by: str | None = None
    lines: list[QuotationLineIn] | None = None


class QuotationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    account_id: uuid.UUID
    opportunity_id: uuid.UUID | None = None
    number: str
    status: QuotationStatus
    title: str | None = None
    valid_until: date | None = None
    currency: str = "EGP"
    gross_total: float = 0
    line_discount_total: float = 0
    discount_amount: float = 0
    subtotal: float
    tax_rate: float = 0
    tax: float
    total: float
    payment_terms: str | None = None
    delivery_period: str | None = None
    terms: str | None = None
    notes: str | None = None
    prepared_by: str | None = None
    lines: list[QuotationLineOut] = []


class QuotationPrint(BaseModel):
    """Everything a printable quotation page needs, in one call."""
    quotation: QuotationOut
    account_name: str
    account_name_en: str | None = None
    account_address: str | None = None
    account_phone: str | None = None
    account_email: str | None = None
    account_tax_number: str | None = None
    contact_name: str | None = None


# --- CRM dashboard summary ---
class CrmSummary(BaseModel):
    total_accounts: int
    by_type: dict[str, int]
    by_classification: dict[str, int]
    open_pipeline_value: float
    won_value: float
    quotation_total: float


# --- Pipeline (sales funnel) ---
class PipelineCard(BaseModel):
    id: uuid.UUID
    title: str
    account_id: uuid.UUID
    account_name: str
    value: float
    probability: int
    expected_close: date | None = None
    loss_reason: str | None = None
    competitor: str | None = None


class PipelineStageCol(BaseModel):
    stage: str
    count: int
    total_value: float
    items: list[PipelineCard]


class PipelineOut(BaseModel):
    stages: list[PipelineStageCol]
    open_total: float
    weighted_forecast: float
    won_total: float
    lost_total: float


# --- Customer 360 ---
class Account360(BaseModel):
    account_id: uuid.UUID
    projects_count: int
    projects_value: float
    invoices_count: int
    invoices_total: float
    invoices_paid: float
    invoices_balance: float
    quotations_count: int
    quotations_total: float
    open_opportunities: int
    open_opportunities_value: float
    won_value: float
    students_count: int
    training_fees: float
    activities_count: int


class AccountsExport(BaseModel):
    filename: str
    content: str



class LoseOpportunityBody(BaseModel):
    loss_reason: str = Field(min_length=2, max_length=255)
    competitor: str | None = None



# --- Sales catalogue (products / services) ---
class ProductCreate(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=255)
    name_en: str | None = None
    category: str | None = None
    unit: str = Field(default="piece", max_length=40)
    unit_price: float = Field(ge=0, default=0)
    unit_cost: float = Field(ge=0, default=0)
    currency: str = Field(default="EGP", max_length=3)
    description: str | None = None


class ProductUpdate(BaseModel):
    code: str | None = Field(default=None, min_length=1, max_length=40)
    name: str | None = Field(default=None, min_length=1, max_length=255)
    name_en: str | None = None
    category: str | None = None
    unit: str | None = None
    unit_price: float | None = Field(default=None, ge=0)
    unit_cost: float | None = Field(default=None, ge=0)
    description: str | None = None
    is_active: bool | None = None


class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    code: str
    name: str
    name_en: str | None = None
    category: str | None = None
    unit: str
    unit_price: float
    unit_cost: float = 0
    currency: str
    description: str | None = None
    is_active: bool


# --- Loss analysis (why we lose, and to whom) ---
class LossReasonRow(BaseModel):
    reason: str
    count: int
    value: float
    pct: float


class CompetitorRow(BaseModel):
    competitor: str
    count: int
    value: float


class LossAnalysis(BaseModel):
    won_count: int
    lost_count: int
    open_count: int
    won_value: float
    lost_value: float
    win_rate_pct: float
    avg_won_value: float
    avg_lost_value: float
    by_reason: list[LossReasonRow] = []
    by_competitor: list[CompetitorRow] = []


# --- Follow-up centre (who to call today) ---
class FollowUpItem(BaseModel):
    kind: str  # activity | stale_opportunity
    id: uuid.UUID
    account_id: uuid.UUID
    account_name: str
    account_phone: str | None = None
    account_whatsapp: str | None = None
    subject: str
    due_date: date | None = None
    days_overdue: int = 0
    activity_type: str | None = None
    value: float = 0
    stage: str | None = None


class FollowUpBoard(BaseModel):
    due_today: list[FollowUpItem] = []
    overdue: list[FollowUpItem] = []
    upcoming: list[FollowUpItem] = []
    stale_opportunities: list[FollowUpItem] = []
    due_today_count: int = 0
    overdue_count: int = 0
    stale_count: int = 0
