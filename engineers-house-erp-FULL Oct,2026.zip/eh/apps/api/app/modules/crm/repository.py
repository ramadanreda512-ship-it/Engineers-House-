"""Tenant-scoped data access for CRM entities."""
from __future__ import annotations

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.modules.crm.models import Account, Activity, Opportunity, Quotation


def get_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> Account | None:
    return db.scalar(
        select(Account).where(Account.id == account_id, Account.tenant_id == tenant_id)
    )


def account_count(db: Session, tenant_id: uuid.UUID) -> int:
    return int(
        db.scalar(select(func.count()).select_from(Account).where(Account.tenant_id == tenant_id))
        or 0
    )


def account_has_dependents(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> bool:
    """True if any opportunity or quotation references this account."""
    opp = db.scalar(
        select(func.count())
        .select_from(Opportunity)
        .where(Opportunity.tenant_id == tenant_id, Opportunity.account_id == account_id)
    )
    quo = db.scalar(
        select(func.count())
        .select_from(Quotation)
        .where(Quotation.tenant_id == tenant_id, Quotation.account_id == account_id)
    )
    return (opp or 0) > 0 or (quo or 0) > 0


def get_opportunity(db: Session, tenant_id: uuid.UUID, opp_id: uuid.UUID) -> Opportunity | None:
    return db.scalar(
        select(Opportunity).where(Opportunity.id == opp_id, Opportunity.tenant_id == tenant_id)
    )


def list_accounts(
    db: Session,
    tenant_id: uuid.UUID,
    limit: int,
    offset: int,
    search: str | None = None,
    type_filter: str | None = None,
    classification: str | None = None,
    health: str | None = None,
    sort: str = "newest",
):
    conds = [Account.tenant_id == tenant_id]
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(Account.name).like(like)
            | func.lower(func.coalesce(Account.name_en, "")).like(like)
            | func.lower(func.coalesce(Account.company_name, "")).like(like)
            | func.lower(func.coalesce(Account.code, "")).like(like)
            | func.lower(func.coalesce(Account.phone, "")).like(like)
            | func.lower(func.coalesce(Account.email, "")).like(like)
        )
    if type_filter:
        conds.append(Account.type == type_filter)
    if classification:
        conds.append(Account.classification == classification)
    if health:
        conds.append(Account.health == health)

    order = {
        "newest": Account.created_at.desc(),
        "oldest": Account.created_at.asc(),
        "name": Account.name.asc(),
        "score": Account.score.desc(),
    }.get(sort, Account.created_at.desc())

    stmt = select(Account).where(*conds).order_by(order)
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Account).where(*conds))
    return items, total or 0


# --- Activities ---
def get_activity(db: Session, tenant_id: uuid.UUID, activity_id: uuid.UUID):
    return db.scalar(
        select(Activity).where(Activity.id == activity_id, Activity.tenant_id == tenant_id)
    )


def list_activities(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID):
    return db.scalars(
        select(Activity)
        .where(Activity.tenant_id == tenant_id, Activity.account_id == account_id)
        .order_by(Activity.activity_date.desc())
    ).all()


def list_opportunities(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID | None, limit: int, offset: int
):
    conds = [Opportunity.tenant_id == tenant_id]
    if account_id:
        conds.append(Opportunity.account_id == account_id)
    stmt = select(Opportunity).where(*conds).order_by(Opportunity.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Opportunity).where(*conds))
    return items, total or 0


def list_quotations(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID | None, limit: int, offset: int
):
    conds = [Quotation.tenant_id == tenant_id]
    if account_id:
        conds.append(Quotation.account_id == account_id)
    stmt = select(Quotation).where(*conds).order_by(Quotation.created_at.desc())
    items = db.scalars(stmt.limit(limit).offset(offset)).all()
    total = db.scalar(select(func.count()).select_from(Quotation).where(*conds))
    return items, total or 0


def next_quotation_number(db: Session, tenant_id: uuid.UUID, year: int) -> str:
    count = db.scalar(
        select(func.count()).select_from(Quotation).where(Quotation.tenant_id == tenant_id)
    )
    return f"Q-{year}-{(count or 0) + 1:04d}"


def get_quotation(db: Session, tenant_id: uuid.UUID, quotation_id: uuid.UUID) -> Quotation | None:
    return db.scalar(
        select(Quotation).where(
            Quotation.id == quotation_id, Quotation.tenant_id == tenant_id
        )
    )
