"""CRM models: accounts, contacts, opportunities, quotations."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.shared.base_model import GUID, Base, TimestampMixin


class Account(Base, TimestampMixin):
    """Enterprise customer/account profile (Salesforce-style).

    Keeps the original lightweight fields (name, type, industry, source,
    owner_id) for backward compatibility, and adds a full professional profile:
    bilingual names, an auto-generated code, classification, full address,
    legal/tax identifiers, commercial terms, and a sales-health score.
    """

    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_account_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)

    # --- Identity ---
    code: Mapped[str | None] = mapped_column(String(20), nullable=True)  # CUST-0001
    name: Mapped[str] = mapped_column(String(255))  # primary/display name
    name_en: Mapped[str | None] = mapped_column(String(255), nullable=True)
    company_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # --- Classification ---
    # type kept for compatibility (lead/prospect/client...). classification adds
    # the richer business category from the prompt.
    type: Mapped[str] = mapped_column(String(20), default="lead")
    classification: Mapped[str | None] = mapped_column(String(30), nullable=True)
    industry: Mapped[str | None] = mapped_column(String(120), nullable=True)
    activity: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source: Mapped[str | None] = mapped_column(String(120), nullable=True)

    # --- Address ---
    country: Mapped[str | None] = mapped_column(String(80), nullable=True)
    governorate: Mapped[str | None] = mapped_column(String(120), nullable=True)
    city: Mapped[str | None] = mapped_column(String(120), nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    gps: Mapped[str | None] = mapped_column(String(120), nullable=True)

    # --- Communication ---
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    whatsapp: Mapped[str | None] = mapped_column(String(40), nullable=True)
    website: Mapped[str | None] = mapped_column(String(255), nullable=True)
    linkedin: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # --- Legal / financial ---
    tax_number: Mapped[str | None] = mapped_column(String(60), nullable=True)
    commercial_reg: Mapped[str | None] = mapped_column(String(60), nullable=True)
    credit_limit: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    payment_terms_days: Mapped[int] = mapped_column(Integer, default=0)
    currency: Mapped[str] = mapped_column(String(3), default="EGP")

    # --- Sales ownership & health ---
    owner_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    sales_engineer: Mapped[str | None] = mapped_column(String(255), nullable=True)
    score: Mapped[int] = mapped_column(Integer, default=0)  # 0-100 customer score
    health: Mapped[str | None] = mapped_column(String(20), nullable=True)  # good/at_risk/critical
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    contacts: Mapped[list[Contact]] = relationship(
        back_populates="account", cascade="all, delete-orphan", lazy="selectin"
    )
    activities: Mapped[list[Activity]] = relationship(
        back_populates="account", cascade="all, delete-orphan", lazy="selectin"
    )


class Contact(Base, TimestampMixin):
    __tablename__ = "contacts"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("accounts.id", ondelete="CASCADE")
    )
    name: Mapped[str] = mapped_column(String(255))
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    whatsapp: Mapped[str | None] = mapped_column(String(40), nullable=True)
    position: Mapped[str | None] = mapped_column(String(120), nullable=True)
    department: Mapped[str | None] = mapped_column(String(120), nullable=True)
    is_decision_maker: Mapped[bool] = mapped_column(Boolean, default=False)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    account: Mapped[Account] = relationship(back_populates="contacts")


# Activity types: call / meeting / site_visit / task / note / email
ACTIVITY_TYPES = ("call", "meeting", "site_visit", "task", "note", "email")


class Activity(Base, TimestampMixin):
    """A timeline event logged against a customer: call, meeting, visit, task,
    or note. Tasks can have a due date and a done flag."""

    __tablename__ = "crm_activities"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("accounts.id", ondelete="CASCADE")
    )
    activity_type: Mapped[str] = mapped_column(String(20), default="note")
    subject: Mapped[str] = mapped_column(String(255))
    body: Mapped[str | None] = mapped_column(Text, nullable=True)
    activity_date: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    is_done: Mapped[bool] = mapped_column(Boolean, default=False)
    owner_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    account: Mapped[Account] = relationship(back_populates="activities")


class Opportunity(Base, TimestampMixin):
    __tablename__ = "opportunities"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("accounts.id", ondelete="CASCADE")
    )
    title: Mapped[str] = mapped_column(String(255))
    stage: Mapped[str] = mapped_column(String(20), default="new")
    value: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    probability: Mapped[int] = mapped_column(Integer, default=0)
    expected_close: Mapped[date | None] = mapped_column(Date, nullable=True)
    owner_id: Mapped[uuid.UUID | None] = mapped_column(GUID(), nullable=True)
    # Pipeline analytics: why deals are lost and to whom (Odoo-style CRM)
    loss_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    competitor: Mapped[str | None] = mapped_column(String(255), nullable=True)


class Quotation(Base, TimestampMixin):
    __tablename__ = "quotations"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("accounts.id", ondelete="CASCADE")
    )
    opportunity_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("opportunities.id", ondelete="SET NULL"), nullable=True
    )
    number: Mapped[str] = mapped_column(String(40), index=True)
    status: Mapped[str] = mapped_column(String(20), default="draft")
    valid_until: Mapped[date | None] = mapped_column(Date, nullable=True)

    # --- Commercial header (what a real quotation needs to be sendable) ---
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    currency: Mapped[str] = mapped_column(String(3), default="EGP")
    # Extra discount applied on the whole quotation, after line discounts.
    discount_amount: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(6, 4), default=0)  # 0.14 = 14%
    payment_terms: Mapped[str | None] = mapped_column(String(255), nullable=True)
    delivery_period: Mapped[str | None] = mapped_column(String(255), nullable=True)
    terms: Mapped[str | None] = mapped_column(Text, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    prepared_by: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # --- Money (all computed server-side, never trusted from the client) ---
    gross_total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    line_discount_total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    subtotal: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    tax: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    lines: Mapped[list[QuotationLine]] = relationship(
        back_populates="quotation", cascade="all, delete-orphan", lazy="selectin"
    )


class QuotationLine(Base):
    __tablename__ = "quotation_lines"
    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    quotation_id: Mapped[uuid.UUID] = mapped_column(
        GUID(), ForeignKey("quotations.id", ondelete="CASCADE")
    )
    product_id: Mapped[uuid.UUID | None] = mapped_column(
        GUID(), ForeignKey("crm_products.id", ondelete="SET NULL"), nullable=True
    )
    description: Mapped[str] = mapped_column(String(255))
    unit: Mapped[str | None] = mapped_column(String(40), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(14, 2), default=1)
    unit_price: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    discount_pct: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    line_total: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    quotation: Mapped[Quotation] = relationship(back_populates="lines")


# Units commonly used when quoting industrial work.
PRODUCT_UNITS = ("piece", "hour", "day", "session", "trainee", "meter", "lump_sum", "month")


class Product(Base, TimestampMixin):
    """A reusable service/item in the sales catalogue.

    Quoting from a catalogue instead of free text is what stops two engineers
    pricing the same panel differently, and it is what makes per-service
    revenue analysis possible later.
    """

    __tablename__ = "crm_products"
    __table_args__ = (UniqueConstraint("tenant_id", "code", name="uq_product_code"),)

    id: Mapped[uuid.UUID] = mapped_column(GUID(), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(GUID(), index=True)
    code: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(255))
    name_en: Mapped[str | None] = mapped_column(String(255), nullable=True)
    category: Mapped[str | None] = mapped_column(String(60), nullable=True)
    unit: Mapped[str] = mapped_column(String(40), default="piece")
    unit_price: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default="EGP")
    # Optional internal cost, so margin per service can be reported later.
    unit_cost: Mapped[float] = mapped_column(Numeric(14, 2), default=0)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
