"""CRM business logic with tenant scoping."""
from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.modules.crm import repository as repo
from app.modules.crm.models import (
    Account,
    Activity,
    Contact,
    Opportunity,
    Quotation,
    QuotationLine,
)
from app.modules.crm.schemas import (
    AccountCreate,
    AccountUpdate,
    ActivityCreate,
    ActivityUpdate,
    ContactCreate,
    OpportunityCreate,
    QuotationCreate,
)
from app.shared.exceptions import Conflict, NotFound


def _next_code(db: Session, tenant_id: uuid.UUID) -> str:
    return f"CUST-{repo.account_count(db, tenant_id) + 1:04d}"


def create_account(
    db: Session, tenant_id: uuid.UUID, owner_id: uuid.UUID, body: AccountCreate
) -> Account:
    data = body.model_dump()
    data["type"] = body.type.value
    account = Account(
        tenant_id=tenant_id,
        owner_id=owner_id,
        code=_next_code(db, tenant_id),
        is_active=True,
        **data,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


def list_accounts(
    db: Session,
    tenant_id: uuid.UUID,
    page: int,
    size: int,
    search: str | None = None,
    type_filter: str | None = None,
    classification: str | None = None,
    health: str | None = None,
    sort: str = "newest",
):
    return repo.list_accounts(
        db, tenant_id, size, (page - 1) * size,
        search=search, type_filter=type_filter,
        classification=classification, health=health, sort=sort,
    )


def get_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> Account:
    account = repo.get_account(db, tenant_id, account_id)
    if not account:
        raise NotFound("Account")
    return account


def update_account(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID, body: AccountUpdate
) -> Account:
    account = get_account(db, tenant_id, account_id)
    data = body.model_dump(exclude_unset=True)
    if "type" in data and data["type"] is not None:
        data["type"] = data["type"].value
    for field, value in data.items():
        setattr(account, field, value)
    db.commit()
    db.refresh(account)
    return account


def delete_account(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> None:
    account = get_account(db, tenant_id, account_id)
    if repo.account_has_dependents(db, tenant_id, account_id):
        raise Conflict(
            "Cannot delete an account that has opportunities or quotations. "
            "Remove them first."
        )
    db.delete(account)
    db.commit()


def list_opportunities(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID | None, page: int, size: int
):
    return repo.list_opportunities(db, tenant_id, account_id, size, (page - 1) * size)


def list_quotations(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID | None, page: int, size: int
):
    return repo.list_quotations(db, tenant_id, account_id, size, (page - 1) * size)


def add_contact(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID, body: ContactCreate
) -> Contact:
    if not repo.get_account(db, tenant_id, account_id):
        raise NotFound("Account")
    contact = Contact(
        tenant_id=tenant_id,
        account_id=account_id,
        **body.model_dump(),
    )
    db.add(contact)
    db.commit()
    db.refresh(contact)
    return contact


# --- Activities (customer timeline) ---
def list_contacts(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID):
    account = get_account(db, tenant_id, account_id)
    return account.contacts


def add_activity(
    db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID, owner_id: uuid.UUID,
    body: ActivityCreate,
) -> Activity:
    if not repo.get_account(db, tenant_id, account_id):
        raise NotFound("Account")
    activity = Activity(
        tenant_id=tenant_id,
        account_id=account_id,
        owner_id=owner_id,
        activity_type=body.activity_type,
        subject=body.subject,
        body=body.body,
        activity_date=body.activity_date or datetime.now(UTC),
        due_date=body.due_date,
        is_done=False,
    )
    db.add(activity)
    db.commit()
    db.refresh(activity)
    return activity


def list_activities(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID):
    get_account(db, tenant_id, account_id)
    return repo.list_activities(db, tenant_id, account_id)


def update_activity(
    db: Session, tenant_id: uuid.UUID, activity_id: uuid.UUID, body: ActivityUpdate
) -> Activity:
    activity = repo.get_activity(db, tenant_id, activity_id)
    if not activity:
        raise NotFound("Activity")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(activity, field, value)
    db.commit()
    db.refresh(activity)
    return activity


def delete_activity(db: Session, tenant_id: uuid.UUID, activity_id: uuid.UUID) -> None:
    activity = repo.get_activity(db, tenant_id, activity_id)
    if not activity:
        raise NotFound("Activity")
    db.delete(activity)
    db.commit()


def create_opportunity(
    db: Session, tenant_id: uuid.UUID, owner_id: uuid.UUID, body: OpportunityCreate
) -> Opportunity:
    if not repo.get_account(db, tenant_id, body.account_id):
        raise NotFound("Account")
    opp = Opportunity(
        tenant_id=tenant_id,
        account_id=body.account_id,
        owner_id=owner_id,
        title=body.title,
        stage=body.stage.value,
        value=body.value,
        currency=body.currency,
        probability=body.probability,
        expected_close=body.expected_close,
    )
    db.add(opp)
    db.commit()
    db.refresh(opp)
    return opp


def _compute_quotation_money(lines_in, discount_amount: float, tax_rate: float) -> dict:
    """Single source of truth for quotation arithmetic.

    gross            = sum(qty * unit_price)
    line discounts   = per-line percentage taken off that line
    subtotal         = gross - line discounts - header discount
    tax              = subtotal * tax_rate       (VAT applied AFTER discounts)
    total            = subtotal + tax
    """
    gross = 0.0
    line_disc = 0.0
    built = []
    for ln in lines_in:
        raw = round(ln.qty * ln.unit_price, 2)
        disc = round(raw * (ln.discount_pct or 0) / 100, 2)
        net = round(raw - disc, 2)
        gross += raw
        line_disc += disc
        built.append((ln, net))
    gross = round(gross, 2)
    line_disc = round(line_disc, 2)
    header_disc = round(min(discount_amount or 0, gross - line_disc), 2)
    subtotal = round(gross - line_disc - header_disc, 2)
    tax = round(subtotal * (tax_rate or 0), 2)
    total = round(subtotal + tax, 2)
    return {
        "gross_total": gross,
        "line_discount_total": line_disc,
        "discount_amount": header_disc,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "built_lines": built,
    }


def create_quotation(db: Session, tenant_id: uuid.UUID, body: QuotationCreate) -> Quotation:
    if not repo.get_account(db, tenant_id, body.account_id):
        raise NotFound("Account")
    if body.opportunity_id and not repo.get_opportunity(db, tenant_id, body.opportunity_id):
        raise NotFound("Opportunity")

    money = _compute_quotation_money(body.lines, body.discount_amount, body.tax_rate)
    lines = [
        QuotationLine(
            product_id=ln.product_id,
            description=ln.description,
            unit=ln.unit,
            qty=ln.qty,
            unit_price=ln.unit_price,
            discount_pct=ln.discount_pct or 0,
            line_total=net,
        )
        for ln, net in money["built_lines"]
    ]

    quotation = Quotation(
        tenant_id=tenant_id,
        account_id=body.account_id,
        opportunity_id=body.opportunity_id,
        number=repo.next_quotation_number(db, tenant_id, datetime.now(UTC).year),
        status="draft",
        title=body.title,
        valid_until=body.valid_until,
        currency=body.currency,
        payment_terms=body.payment_terms,
        delivery_period=body.delivery_period,
        terms=body.terms,
        notes=body.notes,
        prepared_by=body.prepared_by,
        tax_rate=body.tax_rate,
        gross_total=money["gross_total"],
        line_discount_total=money["line_discount_total"],
        discount_amount=money["discount_amount"],
        subtotal=money["subtotal"],
        tax=money["tax"],
        total=money["total"],
        lines=lines,
    )
    db.add(quotation)
    db.commit()
    db.refresh(quotation)
    return quotation


def get_quotation(db: Session, tenant_id: uuid.UUID, quotation_id: uuid.UUID) -> Quotation:
    from sqlalchemy import select

    q = db.scalar(
        select(Quotation).where(
            Quotation.id == quotation_id, Quotation.tenant_id == tenant_id
        )
    )
    if not q:
        raise NotFound("Quotation")
    return q


def update_quotation(
    db: Session, tenant_id: uuid.UUID, quotation_id: uuid.UUID, body
) -> Quotation:
    """Edit a quotation. Accepted/rejected quotations are frozen so the numbers
    a customer agreed to can never change silently."""
    q = get_quotation(db, tenant_id, quotation_id)
    if q.status in ("accepted", "rejected"):
        raise Conflict("An accepted or rejected quotation cannot be edited")
    data = body.model_dump(exclude_unset=True)
    for field in (
        "title", "valid_until", "payment_terms", "delivery_period",
        "terms", "notes", "prepared_by",
    ):
        if field in data:
            setattr(q, field, data[field])

    lines_in = data.get("lines")
    recalc = lines_in is not None or "discount_amount" in data or "tax_rate" in data
    if recalc:
        if lines_in is not None:
            from app.modules.crm.schemas import QuotationLineIn

            parsed = [QuotationLineIn(**ln) for ln in lines_in]
            for old_line in list(q.lines):
                db.delete(old_line)
            q.lines = [
                QuotationLine(
                    product_id=ln.product_id, description=ln.description, unit=ln.unit,
                    qty=ln.qty, unit_price=ln.unit_price,
                    discount_pct=ln.discount_pct or 0, line_total=0,
                )
                for ln in parsed
            ]
        else:
            parsed = [
                type("L", (), {
                    "qty": float(ln.qty), "unit_price": float(ln.unit_price),
                    "discount_pct": float(ln.discount_pct or 0),
                })()
                for ln in q.lines
            ]
        discount_amount = data.get("discount_amount", float(q.discount_amount or 0))
        tax_rate = data.get("tax_rate", float(q.tax_rate or 0))
        money = _compute_quotation_money(parsed, discount_amount, tax_rate)
        for line_obj, (_, net) in zip(q.lines, money["built_lines"], strict=False):
            line_obj.line_total = net
        q.tax_rate = tax_rate
        q.gross_total = money["gross_total"]
        q.line_discount_total = money["line_discount_total"]
        q.discount_amount = money["discount_amount"]
        q.subtotal = money["subtotal"]
        q.tax = money["tax"]
        q.total = money["total"]
    db.commit()
    db.refresh(q)
    return q


def quotation_print_data(db: Session, tenant_id: uuid.UUID, quotation_id: uuid.UUID) -> dict:
    """Bundle quotation + customer details for the printable page."""
    q = get_quotation(db, tenant_id, quotation_id)
    account = repo.get_account(db, tenant_id, q.account_id)
    primary = None
    if account:
        primary = next(
            (c for c in account.contacts if c.is_primary),
            account.contacts[0] if account.contacts else None,
        )
    return {
        "quotation": q,
        "account_name": account.name if account else "",
        "account_name_en": account.name_en if account else None,
        "account_address": account.address if account else None,
        "account_phone": account.phone if account else None,
        "account_email": account.email if account else None,
        "account_tax_number": account.tax_number if account else None,
        "contact_name": primary.name if primary else None,
    }


# ==================== Sales catalogue ====================
def list_products(
    db: Session, tenant_id: uuid.UUID, active_only: bool = False, search: str | None = None
):
    from sqlalchemy import func, select

    from app.modules.crm.models import Product

    conds = [Product.tenant_id == tenant_id]
    if active_only:
        conds.append(Product.is_active.is_(True))
    if search:
        like = f"%{search.lower()}%"
        conds.append(
            func.lower(Product.name).like(like) | func.lower(Product.code).like(like)
        )
    return db.scalars(
        select(Product).where(*conds).order_by(Product.category, Product.name)
    ).all()


def create_product(db: Session, tenant_id: uuid.UUID, body):
    from sqlalchemy import func, select

    from app.modules.crm.models import Product

    clash = db.scalar(
        select(Product).where(
            Product.tenant_id == tenant_id,
            func.lower(Product.code) == body.code.lower(),
        )
    )
    if clash:
        raise Conflict(f"Item code '{body.code}' already exists")
    product = Product(tenant_id=tenant_id, is_active=True, **body.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


def update_product(db: Session, tenant_id: uuid.UUID, product_id: uuid.UUID, body):
    from sqlalchemy import func, select

    from app.modules.crm.models import Product

    product = db.scalar(
        select(Product).where(Product.id == product_id, Product.tenant_id == tenant_id)
    )
    if not product:
        raise NotFound("Product")
    data = body.model_dump(exclude_unset=True)
    new_code = data.get("code")
    if new_code and new_code.lower() != product.code.lower():
        clash = db.scalar(
            select(Product).where(
                Product.tenant_id == tenant_id,
                func.lower(Product.code) == new_code.lower(),
                Product.id != product.id,
            )
        )
        if clash:
            raise Conflict(f"Item code '{new_code}' already exists")
    for field, value in data.items():
        setattr(product, field, value)
    db.commit()
    db.refresh(product)
    return product


def delete_product(db: Session, tenant_id: uuid.UUID, product_id: uuid.UUID) -> None:
    from sqlalchemy import select

    from app.modules.crm.models import Product

    product = db.scalar(
        select(Product).where(Product.id == product_id, Product.tenant_id == tenant_id)
    )
    if not product:
        raise NotFound("Product")
    db.delete(product)
    db.commit()


# ==================== Loss analysis ====================
def loss_analysis(db: Session, tenant_id: uuid.UUID) -> dict:
    """Turns the loss_reason / competitor fields into the answer to the most
    important sales question: why are we losing, and to whom?"""
    from sqlalchemy import select

    opps = db.scalars(
        select(Opportunity).where(Opportunity.tenant_id == tenant_id)
    ).all()
    won = [o for o in opps if o.stage == "won"]
    lost = [o for o in opps if o.stage == "lost"]
    open_opps = [o for o in opps if o.stage not in ("won", "lost")]

    won_value = round(sum(float(o.value) for o in won), 2)
    lost_value = round(sum(float(o.value) for o in lost), 2)
    decided = len(won) + len(lost)

    reasons: dict[str, dict] = {}
    for o in lost:
        key = (o.loss_reason or "غير محدد").strip() or "غير محدد"
        row = reasons.setdefault(key, {"count": 0, "value": 0.0})
        row["count"] += 1
        row["value"] += float(o.value)
    by_reason = [
        {
            "reason": k,
            "count": v["count"],
            "value": round(v["value"], 2),
            "pct": round(v["count"] / len(lost) * 100, 1) if lost else 0.0,
        }
        for k, v in sorted(reasons.items(), key=lambda kv: kv[1]["count"], reverse=True)
    ]

    competitors: dict[str, dict] = {}
    for o in lost:
        if not o.competitor:
            continue
        key = o.competitor.strip()
        row = competitors.setdefault(key, {"count": 0, "value": 0.0})
        row["count"] += 1
        row["value"] += float(o.value)
    by_competitor = [
        {"competitor": k, "count": v["count"], "value": round(v["value"], 2)}
        for k, v in sorted(competitors.items(), key=lambda kv: kv[1]["count"], reverse=True)
    ]

    return {
        "won_count": len(won),
        "lost_count": len(lost),
        "open_count": len(open_opps),
        "won_value": won_value,
        "lost_value": lost_value,
        "win_rate_pct": round(len(won) / decided * 100, 1) if decided else 0.0,
        "avg_won_value": round(won_value / len(won), 2) if won else 0.0,
        "avg_lost_value": round(lost_value / len(lost), 2) if lost else 0.0,
        "by_reason": by_reason,
        "by_competitor": by_competitor,
    }


# ==================== Follow-up centre ====================
def follow_ups(db: Session, tenant_id: uuid.UUID, stale_days: int = 14) -> dict:
    """Answers 'who must I contact today?' by combining two signals:
    open tasks/activities with a due date, and open opportunities that have
    gone quiet for too long."""
    from datetime import date as _date
    from datetime import timedelta

    from sqlalchemy import select

    today = _date.today()
    accounts = {
        a.id: a
        for a in db.scalars(select(Account).where(Account.tenant_id == tenant_id)).all()
    }

    def acc_fields(account_id):
        a = accounts.get(account_id)
        return {
            "account_id": account_id,
            "account_name": a.name if a else "",
            "account_phone": a.phone if a else None,
            "account_whatsapp": a.whatsapp if a else None,
        }

    activities = db.scalars(
        select(Activity).where(
            Activity.tenant_id == tenant_id,
            Activity.is_done.is_(False),
            Activity.due_date.is_not(None),
        )
    ).all()

    due_today, overdue, upcoming = [], [], []
    for act in activities:
        item = {
            "kind": "activity",
            "id": act.id,
            "subject": act.subject,
            "due_date": act.due_date,
            "activity_type": act.activity_type,
            "days_overdue": max((today - act.due_date).days, 0),
            **acc_fields(act.account_id),
        }
        if act.due_date == today:
            due_today.append(item)
        elif act.due_date < today:
            overdue.append(item)
        elif act.due_date <= today + timedelta(days=7):
            upcoming.append(item)

    # Opportunities with no activity logged recently on their account.
    cutoff = today - timedelta(days=stale_days)
    last_touch: dict[uuid.UUID, _date] = {}
    for act in db.scalars(
        select(Activity).where(Activity.tenant_id == tenant_id)
    ).all():
        d = act.activity_date.date() if act.activity_date else None
        if d and (act.account_id not in last_touch or last_touch[act.account_id] < d):
            last_touch[act.account_id] = d

    stale = []
    for o in db.scalars(
        select(Opportunity).where(
            Opportunity.tenant_id == tenant_id,
            Opportunity.stage.notin_(("won", "lost")),
        )
    ).all():
        touched = last_touch.get(o.account_id)
        if touched is None or touched <= cutoff:
            stale.append({
                "kind": "stale_opportunity",
                "id": o.id,
                "subject": o.title,
                "due_date": o.expected_close,
                "days_overdue": (today - touched).days if touched else stale_days,
                "value": float(o.value),
                "stage": o.stage,
                **acc_fields(o.account_id),
            })

    overdue.sort(key=lambda x: x["days_overdue"], reverse=True)
    stale.sort(key=lambda x: x["value"], reverse=True)
    return {
        "due_today": due_today,
        "overdue": overdue,
        "upcoming": sorted(upcoming, key=lambda x: x["due_date"]),
        "stale_opportunities": stale,
        "due_today_count": len(due_today),
        "overdue_count": len(overdue),
        "stale_count": len(stale),
    }


def crm_summary(db: Session, tenant_id: uuid.UUID) -> dict:
    """KPI summary for the CRM dashboard: account counts by type, pipeline
    value from open opportunities, and quotation totals."""
    from sqlalchemy import func, select

    accounts = repo.list_accounts(db, tenant_id, 100000, 0)[0]
    by_type: dict[str, int] = {}
    by_classification: dict[str, int] = {}
    for a in accounts:
        by_type[a.type] = by_type.get(a.type, 0) + 1
        if a.classification:
            by_classification[a.classification] = by_classification.get(a.classification, 0) + 1

    # Pipeline: sum of open opportunity values (not won/lost).
    open_pipeline = float(
        db.scalar(
            select(func.coalesce(func.sum(Opportunity.value), 0)).where(
                Opportunity.tenant_id == tenant_id,
                Opportunity.stage.notin_(("won", "lost")),
            )
        )
        or 0
    )
    won_value = float(
        db.scalar(
            select(func.coalesce(func.sum(Opportunity.value), 0)).where(
                Opportunity.tenant_id == tenant_id, Opportunity.stage == "won"
            )
        )
        or 0
    )
    quotation_total = float(
        db.scalar(
            select(func.coalesce(func.sum(Quotation.total), 0)).where(
                Quotation.tenant_id == tenant_id
            )
        )
        or 0
    )
    return {
        "total_accounts": len(accounts),
        "by_type": by_type,
        "by_classification": by_classification,
        "open_pipeline_value": round(open_pipeline, 2),
        "won_value": round(won_value, 2),
        "quotation_total": round(quotation_total, 2),
    }


# --- Pipeline (sales funnel, Odoo-style) ---
_OPEN_STAGES = ("new", "qualified", "proposal", "negotiation")


def update_opportunity(db: Session, tenant_id: uuid.UUID, opp_id: uuid.UUID, body) -> Opportunity:
    from sqlalchemy import select

    opp = db.scalar(
        select(Opportunity).where(
            Opportunity.id == opp_id, Opportunity.tenant_id == tenant_id
        )
    )
    if not opp:
        raise NotFound("Opportunity")
    data = body.model_dump(exclude_unset=True)
    stage = data.get("stage")
    if stage is not None:
        stage = stage.value if hasattr(stage, "value") else stage
        data["stage"] = stage
        # Winning locks probability to 100; losing to 0.
        if stage == "won":
            data.setdefault("probability", 100)
        if stage == "lost":
            data.setdefault("probability", 0)
    for field, value in data.items():
        setattr(opp, field, value)
    db.commit()
    db.refresh(opp)
    return opp


def pipeline(db: Session, tenant_id: uuid.UUID) -> dict:
    """Group open opportunities by stage with totals + weighted forecast."""
    from sqlalchemy import select

    opps = db.scalars(
        select(Opportunity)
        .where(Opportunity.tenant_id == tenant_id)
        .order_by(Opportunity.created_at.desc())
    ).all()
    account_ids = {o.account_id for o in opps}
    names = {}
    if account_ids:
        rows = db.scalars(select(Account).where(Account.id.in_(account_ids))).all()
        names = {a.id: a.name for a in rows}

    def card(o):
        return {
            "id": o.id,
            "title": o.title,
            "account_id": o.account_id,
            "account_name": names.get(o.account_id, ""),
            "value": float(o.value),
            "probability": o.probability,
            "expected_close": o.expected_close,
            "loss_reason": o.loss_reason,
            "competitor": o.competitor,
        }

    stages = []
    open_total = 0.0
    weighted = 0.0
    for st in _OPEN_STAGES:
        items = [o for o in opps if o.stage == st]
        total = sum(float(o.value) for o in items)
        open_total += total
        weighted += sum(float(o.value) * o.probability / 100 for o in items)
        stages.append({
            "stage": st,
            "count": len(items),
            "total_value": round(total, 2),
            "items": [card(o) for o in items],
        })
    won = [o for o in opps if o.stage == "won"]
    lost = [o for o in opps if o.stage == "lost"]
    for st, group in (("won", won), ("lost", lost)):
        stages.append({
            "stage": st,
            "count": len(group),
            "total_value": round(sum(float(o.value) for o in group), 2),
            "items": [card(o) for o in group],
        })
    return {
        "stages": stages,
        "open_total": round(open_total, 2),
        "weighted_forecast": round(weighted, 2),
        "won_total": round(sum(float(o.value) for o in won), 2),
        "lost_total": round(sum(float(o.value) for o in lost), 2),
    }


def account_360(db: Session, tenant_id: uuid.UUID, account_id: uuid.UUID) -> dict:
    """Unified customer view: projects, invoices, quotations, pipeline,
    training and activity across the whole ERP (Odoo-style smart buttons)."""
    from sqlalchemy import func, select

    from app.modules.finance.models import Invoice, Payment
    from app.modules.projects.models import Project
    from app.modules.training.models import Enrollment, Student

    get_account(db, tenant_id, account_id)  # 404 guard

    projects = db.scalars(
        select(Project).where(
            Project.tenant_id == tenant_id, Project.account_id == account_id
        )
    ).all()
    invoices = db.scalars(
        select(Invoice).where(
            Invoice.tenant_id == tenant_id, Invoice.account_id == account_id
        )
    ).all()
    inv_ids = [i.id for i in invoices]
    paid = 0.0
    if inv_ids:
        paid = float(
            db.scalar(
                select(func.coalesce(func.sum(Payment.amount), 0)).where(
                    Payment.invoice_id.in_(inv_ids)
                )
            )
            or 0
        )
    quotes = db.scalars(
        select(Quotation).where(
            Quotation.tenant_id == tenant_id, Quotation.account_id == account_id
        )
    ).all()
    opps = db.scalars(
        select(Opportunity).where(
            Opportunity.tenant_id == tenant_id, Opportunity.account_id == account_id
        )
    ).all()
    open_opps = [o for o in opps if o.stage in _OPEN_STAGES]
    students = db.scalars(
        select(Student).where(
            Student.tenant_id == tenant_id, Student.account_id == account_id
        )
    ).all()
    student_ids = [s_.id for s_ in students]
    fees = 0.0
    if student_ids:
        fees = float(
            db.scalar(
                select(
                    func.coalesce(func.sum(Enrollment.total_fee - Enrollment.discount), 0)
                ).where(
                    Enrollment.student_id.in_(student_ids),
                    Enrollment.status != "withdrawn",
                )
            )
            or 0
        )
    activities = repo.list_activities(db, tenant_id, account_id)
    inv_total = sum(float(i.total) for i in invoices)
    return {
        "account_id": account_id,
        "projects_count": len(projects),
        "projects_value": round(sum(float(p.contract_value) for p in projects), 2),
        "invoices_count": len(invoices),
        "invoices_total": round(inv_total, 2),
        "invoices_paid": round(paid, 2),
        "invoices_balance": round(inv_total - paid, 2),
        "quotations_count": len(quotes),
        "quotations_total": round(sum(float(q.total) for q in quotes), 2),
        "open_opportunities": len(open_opps),
        "open_opportunities_value": round(sum(float(o.value) for o in open_opps), 2),
        "won_value": round(
            sum(float(o.value) for o in opps if o.stage == "won"), 2
        ),
        "students_count": len(students),
        "training_fees": round(fees, 2),
        "activities_count": len(activities),
    }


def export_accounts_csv(db: Session, tenant_id: uuid.UUID) -> dict:
    """Customers list as CSV (Excel-compatible, UTF-8 BOM for Arabic)."""
    import csv
    import io
    from datetime import date as _date

    items, _ = repo.list_accounts(db, tenant_id, 100000, 0)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([
        "Code", "Name", "English Name", "Company", "Type", "Classification",
        "City", "Phone", "Email", "Tax Number", "Credit Limit",
        "Payment Terms (days)", "Sales Engineer", "Score", "Health",
    ])
    for a in items:
        w.writerow([
            a.code or "", a.name, a.name_en or "", a.company_name or "",
            a.type, a.classification or "", a.city or "", a.phone or "",
            a.email or "", a.tax_number or "", float(a.credit_limit),
            a.payment_terms_days, a.sales_engineer or "", a.score, a.health or "",
        ])
    return {
        "filename": f"customers-{_date.today().isoformat()}.csv",
        "content": "\ufeff" + buf.getvalue(),
    }



def win_opportunity(db: Session, tenant_id: uuid.UUID, opp_id: uuid.UUID) -> Opportunity:
    opp = repo.get_opportunity(db, tenant_id, opp_id)
    if not opp:
        raise NotFound("Opportunity")
    opp.stage = "won"
    opp.probability = 100
    db.commit()
    db.refresh(opp)
    return opp


def lose_opportunity(
    db: Session, tenant_id: uuid.UUID, opp_id: uuid.UUID, body
) -> Opportunity:
    opp = repo.get_opportunity(db, tenant_id, opp_id)
    if not opp:
        raise NotFound("Opportunity")
    opp.stage = "lost"
    opp.probability = 0
    opp.loss_reason = body.loss_reason
    opp.competitor = body.competitor
    db.commit()
    db.refresh(opp)
    return opp


def move_opportunity_stage(
    db: Session, tenant_id: uuid.UUID, opp_id: uuid.UUID, stage: str
) -> Opportunity:
    if stage not in _OPEN_STAGES:
        raise Conflict(f"Stage must be one of {_OPEN_STAGES}")
    opp = repo.get_opportunity(db, tenant_id, opp_id)
    if not opp:
        raise NotFound("Opportunity")
    opp.stage = stage
    db.commit()
    db.refresh(opp)
    return opp




_QUOTATION_STATUSES = ("draft", "sent", "accepted", "rejected")


def set_quotation_status(
    db: Session, tenant_id: uuid.UUID, quotation_id: uuid.UUID, status: str
) -> Quotation:
    if status not in _QUOTATION_STATUSES:
        raise Conflict(f"Status must be one of {_QUOTATION_STATUSES}")
    quotation = repo.get_quotation(db, tenant_id, quotation_id)
    if not quotation:
        raise NotFound("Quotation")
    quotation.status = status
    db.commit()
    db.refresh(quotation)
    return quotation


def import_accounts_csv(
    db: Session, tenant_id: uuid.UUID, owner_id: uuid.UUID, content: str
) -> dict:
    """Bulk-create customers from CSV. Accepts the same columns the export
    produces (English headers) plus common Arabic aliases. Rows without a
    name are reported as errors; existing names are created anyway (names
    are not unique) so re-imports should be reviewed by the user."""
    from app.shared.csv_io import parse_csv_rows, pick, to_float, to_int

    rows = parse_csv_rows(content)
    created, errors = 0, []
    for idx, row in enumerate(rows, start=2):  # header = row 1
        name = pick(row, "name", "الاسم", "اسم العميل", "customer name")
        if not name:
            errors.append({"row": idx, "reason": "missing name"})
            continue
        type_ = pick(row, "type", "النوع") or "lead"
        if type_ not in ("lead", "customer", "supplier"):
            type_ = "lead"
        account = Account(
            tenant_id=tenant_id,
            owner_id=owner_id,
            code=_next_code(db, tenant_id),
            name=name,
            name_en=pick(row, "english name", "name_en") or None,
            company_name=pick(row, "company", "الشركة", "company name") or None,
            type=type_,
            classification=pick(row, "classification", "التصنيف") or None,
            industry=pick(row, "industry", "الصناعة") or None,
            city=pick(row, "city", "المدينة") or None,
            phone=pick(row, "phone", "الهاتف") or None,
            email=pick(row, "email", "البريد") or None,
            tax_number=pick(row, "tax number", "الرقم الضريبي") or None,
            credit_limit=to_float(pick(row, "credit limit", "الحد الائتماني")),
            payment_terms_days=to_int(pick(row, "payment terms (days)", "مدة السداد")),
            sales_engineer=pick(row, "sales engineer", "مهندس المبيعات") or None,
            score=min(max(to_int(pick(row, "score", "التقييم")), 0), 100),
            is_active=True,
        )
        db.add(account)
        db.flush()
        created += 1
    db.commit()
    return {"created": created, "skipped": 0, "errors": errors}
