"""CRM HTTP endpoints. Each write is guarded by an RBAC permission."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.rbac import require_permission
from app.modules.crm import service
from app.modules.crm.schemas import (
    Account360,
    AccountCreate,
    AccountOut,
    AccountsExport,
    AccountUpdate,
    ActivityCreate,
    ActivityOut,
    ActivityUpdate,
    ContactCreate,
    ContactOut,
    CrmSummary,
    FollowUpBoard,
    LoseOpportunityBody,
    LossAnalysis,
    OpportunityCreate,
    OpportunityOut,
    OpportunityUpdate,
    PipelineOut,
    ProductCreate,
    ProductOut,
    ProductUpdate,
    QuotationCreate,
    QuotationOut,
    QuotationPrint,
    QuotationUpdate,
)
from app.modules.identity.models import User
from app.shared.csv_io import CsvImportBody
from app.shared.pagination import Page

router = APIRouter(prefix="/crm", tags=["crm"])


@router.post("/accounts", response_model=AccountOut, status_code=201)
def create_account(
    body: AccountCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    return service.create_account(db, user.tenant_id, user.id, body)


@router.get("/accounts", response_model=Page[AccountOut])
def list_accounts(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    type: str | None = Query(None),
    classification: str | None = Query(None),
    health: str | None = Query(None),
    sort: str = Query("newest"),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    items, total = service.list_accounts(
        db, user.tenant_id, page, size,
        search=search, type_filter=type, classification=classification,
        health=health, sort=sort,
    )
    return Page(items=items, total=total, page=page, size=size)


@router.get("/pipeline", response_model=PipelineOut)
def get_pipeline(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.view")),
):
    return service.pipeline(db, user.tenant_id)


@router.get("/accounts-export", response_model=AccountsExport)
def accounts_export(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.export_accounts_csv(db, user.tenant_id)


@router.get("/summary", response_model=CrmSummary)
def crm_summary(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.crm_summary(db, user.tenant_id)


@router.get("/accounts/{account_id}", response_model=AccountOut)
def get_account(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.get_account(db, user.tenant_id, account_id)


@router.patch("/accounts/{account_id}", response_model=AccountOut)
def update_account(
    account_id: uuid.UUID,
    body: AccountUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    return service.update_account(db, user.tenant_id, account_id, body)


@router.delete("/accounts/{account_id}", status_code=204)
def delete_account(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.delete")),
):
    service.delete_account(db, user.tenant_id, account_id)


@router.post("/accounts/{account_id}/contacts", response_model=ContactOut, status_code=201)
def add_contact(
    account_id: uuid.UUID,
    body: ContactCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.contact.create")),
):
    return service.add_contact(db, user.tenant_id, account_id, body)


@router.get("/accounts/{account_id}/contacts", response_model=list[ContactOut])
def list_contacts(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.list_contacts(db, user.tenant_id, account_id)


# --- Activities (customer timeline) ---
@router.post("/accounts/{account_id}/activities", response_model=ActivityOut, status_code=201)
def add_activity(
    account_id: uuid.UUID,
    body: ActivityCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    return service.add_activity(db, user.tenant_id, account_id, user.id, body)


@router.get("/accounts/{account_id}/activities", response_model=list[ActivityOut])
def list_activities(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.list_activities(db, user.tenant_id, account_id)


@router.patch("/activities/{activity_id}", response_model=ActivityOut)
def update_activity(
    activity_id: uuid.UUID,
    body: ActivityUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    return service.update_activity(db, user.tenant_id, activity_id, body)


@router.delete("/activities/{activity_id}", status_code=204)
def delete_activity(
    activity_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    service.delete_activity(db, user.tenant_id, activity_id)


@router.post("/opportunities", response_model=OpportunityOut, status_code=201)
def create_opportunity(
    body: OpportunityCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.create")),
):
    return service.create_opportunity(db, user.tenant_id, user.id, body)


@router.get("/opportunities", response_model=Page[OpportunityOut])
def list_opportunities(
    account_id: uuid.UUID | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.view")),
):
    items, total = service.list_opportunities(db, user.tenant_id, account_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.post("/quotations", response_model=QuotationOut, status_code=201)
def create_quotation(
    body: QuotationCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.create")),
):
    return service.create_quotation(db, user.tenant_id, body)


@router.get("/quotations", response_model=Page[QuotationOut])
def list_quotations(
    account_id: uuid.UUID | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.view")),
):
    items, total = service.list_quotations(db, user.tenant_id, account_id, page, size)
    return Page(items=items, total=total, page=page, size=size)


@router.patch("/opportunities/{opportunity_id}", response_model=OpportunityOut)
def update_opportunity(
    opportunity_id: uuid.UUID,
    body: OpportunityUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.create")),
):
    return service.update_opportunity(db, user.tenant_id, opportunity_id, body)


@router.get("/accounts/{account_id}/summary360", response_model=Account360)
def account_360(
    account_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.account_360(db, user.tenant_id, account_id)



@router.post("/opportunities/{opportunity_id}/win", response_model=OpportunityOut)
def win_opportunity(
    opportunity_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.create")),
):
    return service.win_opportunity(db, user.tenant_id, opportunity_id)


@router.post("/opportunities/{opportunity_id}/lose", response_model=OpportunityOut)
def lose_opportunity(
    opportunity_id: uuid.UUID,
    body: LoseOpportunityBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.create")),
):
    return service.lose_opportunity(db, user.tenant_id, opportunity_id, body)


@router.post("/opportunities/{opportunity_id}/move/{stage}", response_model=OpportunityOut)
def move_opportunity(
    opportunity_id: uuid.UUID,
    stage: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.create")),
):
    return service.move_opportunity_stage(db, user.tenant_id, opportunity_id, stage)




@router.patch("/quotations/{quotation_id}/status/{status}", response_model=QuotationOut)
def set_quotation_status(
    quotation_id: uuid.UUID,
    status: str,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.create")),
):
    return service.set_quotation_status(db, user.tenant_id, quotation_id, status)


@router.post("/accounts-import", response_model=None)
def import_accounts(
    body: CsvImportBody,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.create")),
):
    return service.import_accounts_csv(db, user.tenant_id, user.id, body.content)


# ==================== Sales catalogue (products / services) ====================
@router.get("/products", response_model=list[ProductOut])
def list_products(
    active_only: bool = Query(False),
    search: str | None = Query(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.list_products(db, user.tenant_id, active_only=active_only, search=search)


@router.post("/products", response_model=ProductOut, status_code=201)
def create_product(
    body: ProductCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.product.manage")),
):
    return service.create_product(db, user.tenant_id, body)


@router.patch("/products/{product_id}", response_model=ProductOut)
def update_product(
    product_id: uuid.UUID,
    body: ProductUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.product.manage")),
):
    return service.update_product(db, user.tenant_id, product_id, body)


@router.delete("/products/{product_id}", status_code=204)
def delete_product(
    product_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.product.manage")),
):
    service.delete_product(db, user.tenant_id, product_id)


# ==================== Quotation detail / edit / print ====================
@router.get("/quotations/{quotation_id}", response_model=QuotationOut)
def get_quotation(
    quotation_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.view")),
):
    return service.get_quotation(db, user.tenant_id, quotation_id)


@router.patch("/quotations/{quotation_id}", response_model=QuotationOut)
def update_quotation(
    quotation_id: uuid.UUID,
    body: QuotationUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.create")),
):
    return service.update_quotation(db, user.tenant_id, quotation_id, body)


@router.get("/quotations/{quotation_id}/print", response_model=QuotationPrint)
def quotation_print(
    quotation_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.quotation.view")),
):
    return service.quotation_print_data(db, user.tenant_id, quotation_id)


# ==================== Sales analytics ====================
@router.get("/reports/loss-analysis", response_model=LossAnalysis)
def loss_analysis(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.opportunity.view")),
):
    return service.loss_analysis(db, user.tenant_id)


@router.get("/follow-ups", response_model=FollowUpBoard)
def follow_ups(
    stale_days: int = Query(14, ge=1, le=180),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("crm.account.view")),
):
    return service.follow_ups(db, user.tenant_id, stale_days=stale_days)
