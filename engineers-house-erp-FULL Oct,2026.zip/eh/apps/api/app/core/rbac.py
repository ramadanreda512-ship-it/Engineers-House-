"""Role-based access control dependency."""
from __future__ import annotations

from fastapi import Depends, HTTPException, status

from app.core.deps import get_current_user
from app.modules.identity.models import User


def user_permission_codes(user: User) -> set[str]:
    if user.is_superadmin:
        return {"*"}
    return {perm.code for role in user.roles for perm in role.permissions}


def require_permission(code: str):
    """Dependency factory enforcing a single permission code."""

    def checker(user: User = Depends(get_current_user)) -> User:
        codes = user_permission_codes(user)
        if "*" in codes or code in codes:
            return user
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail=f"Missing permission: {code}"
        )

    return checker
