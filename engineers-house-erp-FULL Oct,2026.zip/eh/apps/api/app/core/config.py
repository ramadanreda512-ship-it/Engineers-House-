"""Application settings loaded from environment / .env."""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Engineers House ERP API"
    environment: str = "development"

    database_url: str = "sqlite:///./eh_erp.db"
    redis_url: str = "redis://localhost:6379/0"

    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 7

    cors_origins: list[str] = ["http://localhost:3000"]

    default_tenant_name: str = "Engineers House for Industrial Solutions"
    default_tenant_slug: str = "engineers-house"
    superadmin_email: str = "admin@engineershouse.com"
    superadmin_password: str = "ChangeMe!2026"

    # Dev convenience: create tables on startup. Production uses Alembic.
    auto_create_tables: bool = True
    # TEMPORARY test convenience: when true, /auth/dev-login issues a valid
    # token for the superadmin without checking any password. Meant only for
    # local troubleshooting; remove/disable once normal login is confirmed.
    dev_login_enabled: bool = False
    # Re-seeding normally leaves existing passwords untouched. Set to true only
    # to deliberately restore the documented default passwords (e.g. locked out).
    seed_reset_passwords: bool = False
    # Self-service sign-up. Off by default: staff accounts are created by the
    # manager from Settings -> Users. Never enable on an internet server.
    public_registration_enabled: bool = False
    # Brute-force protection for the login endpoint.
    login_max_failures: int = 5
    login_lockout_minutes: int = 15
    # AI Financial Analyst (optional). If anthropic_api_key is set, the analyst
    # endpoint calls Claude; otherwise it returns the financial snapshot only.
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"


@lru_cache
def get_settings() -> Settings:
    return Settings()


WEAK_SECRETS = {
    "change-me-in-production",
    "engineers-house-secret-key-2026-secure-change-me",
}


def validate_production(settings: Settings) -> None:
    """Refuse to start an internet-facing server with unsafe settings."""
    if settings.environment != "production":
        return
    problems = []
    if settings.jwt_secret in WEAK_SECRETS or len(settings.jwt_secret) < 32:
        problems.append("JWT_SECRET is a default or shorter than 32 characters")
    if settings.dev_login_enabled:
        problems.append("DEV_LOGIN_ENABLED must be false in production")
    if settings.public_registration_enabled:
        problems.append("PUBLIC_REGISTRATION_ENABLED must be false in production")
    if problems:
        raise RuntimeError("Unsafe production configuration: " + "; ".join(problems))
