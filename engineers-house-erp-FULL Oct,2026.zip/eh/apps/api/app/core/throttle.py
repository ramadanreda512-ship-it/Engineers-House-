"""In-memory login throttling (brute-force protection).

Counts failed logins per account e-mail. After ``login_max_failures`` failures
inside the lockout window the account is locked for ``login_lockout_minutes``.
A successful login clears the counter. In-memory is enough for a single-server
deployment of this size; it resets when the API restarts.
"""
from __future__ import annotations

import threading
import time

from fastapi import HTTPException

from app.core.config import get_settings

_lock = threading.Lock()
_failures: dict[str, list[float]] = {}


def _key(email: str) -> str:
    return (email or "").strip().lower()


def _recent(key: str, now: float, window: float) -> list[float]:
    stamps = [t for t in _failures.get(key, []) if now - t < window]
    _failures[key] = stamps
    return stamps


def check_allowed(email: str) -> None:
    s = get_settings()
    window = s.login_lockout_minutes * 60
    now = time.time()
    with _lock:
        stamps = _recent(_key(email), now, window)
        if len(stamps) >= s.login_max_failures:
            wait = int((window - (now - stamps[0])) // 60) + 1
            raise HTTPException(
                status_code=429,
                detail=(
                    f"Too many failed login attempts. Try again in {wait} minutes. "
                    f"تم إيقاف الدخول مؤقتًا بسبب محاولات خاطئة متكررة. حاول بعد {wait} دقيقة."
                ),
            )


def record_failure(email: str) -> None:
    with _lock:
        _failures.setdefault(_key(email), []).append(time.time())


def record_success(email: str) -> None:
    with _lock:
        _failures.pop(_key(email), None)


def reset_all() -> None:
    """Used by tests."""
    with _lock:
        _failures.clear()
