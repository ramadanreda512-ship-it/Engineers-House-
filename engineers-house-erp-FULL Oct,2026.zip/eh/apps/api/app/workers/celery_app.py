"""Celery application for background jobs (reminders, notifications, PDFs).

Not imported by the API process. Start a worker with:
    celery -A app.workers.celery_app.celery worker --loglevel=info

And, for the periodic reminder scan, a beat scheduler:
    celery -A app.workers.celery_app.celery beat --loglevel=info

The heavy lifting lives in the training service layer (fully unit-testable
without a broker); these tasks are thin wrappers that open a DB session and
delegate.
"""
from __future__ import annotations

from celery import Celery
from celery.schedules import crontab

from app.core.config import get_settings
from app.core.database import SessionLocal
from app.modules.training import service as training_service

settings = get_settings()

celery = Celery("eh_erp", broker=settings.redis_url, backend=settings.redis_url)

celery.conf.beat_schedule = {
    "installment-reminders-daily": {
        "task": "app.workers.celery_app.scan_installment_reminders",
        # Every day at 08:00 server time.
        "schedule": crontab(hour=8, minute=0),
    }
}


@celery.task(name="app.workers.celery_app.scan_installment_reminders")
def scan_installment_reminders(reminder_window_days: int = 3) -> dict:
    """Daily scan: mark overdue installments and collect ones due soon so a
    notification step (email/SMS/WhatsApp) can act on them."""
    db = SessionLocal()
    try:
        summary = training_service.process_installment_reminders(db, reminder_window_days)
        # A real deployment would now enqueue per-installment notifications
        # here using summary["due_soon_ids"]; left as the integration point.
        return summary
    finally:
        db.close()
