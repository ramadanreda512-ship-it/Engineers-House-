"""FastAPI application entrypoint (modular monolith)."""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings

settings = get_settings()


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Dev convenience only. Production schema is managed by Alembic migrations.
    if settings.auto_create_tables:
        import app.modules.accounting.models  # noqa: F401
        import app.modules.cmms.models  # noqa: F401
        import app.modules.crm.models  # noqa: F401
        import app.modules.finance.models  # noqa: F401
        import app.modules.fixedassets.models  # noqa: F401
        import app.modules.governance.models  # noqa: F401
        import app.modules.hr.models  # noqa: F401
        import app.modules.identity.models  # noqa: F401
        import app.modules.inventory.models  # noqa: F401
        import app.modules.partners.models  # noqa: F401
        import app.modules.projects.models  # noqa: F401
        import app.modules.tendering.models  # noqa: F401
        import app.modules.training.models  # noqa: F401
        from app.core.database import engine
        from app.shared.base_model import Base

        Base.metadata.create_all(bind=engine)
    yield


from app.core.config import validate_production  # noqa: E402

validate_production(settings)
_is_prod = settings.environment == "production"
app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    lifespan=lifespan,
    # The interactive API docs list every endpoint; keep them off the internet.
    docs_url=None if _is_prod else "/docs",
    redoc_url=None if _is_prod else "/redoc",
    openapi_url=None if _is_prod else "/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    return {"status": "ok", "environment": settings.environment}


from app.modules.accounting.router import router as accounting_router  # noqa: E402
from app.modules.analyst.router import router as analyst_router  # noqa: E402
from app.modules.backup.router import router as backup_router  # noqa: E402
from app.modules.cmms.router import router as cmms_router  # noqa: E402
from app.modules.crm.router import router as crm_router  # noqa: E402
from app.modules.finance.router import router as finance_router  # noqa: E402
from app.modules.fixedassets.router import router as fixedassets_router  # noqa: E402
from app.modules.governance.router import router as governance_router  # noqa: E402
from app.modules.help.router import router as help_router  # noqa: E402
from app.modules.hr.router import router as hr_router  # noqa: E402
from app.modules.identity.router import router as identity_router  # noqa: E402
from app.modules.inventory.router import router as inventory_router  # noqa: E402
from app.modules.partners.router import router as partners_router  # noqa: E402
from app.modules.projects.router import router as projects_router  # noqa: E402
from app.modules.settings.router import router as settings_router  # noqa: E402
from app.modules.tendering.router import router as tendering_router  # noqa: E402
from app.modules.training.router import router as training_router  # noqa: E402

app.include_router(identity_router, prefix="/api/v1")
app.include_router(crm_router, prefix="/api/v1")
app.include_router(training_router, prefix="/api/v1")
app.include_router(projects_router, prefix="/api/v1")
app.include_router(finance_router, prefix="/api/v1")
app.include_router(cmms_router, prefix="/api/v1")
app.include_router(inventory_router, prefix="/api/v1")
app.include_router(hr_router, prefix="/api/v1")
app.include_router(tendering_router, prefix="/api/v1")
app.include_router(accounting_router, prefix="/api/v1")
app.include_router(partners_router, prefix="/api/v1")
app.include_router(fixedassets_router, prefix="/api/v1")
app.include_router(analyst_router, prefix="/api/v1")
app.include_router(governance_router, prefix="/api/v1")
app.include_router(settings_router, prefix="/api/v1")
app.include_router(backup_router, prefix="/api/v1")
app.include_router(help_router, prefix="/api/v1")
