REM Engineers House ERP - start everything
@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   Engineers House ERP
echo ============================================
echo Opening two windows: API (backend) and Web (frontend).
echo The first run installs packages, so please be patient.
echo.
start "EH ERP - API" cmd /k "%~dp0run-api.bat"
timeout /t 3 >nul
start "EH ERP - Web" cmd /k "%~dp0run-web.bat"
echo.
echo When the Web window says "Ready", open your browser at:
echo     http://localhost:3000
echo.
pause
