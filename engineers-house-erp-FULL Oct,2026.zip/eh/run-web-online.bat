REM Engineers House ERP - Web in ONLINE (production) mode
@echo off
chcp 65001 >nul
cd /d "%~dp0apps\web"
set "PATH=D:\Programs;%PATH%"
if not exist ".env.local" copy ".env.local.example" ".env.local" >nul
if not exist "node_modules" call npm install
echo Building the optimized version, this takes 1-3 minutes...
call npm run build
if errorlevel 1 (
  echo BUILD FAILED - send a photo of this window to Claude.
  pause
  exit /b 1
)
echo Starting Web (production) on http://localhost:3000 ...
call npx next start -H 127.0.0.1 -p 3000
pause
